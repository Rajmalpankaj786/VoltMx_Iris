define("RefCommonsMA/userflxSegRowRecordController", {
    //Type your controller code here 
});
define("RefCommonsMA/flxSegRowRecordControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefCommonsMA/flxSegRowRecordController", ["RefCommonsMA/userflxSegRowRecordController", "RefCommonsMA/flxSegRowRecordControllerActions"], function() {
    var controller = require("RefCommonsMA/userflxSegRowRecordController");
    var controllerActions = ["RefCommonsMA/flxSegRowRecordControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
