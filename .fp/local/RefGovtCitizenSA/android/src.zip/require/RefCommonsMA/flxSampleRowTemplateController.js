define("RefCommonsMA/userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("RefCommonsMA/flxSampleRowTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefCommonsMA/flxSampleRowTemplateController", ["RefCommonsMA/userflxSampleRowTemplateController", "RefCommonsMA/flxSampleRowTemplateControllerActions"], function() {
    var controller = require("RefCommonsMA/userflxSampleRowTemplateController");
    var controllerActions = ["RefCommonsMA/flxSampleRowTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
