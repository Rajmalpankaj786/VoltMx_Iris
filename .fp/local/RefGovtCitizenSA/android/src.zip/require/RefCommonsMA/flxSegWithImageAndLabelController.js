define("RefCommonsMA/userflxSegWithImageAndLabelController", {
    //Type your controller code here 
});
define("RefCommonsMA/flxSegWithImageAndLabelControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefCommonsMA/flxSegWithImageAndLabelController", ["RefCommonsMA/userflxSegWithImageAndLabelController", "RefCommonsMA/flxSegWithImageAndLabelControllerActions"], function() {
    var controller = require("RefCommonsMA/userflxSegWithImageAndLabelController");
    var controllerActions = ["RefCommonsMA/flxSegWithImageAndLabelControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
