define("RefCommonsMA/userflxSegCategoriesController", {
    //Type your controller code here 
});
define("RefCommonsMA/flxSegCategoriesControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefCommonsMA/flxSegCategoriesController", ["RefCommonsMA/userflxSegCategoriesController", "RefCommonsMA/flxSegCategoriesControllerActions"], function() {
    var controller = require("RefCommonsMA/userflxSegCategoriesController");
    var controllerActions = ["RefCommonsMA/flxSegCategoriesControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
