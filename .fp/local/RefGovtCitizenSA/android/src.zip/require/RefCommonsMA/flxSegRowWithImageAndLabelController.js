define("RefCommonsMA/userflxSegRowWithImageAndLabelController", {
    //Type your controller code here 
});
define("RefCommonsMA/flxSegRowWithImageAndLabelControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefCommonsMA/flxSegRowWithImageAndLabelController", ["RefCommonsMA/userflxSegRowWithImageAndLabelController", "RefCommonsMA/flxSegRowWithImageAndLabelControllerActions"], function() {
    var controller = require("RefCommonsMA/userflxSegRowWithImageAndLabelController");
    var controllerActions = ["RefCommonsMA/flxSegRowWithImageAndLabelControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
