define("RefCommonsMA/userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("RefCommonsMA/flxSectionHeaderTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefCommonsMA/flxSectionHeaderTemplateController", ["RefCommonsMA/userflxSectionHeaderTemplateController", "RefCommonsMA/flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("RefCommonsMA/userflxSectionHeaderTemplateController");
    var controllerActions = ["RefCommonsMA/flxSectionHeaderTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
