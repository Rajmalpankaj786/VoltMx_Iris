define(function() {
    return {
        "properties": [{
            "name": "lblTitleText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "lblCapturePhotoText",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "createComplaintOrRequest",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "complaintOrRequestObject",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": []
    }
});