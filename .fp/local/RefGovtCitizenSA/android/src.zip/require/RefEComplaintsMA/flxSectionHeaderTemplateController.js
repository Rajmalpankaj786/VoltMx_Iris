define("RefEComplaintsMA/userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("RefEComplaintsMA/flxSectionHeaderTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefEComplaintsMA/flxSectionHeaderTemplateController", ["RefEComplaintsMA/userflxSectionHeaderTemplateController", "RefEComplaintsMA/flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("RefEComplaintsMA/userflxSectionHeaderTemplateController");
    var controllerActions = ["RefEComplaintsMA/flxSectionHeaderTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
