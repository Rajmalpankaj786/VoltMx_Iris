define("RefEComplaintsMA/userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("RefEComplaintsMA/flxSampleRowTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefEComplaintsMA/flxSampleRowTemplateController", ["RefEComplaintsMA/userflxSampleRowTemplateController", "RefEComplaintsMA/flxSampleRowTemplateControllerActions"], function() {
    var controller = require("RefEComplaintsMA/userflxSampleRowTemplateController");
    var controllerActions = ["RefEComplaintsMA/flxSampleRowTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
