define("RefEComplaintsMA/navigation/NavigationModel", { 
    "Application": {},
    "Forms" : {},
    "UIModules" : {}
});