define("RefERequestsMA/userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("RefERequestsMA/flxSectionHeaderTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefERequestsMA/flxSectionHeaderTemplateController", ["RefERequestsMA/userflxSectionHeaderTemplateController", "RefERequestsMA/flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("RefERequestsMA/userflxSectionHeaderTemplateController");
    var controllerActions = ["RefERequestsMA/flxSectionHeaderTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
