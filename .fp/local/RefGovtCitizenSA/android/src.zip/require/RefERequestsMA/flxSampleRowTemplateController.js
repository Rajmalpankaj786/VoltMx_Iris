define("RefERequestsMA/userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("RefERequestsMA/flxSampleRowTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefERequestsMA/flxSampleRowTemplateController", ["RefERequestsMA/userflxSampleRowTemplateController", "RefERequestsMA/flxSampleRowTemplateControllerActions"], function() {
    var controller = require("RefERequestsMA/userflxSampleRowTemplateController");
    var controllerActions = ["RefERequestsMA/flxSampleRowTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
