define("RefGovtCitizenSA/userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("RefGovtCitizenSA/flxSampleRowTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefGovtCitizenSA/flxSampleRowTemplateController", ["RefGovtCitizenSA/userflxSampleRowTemplateController", "RefGovtCitizenSA/flxSampleRowTemplateControllerActions"], function() {
    var controller = require("RefGovtCitizenSA/userflxSampleRowTemplateController");
    var controllerActions = ["RefGovtCitizenSA/flxSampleRowTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
