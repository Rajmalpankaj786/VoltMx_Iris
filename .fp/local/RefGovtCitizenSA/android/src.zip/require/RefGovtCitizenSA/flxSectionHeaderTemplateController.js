define("RefGovtCitizenSA/userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("RefGovtCitizenSA/flxSectionHeaderTemplateControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefGovtCitizenSA/flxSectionHeaderTemplateController", ["RefGovtCitizenSA/userflxSectionHeaderTemplateController", "RefGovtCitizenSA/flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("RefGovtCitizenSA/userflxSectionHeaderTemplateController");
    var controllerActions = ["RefGovtCitizenSA/flxSectionHeaderTemplateControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
