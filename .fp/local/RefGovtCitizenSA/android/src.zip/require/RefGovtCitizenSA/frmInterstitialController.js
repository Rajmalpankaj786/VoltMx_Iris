define("RefGovtCitizenSA/userfrmInterstitialController", {
    //Type your controller code here 
});
define("RefGovtCitizenSA/frmInterstitialControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("RefGovtCitizenSA/frmInterstitialController", ["RefGovtCitizenSA/userfrmInterstitialController", "RefGovtCitizenSA/frmInterstitialControllerActions"], function() {
    var controller = require("RefGovtCitizenSA/userfrmInterstitialController");
    var controllerActions = ["RefGovtCitizenSA/frmInterstitialControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
