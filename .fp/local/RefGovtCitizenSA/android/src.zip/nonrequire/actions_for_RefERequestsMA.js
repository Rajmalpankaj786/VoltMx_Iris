//actions.js file of the project: RefERequestsMA
