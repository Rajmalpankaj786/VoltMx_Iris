//actions.js file of the project: RefCommonsMA
