//actions.js file of the project: RefGovtCitizenSA
