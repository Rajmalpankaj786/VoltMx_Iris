 /*
  * voltmx-sdk-ide Version 9.5.7
  */
 /**
  * Volt MX namespace
  * @namespace voltmx
  */
 if (typeof(voltmx) === "undefined") {
     voltmx = {};
 }
 /**
  * Constructor for creating the Volt MX client instance.
  * @class
  * @classdesc voltmx Class
  * @memberof voltmx
  */
 voltmx.sdk = function() {
     var currentObj = this;
     this.mainRef = {};
     var clientParams = {};
     this.tokens = {};
     this.currentClaimToken = null;
     this.globalRequestParams = {
         "headers": {},
         "queryparams": {},
         "bodyparams": {}
     };
     var userId = "";
     var integrityCustomSecurityKey = null;
     this.reportingheaders_allowed = false;
     if (voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE && typeof(voltmx.setUserID) === 'function') {
         var userIDflagGet = voltmx.ds.read("userIDFromLicenseFlag");
         if (voltmx.sdk.isNullOrUndefined(userIDflagGet)) {
             var userIDflagSet = [];
             userIDflagSet.push("false");
             voltmx.ds.save(userIDflagSet, "userIDFromLicenseFlag");
         }
     }
     if (voltmx.internal && voltmx.internal.sdk && voltmx.internal.sdk.Services) {
         this.internalSdkObject = new voltmx.internal.sdk.Services();
     }
     this.getUserId = function() {
         return userId;
     };
     this.setCurrentUserId = function(newUserID) {
         userId = newUserID;
     };
     this.getSessionId = function() {
         if (!voltmxRef.sessionId) {
             var sessionId = voltmx.ds.read(voltmx.sdk.constants.KONYUUID);
             if (sessionId) {
                 voltmxRef.sessionId = sessionId[0];
             } else {
                 voltmx.sdk.logsdk.error("Session id is not available");
                 voltmxRef.sessionId = "";
             }
         }
         return voltmxRef.sessionId;
     };
     this.setSessionId = function(newSessionId) {
         voltmxRef.sessionId = newSessionId;
     };
     this.setClientParams = function(clientParamsMap) {
         clientParams = clientParamsMap;
     };
     this.getClientParams = function() {
         return clientParams;
     };
     this.globalRequestParamType = {
         headers: "headers",
         queryParams: "queryparams",
         bodyParams: "bodyparams"
     };
     this.getGlobalRequestParams = function(paramType) {
         voltmx.sdk.logsdk.trace("Entering getGlobalRequestParams");
         if (voltmx.sdk.isNullOrUndefined(paramType)) {
             return currentObj.globalRequestParams;
         } else if (paramType === currentObj.globalRequestParamType.headers) {
             return currentObj.globalRequestParams.headers;
         } else if (paramType === currentObj.globalRequestParamType.queryParams) {
             return currentObj.globalRequestParams.queryparams;
         } else if (paramType === currentObj.globalRequestParamType.bodyParams) {
             return currentObj.globalRequestParams.bodyparams;
         }
     };
     this.setGlobalRequestParam = function(paramName, paramValue, paramType) {
         voltmx.sdk.logsdk.trace("Entering setGlobalRequestParam");
         if (typeof(paramName) === 'string' && typeof(paramValue) === 'string' && typeof(paramType) === 'string') {
             if (paramType === currentObj.globalRequestParamType.headers) {
                 currentObj.globalRequestParams.headers[paramName] = paramValue;
             } else if (paramType === currentObj.globalRequestParamType.queryParams) {
                 currentObj.globalRequestParams.queryparams[paramName] = paramValue;
             } else if (paramType === currentObj.globalRequestParamType.bodyParams) {
                 currentObj.globalRequestParams.bodyparams[paramName] = paramValue;
             }
             if (!(voltmx.sdk.getAType() === voltmx.sdk.constants.SDK_ATYPE_SPA || voltmx.sdk.getAType() === "watch")) {
                 //invoke NFI only for android,ios and FFI for windows and logger
                 voltmx.sdk.sdkCommons.setGlobalRequestParam(paramName, paramValue, paramType);
                 voltmx.logger.setGlobalRequestParam(paramName, paramValue, paramType);
             }
         }
     };
     this.removeGlobalRequestParam = function(paramName, paramType) {
         voltmx.sdk.logsdk.trace("Entering removeGlobalRequestParam");
         if (typeof(paramName) === 'string' && typeof(paramType) === 'string') {
             if (paramType === currentObj.globalRequestParamType.headers && !voltmx.sdk.isNullOrUndefined(currentObj.globalRequestParams.headers[paramName])) {
                 delete currentObj.globalRequestParams.headers[paramName];
             } else if (paramType === currentObj.globalRequestParamType.queryParams && !voltmx.sdk.isNullOrUndefined(currentObj.globalRequestParams.queryparams[paramName])) {
                 delete currentObj.globalRequestParams.queryparams[paramName];
             } else if (paramType === currentObj.globalRequestParamType.bodyParams && !voltmx.sdk.isNullOrUndefined(currentObj.globalRequestParams.bodyparams[paramName])) {
                 delete currentObj.globalRequestParams.bodyparams[paramName];
             }
             if (!(voltmx.sdk.getAType() === voltmx.sdk.constants.SDK_ATYPE_SPA || voltmx.sdk.getAType() === "watch")) {
                 //invoke NFI only for android,ios and FFI for windows and logger
                 voltmx.sdk.sdkCommons.removeGlobalRequestParam(paramName, paramType);
                 voltmx.logger.removeGlobalRequestParam(paramName, paramType);
             }
         }
     };
     this.resetGlobalRequestParams = function() {
         voltmx.sdk.logsdk.trace("Entering resetGlobalRequestParams");
         currentObj.globalRequestParams = {
             "headers": {},
             "queryparams": {},
             "bodyparams": {}
         };
         if (!(voltmx.sdk.getAType() === voltmx.sdk.constants.SDK_ATYPE_SPA || voltmx.sdk.getAType() === "watch")) {
             //invoke NFI only for android,ios and FFI for windows and logger
             voltmx.sdk.sdkCommons.resetGlobalRequestParams();
             voltmx.logger.resetGlobalRequestParams();
         }
     };
     this.appendGlobalHeaders = function(headers) {
         voltmx.sdk.logsdk.perf("Executing appendGlobalHeaders");
         var globalHeaders = currentObj.getGlobalRequestParams(currentObj.globalRequestParamType.headers);
         if (!voltmx.sdk.isNullOrUndefined(globalHeaders)) {
             if (voltmx.sdk.isNullOrUndefined(headers)) {
                 headers = {};
             }
             for (var obj in globalHeaders) {
                 if (voltmx.sdk.isNullOrUndefined(headers[obj])) {
                     headers[obj] = globalHeaders[obj];
                 }
             }
         }
         voltmx.sdk.logsdk.perf("Executing Finished appendGlobalHeaders");
     };
     this.appendGlobalBodyParams = function(params) {
         voltmx.sdk.logsdk.perf("Executing appendGlobalBodyParams");
         var globalBodyParams = currentObj.getGlobalRequestParams(currentObj.globalRequestParamType.bodyParams);
         if (!voltmx.sdk.isNullOrUndefined(globalBodyParams)) {
             if (voltmx.sdk.isNullOrUndefined(params)) {
                 params = {};
             }
             for (var obj in globalBodyParams) {
                 if (voltmx.sdk.isNullOrUndefined(params[obj])) {
                     params[obj] = globalBodyParams[obj];
                 }
             }
         }
         voltmx.sdk.logsdk.perf("Executing Finished appendGlobalBodyParams");
     };
     this.appendGlobalQueryParams = function(url) {
         voltmx.sdk.logsdk.perf("Executing appendGlobalQueryParams");
         var globalQueryParams = currentObj.getGlobalRequestParams(currentObj.globalRequestParamType.queryParams);
         if (!voltmx.sdk.isNullOrUndefined(globalQueryParams) && Object.keys(globalQueryParams).length !== 0) {
             if (url.indexOf("?") < 0) {
                 url = url + "?" + voltmx.sdk.util.objectToQueryParams(globalQueryParams);
             } else {
                 url = url + "&" + voltmx.sdk.util.objectToQueryParams(globalQueryParams);
             }
         }
         voltmx.sdk.logsdk.perf("Executing Finished appendGlobalQueryParams");
         return url;
     };
     this.appendGlobalParams = function(url, headers, params) {
         voltmx.sdk.logsdk.perf("Executing appendGlobalParams");
         currentObj.appendGlobalHeaders(headers);
         currentObj.appendGlobalBodyParams(params);
         var result = currentObj.appendGlobalQueryParams(url);
         voltmx.sdk.logsdk.perf("Executing Finished appendGlobalParams");
         return result;
     };
     this.setAppSecurityKey = function(customSalt) {
         voltmx.sdk.logsdk.perf("Executing setAppSecurityKey");
         if (!voltmx.sdk.isNullOrUndefined(customSalt) && typeof customSalt === 'string') {
             integrityCustomSecurityKey = customSalt;
             voltmx.sdk.logsdk.perf("Executing Finished setAppSecurityKey");
             if (voltmxRef.mainRef.integrityKey === true) {
                 setIntegrityParamsHandler();
             }
             return true;
         } else {
             var errorObj = {};
             errorObj[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.invalid_security_key;
             errorObj[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.invalid_security_key;
             voltmx.sdk.logsdk.error(voltmx.sdk.errormessages.invalid_security_key);
             voltmx.sdk.logsdk.perf("Executing Finished setAppSecurityKey");
             return errorObj;
         }
     };
     this.getAppSecurityKey = function() {
         return integrityCustomSecurityKey;
     };
 };
 voltmx.mbaas = voltmx.sdk;
 voltmx.sdk.isDebugEnabled = true;
 voltmx.sdk.isInitialized = false;
 voltmx.sdk.currentInstance = null;
 voltmx.sdk.isLicenseUrlAvailable = true;
 voltmx.sdk.isOAuthLogoutInProgress = false;
 voltmx.sdk.constants = voltmx.sdk.constants || {};
 voltmx.sdk.version = "9.5.7";
 voltmx.sdk.logsdk = new voltmxSdkLogger();
 voltmx.sdk.syncService = null;
 voltmx.sdk.dataStore = voltmx.sdk.dataStore || new voltmxDataStore();
 voltmx.sdk.skipAnonymousCall = false;
 voltmx.sdk.convertPassthroughResponseToJson = false;
 voltmx.sdk.getDefaultInstance = function() {
     return voltmx.sdk.currentInstance;
 };
 // This is to be deprecated with getDefaultInstance
 voltmx.sdk.getCurrentInstance = function() {
     return voltmx.sdk.currentInstance;
 };
 // This is to be set by client to skip anonymous login calls.
 voltmx.sdk.skipAnonymousLoginCall = function(state) {
     // If enabled then client can only access public integration services.
     // If disabled then client can access protected integration services.
     // To access private client needs to get authenticated by an identity service.
     voltmx.sdk.skipAnonymousCall = state;
 };
 voltmx.sdk.claimsRefresh = function(callback, failureCallback) {
     voltmx.sdk.logsdk.trace("Entering voltmx.sdk.claimsRefresh");
     var voltmxRef = voltmx.sdk.getCurrentInstance();
     var networkProvider = new voltmxNetworkProvider();
     var loginWithAnonymousProvider = function(successCallback, failureCallback) {
         var identityObject = voltmxRef.getIdentityService("$anonymousProvider");
         identityObject.login(null, function(res) {
             successCallback();
         }, function(res) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getAuthErrObj(res));
         });
     };
     if (voltmxRef.currentClaimToken === null) {
         voltmx.sdk.logsdk.warn("claims Token is Unavialable");
         if (voltmxRef.isAnonymousProvider) {
             loginWithAnonymousProvider(callback, failureCallback);
         } else {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getNullClaimsTokenErrObj());
         }
     } else if (voltmx.sdk.isClaimsTokenExpired(voltmxRef.claimTokenExpiry)) {
         if (voltmxRef.isAnonymousProvider) {
             loginWithAnonymousProvider(callback, failureCallback);
         } else {
             voltmx.sdk.fetchClaimsTokenFromServer(false, callback, failureCallback);
         }
     } else {
         callback();
     }
 };
 voltmx.sdk.isClaimsTokenExpired = function(claimsTokenExpVal) {
     // [MFSDK-4863] - Considering a delay of 60 Secs while checking the expiry of claims token
     // hence, deducting 60 secs from the currentTimeMillis while comparing expiry time
     var DELAY_IN_MILLIS = 60000;
     if (!voltmx.sdk.isNullOrUndefined(claimsTokenExpVal) && (Date.now() + DELAY_IN_MILLIS) > claimsTokenExpVal) {
         return true;
     } else {
         return false;
     }
 }
 voltmx.sdk.claimsAndProviderTokenRefresh = function(callback, failureCallback) {
     voltmx.sdk.logsdk.trace("Entering voltmx.sdk.claimsAndProviderTokenRefresh");
     voltmx.sdk.fetchClaimsTokenFromServer(true, callback, failureCallback);
 };
 /**
  * Checks for the etag in the response data. Gets the service doc & caches it if etag is updated.
  * @param data{JSON} response data from claimsRefresh or login.
  * @param callback{function} callback to be invoked.
  */
 function getLatestServiceDocIfAvailable(data, callback) {
     // Disabling this for phonegap and plain-js as there is no concept of auto-init there
     // Also, If voltmxRef.mainRef.config is not defined which means init is called again or voltmxRef is in invalid state.
     // Hence skipping service doc call.
     if (voltmx.sdk.getSdkType() !== voltmx.sdk.constants.SDK_TYPE_IDE || voltmx.sdk.isNullOrUndefined(voltmxRef.mainRef.config)) {
         voltmx.sdk.verifyAndCallClosure(callback);
         return;
     }
     var currentETag = voltmxRef.mainRef.config.service_doc_etag;
     var serverETag = data.service_doc_etag;
     if (!voltmx.sdk.isNullOrUndefined(serverETag) && (voltmx.sdk.isNullOrUndefined(currentETag) || currentETag != serverETag)) {
         voltmx.sdk.logsdk.info("Service doc update found.");
         var networkProvider = new voltmxNetworkProvider();
         var _serviceUrl = stripTrailingCharacter(voltmxRef.rec.url, "/") + "/appconfig";
         var headers = {};
         headers[voltmx.sdk.constants.APP_KEY_HEADER] = voltmxRef.mainRef.appKey;
         headers[voltmx.sdk.constants.APP_SECRET_HEADER] = voltmxRef.mainRef.appSecret;
         headers["X-HTTP-Method-Override"] = "GET";
         populateHeaderWithFoundryAppVersion(headers);
         voltmx.sdk.logsdk.perf("Executing network call for getLatestServiceDocIfAvailable");
         //For /appConfig call, X-Voltmx-Integrity header should be set always
         setIntegrityParams.call(voltmxRef);
         var options = {};
         options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
         //sending extra an option "isAppConfigCall" for setting integrity for appConfig calls
         options[voltmx.sdk.constants.IS_APP_CONFIG_CALL] = true;
         networkProvider.post(_serviceUrl, null, headers, function(successResponse) {
             voltmx.sdk.util.checkAndUpdateIntegrityKey(successResponse);
             //Saving latest metadata(appKey, appSecret and serviceDoc) in DS
             //for next app launch
             voltmx.sdk.util.saveMetadatainDs(voltmxRef.mainRef.appKey, voltmxRef.mainRef.appSecret, successResponse);
             voltmx.sdk.logsdk.perf("Executing Finished network call for getLatestServiceDocIfAvailable");
             voltmx.sdk.verifyAndCallClosure(callback);
         }, function(failureResponse) {
             voltmx.sdk.logsdk.perf("Executing Finished network call for getLatestServiceDocIfAvailable");
             voltmx.sdk.logsdk.error("Refresh of serviceDoc failed:" + JSON.stringify(failureResponse));
             voltmx.sdk.verifyAndCallClosure(callback);
         }, null, options);
     } else {
         voltmx.sdk.verifyAndCallClosure(callback);
     }
 }
 voltmx.sdk.fetchClaimsTokenFromServer = function(isBackendTokenRefreshRequired, callback, failureCallback) {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.fetchClaimsTokenFromServer");
     var voltmxRef = voltmx.sdk.getCurrentInstance();
     var networkProvider = new voltmxNetworkProvider();
     voltmx.sdk.logsdk.debug("claims token has expired. fetching new token and isBackendTokenRefreshRequired :", isBackendTokenRefreshRequired);
     var _serviceUrl = stripTrailingCharacter(voltmxRef.rec.url, "/");
     var _url = _serviceUrl + "/claims";
     var bodyParams = {};
     var refreshLoginTokenStoreUtilityObject = voltmx.sdk.util.getRefreshLoginTokenStoreUtility();
     if (isBackendTokenRefreshRequired) {
         voltmx.sdk.logsdk.debug('isBackendTokenRefreshRequired is ' + isBackendTokenRefreshRequired + ' in claims refresh');
         _url = _url + "?refresh=true";
         bodyParams[voltmx.sdk.constants.ENABLE_REFRESH_LOGIN] = true;
         //retrieve custom params
         if (!voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh)) {
             var customOAuthParams = {};
             for (var provider in voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh) {
                 for (var paramKey in voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[provider]) {
                     customOAuthParams[paramKey] = voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[provider][paramKey];
                 }
             }
             //populating custom oAuth params
             voltmx.sdk.util.populateCustomOAuthParams(bodyParams, customOAuthParams);
         }
     }
     voltmx.sdk.logsdk.debug("service url is " + _url);
     if (voltmxRef.currentRefreshToken === null) {
         voltmx.sdk.logsdk.perf("Executing Finished network call for fetchClaimsTokenFromServer");
         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getNullRefreshTokenErrObj());
     } else {
         var headers = {};
         headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentRefreshToken;
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
         voltmx.sdk.logsdk.perf("Executing network call for fetchClaimsTokenFromServer");
         networkProvider.post(_url, bodyParams, headers, function(identityResponse) {
             voltmx.sdk.logsdk.perf("Executing Finished network call for fetchClaimsTokenFromServer");
             voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.fetchClaimsTokenFromServer : refresh success");
             var response = voltmx.sdk.processClaimsSuccessResponse(identityResponse, voltmxRef, false);

             function serviceDocCallback() {
                 if (!voltmx.sdk.isNullOrUndefined(identityResponse[voltmx.sdk.constants.LOGIN_PROFILES])) {
                     voltmx.sdk.logsdk.debug("login profiles present in claims refresh");
                     var listOfLoginProfiles = Object.keys(identityResponse[voltmx.sdk.constants.LOGIN_PROFILES]);
                     refreshLoginTokenStoreUtilityObject.setInternalRefreshToken(listOfLoginProfiles, voltmxRef.currentRefreshToken);
                 }
                 if (isBackendTokenRefreshRequired && !voltmx.sdk.isNullOrUndefined(identityResponse[voltmx.sdk.constants.BACKEND_REFRESH_TOKENS])) {
                     voltmx.sdk.logsdk.debug("trying to update backend tokens securely");
                     var providerToLocalTokenObjectJSON = refreshLoginTokenStoreUtilityObject.getAllPersistedRefreshLoginProviderTokens();
                     if (!voltmx.sdk.isNullOrUndefined(providerToLocalTokenObjectJSON)) {
                         voltmx.sdk.logsdk.debug("retrieved local tokens securely");
                         var providerToBackendResponseTokenJSON = identityResponse[voltmx.sdk.constants.BACKEND_REFRESH_TOKENS];
                         //updating backend refresh tokens of the providers
                         refreshLoginTokenStoreUtilityObject.setBulkBackendRefreshTokens(providerToBackendResponseTokenJSON);
                     }
                 }
                 voltmx.sdk.verifyAndCallClosure(callback, response);
             }
             getLatestServiceDocIfAvailable(identityResponse, serviceDocCallback);
         }, function(data) {
             voltmx.sdk.logsdk.perf("Executing Finished network call for fetchClaimsTokenFromServer");
             voltmx.sdk.logsdk.error("failed to acquire refresh token", data);
             voltmx.sdk.processClaimsErrorResponse(data, voltmxRef, true, failureCallback);
         });
     }
 };
 voltmx.sdk.processClaimsSuccessResponse = function(data, voltmxRef, isAsync, callBack) {
     voltmx.sdk.logsdk.trace("Entering voltmx.sdk.processClaimsSuccessResponse");
     data = voltmx.sdk.formatSuccessResponse(data);
     voltmxRef.currentClaimToken = data.claims_token.value;
     voltmxRef.claimTokenExpiry = data.claims_token.exp;
     voltmxRef.currentRefreshToken = data.refresh_token;
     voltmx.logger.setClaimsToken();
     //if offline login enabled then updating the claimstoken in the store
     if (voltmx.sdk.offline.isOfflineEnabled && voltmx.sdk.offline.isOfflineEnabled == true) {
         voltmx.sdk.offline.updateAuthToken(data);
     }
     if (voltmx.sdk.offline.persistToken || voltmx.sdk.offline.isPersistentLoginResponseEnabled()) {
         voltmx.sdk.offline.updatePersistedToken(data);
     }
     if (!isAsync) {
         return {
             "message": "success"
         };
     } else if (callBack) {
         callBack();
     }
 };
 voltmx.sdk.processClaimsErrorResponse = function(data, voltmxRef, isAsync, callBack) {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.processClaimsErrorResponse");
     //setting the anonymous provider as true to access the public protected urls without any issue
     voltmxRef.isAnonymousProvider = true;
     if (!isAsync) {
         var result = voltmx.sdk.error.getAuthErrObj(data);
         voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.processClaimsErrorResponse");
         return result;
     } else if (callBack) {
         voltmx.sdk.verifyAndCallClosure(callBack, voltmx.sdk.error.getAuthErrObj(data));
     }
 };
 /**
  * Init success callback method.
  * @callback initSuccessCallback
  * @param {json} mainRef - Application Configuration
  */
 /**
  * Init failure callback method.
  * @callback initFailureCallback
  */
 /**
  * Initialization method for the Volt MX SDK.
  * This method will fetch the app configuration from the HCL server and stores in memory.
  * This method has to be invoked before invoking any other SDK methods.
  * @param {string} appKey - Appkey of the Volt MX application
  * @param {string} appSecret - App Secret of the Volt MX application
  * @param {string} serviceUrl - URL of the Volt MX Server
  * @param {initSuccessCallback} successCallback  - Callback method on success
  * @param {initFailureCallback} failureCallback - Callback method on failure
  */
 voltmx.sdk.prototype.init = function(appKey, appSecret, serviceUrl, successCallback, failureCallback, initOptions) {
     // removing app metadata with key for the latest app metadata
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.prototype.init");
     voltmx.sdk.util.clearExistingWebsocketObject();
     voltmx.sdk.util.deleteMetadatafromDs();
     if (!(appKey && appSecret && serviceUrl)) {
         voltmx.sdk.logsdk.error("### init:: Invalid credentials passed");
         voltmx.sdk.verifyAndCallClosure(failureCallback, "Invalid initialization parameters passed. Please check appKey, appSecret and ServiceUrl parameters");
         return;
     }
     var networkProvider = new voltmxNetworkProvider();
     serviceUrl = serviceUrl.trim();
     this.mainRef.serviceUrl = serviceUrl;
     this.mainRef.appSecret = appSecret;
     this.mainRef.appKey = appKey;
     voltmxRef = this;
     KNYMobileFabric = VMXFoundry = this;
     //Initializing integrity key for the first time as false
     //If integrity is not set on server by default the value remains false
     voltmxRef.mainRef.integrityKey = false;
     voltmx.sdk.currentInstance = voltmxRef;
     var options = {};
     options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
     //sending extra an option "isAppConfigCall" for setting integrity for appConfig calls
     options[voltmx.sdk.constants.IS_APP_CONFIG_CALL] = true;
     setIntegrityParams.call(voltmxRef);
     voltmx.sdk.logsdk.trace("### init:: calling GET on appConfig to retrieve servicedoc");
     var headers = {};
     headers[voltmx.sdk.constants.APP_KEY_HEADER] = appKey;
     headers[voltmx.sdk.constants.APP_SECRET_HEADER] = appSecret;
     headers["X-HTTP-Method-Override"] = "GET";
     //Resetting the value.
     voltmx.sdk.setFoundryAppVersion(null);
     if (!voltmx.sdk.isNullOrUndefined(initOptions) && initOptions["MFAppVersion"]) {
         voltmx.sdk.setFoundryAppVersion(initOptions["MFAppVersion"]);
     }
     populateHeaderWithFoundryAppVersion(headers);
     voltmx.sdk.logsdk.perf("Executing network call for fetching servicedoc");
     networkProvider.post(serviceUrl, null, headers, function(data) {
         data = voltmx.sdk.formatSuccessResponse(data);
         voltmx.sdk.logsdk.info("### init::_doInit fetched servicedoc successfuly");
         voltmx.sdk.logsdk.debug("### init:: retrieved data from service doc", data);
         voltmxRef.mainRef.config = data;
         voltmxRef.servicedoc = data;
         voltmxRef.mainRef.appId = data.appId;
         var processServiceDocResult = voltmxRef.initWithServiceDoc(appKey, appSecret, data);
         if (processServiceDocResult === true) {
             voltmx.sdk.logsdk.info("### init::_doInit processing service document successful");
             voltmx.sdk.logsdk.debug("### init::_doInit saving done. Calling success callback", data);
             voltmx.sdk.initiateSession(voltmxRef);
             if (typeof(VMXMetricsService) !== "undefined" && voltmx.sdk.currentInstance.getMetricsService) {
                 KNYMetricsService = VMXMetricsService = voltmx.sdk.currentInstance.getMetricsService();
                 if (VMXMetricsService && typeof(appConfig) !== "undefined" && voltmx.sdk.util.isJsonObject(appConfig) && appConfig.hasOwnProperty("eventTypes") && voltmx.sdk.isArray(appConfig.eventTypes) && appConfig.eventTypes.length !== 0) {
                     VMXMetricsService.setEventTracking(appConfig.eventTypes);
                 }
             }
             if (voltmx.sdk.skipAnonymousCall) {
                 voltmx.sdk.logsdk.info("### init::skipping anonymous login call");
                 // Enabling this flag to connect to any protected integration service.
                 voltmxRef.isAnonymousProvider = true;
                 voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.init");
                 voltmx.sdk.verifyAndCallClosure(successCallback, voltmxRef.mainRef);
             } else {
                 var identityObject = voltmx.sdk.getCurrentInstance().getIdentityService("$anonymousProvider");
                 identityObject.login(null, function(res) {
                     voltmx.sdk.logsdk.perf("Executing Finished network call for fetching servicedoc");
                     voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.init");
                     voltmx.sdk.verifyAndCallClosure(successCallback, voltmxRef.mainRef);
                 }, function(res) {
                     voltmx.sdk.logsdk.perf("Executing Finished network call for fetching servicedoc");
                     voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.init");
                     voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getAuthErrObj(res));
                 });
             }
         } else {
             voltmx.sdk.logsdk.error("### init::_doInit processing servicedoc failed. Calling failure callback");
             voltmx.sdk.logsdk.perf("Executing Finished network call for fetching servicedoc");
             voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.init");
             voltmx.sdk.verifyAndCallClosure(failureCallback, JSON.stringify(processServiceDocResult));
         }
     }, function(error) {
         voltmx.sdk.logsdk.error("### init::_doInit fetching service document from Server failed", error);
         voltmx.sdk.logsdk.info("### init::_doInit  calling failure callback");
         voltmx.sdk.logsdk.perf("Executing Finished network call for fetching servicedoc");
         voltmx.sdk.isInitialized = false;
         voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.init");
         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getAuthErrObj(error));
     }, null, options);
 };
 voltmx.sdk.prototype.initWithServiceDoc = function(appKey, appSecret, serviceDoc) {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.prototype.initWithServiceDoc");
     voltmxRef = this;
     var mSessionUrl = "";
     // initializing identity SID as empty string
     voltmxRef.idSid = "";
     // initializing refresh login record keeping Set.
     voltmxRef.refreshLoginProvidersSet = new Set();
     KNYMobileFabric = VMXFoundry = this;
     voltmx.sdk.currentInstance = this;
     var unprocessedServiceDoc = voltmx.sdk.cloneObject(serviceDoc);
     if (voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE) {
         if (!voltmx.sdk.isNullOrUndefined(serviceDoc)) {
             voltmx.sdk.util.checkAndUpdateIntegrityKey(serviceDoc);
         }
     } else {
         //platform phonegap and plain-js doesn't support http integrity
         voltmxRef.mainRef.integrityKey = false;
     }
     if (serviceDoc instanceof voltmx.sdk.serviceDoc) {
         var servConfig = serviceDoc.toJSON();
         processServiceDocMap(servConfig);
     } else {
         return processServiceDocMap(serviceDoc);
     }

     function processServiceDocMap(servConfig) {
         for (var item in servConfig) {
             if (voltmx.sdk.isNullOrUndefined(servConfig[item]) || voltmx.sdk.isEmptyObject(servConfig[item])) {
                 delete servConfig[item];
             }
         }
         voltmx.sdk.logsdk.debug("### init::_doInit::_processServiceDoc", servConfig);
         try {
             voltmxRef.mainRef.appKey = appKey;
             voltmxRef.mainRef.appSecret = appSecret;
             voltmxRef.mainRef.appId = servConfig.appId;
             voltmxRef.mainRef.config = serviceDoc;
             /* if (!servConfig.baseId) {
              throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "invalid baseId " + servConfig.baseId);
              } */
             voltmxRef.mainRef.baseId = servConfig.baseId;
             /* if (!servConfig.name) {
              throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "invalid name " + servConfig.name);
              } */
             voltmxRef.mainRef.name = servConfig.name;
             if (servConfig.login) {
                 voltmxRef.login = servConfig.login;
             } else {
                 voltmxRef.login = [];
             }
             var url = servConfig.selflink;
             if (url) {
                 var lastPos = url.indexOf("/appconfig");
                 if (lastPos != -1) {
                     url = url.slice(0, lastPos);
                 } else {
                     throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "invalid self link");
                 }
                 var anonymousLoginProvider = {};
                 anonymousLoginProvider.type = "anonymous";
                 anonymousLoginProvider.url = url;
                 anonymousLoginProvider.prov = "$anonymousProvider";
                 voltmxRef.login.push(anonymousLoginProvider);
             }
             if (typeof(servConfig.integsvc) !== 'undefined') {
                 voltmx.sdk.logsdk.info("### init::_doInit::_processServiceDoc parsing Integration services");
                 voltmxRef.integsvc = servConfig.integsvc;
                 voltmx.sdk.logsdk.debug("### init::_doInit::voltmxRef integration Services", voltmxRef.integsvc);
             }
             if (typeof(servConfig.services_meta) === 'object') {
                 voltmx.sdk.logsdk.info("### init::_doInit::_processServiceDoc parsing Object services");
                 voltmx.sdk.util.populateIndividualServiceLists(servConfig, voltmxRef);
             }
             if (typeof(servConfig.messagingsvc) !== 'undefined') {
                 voltmx.sdk.logsdk.info("### init::_doInit::_processServiceDoc parsing Messaging services");
                 voltmxRef.messagingsvc = servConfig.messagingsvc;
             }
             if (typeof(servConfig.logicsvc) !== 'undefined') {
                 voltmx.sdk.logsdk.info("### init::_doInit::_processServiceDoc parsing Logic services");
                 voltmxRef.logicsvc = servConfig.logicsvc;
             }
             if (typeof(servConfig.sync) !== 'undefined') {
                 voltmxRef.sync = servConfig.sync;
             }
             if (servConfig.identity_features && servConfig.identity_features.reporting_params_header_allowed) {
                 voltmx.sdk.logsdk.info("### init::_doInit::_processServiceDoc parsing Identity features");
                 voltmxRef.reportingheaders_allowed = servConfig.identity_features.reporting_params_header_allowed;
             }
             if (voltmx.sdk.isLicenseUrlAvailable) {
                 if (servConfig.reportingsvc && servConfig.reportingsvc.custom && servConfig.reportingsvc.session) {
                     voltmxRef.customReportingURL = servConfig.reportingsvc.custom;
                     voltmxRef.sessionReportingURL = servConfig.reportingsvc.session;
                     mSessionUrl = voltmxRef.sessionReportingURL;
                     if (mSessionUrl) {
                         var lastIndex = mSessionUrl.lastIndexOf("/");
                         if (lastIndex !== -1) {
                             var networkUrl = mSessionUrl.substring(0, lastIndex + 1);
                             //set the Websocket URL
                             if (voltmx.serverEvents) {
                                 voltmxRef.serverEventsUrl = (networkUrl + voltmx.sdk.constants.SERVER_EVENTS_URL_ENDPOINT).replace("http", "ws");
                                 initializeServerEvents();
                             }
                             //Set the logger networkpersistor URL
                             if (voltmx.logger.isNativeLoggerAvailable()) {
                                 var networkPersistor = voltmx.logger.createNetworkPersistor();
                                 networkPersistor.URL = networkUrl + voltmx.logger.networkPersistorUrlEndpoint;
                                 voltmx.logger.setPersistorConfig(networkPersistor);
                             }
                         }
                     }
                 } else {
                     throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "invalid url for reporting service");
                 }
             }
             if (voltmxRef.internalSdkObject) {
                 voltmxRef.internalSdkObject.initWithServiceDoc(appKey, appSecret, servConfig);
                 if (voltmxRef.internalSdkObject.setClientParams) {
                     if (appConfig) {
                         voltmxRef.internalSdkObject.setClientParams({
                             "aid": appConfig.appId,
                             "aname": appConfig.appName,
                             "aversion": appConfig.appVersion
                         });
                     } else {
                         voltmxRef.internalSdkObject.setClientParams(voltmxRef.getClientParams());
                     }
                 }
                 voltmx.sdk.logsdk.info("### init::internal sdk object initialized");
             }
             voltmx.sdk.logsdk.info("### init::_doInit::_processServiceDoc parsing service document done");
             voltmx.sdk.isInitialized = true;
             voltmxRef.isAnonymousProvider = true;
             if (voltmx.sdk.metric && voltmx.os.deviceInfo().name === voltmx.sdk.constants.PLATFORM_SPA) {
                 voltmx.sdk.metric.flushEvents();
             }
             //checking for licenseCall
             if (!voltmx.sdk.isNullOrUndefined(servConfig.reportingsvc)) {
                 voltmx.sdk.setLicenseCall(appKey, appSecret, unprocessedServiceDoc);
             }
             //making this check for plain-js and phoneGap in android.
             if (voltmx.sdk.getSdkType() !== voltmx.sdk.constants.SDK_TYPE_PLAIN_JS && voltmx.sdk.getSdkType() !== voltmx.sdk.constants.SDK_TYPE_PHONEGAP) {
                 if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_ANDROID && (appConfig.isSSOEnabled === true || appConfig.isSSOEnabled === "true")) {
                     voltmx.sdk.util.initializeSSO();
                 }
             }
             var sdkType = voltmx.sdk.getSdkType();
             var type = voltmx.sdk.getAType();
             var platformName = voltmx.sdk.getPlatformName();
             if (sdkType == voltmx.sdk.constants.SDK_TYPE_IDE && ((type === voltmx.sdk.constants.SDK_ATYPE_NATIVE) || (type === voltmx.sdk.constants.SDK_ATYPE_SPA))) {
                 if ((!voltmx.sdk.isNullOrUndefined(voltmxRef.offlineObjectsvc)) && !(voltmx.sdk.isEmptyObject(voltmxRef.offlineObjectsvc))) {
                     voltmxRef.OfflineObjects = new voltmx.sdk.OfflineObjects(voltmxRef.offlineObjectsvc);
                 }
             }
             if (voltmx.license) {
                 if (voltmx.licensevar && voltmx.licensevar.changeHandlers && voltmx.licensevar.changeHandlers.length == 0 && voltmx.license.registerChangeListener) {
                     voltmx.license.registerChangeListener(voltmxRef.sessionChangeHandler);
                     voltmxRef.overrideUserIdFlag = true;
                 }
             }
             if (voltmxRef.mainRef.integrityKey === true) {
                 setIntegrityParamsHandler();
             } else {
                 resetIntegrityParams();
                 if (!(voltmx.sdk.getAType() === voltmx.sdk.constants.SDK_ATYPE_SPA || voltmx.sdk.getAType() === "watch")) {
                     //invoke NFI only for android,ios and FFI for windows 
                     voltmx.sdk.httpIntegrity.removeIntegrityCheck();
                 }
             }
             // Generating SDK Client UUID for service calls and server events
             if (voltmx.sdk.getSdkType() !== voltmx.sdk.constants.SDK_TYPE_PHONEGAP) {
                 voltmx.sdk.util.checkAndGenerateClientUUID();
             }
             voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.initWithServiceDoc");
             return true;
         } catch (err) {
             voltmx.sdk.logsdk.error("### init::_doInit::_processServiceDoc failed with an exception: ", err);
             return ("processing the ServiceDoc failed with an exception: " + JSON.stringify(err));
         }
     }
 };
 voltmx.sdk.prototype.sessionChangeHandler = function(changes) {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.prototype.sessionChangeHandler");
     var voltmxRef = voltmx.sdk.getCurrentInstance();
     voltmxRef.getMetricsService();
     var sessionId = null;
     var userId = null;
     if (!voltmx.sdk.util.isNullOrEmptyString(changes["sessionId"])) {
         sessionId = changes["sessionId"];
         voltmxRef.setSessionId(sessionId);
         if (voltmxRef.internalSdkObject) {
             sessionId = sessionId + "," + voltmx.sdk.util.getSessionType();
         }
         if (voltmxRef.metricsServiceObject && voltmxRef.metricsServiceObject.setSessionId) {
             voltmxRef.metricsServiceObject.setSessionId(sessionId);
         }
     }
     if (changes["userId"] != undefined) {
         voltmxRef.overrideUserIdFlag = true;
         userId = changes["userId"];
         voltmxRef.setCurrentUserId(userId);
         if (voltmxRef.metricsServiceObject && voltmxRef.metricsServiceObject.setUserId) {
             voltmxRef.metricsServiceObject.setUserId(userId);
         }
     }
     voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.sessionChangeHandler");
 };

 function setIntegrityParams() {
     var integrityParams = {
         "algo": voltmx.sdk.constants.HASHING_ALGORITHM,
         "headerName": voltmx.sdk.constants.INTEGRITY_HEADER,
         "validateResp": true,
         "passthroughHeaderName": voltmx.sdk.constants.PASSTHROUGH_RESPONSE_HEADER
     };
     if (!voltmx.sdk.isNullOrUndefined(voltmxRef.getAppSecurityKey())) {
         integrityParams["salt"] = voltmxRef.getAppSecurityKey();
     } else {
         integrityParams["salt"] = voltmxRef.mainRef.appSecret;
     }
     //commenting integrity global header as only appConfig call requires integrity enabled
     //if not set by the server
     //voltmxRef.mainRef.integrityKey = true;
     voltmxRef.mainRef.integrityParams = integrityParams;
 }

 function resetIntegrityParams() {
     voltmxRef.mainRef.integrityKey = false;
     voltmxRef.mainRef.integrityParams = {};
 }

 function setIntegrityParamsHandler() {
     setIntegrityParams();
     try {
         if (!(voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_WINDOWS || voltmx.sdk.getAType() === voltmx.sdk.constants.SDK_ATYPE_SPA || voltmx.sdk.getAType() === "watch")) {
             //invoke NFI only for android and ios.
             voltmx.sdk.httpIntegrity.setIntegrityCheck(voltmxRef.mainRef.integrityParams);
         }
     } catch (e) {
         voltmx.sdk.logsdk.warn("Invalid Integrity properties received");
         throw new Exception(voltmx.sdk.errorConstants.INTEGRITY_FAILURE, "Invalid Integrity properties");
     }
 }
 /**
  * MFSDK
  * Created by KH1969 on 18-01-2018.
  * Copyright © 2018 Kony. All rights reserved.
  */
 /**
  * Constructor for ClientCache service, uses lruCache.js internally to save key, value pairs.
  * This is a singleton class, object gets created for the first time of instantiation and the same object is
  * returned for next initializations.
  *
  * @param size {Number} Maximum size of the cache. It should be non zero positive number.
  * @return {voltmx.sdk.ClientCache}
  *
  */
 voltmx.sdk.ClientCache = function(size) {
         if (typeof voltmx.sdk.ClientCache.instance === 'object') return voltmx.sdk.ClientCache.instance;
         var lruCacheObj = null;
         if (size === undefined || size === null) lruCacheObj = new lruCache(voltmx.sdk.constants.DEFAULT_CACHE_SIZE);
         else if (typeof size != 'number' || size <= 0) {
             voltmx.sdk.logsdk.warn("cache cannot be created of size <= 0");
             return null;
         } else lruCacheObj = new lruCache(size);
         /**
          * Gets the response cached for the key. Returns null if not found.
          * @param key {string}
          * @return {null|object}
          */
         this.get = function(key) {
                 return lruCacheObj.get(key);
             }
             /**
              * Gets the boolean assertion for key existence in the cache.
              * @param key {string}
              * @return {boolean}
              */
         this.has = function(key) {
                 return lruCacheObj.has(key);
             }
             /**
              * Adds the key, value pair to cache.
              * @param key {string}
              * @param value {string}
              * @param expiryTime {number} Expiry time in seconds.
              */
         this.add = function(key, value, expiryTime) {
                 lruCacheObj.add(key, value, expiryTime);
             }
             /**
              * Removes the key, value from cache.
              * @param key {string}
              */
         this.remove = function(key) {
             lruCacheObj.remove(key);
         }
         voltmx.sdk.ClientCache.instance = this;
     }
     /**
      * MFSDK
      * Created by KH1969 on 18-01-2018.
      * Copyright © 2018 Kony. All rights reserved.
      */
     /**
      * Constructor for standalone LRU page replacement implementation.
      * Implementation is done using a double linked list data structure and a hashmap.
      * Upon every insert & get the head gets updated to the newest element.
      * Cached nodes gets removed if size is more than the requested capacity.
      * Default cache size is 100.
      *
      * Should not be called by the developer.
      *
      *  Below is the list structure if elements are inserted in the order A, B, C & D

      *  Head = D, Tail = A
      *  D--(older)-->C--(older)-->B--(older)-->A--(older)-->NULL
      *  NULL<--(newer)--D<--(newer)--C<--(newer)--B<--(newer)--A
      *
      *  Now if B is accessed the list structure will be modified as,
      *  Head = B, Tail = A
      *
      *  B--(older)-->D--(older)-->C--(older)-->A--(older)-->NULL
      *  NULL<--(newer)--B<--(newer)--D<--(newer)--C<--(newer)--A
      */
 lruCache = function(size) {
         var LOG_PREFIX = "SDK_CACHE ";
         if (size === undefined || size === null) this.capacity = voltmx.sdk.constants.DEFAULT_CACHE_SIZE;
         else if (typeof size != 'number' || size <= 0) {
             voltmx.sdk.logsdk.warn("cache cannot be created of size <= 0");
             return null;
         } else this.capacity = size;
         this.length = 0;
         this.map = {};
         // save the head and tail so we can update it easily
         this.head = null;
         this.tail = null;
         /**
          * Gets the current time in seconds.
          * @returns {number}
          */
         function getCurrentTimeInSeconds() {
             return Math.floor(new Date().getTime() / 1000);
         }
         /**
          * Double linked list data structure.
          * @param key
          * @param value
          */
         function cacheNode(key, value, expiry) {
             this.key = key;
             this.val = value;
             this.newer = null; // Next newer node
             this.older = null; // Previous older node
             this.expiryTime = 0;
             if (expiry !== undefined && typeof expiry === 'number' && expiry != 0) {
                 this.expiryTime = getCurrentTimeInSeconds() + expiry;
             }
         }
         /**
          * Shuffles the cache by last recently used.
          * @param key
          */
         function shuffleLRUCache(key) {
             var node = this.map[key];
             if (this.head === node) {
                 // No need to shuffle the cache, as the head itself is the recently accessed node.
                 return;
             }
             // Head will not have newer node.
             if (node.newer) {
                 node.newer.older = node.older;
             } else {
                 this.head = node.older;
             }
             // Tail will not have older node.
             if (node.older) {
                 node.older.newer = node.newer;
             } else {
                 this.tail = node.newer;
             }
             // Now node is detached. Place it at head.
             // Updates are done in this way
             // 1: node--(older)-->head
             // 2: null<--(newer)--node
             // 3: node<--(newer)--head
             // 4: node is assigned to head. So current head got updated to node.
             node.older = this.head;
             node.newer = null;
             if (this.head) {
                 this.head.newer = node;
             }
             this.head = node;
         }
         /**
          * Returns the current size of the cache.
          * @returns {number}
          */
         this.getSize = function() {
                 return this.length;
             }
             /**
              * Adds the key value pair to the cache.
              * Key gets removed upon expiry, expiry time is calculated by currentTimeInSeconds + expiryTime.
              * If no expiryTime is specified then key will not expire.
              * @param key {String}
              * @param value {Object}
              * @param expiryTime {Number}
              */
         this.add = function(key, value, expiryTime) {
                 if (key === undefined || value === undefined || key === null || value === null) return;
                 // update the value for existing entries
                 if (this.has(key)) {
                     this.map[key].val = value;
                     voltmx.sdk.logsdk.debug(LOG_PREFIX + "Key: " + key + " updated");
                     shuffleLRUCache.call(this, key);
                     return;
                 }
                 if (this.length >= this.capacity) {
                     // remove the least recently used item
                     this.remove(this.tail.key)
                 }
                 var node = new cacheNode(key, value, expiryTime);
                 // Additions are done in this way
                 // 1: node--(older)-->head
                 // 2: node<--(newer)--head
                 // 3: node is assigned to head. So current head got updated to node.
                 // 4: tail = node, if there is no tail node then current node is tail node. This happens only for the first add.
                 node.older = this.head;
                 // if have head, we need re-connect node with other nodes older than head
                 if (this.head) {
                     this.head.newer = node;
                 }
                 this.head = node;
                 // if no tail which means first insert, set the tail to node too
                 if (!this.tail) {
                     this.tail = node;
                 }
                 this.map[key] = node;
                 this.length++;
                 voltmx.sdk.logsdk.debug(LOG_PREFIX + "Key: " + key + " added");
             }
             /**
              * Gets the cached node by key. Returns null if key is not found.
              * The key is removed if it is expired, returns null here as well.
              * @param key {String}
              * @returns {Object}
              */
         this.get = function(key) {
                 if (this.has(key)) {
                     if (this.map[key].expiryTime != 0 && getCurrentTimeInSeconds() > this.map[key].expiryTime) {
                         this.remove(key);
                         voltmx.sdk.logsdk.debug(LOG_PREFIX + "Key: " + key + " expired");
                         return null;
                     }
                     shuffleLRUCache.call(this, key);
                     return this.map[key].val;
                 } else {
                     return null;
                 }
             }
             /**
              * Removes the key, value from the cache by key.
              * @param key {String} Key to delete from the cache
              */
         this.remove = function(key) {
                 if (this.has(key)) {
                     var node = this.map[key];
                     // Head node will not have newer node.
                     if (node.newer) {
                         node.newer.older = node.older;
                     } else {
                         this.head = node.older;
                     }
                     // Tail node will not have older node.
                     if (node.older) {
                         node.older.newer = node.newer;
                     } else {
                         this.tail = node.newer;
                     }
                     delete this.map[key];
                     node = null;
                     this.length--;
                 }
             }
             /**
              * Clears the cache.
              */
         this.clear = function() {
                 this.map = {};
                 this.length = 0;
             }
             /**
              * Check if key exists.
              * @param key {string} Key to be found in the cache
              * @returns {boolean}
              */
         this.has = function(key) {
                 return this.map.hasOwnProperty(key);
             }
             /**
              * Updates the cache size.
              * @param size {number}
              */
         this.setMaxCacheSize = function(size) {
             //    Todo: If requested size < capacity remove the last (N - size) nodes from tail.
             voltmx.sdk.logsdk.debug(LOG_PREFIX + "updating cache size from " + this.capacity + " to " + size);
             this.capacity = size;
         }
     }
     /**
      * Method to create the configuration service instance
      * @returns {ConfigurationService} Configuration service instance
      */
 voltmx.sdk.prototype.getConfigurationService = function() {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.prototype.getConfigurationService")
     if (!voltmx.sdk.isInitialized) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + " Configuration service.");
     }
     var configObj = new ConfigurationService(this);
     voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.getConfigurationService")
     if (configObj) {
         return configObj;
     } else {
         throw new Exception(voltmx.sdk.errorConstants.CONFIGURATION_FAILURE, "Error in creating configuration object");
     }
 };
 /**
  * Should not be called by the developer.
  * @class
  * @classdesc Configuration service instance for fetching client app properties.
  */
 function ConfigurationService(voltmxRef) {
     var istUrl = voltmxRef.mainRef.config.reportingsvc.session.split("/IST")[0];
     voltmx.sdk.logsdk.debug("IST url fetched from service doc is :" + istUrl);
     var configUrl = istUrl + voltmx.sdk.constants.GET_CLIENT_PROPERTY_URL;
     voltmx.sdk.logsdk.debug("Configuration url formed is :" + configUrl);
     var networkProvider = new voltmxNetworkProvider();
     /**
      * Configuration svc method to get all the client app properties which is configured in admin console.
      * @successCallback this is called on successfull retrieval of properties
      * @failureCallback this is called on failure in retrieving properties
      * @returns {json} key value pair of all client app properties
      */
     this.getAllClientAppProperties = function(successCallback, failureCallback) {
         function fetchClientPropertiesHandler() {
             _getAllClientAppProperties(successCallback, failureCallback);
         }
         if (voltmx.sdk.skipAnonymousCall) {
             fetchClientPropertiesHandler();
         } else {
             voltmx.sdk.claimsRefresh(fetchClientPropertiesHandler, failureCallback);
         }
     };

     function _getAllClientAppProperties(successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering into _getAllClientAppProperties");
         var defaultHeaders = {};
         if (!voltmx.sdk.skipAnonymousCall) {
             var token = voltmxRef.currentClaimToken;
             if (!token) {
                 token = voltmx.sdk.getCurrentInstance().currentClaimToken;
             }
             defaultHeaders[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = token;
         }
         var options = {};
         options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
         networkProvider.get(configUrl, null, defaultHeaders, function(res) {
             voltmx.sdk.logsdk.trace("Entering Configuration service network success");
             voltmx.sdk.logsdk.debug("response from server for client properties is :" + JSON.stringify(res));
             var tempArray = ["httpresponse", voltmx.sdk.constants.MF_OPSTATUS];
             var tempJSON = {};
             for (var key in res) {
                 if (tempArray.indexOf(key.toLowerCase()) > -1) {
                     continue;
                 }
                 tempJSON[key] = res[key];
             }
             voltmx.sdk.verifyAndCallClosure(successCallback, tempJSON);
         }, function(xhr, status, err) {
             voltmx.sdk.logsdk.trace("Entering Configuration service network error");
             if (xhr && !(status && err)) {
                 err = xhr;
             }
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getObjectServiceErrObj(err));
         }, null, options);
     }
 }
 voltmx.sdk.constants = {
     /**Logger Constants**/
     LOGGER_NAME: "MFSDK",
     SYNC_LOGGER_NAME: "SYNCV1",
     APP_LOGGER_NAME: "VoltmxLogger",
     /**Network constants**/
     LAUNCHMODE_DEEPLINK: 3,
     DEEPLINK_VALID_PARAM: "code",
     HASHING_ALGORITHM: "SHA256",
     REMOVE_INTEGRITY_CHECK: "removeIntegrityCheck",
     SET_INTEGRITY_CHECK: "setIntegrityCheck",
     DISABLE_INTEGRITY_CHECK: "disableIntegrityCheck",
     DEFAULT_CACHE_SIZE: 100,
     GET_CLIENT_PROPERTY_URL: "/metadata/configurations/client/properties",
     DEFAULT_CACHE_EXPIRY_TIME: 0, //Which means it doesn't expire in the application session.
     QUERY_PARAMS: "queryParams",
     QUERY: "query",
     BODY_PARAMS: "bodyParams",
     OAUTH_SESSION_RESPONSE_TYPE: "oauth_session_response_type",
     /**Service ID's for Identity Calls**/
     GET_BACKEND_TOKEN: "getBackendToken",
     GET_SECURITY_ATTRIBUTES: "getSecurityAttributes",
     GET_USER_ATTRIBUTES: "getUserAttributes",
     GET_USER_DATA: "getUserData",
     GET_PROFILE: "getProfile",
     KEY_PROVIDER: "provider",
     KEY_INCLUDE_PROFILE: "include_profile",
     OAUTH_TOKEN_URL: "/oauth2/token",
     KEY_HTTP_REQUEST_OPTIONS: "httpRequestOptions",
     KEY_XML_HTTP_REQUEST_OPTIONS: "xmlHttpRequestOptions",
     ENABLE_WITH_CREDENTIALS: "enableWithCredentials",
     KEY_GRANT_TYPE: "grant_type",
     KEY_REFRESH_TOKEN: "refresh_token",
     KEY_BACKEND_REFRESH_TOKEN: "backend_refresh_token",
     KEY_AUTH_REFRESH_TOKEN: "auth_refresh_token",
     KEY_URL: "url",
     KEY_APP_CHALLENGE_METHOD: "app_challenge_method",
     APP_VERIFIER: "app_verifier",
     APP_CHALLENGE: "app_challenge",
     APP_CHALLENGE_METHOD_VALUE: "S256",
     PKCE_CODE_MAX_LENGTH: 128,
     IS_ENABLE_IDENTITY_PKCE: "is_enable_identity_pkce",
     ENABLE_IDENTITY_PKCE: "enable_identity_pkce",
     /** Identity Options**/
     OAUTH_REDIRECT_SUCCESS_URL: "success_url",
     /** ETAG_ID Constants **/
     ETAGID: "etagID",
     TOOLS_ETAG_ID: "tools_etagID",
     /** Init flags**/
     IS_APP_CONFIG_CALL: "isAppConfigCall",
     /** Multifactor auth related constants**/
     IS_MFA_ENABLED: "is_mfa_enabled",
     MFA_META: "mfa_meta",
     //OAuth for IE11 Workaround Constants, MFSDK-3657
     IE11_CROSS_DOMAIN_OAUTH_BASE_URL: "IE11CrossDomainOAuthBaseUrl",
     KNY_OAUTH_REDIRECT_HTML: "KNYOAuthRedirect.html",
     KNY_OAUTH_CALLBACK_HTML: "KNYOAuthCallback.html",
     KNY_OAUTH_REDIRECT_URL: "kny_oauth_redirect_url",
     KNY_OAUTH_PROTOCOL_PARAM: "kny_protocol_param",
     /**HttpMethods and header constants**/
     HTTP_METHOD_GET: "GET",
     HTTP_METHOD_POST: "POST",
     HTTP_METHOD_DELETE: "DELETE",
     HTTP_CONTENT_HEADER: "Content-Type",
     HTTP_REQUEST_HEADER_ACCEPT: "Accept",
     HEADER: "header",
     /**Content Type Value Constants**/
     CONTENT_TYPE_FORM_URL_ENCODED: "application/x-www-form-urlencoded",
     //Added a new content-type based on the bug MFSDK-5665
     CONTENT_TYPE_FORM_URL_ENCODED_CHARSET_UTF8: "application/x-www-form-urlencoded;charset=utf-8",
     CONTENT_TYPE_JSON: "application/json",
     //Added a new content-type based on the bug MFSDK-4096
     CONTENT_TYPE_JSON_CHARSET_UTF8: "application/json;charset=utf-8",
     CONTENT_TYPE_OCTET_STREAM: "application/octet-stream",
     CONTENT_TYPE_TEXT_HTML: "text/html",
     CONTENT_TYPE_TEXT_PLAIN: "text/plain",
     /**SDK Plugin Type**/
     SDK_TYPE_IDE: "js",
     SDK_TYPE_PHONEGAP: "phonegap",
     SDK_TYPE_PLAIN_JS: "plain-js",
     /**APP Session Type**/
     APP_SESSION_INTERACTIVE: "I",
     APP_SESSION_NON_INTERACTIVE: "NI",
     /**SDK Architecture Type**/
     SDK_ATYPE_NATIVE: "native",
     SDK_ATYPE_SPA: "spa",
     /**Device platform**/
     PLATFORM_WINDOWS: "windows",
     PLATFORM_ANDROID: "android",
     PLATFORM_IOS: "ios",
     PLATFORM_THIN_CLIENT: "web",
     //voltmx.os.device.info() for SPA returns thinclient
     PLATFORM_SPA: "thinclient",
     /***Metrics Constants**/
     REPORTING_PARAMS: "konyreportingparams",
     KEY_DEVICE_ID: "deviceID",
     KONY_METRICS_BUFFER: "konyMetricsBuffer",
     KONY_CUSTOM_REPORT_DATA: "konyCustomReportData",
     EVENT_BUFFER_MAX_COUNT: "eventBufferMaxCount",
     EVENT_BUFFER_AUTO_FLUSH_COUNT: "eventBufferAutoFlushCount",
     EVENT_SUB_TYPE: "evtSubType",
     FORM_ID: "formID",
     WIDGET_ID: "widgetID",
     FLOW_TAG: "flowTag",
     BUFFER: "BUFFER",
     CONFIG_TYPE: "confType",
     /**Headers**/
     APP_KEY_HEADER: "X-Voltmx-App-Key",
     APP_SECRET_HEADER: "X-Voltmx-App-Secret",
     KONY_AUTHORIZATION_HEADER: "X-Voltmx-Authorization",
     AUTHORIZATION_HEADER: "Authorization",
     REPORTING_HEADER: "X-Voltmx-ReportingParams",
     INTEGRITY_HEADER: "X-Voltmx-Integrity",
     DEVICEID_HEADER: "X-Voltmx-DeviceId",
     API_VERSION_HEADER: "X-Voltmx-API-Version",
     APP_VERSION_HEADER: "X-Voltmx-App-Version",
     SDK_TYPE_HEADER: "X-Voltmx-SDK-Type",
     SDK_VERSION_HEADER: "X-Voltmx-SDK-Version",
     PLATFORM_TYPE_HEADER: "X-Voltmx-Platform-Type",
     HTTP_OVERRIDE_HEADER: "X-HTTP-Method-Override",
     /**Volt MX Foundry constants**/
     HTTP_STATUS_CODE: "httpStatusCode",
     MF_OPSTATUS: "opstatus",
     MF_CODE: "mfcode",
     MF_ERROR_MSG: "errmsg",
     MF_ERROR_CODE: "errcode",
     MF_SERVICE: "service",
     KEY_RESPONSE_CODE: "responsecode",
     KEY_HTTP_RESPONSE: "httpresponse",
     HTTP_CODE_400: 400,
     HTTP_CODE_401: 401,
     /**Engagement service API constants**/
     SUBSCRIBE_AUDIENCE: "/subscribeaudience",
     BEACON_UPDATE: "/beaconupdate",
     RICH_PUSH_MESSAGE: "/messages/rich/",
     LAST_ACTIVE_DATE: "lastActiveDate",
     KSID: "ksid",
     AUTH_TOKEN: "authToken",
     DEVICE_AUTHTOKEN_HEADER: "X-Device-AuthToken",
     FUNCTION_STRING: "function",
     /**Parsed Template Constants**/
     PROCESSED_TEMPLATE: "processedTemplate",
     MISSING_VARIABLES: "missingVariables",
     /**Mandatory Binary Params**/
     FILE_PATH: "FilePath",
     RAW_BYTES: "rawBytes",
     FILE_OBJECT: "fileObject",
     FILE_NAME: "fileName",
     /**Miscellaneous**/
     KONYUUID: "konyUUID",
     BROWSER_WIDGET: "browserWidget",
     INIT_FAILURE_MESSAGE: "SDK is not initialized, call init before invoking any operation on",
     DISABLE_INTEGRITY: "disableIntegrity",
     PASSTHROUGH: "passthrough",
     BINARY_DATATYPE: "binary",
     JSON_DATA: "jsondata",
     IGNORE_MESSAGE_INTEGRITY: "ignoreMessageIntegrity",
     KEY_MESSAGE: "message",
     KEY_CODE: "code",
     EQUAL_TO: "=",
     /** License Constants **/
     LICENSE_SESSION_TIMEOUT_IN_MILLIS: 14400000,
     LICENSE_BG_TO_FG_SESSION_TIMEOUT_IN_MILLIS: 1800000,
     LICENSE_KONY_OFFLINE_ACCESS_DATA: "konyOfflineAccessData",
     /** SSO Constants **/
     DW_SSO_TOKEN_KEY: "ssoAuth",
     SSO_TOKEN_KEY: "ssoTokenKey",
     SSO_SECRET_KEY: "ssoSecretKey",
     SSO_ENCRYPTION_KEY: "ssoencryption",
     /** Encryption Constants **/
     ENCRYPTION_ALGO_AES: "aes",
     HASH_FUNCTION_MD5: "md5",
     HASH_FUNCTION_SHA2: "sha2",
     ENC_TYPE_PASSPHRASE: "passphrase",
     ENC_PASSPHRASE_HASH_ALGO: "passphrasehashalgo",
     AES_ALGO_KEY_STRENGTH_128: 128,
     AES_ALGO_KEY_STRENGTH_256: 256,
     ENCRYPTION_APPCONFIG_FLAG: "appConfig_v1",
     SHARED_CLIENT_IDENTIFIER: "shared_client_identifier",
     MOBILE_FABRIC_SERVICE_DOC: "mobileFabricServiceDoc",
     /** Auth Providers Types **/
     AUTH_PROVIDER_TYPE_SAML: "saml",
     AUTH_PROVIDER_TYPE_OAUTH2: "oauth2",
     /**Persist login constants**/
     PERSISTED_AUTH_RESPONSE: "persistedAuthResponse",
     PERSIST_LOGIN_RESPONSE_FLAG: "persistLoginResponseFlag",
     CUSTOM_DATA_SAVE_HANDLE: "customDataSaveHandle",
     /**single window login constants**/
     NO_POP_UP: "noPopup",
     LOGIN_OPTIONS: "loginOptions",
     URL_TYPE: "url_type",
     METADATA_MANAGER_FOR_LOGIN_IN_SAME_WINDOW_OBJECT: "metadata_manager_for_login_in_same_window_object",
     APP_VERIFIER_MW_STORE_ENDPOINT: "/ClientState",
     IS_ERROR: "isError",
     LOGIN_RESPONSE: "LOGIN_RESPONSE",
     SINGLE_WINDOW_LOGIN_BODY_PARAMS: "single_window_login_body_params",
     KEY_IS_SAME_WINDOW: "isSameWindow",
     KEY_METADATA_SDK_LOGIN_FOR_SAME_WINDOW: "key_metadata_sdk_login_for_same_window",
     KEY_APPCONFIG_FOR_SINGLE_WINDOW_LOGIN: "appConfigForSingleWindowLogin",
     /**Offline login constants**/
     OFFLINE_LOGIN_AUTH_RESPONSE: "authResponse",
     /** Passthrough constant **/
     PASSTHROUGH_RESPONSE_HEADER: "X-Voltmx-Passthrough",
     /**Server events constants**/
     SERVER_EVENTS_URL_ENDPOINT: "ServerEvents/Stream",
     SERVER_EVENTS_CLOSE_CONNECTION: "closeConnection",
     PERSISTED_REFRESH_LOGIN_PROVIDER_TOKENS: "persistedRefreshLoginProviderTokens",
     INTERNAL_REFRESH_TOKEN: "internalRefreshToken",
     BACKEND_REFRESH_TOKEN: "backendRefreshToken",
     ENABLE_REFRESH_LOGIN: "enable_refresh_login",
     BACKEND_REFRESH_TOKENS: "backend_refresh_tokens",
     RETAIN_BACKEND_REFRESH_TOKEN: "retain_backend_refresh_token",
     LOGIN_PROFILES: "profiles",
     LOGIN_PROVIDER_TYPE: "provider_type",
     /**Integration service constants**/
     INTEGRATION_SERVICE_KEY: "integsvc",
     INTEGRATION_INTERNAL_LOGOUT_URL: "_internal_logout",
     INTEGRATION_INTERNAL_CLEAR_SESSION_ENDPOINT: "clearSession",
     /** SDK Universal Constants **/
     CLIENT_SDK_UUID: "clientUUID",
     CLIENT_SDK_UNIVERSAL_SALT: "sdkIdentifier",
     /**custom params for oauth**/
     CUSTOM_QUERY_PARAMS_FOR_OAUTH: "customQueryParamsForOAuth",
     CUSTOM_OAUTH_PARAMS: "customOAuthParams",
     LOGOUT_OPTIONS: "logoutOptions"
 };
 if (typeof(voltmx.sdk) === "undefined") {
     voltmx.sdk = {};
 }
 if (typeof(voltmx.sdk.error) === "undefined") {
     voltmx.sdk.error = {};
 }
 voltmx.sdk.error.getAuthErrObj = function(errResponse) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getAuthErrObj");
     if (errResponse && errResponse.httpresponse) {
         delete errResponse.httpresponse;
     }
     if (errResponse && errResponse[voltmx.sdk.constants.MF_ERROR_MSG]) {
         errResponse["message"] = errResponse[voltmx.sdk.constants.MF_ERROR_MSG];
         delete errResponse.errmsg;
     }
     try {
         var mfcode = errResponse[voltmx.sdk.constants.MF_CODE];
         var message = errResponse["message"];
         var details = errResponse["details"];
         if (mfcode) {
             return voltmx.sdk.error.getMFcodeErrObj(mfcode, message, details, "");
         }
         return errResponse;
     } catch (err) {
         return errResponse;
     }
 }
 voltmx.sdk.error.getNullClaimsTokenErrObj = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getNullClaimsTokenErrObj");
     var errorObj = {};
     errorObj.opstatus = voltmx.sdk.errorcodes.cliams_token_null
     errorObj.message = voltmx.sdk.errormessages.cliams_token_null
     errorObj.details = {};
     errorObj.mfcode = "";
     return errorObj;
 }
 voltmx.sdk.error.getIdentitySessionInactiveErrObj = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getIdentitySessionInactiveErrObj");
     var errorObj = {};
     errorObj.opstatus = voltmx.sdk.errorcodes.identity_session_inactive
     errorObj.message = voltmx.sdk.errormessages.identity_session_inactive
     errorObj.details = {};
     errorObj.mfcode = "";
     return errorObj;
 }
 voltmx.sdk.error.getNullRefreshTokenErrObj = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getNullRefreshTokenErrObj");
     var errorObj = {};
     errorObj.opstatus = voltmx.sdk.errorcodes.invalid_session_or_token_expiry
     errorObj.message = voltmx.sdk.errormessages.invalid_session_or_token_expiry
     errorObj.details = {};
     errorObj.mfcode = "";
     return errorObj;
 }
 voltmx.sdk.error.getIntegrationErrObj = function(errResponse) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getIntegrationErrObj");
     try {
         var mfcode = errResponse[voltmx.sdk.constants.MF_CODE];
         var message = errResponse[voltmx.sdk.constants.MF_ERROR_MSG];
         var details = errResponse["mferrmsg"];
         var service = errResponse[voltmx.sdk.constants.MF_SERVICE];
         if (!service) {
             service = "";
         }
         if (!details) {
             details = "";
         }
         var errorMessagePrefixForIntegration = "";
         if (service) {
             errorMessagePrefixForIntegration = "Integration Service Request Failed for " + service + ":";
         } else {
             errorMessagePrefixForIntegration = "Integration Service Request Failed:";
         }
         if (mfcode) {
             return voltmx.sdk.error.getMFcodeErrObj(mfcode, message, details, errorMessagePrefixForIntegration);
         }
         return errResponse;
     } catch (err) {
         return errResponse;
     }
 }
 voltmx.sdk.error.getLogicErrObj = function(errResponse) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getLogicErrObj");
     try {
         var mfcode = errResponse[voltmx.sdk.constants.MF_CODE];
         var message = errResponse[voltmx.sdk.constants.MF_ERROR_MSG];
         var details = errResponse["mferrmsg"];
         var service = errResponse[voltmx.sdk.constants.MF_SERVICE];
         if (!service) {
             service = "";
         }
         if (!details) {
             details = "";
         }
         var errorMessagePrefixForLogic = "";
         if (service) {
             errorMessagePrefixForLogic = "Logic Service Request Failed for " + service + ":";
         } else {
             errorMessagePrefixForLogic = "Logic Service Request Failed:";
         }
         if (mfcode) {
             return voltmx.sdk.error.getMFcodeErrObj(mfcode, message, details, errorMessagePrefixForLogic);
         }
         return errResponse;
     } catch (err) {
         return errResponse;
     }
 }
 voltmx.sdk.error.getMFcodeErrObj = function(mfcode, message, details, errMessagePrefix) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getMFcodeErrObj");
     var errorObj = {};
     errorObj.details = {};
     if (details) {
         errorObj.details = details;
     }
     errorObj.mfcode = mfcode;
     if (mfcode === "Auth-4") {
         if (!message) {
             message = voltmx.sdk.errormessages.invalid_user_credentials
         }
         errorObj.opstatus = voltmx.sdk.errorcodes.invalid_user_credentials
         errorObj.message = errMessagePrefix + message;
     } else if (mfcode === "Auth-9") {
         if (!message) {
             message = voltmx.sdk.errormessages.invalid_app_credentials
         }
         errorObj.opstatus = voltmx.sdk.errorcodes.invalid_app_credentials
         errorObj.message = errMessagePrefix + message;
     } else if (mfcode === "Auth-3") {
         if (!message) {
             message = voltmx.sdk.errormessages.invalid_user_app_credentials
         }
         errorObj.opstatus = voltmx.sdk.errorcodes.invalid_user_app_credentials
         errorObj.message = errMessagePrefix + message;
     } else if ((mfcode === "Auth-5") || (mfcode === "Auth-6") || (mfcode === "Gateway-31") || (mfcode === "Gateway-33") || (mfcode === "Gateway-35") || (mfcode === "Gateway-36") || (mfcode === "Auth-46") || (mfcode === "Auth-55")) {
         errorObj.opstatus = voltmx.sdk.errorcodes.invalid_session_or_token_expiry
         errorObj.message = errMessagePrefix + voltmx.sdk.errormessages.invalid_session_or_token_expiry
     } else if (mfcode === "Auth-7" || mfcode === "Auth-27") {
         if (!message) {
             message = errMessagePrefix + voltmx.sdk.errormessages.invalid_user_app_services
         }
         errorObj.opstatus = voltmx.sdk.errorcodes.invalid_user_app_services
         errorObj.message = message;
     } else if (mfcode === "Auth-128") {
         errorObj.message = voltmx.sdk.errormessages.invalid_pkce_params;
         errorObj.opstatus = voltmx.sdk.errorcodes.invalid_pkce_params;
     } else if (mfcode === "Auth-129") {
         errorObj.details.errmsg = voltmx.sdk.errormessages.CORS_disabled_at_identity;
         errorObj.details.message = voltmx.sdk.errormessages.CORS_disabled_at_identity;
         errorObj.message = voltmx.sdk.errormessages.CORS_disabled_at_identity
         errorObj.opstatus = voltmx.sdk.errorcodes.CORS_disabled_at_identity;
     } else {
         errorObj.opstatus = voltmx.sdk.errorcodes.default_code
         errorObj.message = errMessagePrefix + voltmx.sdk.errormessages.default_message
     }
     return errorObj;
 }

 function getAuthErrorMessage(mfcode) {
     voltmx.sdk.logsdk.trace("Entering into getAuthErrorMessage");
     if (mfcode === "Auth-4") {
         return voltmx.sdk.errormessages.invalid_user_credentials
     } else if (mfcode === "Auth-9") {
         return voltmx.sdk.errormessages.invalid_app_credentials
     } else if (mfcode === "Auth-3") {
         return voltmx.sdk.errormessages.invalid_user_app_credentials
     } else if ((mfcode === "Auth-5") || (mfcode === "Auth-6") || (mfcode === "Gateway-31") || (mfcode === "Gateway-33") || (mfcode === "Gateway-35") || (mfcode === "Gateway-36") || (mfcode === "Auth-46") || (mfcode === "Auth-55")) {
         return voltmx.sdk.errormessages.invalid_session_or_token_expiry
     } else if (mfcode === "Auth-7" || mfcode === "Auth-27") {
         return voltmx.sdk.errormessages.invalid_user_app_services
     } else {
         return mfcode + ":" + voltmx.sdk.errormessages.default_message
     }
 }
 voltmx.sdk.error.getSingleWindowLoginErrObj = function(errorCode, errorMessage) {
     var errorObject = {};
     errorObject[voltmx.sdk.constants.KEY_CODE] = errorCode;
     errorObject[voltmx.sdk.constants.KEY_MESSAGE] = errorMessage;
     return errorObject;
 }
 voltmx.sdk.error.getErrObj = function(errorCode, errorMessage) {
     var err = {};
     err[voltmx.sdk.constants.KEY_CODE] = errorCode;
     err[voltmx.sdk.constants.KEY_MESSAGE] = errorMessage;
     return err;
 }
 voltmx.sdk.error.getObjectServiceErrObj = function(errResponse) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getObjectServiceErrObj");
     try {
         var mfcode = errResponse[voltmx.sdk.constants.MF_CODE];
         var message = errResponse[voltmx.sdk.constants.MF_ERROR_MSG];
         var details = errResponse["mferrmsg"];
         var service = errResponse[voltmx.sdk.constants.MF_SERVICE];
         if (!service) {
             service = "";
         }
         if (!details) {
             details = "";
         }
         var errorMessagePrefixForIntegration = "";
         if (service) {
             errorMessagePrefixForIntegration = "Object Service Request Failed for " + service + ":";
         } else {
             errorMessagePrefixForIntegration = "Object Service Request Failed:";
         }
         if (mfcode) {
             return voltmx.sdk.error.getMFcodeErrObj(mfcode, message, details, errorMessagePrefixForIntegration);
         }
         return errResponse;
     } catch (err) {
         return errResponse;
     }
 }
 voltmx.sdk.error.getClientErrObj = function(errCode, errMsg) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getClientErrObj");
     var errObj = new Object();
     errObj.opstatus = voltmx.sdk.errorcodes.clientvalidation_error_opstatus;
     errObj.errmsg = errMsg;
     errObj.errcode = errCode;
     return errObj;
 }
 voltmx.sdk.error.getMessagingError = function(errMsg) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getMessagingError");
     var errObj = new Object();
     errObj.opstatus = voltmx.sdk.errorcodes.messaging_service_fail;
     errObj.errmsg = voltmx.sdk.errormessages.messaging_service_fail + errMsg;
     errObj.errcode = voltmx.sdk.errorcodes.messaging_service_fail;
     return errObj;
 }
 voltmx.sdk.error.getConfigServiceErrObject = function(errResponse) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getConfigServiceErrObject");
     try {
         var mfcode = errResponse[voltmx.sdk.constants.MF_CODE];
         var message = errResponse[voltmx.sdk.constants.MF_ERROR_MSG];
         var details = errResponse["mferrmsg"];
         var service = errResponse[voltmx.sdk.constants.MF_SERVICE];
         if (!service) {
             service = "";
         }
         if (!details) {
             details = "";
         }
         var errorMessagePrefixForIntegration = "";
         if (service) {
             errorMessagePrefixForIntegration = "Configuration Service Request Failed for " + service + ":";
         } else {
             errorMessagePrefixForIntegration = "Configuration Service Request Failed:";
         }
         if (mfcode) {
             return voltmx.sdk.error.getMFcodeErrObj(mfcode, message, details, errorMessagePrefixForIntegration);
         }
         return errResponse;
     } catch (err) {
         return errResponse;
     }
 };
 voltmx.sdk.error.getIntegrityErrorMessage = function(httpRequest, url) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getIntegrityErrorMessage");
     var errorMessage = {};
     errorMessage.httpresponse = {};
     errorMessage[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.integrity_check_failed;
     errorMessage[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.integrity_check_failed;
     errorMessage[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.integrity_check_failed;
     errorMessage[voltmx.sdk.constants.HTTP_STATUS_CODE] = httpRequest.status.toString();
     errorMessage.httpresponse["response"] = httpRequest.response;
     errorMessage.httpresponse.headers = httpRequest.getAllResponseHeaders();
     errorMessage.httpresponse.url = url;
     errorMessage.httpresponse.responsecode = httpRequest.status.toString();
     return errorMessage;
 };
 voltmx.sdk.error.getOperationFailedErrorMessage = function(httpRequest, url) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.error.getOperationFailedErrorMessage");
     var errorMessage = {};
     errorMessage[voltmx.sdk.constants.MF_OPSTATUS] = httpRequest.response.opstatus;
     errorMessage[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.server_operation_failed;
     errorMessage[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.server_operation_failed;
     errorMessage[voltmx.sdk.constants.HTTP_STATUS_CODE] = httpRequest.status.toString();
     var httpResponse = {};
     httpResponse.response = httpRequest.response;
     httpResponse.headers = httpRequest.getAllResponseHeaders();
     httpResponse.responsecode = httpRequest.status.toString();
     httpResponse.url = url;
     errorMessage.httpResponse = httpResponse;
     return errorMessage;
 };
 if (typeof(voltmx.sdk) === "undefined") {
     voltmx.sdk = {};
 }
 if (typeof(voltmx.sdk.errorcodes) === "undefined") {
     voltmx.sdk.errorcodes = {};
 }
 if (typeof(voltmx.sdk.errormessages) === "undefined") {
     voltmx.sdk.errormessages = {};
 }
 voltmx.sdk.errorcodes.invalid_user_credentials = 101;
 voltmx.sdk.errormessages.invalid_user_credentials = "Invalid User Credentials.";
 voltmx.sdk.errorcodes.invalid_app_credentials = 102;
 voltmx.sdk.errormessages.invalid_app_credentials = "Invalid App Credentials.";
 voltmx.sdk.errorcodes.invalid_user_app_credentials = 103;
 voltmx.sdk.errormessages.invalid_user_app_credentials = "Invalid User/App Credentials.";
 voltmx.sdk.errorcodes.invalid_session_or_token_expiry = 104;
 voltmx.sdk.errormessages.invalid_session_or_token_expiry = "Session/Token got invalidated in the backend.Please login.";
 voltmx.sdk.errorcodes.invalid_user_app_services = 105;
 voltmx.sdk.errormessages.invalid_user_app_services = "Invalid provider in appServices.";
 voltmx.sdk.errorcodes.cliams_token_null = 106;
 voltmx.sdk.errormessages.cliams_token_null = "Claims Token is Unavialable";
 voltmx.sdk.errorcodes.identity_session_inactive = 107;
 voltmx.sdk.errormessages.identity_session_inactive = "Identity Provider's sessions is not active. Please login";
 voltmx.sdk.errorcodes.refresh_login_tokens_null_or_undefined = 108;
 voltmx.sdk.errormessages.refresh_login_tokens_null_or_undefined = "Required refresh tokens to enable refresh login are null or undefined";
 voltmx.sdk.errorcodes.app_verifier_save_failed = 109;
 voltmx.sdk.errormessages.app_verifier_save_failed = "Unable to store app verifier at middleware server";
 voltmx.sdk.errorcodes.app_verifier_retrieve_failed = 110;
 voltmx.sdk.errormessages.app_verifier_retrieve_failed = "Unable to retrieve app verifier from middleware server";
 voltmx.sdk.errorcodes.invalid_custom_data_save_handle = 111;
 voltmx.sdk.errormessages.invalid_custom_data_save_handle = "CustomDataSaveHandle should be function and should " + "accept successCallback and failureCallback";
 voltmx.sdk.errorcodes.custom_data_save_handle_failed = 112;
 voltmx.sdk.errormessages.custom_data_save_handle_failed = "CustomDataSaveHandle failed by user";
 voltmx.sdk.errorcodes.partial_login_error = 113;
 voltmx.sdk.errormessages.partial_login_error = "The application was launched with code query param but is not a continued login process";
 voltmx.sdk.errorcodes.CORS_disabled_at_identity = 114;
 voltmx.sdk.errormessages.CORS_disabled_at_identity = "Login Failed. PKCE parameters are missing, please check if CORS setting is properly configured in Fabric Identity";
 voltmx.sdk.errorcodes.invalid_pkce_params = 115;
 voltmx.sdk.errormessages.invalid_pkce_params = "Invalid PKCE params";
 voltmx.sdk.errorcodes.invalid_appconfig = 116;
 voltmx.sdk.errormessages.invalid_appconfig = "Appconfig is null or undefined.";
 voltmx.sdk.errorcodes.error_no_metadata_found = 117;
 voltmx.sdk.errormessages.error_no_metadata_found = "No metadata was found to continue with single window login";
 voltmx.sdk.errorcodes.invalid_auth_code = 118;
 voltmx.sdk.errormessages.invalid_auth_code = "No Auth Code found in the Url.";
 voltmx.sdk.errorcodes.pkce_params_generation_failed = 119;
 voltmx.sdk.errormessages.pkce_params_generation_failed = "Login Failed. Error occured while generating PKCE parameters.";
 voltmx.sdk.errorcodes.default_code = 100;
 voltmx.sdk.errormessages.default_message = "UnhandledMFcode";
 voltmx.sdk.errorcodes.unknown_error_code = 1000;
 voltmx.sdk.errormessages.unknown_error_message = "An unknown error has occured";
 voltmx.sdk.errorcodes.connectivity_error_code = 1011;
 voltmx.sdk.errormessages.connectivity_error_message = "An error occurred while making the request. Please check device connectivity, server url and request parameters";
 voltmx.sdk.errorcodes.invalid_json_code = 1013;
 voltmx.sdk.errormessages.invalid_json_message = "Invalid Json response was returned";
 voltmx.sdk.errorcodes.request_timed_out_code = 1014;
 voltmx.sdk.errormessages.request_timed_out_message = "Request to server has timed out";
 voltmx.sdk.errorcodes.offline_auth_failed = 1015;
 voltmx.sdk.errormessages.offline_auth_failed = "Offline Authentication failed, User should atleast login once when network connectivity is available.";
 voltmx.sdk.errorcodes.servicedoc_unavailable = 1016;
 voltmx.sdk.errormessages.servicedoc_unavailable = "MBAAS app is not initialized properly. Service document is unavailable.";
 voltmx.sdk.errorcodes.transient_login_fail = 1017;
 voltmx.sdk.errormessages.transient_login_fail = "Transient Login failed, Previous Identity Token expired in backend.";
 voltmx.sdk.errorcodes.messaging_service_fail = 1018;
 voltmx.sdk.errormessages.messaging_service_fail = "Failure in Messaging Service. ";
 voltmx.sdk.errorcodes.integrity_check_failed = 1019;
 voltmx.sdk.errormessages.integrity_check_failed = "Http message Body Integrity Check failed.";
 voltmx.sdk.errorcodes.invalid_security_key = 1023;
 voltmx.sdk.errormessages.invalid_security_key = "Security key should be a non empty string.";
 voltmx.sdk.errorcodes.server_operation_failed = 1020;
 voltmx.sdk.errormessages.server_operation_failed = "Operation Failed on server";
 voltmx.sdk.errorcodes.populating_template_failed = 1021;
 voltmx.sdk.errormessages.populating_template_failed = "Template population failed, template parameters are invalid or template is malformed";
 voltmx.sdk.errorcodes.service_unavailable = 1022;
 voltmx.sdk.errormessages.service_unavailable_message = "Service unavailable or cannot connect to host";
 voltmx.sdk.errorcodes.connection_timeout = 1023;
 voltmx.sdk.errormessages.connection_timeout_message = "Network call failed due to connection timeout";
 voltmx.sdk.errorcodes.clientvalidation_error_opstatus = 112233;
 //Invaild API's for phonegap and plain-js
 voltmx.sdk.errorcodes.invalid_api = 7000;
 voltmx.sdk.errormessages.invalid_api = "Invalid Operation name, Operation Failed.";
 //Object Service Error Messages
 voltmx.sdk.errorcodes.invalid_dataobject_instance = 90001;
 voltmx.sdk.errormessages.invalid_dataobject_instance = "Provided dataobject is invalid and should be instance of voltmx.sdk.dto.DataObject";
 voltmx.sdk.errorcodes.primarykey_unavailable = 90002;
 voltmx.sdk.errormessages.primarykey_unavailable = "Primary Keys missing, Operation Failed";
 voltmx.sdk.errorcodes.null_or_undefined = 90003;
 voltmx.sdk.errormessages.null_or_undefined = " cannot be null or undefined";
 voltmx.sdk.errorcodes.transaction_failed = 90004;
 voltmx.sdk.errormessages.transaction_failed = "Some error occurred, Operation Failed";
 voltmx.sdk.errorcodes.norecords_to_delete = 90005;
 voltmx.sdk.errormessages.norecords_to_delete = "No records deleted with the specified criteria";
 voltmx.sdk.errorcodes.invalid_queryparams_instance = 90006;
 voltmx.sdk.errormessages.invalid_queryparams_instance = "Provided queryParams is invalid and should be a json object";
 voltmx.sdk.errorcodes.invalid_params_instance = 90007;
 voltmx.sdk.errormessages.invalid_params_instance = "Provided params are invalid";
 voltmx.sdk.errorcodes.invalid_object = 90008;
 voltmx.sdk.errormessages.invalid_object = "Invalid object name, Operation Failed.";
 voltmx.sdk.errorcodes.invalid_blob = 90009;
 voltmx.sdk.errormessages.invalid_blob = "Failed to read from binary file, either the file does not exist or invalid";
 voltmx.sdk.errorConstants = {
     INIT_FAILURE: "INIT_FAILURE",
     DATA_STORE_EXCEPTION: "DATASTORE_FAILURE",
     AUTH_FAILURE: "AUTH_FAILURE",
     INTEGRATION_FAILURE: "INTEGRATION_FAILURE",
     MESSAGING_FAILURE: "MESSAGING_FAILURE",
     SYNC_FAILURE: "SYNC_FAILURE",
     METRICS_FAILURE: "METRICS_FAILURE",
     MISC_FAILURE: "MISCELLANEOUS_FAILURE",
     OBJECT_FAILURE: "OBJECT_FAILURE",
     LOGIC_SERVICE_FAILURE: "LOGIC_SERVICE_FAILURE",
     SYNC_V2_FAILURE: "SYNC_V2_FAILURE",
     CONFIGURATION_URL_FAILURE: "CONFIGURATION_URL_FAILURE",
     CONFIGURATION_FAILURE: "CONFIGURATION_FAILURE",
     INTEGRITY_FAILURE: "INTEGRITY_FAILURE",
     INVALID_API_FAILURE: "INVALID_API_FAILURE"
 };
 voltmx.sdk.offline = voltmx.sdk.offline || {};
 voltmx.sdk.sso = voltmx.sdk.sso || {};
 voltmx.sdk.pkceUtilityInstance = null;
 voltmx.sdk.isSSOLoginSuccess = voltmx.sdk.isSSOLoginSuccess || true;
 voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh = {};
 /**
  * This function will resume the oauth2 login process after oauth code retrieval part.
  * This function takes auth code as input and will call loginCompleteCallback with appropriate repsonse
  * @param code
  * @param loginCompleteCallback
  */
 voltmx.sdk.completeSingleWindowLogin = function(code, loginCompleteCallback) {
         voltmx.sdk.logsdk.info("Entering completeSingleWindowLogin");
         voltmx.application.removeQueryParamsByKey(voltmx.sdk.constants.DEEPLINK_VALID_PARAM);
         if (voltmx.sdk.isNullOrUndefined(code)) {
             voltmx.sdk.logsdk.info("code is undefined");
             return loginCompleteCallback();
         }
         var bodyParams = {};
         var loginOptions = null;
         var metaDataManagerForLoginInSameWindow = voltmx.sdk.util.getMetaDataManagerForLoginInSameWindow();

         function performTokenCall(networkResponseJSON) {
             voltmx.sdk.logsdk.info("Entering performTokenCall");
             if (is_enable_identity_pkce === true && !voltmx.sdk.isNullOrUndefined(networkResponseJSON[voltmx.sdk.constants.APP_VERIFIER])) {
                 bodyParams[voltmx.sdk.constants.APP_VERIFIER] = networkResponseJSON[voltmx.sdk.constants.APP_VERIFIER];
             }
             bodyParams[voltmx.sdk.constants.DEEPLINK_VALID_PARAM] = code;
             delete loginOptions[voltmx.sdk.constants.NO_POP_UP]; //avoiding circular logins
             //make login
             var options = {};
             options[voltmx.sdk.constants.LOGIN_OPTIONS] = loginOptions;
             options[voltmx.sdk.constants.SINGLE_WINDOW_LOGIN_BODY_PARAMS] = bodyParams; //this param will tell us to by pass auth code process
             var provider = metaDataManagerForLoginInSameWindow.getItem(voltmx.sdk.constants.KEY_PROVIDER);
             var sdkInstance = voltmx.sdk.getDefaultInstance();
             var identityInstance = sdkInstance.getIdentityService(provider);
             identityInstance.login(options, successCallback, failureCallback);
         }

         function successCallback(successResponse) {
             var successLoginResponse = {};
             successLoginResponse[voltmx.sdk.constants.IS_ERROR] = false;
             successLoginResponse[voltmx.sdk.constants.LOGIN_RESPONSE] = successResponse;
             voltmx.sdk.logsdk.info("Exiting completeSingleWindowLogin with success");
             voltmx.sdk.verifyAndCallClosure(loginCompleteCallback, successLoginResponse)
         }

         function failureCallback(errorObject) {
             var errorLoginResponse = {};
             errorLoginResponse[voltmx.sdk.constants.IS_ERROR] = true;
             errorLoginResponse[voltmx.sdk.constants.LOGIN_RESPONSE] = errorObject;
             metaDataManagerForLoginInSameWindow.destroy();
             voltmx.sdk.logsdk.info("Exiting completeSingleWindowLogin with failure");
             voltmx.sdk.verifyAndCallClosure(loginCompleteCallback, errorLoginResponse)
         }
         metaDataManagerForLoginInSameWindow.initialize();
         metaDataManagerForLoginInSameWindow.loadSavedMetaData(); //gets the saved data from local
         loginOptions = metaDataManagerForLoginInSameWindow.getItem(voltmx.sdk.constants.LOGIN_OPTIONS);
         is_enable_identity_pkce = metaDataManagerForLoginInSameWindow.getItem(voltmx.sdk.constants.ENABLE_IDENTITY_PKCE);
         if (voltmx.sdk.isNullOrUndefined(loginOptions)) {
             voltmx.sdk.logsdk.error(voltmx.sdk.errormessages.partial_login_error);
             var errorObject = voltmx.sdk.error.getSingleWindowLoginErrObj(voltmx.sdk.errorcodes.partial_login_error, voltmx.sdk.errormessages.partial_login_error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObject);
             return;
         }
         if (is_enable_identity_pkce === true) {
             metaDataManagerForLoginInSameWindow.retrieveAppVerifier(performTokenCall, failureCallback);
         } else {
             performTokenCall({});
         }
     }
     /**
      * Method to create the Identity service instance with the provided provider name.
      * @param {string} providerName - Name of the provider
      * @returns {IdentityService} Identity service instance
      */
 voltmx.sdk.prototype.getIdentityService = function(providerName) {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.prototype.getIdentityService");
     if (!voltmx.sdk.isInitialized) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + " Identity service.");
     }
     var provider = null;
     if (providerName) {
         if (this.login != null) {
             for (var i = 0; i < this.login.length; i++) {
                 var rec = this.login[i];
                 if ((rec.alias && rec.alias.toUpperCase() === providerName.toUpperCase()) || (rec.prov.toUpperCase() === providerName.toUpperCase())) {
                     provider = new IdentityService(this, rec);
                     break;
                 }
             }
             if (provider === null) {
                 throw new Exception(voltmx.sdk.errorConstants.AUTH_FAILURE, "Invalid providerName");
             }
             //TODO: what if the providerName is not passed by the user? 
             voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.getIdentityService");
             voltmx.sdk.logsdk.debug("### auth:: returning authService for providerName = " + provider.getProviderName());
             return provider;
         }
     } else {
         throw new Exception(voltmx.sdk.errorConstants.AUTH_FAILURE, "Invalid providerName");
     }
 };
 /**
  * Should not be called by the developer.
  * @class
  * @classdesc Identity service instance for handling login/logout calls.
  */
 function IdentityService(voltmxRef, rec) {
     voltmx.sdk.logsdk.perf("Executing IdentityService");
     var networkProvider = new voltmxNetworkProvider();
     var dataStore = new voltmxDataStore();
     var serviceObj = rec;
     voltmxRef.rec = rec;
     var is_mfa_enabled = false;
     if (!voltmx.sdk.isNullOrUndefined(rec[voltmx.sdk.constants.IS_MFA_ENABLED])) {
         is_mfa_enabled = rec[voltmx.sdk.constants.IS_MFA_ENABLED];
     }
     var mfa_meta = {};
     if (!voltmx.sdk.isNullOrUndefined(rec[voltmx.sdk.constants.MFA_META])) {
         mfa_meta = rec[voltmx.sdk.constants.MFA_META];
     }
     var mainRef = voltmxRef.mainRef;
     var user_attributes = {};
     var offlineEnabled = false;
     var persistToken = false;
     if (serviceObj === undefined || serviceObj.prov == undefined || serviceObj.type == undefined) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "Invalid service url and service type");
     }
     var _type = serviceObj.type;
     var _serviceUrl = stripTrailingCharacter(serviceObj.url, "/");
     var _providerName = serviceObj.prov;
     var is_enable_identity_pkce = serviceObj.enable_identity_pkce === true;
     //refresh login changes
     var refreshLoginEnabled = false;
     var refreshLoginTokenStoreUtilityObject = voltmx.sdk.util.getRefreshLoginTokenStoreUtility();
     var metaDataManagerForLoginInSameWindow = voltmx.sdk.util.getMetaDataManagerForLoginInSameWindow();
     var providerType = rec[voltmx.sdk.constants.LOGIN_PROVIDER_TYPE];
     voltmx.sdk.logsdk.debug("### AuthService:: initialized for provider " + _providerName + " with type " + _type);

     function isLoggedIn() {
         if (voltmx.sdk.getCurrentInstance() && voltmx.sdk.getCurrentInstance().tokens && voltmx.sdk.getCurrentInstance().tokens.hasOwnProperty(_providerName) && !voltmx.sdk.isNullOrUndefined(voltmx.sdk.getCurrentInstance().tokens[_providerName]) && Object.keys(voltmx.sdk.getCurrentInstance().tokens[_providerName]).length !== 0) {
             return true;
         }
         return false;
     }
     var dsKey = _serviceUrl + "::" + _providerName + "::" + _type + "::RAW";

     function resetAllCurrentTokens(voltmxRef, _providerName) {
         voltmx.sdk.resetProviderKeys(voltmxRef, _providerName);
     }
     /**
      * Register / Sign-Up a new user asynchronously and executes the given callback.
      * @param {object} params - Userid, password, firstName, lastname, phone)
      * e.g. {
      *     "userid":"john.doe@abc.com",
      *     "password":"Qwerty@123"'
      *		"first_name":"John",
      *		"last_name":"Doe",
      *		"phone":"1234569870"		// Phone- Not mandatory
      * }
      * @param {function} successCallback  - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {object} options
      */
     this.register = function(params, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing Register");

         function invokeAjaxCall(url, params, headers) {
             if (voltmx.sdk.isNullOrUndefined(headers)) {
                 headers = {};
             }
             headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
             headers[voltmx.sdk.constants.APP_KEY_HEADER] = mainRef.appKey;
             headers[voltmx.sdk.constants.APP_SECRET_HEADER] = mainRef.appSecret;
             headers[voltmx.sdk.constants.SDK_TYPE_HEADER] = voltmx.sdk.getSdkType();
             headers[voltmx.sdk.constants.SDK_VERSION_HEADER] = voltmx.sdk.version;
             headers[voltmx.sdk.constants.PLATFORM_TYPE_HEADER] = voltmx.sdk.getPlatformName();
             headers[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
             headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
             populateHeaderWithFoundryAppVersion(headers);
             if (voltmxRef.reportingheaders_allowed) {
                 if (!voltmx.sdk.isNullOrUndefined(reportingData)) {
                     headers[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
                 }
             }
             var networkOptions = voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options, false);
             networkProvider.post(url, params, headers, localSuccessCallback, localFailureCallback, null, networkOptions);
         }

         function localFailureCallback(error) {
             voltmx.sdk.logsdk.perf("Register finished with Failure");
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }

         function localSuccessCallback(data) {
             voltmx.sdk.logsdk.perf("Register finished with Success");
             var response = {};
             response["status"] = data.status;
             voltmx.sdk.verifyAndCallClosure(successCallback, response);
         }
         voltmx.sdk.logsdk.debug("### AuthService:: Invoked Register call  for provider " + _providerName);
         var reportingData = null;
         if (voltmx.sdk.isNullOrUndefined(params)) {
             throw new Exception(voltmx.sdk.errorConstants.AUTH_FAILURE, "Missing required params to register function");
         }

         function invokeSignUp() {
             var endPointUrl = _serviceUrl + "/signup/register?provider=" + _providerName;
             reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid("register_" + _providerName);
             params["provider"] = _providerName;
             invokeAjaxCall(endPointUrl, params, null);
         }
         voltmx.sdk.claimsRefresh(invokeSignUp, failureCallback);
     };

     function genericPostLoginSuccessCallback(networkResponse, successCallback) {
         var response = processLoginSuccessResponse(networkResponse, voltmxRef, false);
         if (!voltmx.sdk.isNullOrUndefined(response.mfa_response) && !voltmx.sdk.isNullOrUndefined(response.mfa_response[voltmx.sdk.constants.IS_MFA_ENABLED])) {
             is_mfa_enabled = response.mfa_response[voltmx.sdk.constants.IS_MFA_ENABLED];
             mfa_meta = response.mfa_response[voltmx.sdk.constants.MFA_META];
             delete response.mfa_response;
         }

         function serviceDocCallback() {
             //if refresh login is enabled, store the required internal refresh and backend refresh tokens in data store
             if (refreshLoginEnabled) {
                 voltmxRef.refreshLoginProvidersSet.add(_providerName);
                 storeRefreshLoginTokens(networkResponse);
             }
             voltmx.sdk.verifyAndCallClosure(successCallback, response);
         }
         /**
          * This function checks whether the required refresh tokens exist as part of login response
          * @param {Object} data - containing login response containing security attributes as well
          * @returns {boolean} - true if the required refresh tokens available to make refresh login else false
          */
         function areRequiredRefreshTokensForRefreshLoginAvailable(data) {
             if (voltmx.sdk.isNullOrUndefined(voltmxRef.currentRefreshToken) || voltmx.sdk.isNullOrUndefined(data[voltmx.sdk.constants.BACKEND_REFRESH_TOKENS]) || voltmx.sdk.isNullOrUndefined(data[voltmx.sdk.constants.BACKEND_REFRESH_TOKENS][_providerName])) {
                 return false;
             }
             return true;
         }
         /**
          * This function stores backend and internal refresh tokens in data store for subsequent refresh login
          * @param data containing security attributes
          */
         function storeRefreshLoginTokens(data) {
             voltmx.sdk.logsdk.info("Entering storeRefreshLoginTokens");
             if (!areRequiredRefreshTokensForRefreshLoginAvailable(data)) {
                 voltmx.sdk.logsdk.error("required refresh tokens doesn't exist in data store to enable refresh login");
                 var errObject = voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.refresh_login_tokens_null_or_undefined, voltmx.sdk.errormessages.refresh_login_tokens_null_or_undefined);
                 //adding errObject to login response
                 Object.assign(response, errObject);
                 return;
             }
             var tokensData = {};
             tokensData[voltmx.sdk.constants.INTERNAL_REFRESH_TOKEN] = voltmxRef.currentRefreshToken;
             tokensData[voltmx.sdk.constants.BACKEND_REFRESH_TOKEN] = data[voltmx.sdk.constants.BACKEND_REFRESH_TOKENS][_providerName];
             voltmx.sdk.logsdk.info("storing provider specific internal and backend refresh tokens");
             refreshLoginTokenStoreUtilityObject.storeTokens(_providerName, tokensData);
             //setting the internal refresh token for current loggedin providers in data store based on login profiles
             if (!voltmx.sdk.isNullOrUndefined(data[voltmx.sdk.constants.LOGIN_PROFILES])) {
                 var listOfLoginProfiles = Object.keys(data[voltmx.sdk.constants.LOGIN_PROFILES]);
                 refreshLoginTokenStoreUtilityObject.setInternalRefreshToken(listOfLoginProfiles, voltmxRef.currentRefreshToken);
             }
         }
         getLatestServiceDocIfAvailable(networkResponse, serviceDocCallback);
     }
     /**
      * Login with the given credentials asynchronously and executes the given callback.
      * @param {object} options - User name and password
      * @param {function} successCallback  - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     this.login = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf("Executing Login");
         voltmx.sdk.pkceUtilityInstance = null;
         var continueOnRefreshError = true;
         var customQueryParamsForOAuth = null;
         var customOAuthParams = null;
         var isSingleWindowLoginEnabled = false;
         var customDaveSaveHandleFunction = null;

         function invokeAjaxCall(url, params, headers) {
             if (!headers) {
                 headers = {};
             }
             voltmx.sdk.util.populateAuthorizationHeaderForLogin(headers, _providerName);
             if (voltmx.sdk.isNullOrUndefined(mainRef.appKey) || voltmx.sdk.isNullOrUndefined(mainRef.appSecret)) {
                 var formID = "P:" + _type;
                 var widgetID = "AK:" + mainRef.appKey + ",  AS:" + mainRef.appSecret;
                 var flowTag = "Login Call";
                 voltmx.sdk.util.recordAndFlushCustomEvent("INVALID APP CREDENTIALS", formID, widgetID, flowTag, null);
             }
             headers[voltmx.sdk.constants.APP_KEY_HEADER] = mainRef.appKey;
             headers[voltmx.sdk.constants.APP_SECRET_HEADER] = mainRef.appSecret;
             headers[voltmx.sdk.constants.SDK_TYPE_HEADER] = voltmx.sdk.getSdkType();
             headers[voltmx.sdk.constants.SDK_VERSION_HEADER] = voltmx.sdk.version;
             headers[voltmx.sdk.constants.PLATFORM_TYPE_HEADER] = voltmx.sdk.getPlatformName();
             headers[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
             headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
             populateHeaderWithFoundryAppVersion(headers);
             //populating custom oAuth params
             if (providerType === voltmx.sdk.constants.AUTH_PROVIDER_TYPE_OAUTH2) {
                 voltmx.sdk.util.populateCustomOAuthParams(params, customOAuthParams);
             }
             if (voltmxRef.reportingheaders_allowed) {
                 // get reporting data for login operation
                 var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid("login_" + _providerName);
                 if (reportingData != null && reportingData != undefined) {
                     try {
                         headers[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
                     } catch (error) {
                         voltmx.sdk.logsdk.error("### login::error while parsing metrics payload" + error);
                     }
                 }
             }
             var endPointUrl = null;
             if (_type === "anonymous") {
                 endPointUrl = _serviceUrl + url;
             } else {
                 endPointUrl = _serviceUrl + url + "?provider=" + _providerName;
                 params["provider"] = _providerName;
             }
             //Save the user entered form data to a temporary store and only if login is successful, we store the value in this to proper credentials store.
             if (voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE && (_type === "basic" || (options && options["userid"] && options["password"])) && offlineEnabled === true) {
                 voltmx.sdk.offline.saveTempUserCredentials(options);
                 if (!voltmx.sdk.isNetworkAvailable()) {
                     voltmx.sdk.offline.loginOffline(_providerName, function(cachedAuthResponse) {
                         voltmx.sdk.logsdk.info("successfully authenticated offline");
                         processLoginSuccessResponse(cachedAuthResponse, voltmxRef, true, successCallback);
                     }, function(error) {
                         voltmx.sdk.logsdk.error("offline authentication also failed");
                         resetAllCurrentTokens(voltmxRef, _providerName);
                         if (failureCallback) {
                             failureCallback(voltmx.sdk.error.getAuthErrObj(error));
                         }
                     });
                     return;
                 }
             }
             var networkOptions = {};
             if (!voltmx.sdk.isNullOrUndefined(options)) {
                 if (!voltmx.sdk.isNullOrUndefined(options["httpRequestOptions"]) && options["httpRequestOptions"] instanceof Object) {
                     networkOptions["httpRequestOptions"] = options["httpRequestOptions"];
                 }
                 if (!voltmx.sdk.isNullOrUndefined(options["xmlHttpRequestOptions"]) && options["xmlHttpRequestOptions"] instanceof Object) {
                     networkOptions["xmlHttpRequestOptions"] = options["xmlHttpRequestOptions"];
                 }
                 if (!voltmx.sdk.isNullOrUndefined(options["include_profile"])) {
                     params["include_profile"] = params["include_profile"] ? params["include_profile"] : options["include_profile"];
                 }
                 //Passing enable_refresh_login as body param to login call to get the backend refresh token as part of initial login response
                 if (refreshLoginEnabled) {
                     params[voltmx.sdk.constants.ENABLE_REFRESH_LOGIN] = true;
                     voltmxRef.refreshLoginProvidersSet.add(_providerName);
                 } else {
                     if (voltmxRef.refreshLoginProvidersSet.has(_providerName)) {
                         voltmxRef.refreshLoginProvidersSet.delete(_providerName);
                     }
                 }
             }
             if (is_enable_identity_pkce) {
                 if (voltmx.sdk.isNullOrUndefined(networkOptions[voltmx.sdk.constants.KEY_XML_HTTP_REQUEST_OPTIONS])) {
                     networkOptions[voltmx.sdk.constants.KEY_XML_HTTP_REQUEST_OPTIONS] = {};
                 }
                 networkOptions[voltmx.sdk.constants.KEY_XML_HTTP_REQUEST_OPTIONS][voltmx.sdk.constants.ENABLE_WITH_CREDENTIALS] = true;
             }
             networkProvider.post(endPointUrl, params, headers, function(data) {
                 genericPostLoginSuccessCallback(data, successCallback);
             }, function(data) {
                 processLoginErrorResponse(data, voltmxRef, true, failureCallback)
             }, null, networkOptions);
         }

         function loginHelper(url, params, headers, isError, errorObject) {
             voltmx.sdk.logsdk.trace("Entering loginHelper, isError = " + isError);
             if (isError) {
                 var err = {};
                 if (!voltmx.sdk.isNullOrUndefined(errorObject)) {
                     err = errorObject;
                 } else {
                     err.message = "Login Failed";
                     err.opstatus = voltmx.sdk.errorcodes.transient_login_fail;
                     err.code = (params && params.error) ? params.error : "";
                 }
                 voltmx.sdk.verifyAndCallClosure(failureCallback, err);
                 return;
             }
             if (!voltmx.sdk.isNullOrUndefined(voltmxRef.currentClaimToken) && !voltmxRef.isAnonymousProvider) {
                 voltmx.sdk.claimsRefresh(function(res) {
                     invokeAjaxCall(url, params, headers);
                 }, function(err) {
                     if (continueOnRefreshError) {
                         voltmx.sdk.logsdk.error("### AuthService::login claimsRefresh failed, performing force login");
                         invokeAjaxCall(url, params, headers);
                     } else {
                         voltmx.sdk.logsdk.error("### AuthService::login claimsRefresh failed, invoking failurecallback");
                         err.message = voltmx.sdk.errormessages.transient_login_fail;
                         err.opstatus = voltmx.sdk.errorcodes.transient_login_fail;
                         voltmx.sdk.verifyAndCallClosure(failureCallback, err);
                     }
                 });
             } else {
                 voltmx.sdk.logsdk.info("### AuthService::login Claims token unavailable, performing regular login");
                 invokeAjaxCall(url, params, headers);
             }
         }

         function loginForDeeplink(deeplinkOptions) {
             voltmx.sdk.logsdk.trace("Entering loginForDeeplink");
             if (deeplinkOptions) {
                 var code = deeplinkOptions[voltmx.sdk.constants.DEEPLINK_VALID_PARAM];
                 var urlType = deeplinkOptions["urlType"];
                 try {
                     voltmx.sdk.logsdk.debug("### AuthService::login received authorization code");
                     loginHelper("/" + urlType + "/" + "token", {
                         code: code
                     }, {});
                 } catch (err) {
                     voltmx.sdk.logsdk.error("exception ::" + err);
                     failureCallback();
                 }
             }
         }

         function extractLoginOptions(loginOptions) {
             if (!voltmx.sdk.isNullOrUndefined(loginOptions)) {
                 offlineEnabled = loginOptions["isOfflineEnabled"] || false;
                 voltmx.sdk.offline.isOfflineEnabled = voltmx.sdk.offline.isOfflineEnabled || offlineEnabled;
                 voltmx.sdk.sso.isSSOEnabled = loginOptions["isSSOEnabled"] || false;
                 customQueryParamsForOAuth = loginOptions[voltmx.sdk.constants.CUSTOM_QUERY_PARAMS_FOR_OAUTH];
                 if (loginOptions["continueOnRefreshError"] === false) {
                     continueOnRefreshError = false;
                 }
                 if (loginOptions["persistLoginResponse"] === true) {
                     persistToken = true;
                     dataStore.setItem(voltmx.sdk.constants.PERSIST_LOGIN_RESPONSE_FLAG, true);
                     voltmx.sdk.offline.persistToken = true;
                 }
                 refreshLoginEnabled = false;
                 if (providerType === voltmx.sdk.constants.AUTH_PROVIDER_TYPE_OAUTH2) {
                     //Extracting enable_refresh_login flag from login options
                     if (typeof loginOptions[voltmx.sdk.constants.ENABLE_REFRESH_LOGIN] === "boolean") {
                         refreshLoginEnabled = loginOptions[voltmx.sdk.constants.ENABLE_REFRESH_LOGIN];
                     } else {
                         voltmx.sdk.logsdk.warn("the value of " + voltmx.sdk.constants.ENABLE_REFRESH_LOGIN + " should be of boolean type");
                     }
                     //Extracting customOAuthParams from login options
                     customOAuthParams = loginOptions[voltmx.sdk.constants.CUSTOM_OAUTH_PARAMS];
                     if (!voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(customOAuthParams)) {
                         voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[_providerName] = {};
                         //populating custom oAuth params in global voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh object so that these
                         // params will be used in /claims?refresh=true call which happens when server throws 401 status code incase of service call
                         // failure
                         voltmx.sdk.util.populateCustomOAuthParams(voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[_providerName], customOAuthParams);
                     }
                 }
                 //no popup option in single window login are only meant for SPA/DW and PlainJS apps
                 if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_THIN_CLIENT && loginOptions[voltmx.sdk.constants.NO_POP_UP] === true && !voltmx.sdk.isNullOrUndefined(voltmx.license.saveCurrentSessionForReuse)) {
                     isSingleWindowLoginEnabled = true;
                     customDaveSaveHandleFunction = loginOptions[voltmx.sdk.constants.CUSTOM_DATA_SAVE_HANDLE];
                     if (!voltmx.sdk.util.isPlatformPlainJS() && voltmx.sdk.getSdkType() !== voltmx.sdk.constants.SDK_TYPE_PHONEGAP) {
                         voltmx.license.saveCurrentSessionForReuse();
                     }
                     metaDataManagerForLoginInSameWindow.initialize();
                     metaDataManagerForLoginInSameWindow.setItem(voltmx.sdk.constants.LOGIN_OPTIONS, loginOptions);
                     metaDataManagerForLoginInSameWindow.setItem(voltmx.sdk.constants.KEY_PROVIDER, _providerName);
                     metaDataManagerForLoginInSameWindow.setItem(voltmx.sdk.constants.URL_TYPE, "/" + _type + "/token");
                 }
             } else {
                 voltmx.sdk.sso.isSSOEnabled = false;
             }
         }

         function extractOauthOptions(authOptions) {
             var _oauthOptions = {};
             _oauthOptions[voltmx.sdk.constants.CUSTOM_QUERY_PARAMS_FOR_OAUTH] = customQueryParamsForOAuth;
             _oauthOptions[voltmx.sdk.constants.IS_ENABLE_IDENTITY_PKCE] = is_enable_identity_pkce === true;
             if (voltmx.sdk.util.isValidString(authOptions[voltmx.sdk.constants.IE11_CROSS_DOMAIN_OAUTH_BASE_URL])) {
                 _oauthOptions[voltmx.sdk.constants.IE11_CROSS_DOMAIN_OAUTH_BASE_URL] = authOptions[voltmx.sdk.constants.IE11_CROSS_DOMAIN_OAUTH_BASE_URL];
             }
             if (voltmx.sdk.util.hasBrowserWidget(authOptions)) {
                 _oauthOptions[voltmx.sdk.constants.BROWSER_WIDGET] = authOptions[voltmx.sdk.constants.BROWSER_WIDGET];
             } else {
                 if (authOptions["UseDeviceBrowser"]) {
                     //Validating to check the existence of param "UseDeviceBrowser".
                     // if found login url will be opened in device native browser, else in browser widget.
                     _oauthOptions["UseDeviceBrowser"] = authOptions["UseDeviceBrowser"];
                 }
                 if (authOptions[voltmx.sdk.constants.OAUTH_REDIRECT_SUCCESS_URL]) {
                     //Validating to check the existence of param "success_url".
                     // if found after login success we will redirect to the url specified in param "success_url".
                     var success_url = authOptions[voltmx.sdk.constants.OAUTH_REDIRECT_SUCCESS_URL];
                     //Encoding is being done specifically for android because, in android voltmx.application.openUrl is not
                     // opening the url without encoding where as in ios its encoding and opening.
                     if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_ANDROID) {
                         //decoding and encoding, to handle the case where in the user himself is giving us the encoded value.
                         success_url = encodeURIComponent(decodeURIComponent(success_url));
                     }
                     _oauthOptions[voltmx.sdk.constants.OAUTH_REDIRECT_SUCCESS_URL] = success_url;
                 }
                 //nopop of single window login are only meant for SPA/DW apps
                 if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_THIN_CLIENT && isSingleWindowLoginEnabled === true) {
                     _oauthOptions[voltmx.sdk.constants.NO_POP_UP] = isSingleWindowLoginEnabled;
                     _oauthOptions[voltmx.sdk.constants.CUSTOM_DATA_SAVE_HANDLE] = customDaveSaveHandleFunction;
                     _oauthOptions[voltmx.sdk.constants.METADATA_MANAGER_FOR_LOGIN_IN_SAME_WINDOW_OBJECT] = metaDataManagerForLoginInSameWindow;
                 }
             }
             //no popup in single window login are only meant for SPA/DW and PlainJS apps
             if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_THIN_CLIENT && isSingleWindowLoginEnabled === true) {
                 _oauthOptions[voltmx.sdk.constants.NO_POP_UP] = isSingleWindowLoginEnabled;
                 _oauthOptions[voltmx.sdk.constants.CUSTOM_DATA_SAVE_HANDLE] = customDaveSaveHandleFunction;
                 _oauthOptions[voltmx.sdk.constants.METADATA_MANAGER_FOR_LOGIN_IN_SAME_WINDOW_OBJECT] = metaDataManagerForLoginInSameWindow;
             }
             return _oauthOptions;
         }

         function isMFVersionCompatible() {
             //To provide backward compatibility, if MF is an older it will not have the changes for blocking the popup or opening the login url in the native browser.
             //Identity will add a new tuple in the service doc "identity_meta". SDK will validate the compatibility with the existance of serviceDoc["identity_meta"][<priovider_name>]["success_url"]
             if (mainRef && mainRef.config && mainRef.config.identity_meta && mainRef.config.identity_meta[_providerName] && mainRef.config.identity_meta[_providerName]["success_url"]) {
                 return true;
             }
             return false;
         }

         function performBasicOrCustomLogin(basicLoginOptions) {
             if (voltmx.sdk.sso.isSSOEnabled === false) {
                 // check for mandatory params only if auth type is basic.(includes custom auth mandatory fields)
                 if (_type == "basic") {
                     var mandatory_fields = ["userid", "password"];
                     if (serviceObj.mandatory_fields && voltmx.sdk.isArray(serviceObj.mandatory_fields)) {
                         mandatory_fields = serviceObj.mandatory_fields;
                     }
                     for (var i = 0; i < mandatory_fields.length; ++i) {
                         if (voltmx.sdk.isNullOrUndefined(basicLoginOptions[mandatory_fields[i]])) {
                             throw new Exception(voltmx.sdk.errorConstants.AUTH_FAILURE, " Require " + mandatory_fields[i]);
                         }
                     }
                 }
             }
             var payload = {};
             for (var option in basicLoginOptions) {
                 payload[option] = basicLoginOptions[option];
             }
             loginHelper("/login", payload, {});
         }

         function performOauthOrSamlLogin(authOptions) {
             // Older oAuth versions support POST calls with userid and password. (e.g. Salesforce)
             // Check if the developer has provided userid and password for oAuth, These calls don't require browser widget
             if (authOptions.hasOwnProperty("userid") && authOptions.hasOwnProperty("password")) {
                 performBasicOrCustomLogin(authOptions);
             } else {
                 // Check if SSO is enabled and SSO token is neither null nor empty
                 if (voltmx.sdk.isSSOLoginSuccess && voltmx.sdk.sso.isSSOEnabled == true && !voltmx.sdk.util.isNullOrEmptyString(voltmx.sdk.util.getSSOToken())) {
                     // call SSO login according to the identity type
                     if (_type === "oauth2") {
                         loginHelper("/oauth2/token", {}, {});
                     } else if (_type === "saml") {
                         loginHelper("/saml/token", {}, {});
                     } else {
                         loginHelper("/login", {}, {});
                     }
                 } else {
                     //only for thin clients where code is already present and we need to do token call
                     if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_THIN_CLIENT && !voltmx.sdk.isNullOrUndefined(authOptions[voltmx.sdk.constants.SINGLE_WINDOW_LOGIN_BODY_PARAMS])) {
                         var bodyParams = authOptions[voltmx.sdk.constants.SINGLE_WINDOW_LOGIN_BODY_PARAMS];
                         var urlType = metaDataManagerForLoginInSameWindow.getItem(voltmx.sdk.constants.URL_TYPE);
                         metaDataManagerForLoginInSameWindow.destroy(); // no longer needed saved data
                         loginHelper(urlType, bodyParams, {}); //token call
                     } else {
                         OAuthHandler(_serviceUrl, _providerName, mainRef.appKey, loginHelper, _type, extractOauthOptions(authOptions), isMFVersionCompatible());
                     }
                 }
             }
         }
         voltmx.sdk.logsdk.debug("### AuthService::login Invoked login for provider " + _providerName + " of type " + _type);
         if (typeof(options) == 'undefined') {
             throw new Exception(voltmx.sdk.errorConstants.AUTH_FAILURE, "Missing required number of arguments to login function");
         }
         if (options !== null) {
             // extract and set respective login option values like isOfflineEnabled, isSSOEnabled etc.
             extractLoginOptions(options["loginOptions"]);
         } else {
             options = {};
         }
         if (_type === "anonymous") {
             voltmxRef.isAnonymousProvider = true;
             loginHelper("/login", {}, {});
         } else if (_type == "basic") {
             performBasicOrCustomLogin(options);
         } else {
             performOauthOrSamlLogin(options);
         }
     };
     /**
      * validateMfa validates the multi factor authentication parameters
      * @param {object} mfaParams- 2nd factor authentic param
      * @param {function} successCallback  - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     this.validateMfa = function(mfaParams, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.debug("AuthService::validateMfa Invoked login for provider " + _providerName + " of type " + _type);

         function performValidateCall(urlMFA, params) {
             var headers = {};
             headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
             headers[voltmx.sdk.constants.APP_KEY_HEADER] = mainRef.appKey;
             headers[voltmx.sdk.constants.APP_SECRET_HEADER] = mainRef.appSecret;
             headers[voltmx.sdk.constants.SDK_TYPE_HEADER] = voltmx.sdk.getSdkType();
             headers[voltmx.sdk.constants.SDK_VERSION_HEADER] = voltmx.sdk.version;
             headers[voltmx.sdk.constants.PLATFORM_TYPE_HEADER] = voltmx.sdk.getPlatformName();
             headers[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
             headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
             populateHeaderWithFoundryAppVersion(headers);
             if (voltmxRef.reportingheaders_allowed) {
                 headers[voltmx.sdk.constants.REPORTING_HEADER] = voltmx.sdk.getEncodedReportingParamsForSvcid("login_" + _providerName);
             }
             var endPointUrl = _serviceUrl + urlMFA + "?provider=" + _providerName;
             var networkOptions = voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options);
             networkProvider.post(endPointUrl, params, headers, function(data) {
                 var response = processLoginSuccessResponse(data, voltmxRef, false);
                 voltmx.sdk.verifyAndCallClosure(successCallback, response);
             }, function(data) {
                 processLoginErrorResponse(data, voltmxRef, true, failureCallback)
             }, null, networkOptions);
         }
         if (voltmx.sdk.isNullOrUndefined(mfaParams)) {
             throw new Exception(voltmx.sdk.errorConstants.AUTH_FAILURE, " mfaParams are null");
         }
         var payload = {};
         payload["provider"] = _providerName;
         for (var key in mfaParams) {
             payload[key] = mfaParams[key];
         }
         if (!voltmx.sdk.isNullOrUndefined(voltmxRef.currentClaimToken) && !voltmxRef.isAnonymousProvider) {
             voltmx.sdk.claimsRefresh(function(res) {
                 performValidateCall("/login/mfa", payload)
             }, function(err) {
                 voltmx.sdk.logsdk.error("AuthService::validateMfa claimsRefresh failed, invoking failurecallback");
                 err.message = voltmx.sdk.errormessages.transient_login_fail;
                 err.opstatus = voltmx.sdk.errorcodes.transient_login_fail;
                 voltmx.sdk.verifyAndCallClosure(failureCallback, err);
             })
         } else {
             voltmx.sdk.logsdk.error("AuthService::validateMfa Claims token unavailable, please login");
             err.message = voltmx.sdk.errormessages.offline_auth_failed;
             err.opstatus = voltmx.sdk.errorcodes.offline_auth_failedl;
             voltmx.sdk.verifyAndCallClosure(failureCallback, err);
         }
     };
     /**
      * getMfaDetails functions lets the user to know whether 2factor security is enabled
      * @return {boolean}
      **/
     this.getMfaDetails = function() {
         var mfaDetails = {};
         mfaDetails[voltmx.sdk.constants.IS_MFA_ENABLED] = is_mfa_enabled;
         mfaDetails[voltmx.sdk.constants.MFA_META] = mfa_meta;
         return mfaDetails;
     };
     /**
      * Tries to get persisted token from local store and update sdk.
      */
     this.usePersistedLogin = function() {
         voltmx.sdk.logsdk.perf("Executing usePersistedLogin");
         var stringifiedResponse = voltmx.sdk.offline.getUserAuthInformation(voltmx.sdk.constants.PERSISTED_AUTH_RESPONSE);
         if (stringifiedResponse && voltmx.sdk.isJson(stringifiedResponse)) {
             voltmx.sdk.logsdk.debug("### PersistLogin: Persisted auth response retrieved succcessfully");
             var persistedAuthResponse = JSON.parse(stringifiedResponse);
             // To support multilogin we are checking for the existence of provider name in profiles.
             if (persistedAuthResponse && persistedAuthResponse.profiles && persistedAuthResponse.profiles[_providerName]) {
                 voltmxRef.isAnonymousProvider = false;
                 processMultipleProvidersResponse(persistedAuthResponse, _providerName);
                 voltmx.sdk.logsdk.perf("Executing Finished usePersistedLogin");
                 return true;
             }
         } else {
             voltmx.sdk.logsdk.debug("### PersistLogin: Failed to retrieve persisted auth response");
         }
         voltmx.sdk.logsdk.perf("Executing Finished usePersistedLogin");
         return false;
     };
     var processMultipleProvidersResponse = function(data, providerName) {
         if (data && data.profiles) {
             voltmxRef.isAnonymousProvider = false;
             for (var provider in data.profiles) {
                 if (!voltmxRef.tokens[provider]) {
                     voltmxRef.tokens[provider] = {};
                 }
                 voltmxRef.tokens[provider].profile = data.profiles[provider];
             }
         } else if (data && providerName && data.profile) {
             voltmxRef.isAnonymousProvider = false;
             voltmxRef.tokens[providerName].profile = data.profile;
         }
         if (data && providerName && data.provider_token) {
             voltmxRef.tokens[providerName].provider_token = data.provider_token;
         }
         if (data && data.provider_tokens) {
             for (var provider in data.provider_tokens) {
                 if (!voltmxRef.tokens[provider]) {
                     voltmxRef.tokens[provider] = {};
                 }
                 if (!voltmxRef.tokens[provider].provider_token) {
                     voltmxRef.tokens[provider].provider_token = {}
                 }
                 voltmxRef.tokens[provider].provider_token.value = data.provider_tokens[provider];
             }
         }
         voltmxRef.currentClaimToken = data.claims_token.value;
         voltmxRef.claimTokenExpiry = data.claims_token.exp;
         voltmxRef.currentRefreshToken = data.refresh_token;
         if (!voltmx.sdk.isNullOrUndefined(data.claims_token.session_id)) {
             voltmxRef.idSid = data.claims_token.session_id;
         }
         if (!voltmxRef.isAnonymousProvider && !voltmx.sdk.isNullOrUndefined(data.claims_token[voltmx.sdk.constants.IS_MFA_ENABLED])) {
             for (var providerPosition = 0; providerPosition < voltmxRef.login.length; providerPosition++) {
                 if (voltmxRef.login[providerPosition].prov === providerName) {
                     //we are doing this so that if user makes anoher identity object with same provider , is_mfa_enabled value can be available
                     voltmxRef.login[providerPosition][voltmx.sdk.constants.IS_MFA_ENABLED] = data.claims_token[voltmx.sdk.constants.IS_MFA_ENABLED];
                     voltmxRef.login[providerPosition][voltmx.sdk.constants.MFA_META] = data.claims_token[voltmx.sdk.constants.MFA_META];
                     var result = {};
                     result[voltmx.sdk.constants.IS_MFA_ENABLED] = data.claims_token[voltmx.sdk.constants.IS_MFA_ENABLED];
                     result[voltmx.sdk.constants.MFA_META] = data.claims_token[voltmx.sdk.constants.MFA_META];
                     return result;
                 }
             }
         }
     };
     var processLoginSuccessResponse = function(data, voltmxRef, isAsync, callBack) {
         voltmx.sdk.logsdk.perf("Executing processLoginSuccessResponse");
         var response = {};
         data = voltmx.sdk.formatSuccessResponse(data);
         if (_type !== "anonymous" && !voltmxRef.tokens[_providerName]) {
             voltmxRef.tokens[_providerName] = {};
         }
         voltmx.sdk.logsdk.info("### AuthService::login successful. Retrieved Data::");
         var result = processMultipleProvidersResponse(data, _providerName)
         if (!voltmx.sdk.isNullOrUndefined(result) && !voltmx.sdk.isNullOrUndefined(result[voltmx.sdk.constants.IS_MFA_ENABLED])) {
             response.mfa_response = result;
         }
         voltmx.sdk.logsdk.info("### AuthService::login extracted token. Calling success callback");
         if (voltmx.sdk.sso.isSSOEnabled === true) {
             if (data.sso_token) {
                 var isSSOSaved = voltmx.sdk.util.saveSSOToken(voltmx.sdk.util.addOrUpdateSSOTokenWithProvider(data.sso_token, _providerName));
                 if (isSSOSaved === true) {
                     voltmx.sdk.isSSOLoginSuccess = true;
                     voltmx.sdk.logsdk.info("### SSOLoginService::SSOToken being saved successfully.");
                 } else {
                     voltmx.sdk.logsdk.info("### SSOLoginService::Failed to save SSOToken.This might result in failure of corresponding sso Logins. Please check the configuration params");
                 }
             } else {
                 voltmx.sdk.logsdk.info("### SSOLoginService::Unable to fetch sso token.");
             }
         }
         if (data.profile && data.profile != undefined && data.profile.user_attributes != undefined) {
             user_attributes = data.profile.user_attributes;
         }
         if (data.profile) {
             voltmx.sdk.overrideUserId(data.profile.userid);
         }
         if (voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE) {
             //We store the user credentials and the success auth response only on successful online login.
             if (voltmx.sdk.offline.isOfflineEnabled === true) {
                 if (voltmx.sdk.isNetworkAvailable() && offlineEnabled && _type === "basic") {
                     voltmx.sdk.offline.updateSuccessUserCredentials(_providerName);
                 }
                 voltmx.sdk.offline.saveUserAuthInformation("authResponse", data);
             }
             if (_type !== "anonymous") {
                 if (persistToken || voltmx.sdk.offline.persistToken || voltmx.sdk.offline.isPersistentLoginResponseEnabled()) {
                     voltmx.sdk.offline.saveUserAuthInformation(voltmx.sdk.constants.PERSISTED_AUTH_RESPONSE, data);
                 }
             }
         }
         voltmx.logger.setClaimsToken();
         if (!isAsync) {
             return response;
         } else if (callBack) {
             delete response.mfa_response;
             voltmx.sdk.verifyAndCallClosure(callBack, response);
         }
     };
     var processLoginErrorResponse = function(data, voltmxRef, isAsync, callBack) {
         voltmx.sdk.logsdk.perf("Executing processLoginErrorResponse");
         voltmx.sdk.logsdk.info("### AuthService::login Calling failure callback");
         /*resetting all the token in case of error */
         resetAllCurrentTokens(voltmxRef, _providerName);
         if (voltmx.sdk.sso.isSSOEnabled === true) {
             if (data.mfcode == "Auth-55") {
                 voltmx.sdk.util.deleteSSOToken();
             }
             voltmx.sdk.isSSOLoginSuccess = false;
         }
         if (!isAsync) {
             return voltmx.sdk.error.getAuthErrObj(data);
         } else if (callBack) {
             callBack(voltmx.sdk.error.getAuthErrObj(data));
         }
     };
     /**
      * Login anonymous with the given credentials synchronously and executes the given callback.
      * @param {object} options - User name and password
      */
     this.anonymousLoginSync = function(options) {
         voltmx.sdk.logsdk.perf("Executing anonymousLoginSync");
         voltmxRef.isAnonymousProvider = false;
         var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid("login_" + _providerName);
         voltmx.sdk.logsdk.debug("### AuthService::login Invoked login for provider " + _providerName + " of type " + _type);
         if (typeof(options) == 'undefined') {
             throw new Exception(voltmx.sdk.errorConstants.AUTH_FAILURE, "Missing required number of arguments to login function");
         }

         function invokeAjaxCall(url, params, headers) {
             if (!headers) {
                 headers = {};
             }
             headers[voltmx.sdk.constants.APP_KEY_HEADER] = mainRef.appKey;
             headers[voltmx.sdk.constants.APP_SECRET_HEADER] = mainRef.appSecret;
             headers[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
             if (voltmxRef.reportingheaders_allowed) {
                 if (reportingData != null && reportingData != undefined) {
                     try {
                         headers[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
                     } catch (error) {
                         voltmx.sdk.logsdk.error("### anonymousLoginSync::error while parsing metrics payload" + error);
                     }
                 }
             }
             var endPointUrl = null;
             if (_type === "anonymous") {
                 endPointUrl = _serviceUrl + url;
             } else {
                 endPointUrl = _serviceUrl + url + "?provider=" + _providerName;
                 params["provider"] = _providerName;
             }
             var data = networkProvider.postSync(endPointUrl, params, headers);
             if (data.opstatus == 0) {
                 return processLoginSuccessResponse(data, voltmxRef, false);
             } else {
                 return processLoginErrorResponse(data, voltmxRef, false);
             }
         }
         voltmxRef.isAnonymousProvider = true;
         voltmx.sdk.logsdk.info("### AuthService::login Adapter type is anonymous");
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
         var result = invokeAjaxCall("/login", {}, headers);
         voltmx.sdk.logsdk.perf("Executing Finished anonymousLoginSync");
         return result;
     };
     /**
      * Logout and executes the given callback.
      * @param {function} successCallback  - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {object} options - additional options for logout
      */
     this.logout = function(successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.trace("Entering logout");

         function logoutHandler() {
             _logout(successCallback, failureCallback, options);
         }

         function claimsRefreshFailureCallback() {
             voltmx.sdk.logsdk.error("### AuthService::logout claimsRefresh failed");
             logoutHandler();
         }
         if (voltmx.sdk.getPlatformName() !== voltmx.sdk.constants.PLATFORM_WINDOWS) {
             //if the user logged in using offline logout
             if (offlineEnabled == true && voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE && _type === "basic" && !voltmx.sdk.isNetworkAvailable()) {
                 logoutHandler();
             } else {
                 voltmx.sdk.claimsRefresh(logoutHandler, claimsRefreshFailureCallback);
             }
         } else {
             voltmx.sdk.claimsRefresh(logoutHandler, claimsRefreshFailureCallback);
         }
     };

     function _logout(successCallback, failureCallback, options) {
         var customOAuthParams = null;

         function extractLogoutOptions(logoutOptions) {
             if (!voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(logoutOptions)) {
                 if (providerType === voltmx.sdk.constants.AUTH_PROVIDER_TYPE_OAUTH2) {
                     customOAuthParams = logoutOptions[voltmx.sdk.constants.CUSTOM_OAUTH_PARAMS];
                 }
             }
         }

         function invokeLogoutHelper(formData, invokeLogoutSuccess, invokeLogoutFailure) {
             var claimsTokenValue = null;
             var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid("logout_" + _providerName);
             if (!voltmx.sdk.isNullOrUndefined(voltmxRef.currentClaimToken)) {
                 claimsTokenValue = voltmxRef.currentClaimToken;
             }
             formdata.provider = _providerName;
             var url = "";
             //type (/oauth2/) should be added in the url for oauth2 provider only (not even in saml though it is similar to oauth2)
             if (_type == voltmx.sdk.constants.AUTH_PROVIDER_TYPE_OAUTH2 && voltmx.sdk.getSdkType() == voltmx.sdk.constants.SDK_TYPE_IDE) {
                 url = _serviceUrl + "/oauth2/logout?provider=" + _providerName;
             } else {
                 url = _serviceUrl + "/logout?provider=" + _providerName;
             }
             var headers = {};
             headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = claimsTokenValue;
             headers[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = "*/*";
             headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
             if (voltmxRef.reportingheaders_allowed) {
                 if (reportingData != null && reportingData != undefined) {
                     try {
                         headers[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
                     } catch (error) {
                         voltmx.sdk.logsdk.error("### login::error while parsing metrics payload" + error);
                     }
                 }
             }
             //populating custom oAuth params
             if (providerType === voltmx.sdk.constants.AUTH_PROVIDER_TYPE_OAUTH2) {
                 voltmx.sdk.util.populateCustomOAuthParams(formData, customOAuthParams);
             }
             populateHeaderWithFoundryAppVersion(headers);
             networkProvider.post(url, formdata, headers, function(data) {
                 voltmx.sdk.logsdk.info("AuthService::logout successfully logged out. Calling success callback");

                 function serviceDocCallback() {
                     logoutSuccess(data);
                     return;
                 }
                 getLatestServiceDocIfAvailable(data, serviceDocCallback);
             }, function(err) {
                 voltmx.sdk.isOAuthLogoutInProgress = false;
                 voltmx.sdk.logsdk.error("### AuthService::logout logged out Failed. Calling failure callback");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getAuthErrObj(err));
             });
         }

         function logoutSuccess(data) {
             voltmx.sdk.logsdk.trace("Entering logoutSuccess from Identity.");
             data = voltmx.sdk.formatSuccessResponse(data);
             delete voltmxRef.tokens[_providerName];
             var pastClaimsToken = voltmxRef.currentClaimToken;
             var doesSessionNeedsToBeCleanedAtMW = true;
             if (voltmxRef.refreshLoginProvidersSet.has(_providerName)) {
                 voltmxRef.refreshLoginProvidersSet.delete(_providerName);
             }
             //reset all current keys
             voltmx.sdk.resetCurrentKeys(voltmxRef, _providerName);
             //processing multiple profiles
             if (data && data.claims_token) {
                 processMultipleProvidersResponse(data);
                 voltmxRef.isAnonymousProvider = false;
                 doesSessionNeedsToBeCleanedAtMW = false;
                 if (!voltmx.sdk.isNullOrUndefined(data[voltmx.sdk.constants.LOGIN_PROFILES])) {
                     var listOfLoginProfiles = Object.keys(data[voltmx.sdk.constants.LOGIN_PROFILES]);
                     //setting the internal refresh token for current logged-in providers in secured storage based on login profiles
                     refreshLoginTokenStoreUtilityObject.setInternalRefreshToken(listOfLoginProfiles, voltmxRef.currentRefreshToken);
                 }
             }
             if (offlineEnabled) {
                 voltmx.sdk.offline.isOfflineEnabled = false;
                 voltmx.sdk.offline.removeUserAuthInformation();
                 voltmx.sdk.offline.removeUserCredentials(_providerName);
             }
             if (persistToken || voltmx.sdk.offline.persistToken || voltmx.sdk.offline.isPersistentLoginResponseEnabled()) {
                 voltmx.sdk.offline.removePersistedUserAuthInformation();
                 persistToken = false;
                 voltmx.sdk.offline.persistToken = false;
                 dataStore.setItem(voltmx.sdk.constants.PERSIST_LOGIN_RESPONSE_FLAG, false);
             }
             // slo : Single Logout out
             //deleting all SSO token as the backend session has expired.
             if (slo === true || slo === "true") {
                 voltmx.sdk.util.deleteSSOToken();
             } else if (!voltmx.sdk.util.isNullOrEmptyString(voltmx.sdk.util.getSSOTokenForProvider(_providerName))) {
                 //removing SSO token for the provider.
                 voltmx.sdk.util.deleteSSOTokenForProvider(_providerName);
             }
             //reset global customOAuthParams for the logged out provider from global voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh
             if ((providerType === voltmx.sdk.constants.AUTH_PROVIDER_TYPE_OAUTH2) && !voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[_providerName])) {
                 voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[_providerName] = {};
             }
             if (doesSessionNeedsToBeCleanedAtMW) {
                 //user has no active provider logged in left, we should go for session deletion with MW
                 var middlewareSessionInvalidationURL = voltmxRef[voltmx.sdk.constants.INTEGRATION_SERVICE_KEY]
                     [voltmx.sdk.constants.INTEGRATION_INTERNAL_LOGOUT_URL] + '/' + voltmx.sdk.constants.INTEGRATION_INTERNAL_CLEAR_SESSION_ENDPOINT;
                 var headers = {};
                 headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = pastClaimsToken;
                 var options = {};
                 options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
                 networkProvider.post(middlewareSessionInvalidationURL, null, headers, function(successResponseFromMW) {
                     voltmx.sdk.logsdk.trace('Entering logoutSuccess from Middleware with message' + successResponseFromMW[voltmx.sdk.constants.KEY_MESSAGE]);
                     voltmx.sdk.isOAuthLogoutInProgress = false;
                     voltmx.sdk.verifyAndCallClosure(successCallback, {});
                 }, function(errorResponseFromMW) {
                     voltmx.sdk.isOAuthLogoutInProgress = false;
                     voltmx.sdk.logsdk.error('Entering logoutFailure from Middleware with error message -' + errorResponseFromMW[voltmx.sdk.constants.MF_ERROR_MSG]);
                     var errObject = voltmx.sdk.error.getAuthErrObj(errorResponseFromMW);
                     errObject[voltmx.sdk.constants.KEY_MESSAGE] = 'Failed to invalidate session with middleware,' + ' It\'s good idea to close all browser windows.';
                     voltmx.sdk.verifyAndCallClosure(failureCallback, errObject);
                 }, null, options);
             } else {
                 voltmx.sdk.isOAuthLogoutInProgress = false;
                 voltmx.sdk.verifyAndCallClosure(successCallback, {});
             }
         }
         voltmx.sdk.logsdk.debug("### AuthService::logout invoked on provider " + _providerName + " of type " + _type);
         var slo = false;
         if (!voltmx.sdk.isNullOrUndefined(options) && (options["slo"] === true || options["slo"] === false)) {
             slo = options["slo"];
         }
         var formdata = {};
         formdata = {
             "slo": slo
         };
         //extract logout options
         if (!voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(options)) {
             extractLogoutOptions(options[voltmx.sdk.constants.LOGOUT_OPTIONS]);
         }
         if (!isLoggedIn()) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getIdentitySessionInactiveErrObj());
         } else if ((_type == voltmx.sdk.constants.AUTH_PROVIDER_TYPE_OAUTH2 || _type == voltmx.sdk.constants.AUTH_PROVIDER_TYPE_SAML) && voltmx.sdk.getSdkType() == voltmx.sdk.constants.SDK_TYPE_IDE) {
             if (!voltmx.sdk.isOAuthLogoutInProgress) {
                 voltmx.sdk.isOAuthLogoutInProgress = true;
                 var callback_invoke = true;
                 var oauth_status;

                 function oAuthCallback(status) {
                     oauth_status = status;
                     //Workaround to get around redirects
                     if (callback_invoke) {
                         callback_invoke = false;
                         voltmx.timer.schedule("oAuthCallbackHandle", function() {
                             if (oauth_status) invokeLogoutHelper(formdata, logoutSuccess, failureCallback);
                             else voltmx.sdk.verifyAndCallClosure(failureCallback, {});
                         }, 3, false);
                     }
                 }
                 var oauthOptions = {};
                 oauthOptions["logout"] = true;
                 oauthOptions["slo"] = slo;
                 if (voltmx.sdk.util.hasBrowserWidget(options)) {
                     oauthOptions[voltmx.sdk.constants.BROWSER_WIDGET] = options[voltmx.sdk.constants.BROWSER_WIDGET];
                 }
                 OAuthHandler(_serviceUrl, _providerName, mainRef.appKey, oAuthCallback, _type, oauthOptions);
             }
         } else {
             if (voltmx.sdk.getPlatformName() !== voltmx.sdk.constants.PLATFORM_WINDOWS) {
                 //if the user logged in using offline login
                 if (voltmx.sdk.offline.isOfflineEnabled == true && voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE && _type === "basic" && !voltmx.sdk.isNetworkAvailable()) {
                     voltmx.sdk.logsdk.info("AuthService::offline logout successfully logged out. Calling success callback");
                     logoutSuccess();
                     return;
                 }
             }
             invokeLogoutHelper(formdata, logoutSuccess, failureCallback);
         }
     }
     /**
      * Fetch the backend datasource token.
      * @param {boolean} fromserver - Flag to force fetch from server only.
      * @param {object} options - Options
      * @param {function} successCallback  - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     this.getBackendToken = function(fromserver, options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf("Executing getBackendToken");

         function _claimsRefreshSuccess(token) {
             voltmx.sdk.logsdk.perf("Executing Finished getBackendToken : status success");
             voltmx.sdk.logsdk.trace("Entering _claimsRefreshSuccess with valid token");
             processMultipleProvidersResponse(token, _providerName);
             //voltmxRef.currentBackEndToken = token.provider_token;
             //if offline login enabled then updating the backend token in the store
             if (voltmx.sdk.offline.isOfflineEnabled && voltmx.sdk.offline.isOfflineEnabled == true) {
                 voltmx.sdk.offline.updateAuthToken(token);
             }
             if (persistToken || voltmx.sdk.offline.persistToken || voltmx.sdk.offline.isPersistentLoginResponseEnabled()) {
                 voltmx.sdk.offline.updatePersistedToken(voltmx.sdk.constants.PERSISTED_AUTH_RESPONSE, token);
             }
             //if the provider has refresh tokens , we should update internal refresh tokens
             if (!voltmx.sdk.isNullOrUndefined(refreshLoginTokenStoreUtilityObject.getInternalRefreshToken(_providerName))) {
                 // update current provider's internal refresh token
                 refreshLoginTokenStoreUtilityObject.setInternalRefreshToken(_providerName, voltmxRef.currentRefreshToken);
                 // we need to update tokens for for multiple providers
                 if (!voltmx.sdk.isNullOrUndefined(token[voltmx.sdk.constants.LOGIN_PROFILES])) {
                     var listOfLoginProfiles = Object.keys(token[voltmx.sdk.constants.LOGIN_PROFILES]);
                     //for multiple providers setting the internal refresh token for current logged-in providers in secured storage based on login profiles
                     refreshLoginTokenStoreUtilityObject.setInternalRefreshToken(listOfLoginProfiles, voltmxRef.currentRefreshToken);
                 }
                 //if user gave options to refresh backend refresh tokens, we should update backend tokens as well
                 if (doesStoredRefreshTokensNeedsUpdate) {
                     var providerToBackendResponseTokenJSON = token[voltmx.sdk.constants.BACKEND_REFRESH_TOKENS];
                     //updating backend refresh tokens of the providers
                     refreshLoginTokenStoreUtilityObject.setBulkBackendRefreshTokens(providerToBackendResponseTokenJSON);
                 }
             }
             voltmx.sdk.verifyAndCallClosure(successCallback, voltmxRef.tokens[_providerName].provider_token);
         }

         function _claimsRefreshFailure(error) {
             voltmx.sdk.logsdk.perf("Executing Finished getBackendToken : status failure");
             voltmx.sdk.logsdk.trace("Entering _claimsRefreshFailure");
             voltmx.sdk.logsdk.info("### AuthService::getBackendToken fetching refresh failed. Calling failure callback");
             // voltmxRef.tokens[_providerName] = null;
             // voltmxRef.currentBackEndToken = null;
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getAuthErrObj(error));
         }
         voltmx.sdk.logsdk.debug("### AuthService::getBackendToken called for provider " + _providerName + " of type " + _type);
         if (!isLoggedIn()) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getIdentitySessionInactiveErrObj());
         }
         var claimsOptions = null;
         var doesStoredRefreshTokensNeedsUpdate = false;
         if (options && options.refresh && options.refresh === true) {
             claimsOptions = {
                 "requestParams": {
                     "refresh": "true"
                 }
             };
             claimsOptions[voltmx.sdk.constants.BODY_PARAMS] = {};
             if (!voltmx.sdk.isNullOrUndefined(refreshLoginTokenStoreUtilityObject.getBackendRefreshToken(_providerName))) {
                 doesStoredRefreshTokensNeedsUpdate = true;
                 claimsOptions[voltmx.sdk.constants.BODY_PARAMS][voltmx.sdk.constants.ENABLE_REFRESH_LOGIN] = true;
             }
             //populating custom oAuth params
             if (providerType === voltmx.sdk.constants.AUTH_PROVIDER_TYPE_OAUTH2) {
                 //reset earlier oAuth params in voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh for the current provider
                 if (!voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(options[voltmx.sdk.constants.CUSTOM_OAUTH_PARAMS])) {
                     voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[_providerName] = {};
                     //populating custom oAuth params in global voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh object so that
                     // these params will be used in /claims?refresh=true call which happens when server throws 401 status code incase
                     // of service call failure
                     voltmx.sdk.util.populateCustomOAuthParams(voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[_providerName], options[voltmx.sdk.constants.CUSTOM_OAUTH_PARAMS]);
                 }
                 //populating custom oAuth params in body params for this refresh call
                 if (!voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[_providerName])) {
                     voltmx.sdk.util.populateCustomOAuthParams(claimsOptions[voltmx.sdk.constants.BODY_PARAMS], voltmx.sdk.customOAuthParmsForClaimsAndBackendTokenRefresh[_providerName]);
                 }
             }
         }
         if (fromserver != undefined && fromserver === true) {
             voltmx.sdk.logsdk.info("### AuthService::getBackendToken fromserver is enabled. Trying to login");
             _claimsRefresh(claimsOptions, _claimsRefreshSuccess, _claimsRefreshFailure);
         } else {
             if (voltmxRef.tokens[_providerName]) {
                 var val = voltmxRef.tokens[_providerName];
                 var _exp = val.provider_token.exp;
                 voltmx.sdk.logsdk.debug("token expiry time: " + _exp);
                 voltmx.sdk.logsdk.debug("Current time: " + (new Date().getTime()));
                 if (_exp && _exp < (new Date().getTime())) {
                     voltmx.sdk.logsdk.info("### AuthService::getBackendToken Token expired. Fetching refresh from claims api");
                     _claimsRefresh(claimsOptions, _claimsRefreshSuccess, _claimsRefreshFailure);
                 } else {
                     voltmx.sdk.logsdk.info("### AuthService::getBackendToken present token is valid/doesn't have expiry time. Calling success callback");
                     //voltmxRef.currentBackEndToken = val.provider_token;
                     voltmx.sdk.verifyAndCallClosure(successCallback, voltmxRef.tokens[_providerName].provider_token);
                 }
             } else {
                 voltmx.sdk.logsdk.info("### AuthService::getBackendToken failed for find info for key " + dsKey + "in database. calling failure callback");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, null);
             }
         }
     };
     /**
      * Get profile.
      * @param {boolean} fromserver - Flag to force fetch from server only.
      * @param {function} successCallback  - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     this.getProfile = function(fromserver, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering getProfile");
         if (!isLoggedIn()) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getIdentitySessionInactiveErrObj());
         } else if (fromserver && fromserver == true) {
             profileRefresh(function(token) {
                 voltmxRef.tokens[_providerName].profile = token;
                 voltmx.sdk.verifyAndCallClosure(successCallback, token);
             }, failureCallback)
         } else {
             if (voltmxRef.tokens[_providerName]) {
                 var val = voltmxRef.tokens[_providerName];
                 voltmx.sdk.verifyAndCallClosure(successCallback, val.profile);
             } else {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, null);
             }
         }
     };
     /**
      * Get the provider name.
      * @returns {string} Provider name.
      */
     this.getProviderName = function() {
         return _providerName;
     };
     /**
      * Get the provider type.
      * @returns {string} Provider type.
      */
     this.getProviderType = function() {
         return _type;
     };
     /**
      * Get the generic session data type.
      * @returns {string} session data.
      */
     this.getUserData = function(successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering getUserData (Get the generic session data type)");
         if (!isLoggedIn()) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getIdentitySessionInactiveErrObj());
         } else {
             var userDataUrl = _serviceUrl + "/session/user_data";
             var options = {};
             options["invokedFrom"] = voltmx.sdk.constants.GET_USER_DATA;
             getSessionData(userDataUrl, successCallback, failureCallback, options);
         }
     };
     /**
      * Get the user attributes returned by a provider
      * @returns {string} user attributes.
      */
     this.getUserAttributes = function(successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering getUserAttributes");
         if (!isLoggedIn()) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getIdentitySessionInactiveErrObj());
         } else if (user_attributes && Object.keys(user_attributes).length === 0) {
             var userAttributesUrl = _serviceUrl + "/session/user_attributes?provider=" + _providerName;
             var options = {};
             options["invokedFrom"] = voltmx.sdk.constants.GET_USER_ATTRIBUTES;
             getSessionData(userAttributesUrl, function(res) {
                 user_attributes = res;
                 voltmx.sdk.verifyAndCallClosure(successCallback, user_attributes);
             }, failureCallback, options);
         } else {
             if (voltmxRef.currentClaimToken === null) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getNullClaimsTokenErrObj());
             } else {
                 voltmx.sdk.verifyAndCallClosure(successCallback, user_attributes);
             }
         }
     };
     /**
      * Get the security attributes returned by a provider
      * @returns {string} security attributes.
      */
     this.getSecurityAttributes = function(successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering getSecurityAttributes");
         if (!isLoggedIn()) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getIdentitySessionInactiveErrObj());
         } else {
             var securityAttributesUrl = _serviceUrl + "/session/security_attributes?provider=" + _providerName;
             var options = {};
             options["invokedFrom"] = voltmx.sdk.constants.GET_SECURITY_ATTRIBUTES;
             getSessionData(securityAttributesUrl, successCallback, failureCallback, options);
         }
     };
     /**
      * Refresh the already created Login
      * @param {function} successCallback  - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {object} options - network options
      */
     this.refreshLogin = function(successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing refreshLogin");
         var internalRefreshToken = refreshLoginTokenStoreUtilityObject.getInternalRefreshToken(_providerName);
         if (voltmx.sdk.isNullOrUndefined(internalRefreshToken)) {
             voltmx.sdk.logsdk.perf("Executing finished refreshLogin");
             voltmx.sdk.logsdk.error("Tokens absent for refreshing login provider" + _providerName);
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getIdentitySessionInactiveErrObj());
         } else {
             var urlObject = {};
             urlObject[voltmx.sdk.constants.KEY_URL] = null;
             var headers = {};
             var bodyParams = {};
             var networkOptions = {};

             function checkClaimsRefreshAndSetNetworkParameters(urlObject, headers, bodyParams, networkOptions, setterCompletionCallback) {
                 voltmx.sdk.logsdk.perf("Executing checkClaimsRefreshAndSetNetworkParameters");

                 function setNetworkParameters() {
                     voltmx.sdk.logsdk.perf("Executing setNetworkParameters");
                     headers[voltmx.sdk.constants.APP_KEY_HEADER] = mainRef.appKey;
                     headers[voltmx.sdk.constants.APP_SECRET_HEADER] = mainRef.appSecret;
                     headers[voltmx.sdk.constants.SDK_TYPE_HEADER] = voltmx.sdk.getSdkType();
                     headers[voltmx.sdk.constants.SDK_VERSION_HEADER] = voltmx.sdk.version;
                     headers[voltmx.sdk.constants.PLATFORM_TYPE_HEADER] = voltmx.sdk.getPlatformName();
                     headers[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
                     headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
                     populateHeaderWithFoundryAppVersion(headers);
                     if (voltmxRef.reportingheaders_allowed) {
                         try {
                             var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid('refreshLogin_' + _providerName);
                             if (!voltmx.sdk.isNullOrUndefined(reportingData)) {
                                 headers[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
                             }
                         } catch (error) {
                             voltmx.sdk.logsdk.error('### login::error while parsing metrics payload in refresh login' + error);
                         }
                     }
                     if (!voltmx.sdk.isNullOrUndefined(options)) {
                         if (!voltmx.sdk.isNullOrUndefined(options[voltmx.sdk.constants.KEY_INCLUDE_PROFILE]) && options[voltmx.sdk.constants.KEY_INCLUDE_PROFILE] instanceof Object) {
                             networkOptions[voltmx.sdk.constants.KEY_INCLUDE_PROFILE] = options[voltmx.sdk.constants.KEY_INCLUDE_PROFILE];
                         }
                         if (!voltmx.sdk.isNullOrUndefined(options[voltmx.sdk.constants.KEY_HTTP_REQUEST_OPTIONS]) && options[voltmx.sdk.constants.KEY_HTTP_REQUEST_OPTIONS] instanceof Object) {
                             networkOptions[voltmx.sdk.constants.KEY_HTTP_REQUEST_OPTIONS] = options[voltmx.sdk.constants.KEY_HTTP_REQUEST_OPTIONS];
                         }
                         if (!voltmx.sdk.isNullOrUndefined(options[voltmx.sdk.constants.KEY_INCLUDE_PROFILE])) {
                             bodyParams[voltmx.sdk.constants.KEY_INCLUDE_PROFILE] = options[voltmx.sdk.constants.KEY_INCLUDE_PROFILE];
                         }
                     }
                     //populating custom oAuth params
                     if (!voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(options)) {
                         voltmx.sdk.util.populateCustomOAuthParams(bodyParams, options[voltmx.sdk.constants.CUSTOM_OAUTH_PARAMS]);
                     }
                     bodyParams[voltmx.sdk.constants.KEY_PROVIDER] = _providerName;
                     bodyParams[voltmx.sdk.constants.KEY_GRANT_TYPE] = voltmx.sdk.constants.KEY_REFRESH_TOKEN;
                     bodyParams[voltmx.sdk.constants.KEY_BACKEND_REFRESH_TOKEN] = refreshLoginTokenStoreUtilityObject.getBackendRefreshToken(_providerName);
                     bodyParams[voltmx.sdk.constants.KEY_AUTH_REFRESH_TOKEN] = internalRefreshToken;
                     bodyParams[voltmx.sdk.constants.ENABLE_REFRESH_LOGIN] = true;
                     refreshLoginEnabled = true;
                     urlObject[voltmx.sdk.constants.KEY_URL] = _serviceUrl + voltmx.sdk.constants.OAUTH_TOKEN_URL + '?' + voltmx.sdk.constants.KEY_PROVIDER + '=' + _providerName;
                     voltmx.sdk.logsdk.perf("Executing finished setNetworkParameters & checkClaimsRefreshAndSetNetworkParameters");
                     setterCompletionCallback();
                 }
                 voltmx.sdk.claimsRefresh(function(response) {
                     headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
                     setNetworkParameters();
                 }, function(error) {
                     setNetworkParameters();
                 });
             }
             checkClaimsRefreshAndSetNetworkParameters(urlObject, headers, bodyParams, networkOptions, makeRefreshLoginCallToIdentity);
             /**
              * checks if network status is 400 or 401 then we have to delete secured stored refresh login tokens
              * @param networkResponse
              * @return boolean
              */
             function doesStoredTokensNeedsToBeRemoved(networkResponse) {
                 var deleteRefreshToken = false;
                 if (!voltmx.sdk.isNullOrUndefined(options) && !voltmx.sdk.isNullOrUndefined(options[voltmx.sdk.constants.RETAIN_BACKEND_REFRESH_TOKEN])) {
                     if (typeof options[voltmx.sdk.constants.RETAIN_BACKEND_REFRESH_TOKEN] === "boolean" && options[voltmx.sdk.constants.RETAIN_BACKEND_REFRESH_TOKEN]) {
                         voltmx.sdk.logsdk.debug("Not deleting refresh token as retain_backend_refresh_token flag is set to true.");
                         return deleteRefreshToken;
                     }
                 }
                 if (!voltmx.sdk.isNullOrUndefined(networkResponse)) {
                     if (networkResponse.hasOwnProperty(voltmx.sdk.constants.HTTP_STATUS_CODE)) {
                         //check for status in httpStatusCode
                         if (networkResponse[voltmx.sdk.constants.HTTP_STATUS_CODE] == voltmx.sdk.constants.HTTP_CODE_400) {
                             deleteRefreshToken = true;
                             voltmx.sdk.logsdk.error("got httpStatusCode as 400");
                         } else if (networkResponse[voltmx.sdk.constants.HTTP_STATUS_CODE] == voltmx.sdk.constants.HTTP_CODE_401) {
                             deleteRefreshToken = true;
                             voltmx.sdk.logsdk.error("got httpStatusCode as 401");
                         }
                     } else if (networkResponse.hasOwnProperty(voltmx.sdk.constants.KEY_HTTP_RESPONSE) && networkResponse[voltmx.sdk.constants.KEY_HTTP_RESPONSE].hasOwnProperty(voltmx.sdk.constants.KEY_RESPONSE_CODE)) {
                         //if we didnt get status in httpStatusCode, we might get status under httpresponse object in responsecode
                         if (networkResponse[voltmx.sdk.constants.KEY_HTTP_RESPONSE][voltmx.sdk.constants.KEY_RESPONSE_CODE] == voltmx.sdk.constants.HTTP_CODE_400) {
                             deleteRefreshToken = true;
                             voltmx.sdk.logsdk.error("got httpresponse.responsecode as 400");
                         } else if (networkResponse[voltmx.sdk.constants.KEY_HTTP_RESPONSE][voltmx.sdk.constants.KEY_RESPONSE_CODE] == voltmx.sdk.constants.HTTP_CODE_401) {
                             deleteRefreshToken = true;
                             voltmx.sdk.logsdk.error("got httpresponse.responsecode as 401");
                         }
                     }
                 }
                 return deleteRefreshToken;
             }

             function makeRefreshLoginCallToIdentity() {
                 voltmx.sdk.logsdk.perf("Executing makeRefreshLoginCallToIdentity");
                 networkProvider.post(urlObject[voltmx.sdk.constants.KEY_URL], bodyParams, headers, function(loginResponse) {
                     voltmx.sdk.logsdk.perf("Executing finished makeRefreshLoginCallToIdentity");
                     voltmx.sdk.logsdk.debug("refresh login success");
                     genericPostLoginSuccessCallback(loginResponse, successCallback);
                     voltmx.sdk.logsdk.perf("Executing finished refreshLogin");
                 }, function(failureResponse) {
                     voltmx.sdk.logsdk.perf("Executing finished makeRefreshLoginCallToIdentity");
                     voltmx.sdk.logsdk.error("refresh login failed");
                     if (doesStoredTokensNeedsToBeRemoved(failureResponse)) {
                         voltmx.sdk.logsdk.debug("removing stored refresh tokens for provider -" + _providerName);
                         refreshLoginTokenStoreUtilityObject.removeTokens(_providerName);
                     }
                     processLoginErrorResponse(failureResponse, voltmxRef, true, failureCallback);
                     voltmx.sdk.logsdk.perf("Executing finished refreshLogin");
                 }, null, networkOptions);
             }
         }
     };
     /**
     	utility method to get session data
     	@private
     */
     var getSessionData = function(sessionAttributesEndPointUrl, successCallback, failureCallback, options) {
         var svcid = null;
         if (options["invokedFrom"] == voltmx.sdk.constants.GET_USER_ATTRIBUTES) {
             svcid = voltmx.sdk.constants.GET_USER_ATTRIBUTES;
         } else if (options["invokedFrom"] == voltmx.sdk.constants.GET_SECURITY_ATTRIBUTES) {
             svcid = voltmx.sdk.constants.GET_SECURITY_ATTRIBUTES;
         } else {
             svcid = voltmx.sdk.constants.GET_USER_DATA;
         }
         var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid(svcid);
         if (voltmxRef.currentClaimToken === null) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getNullClaimsTokenErrObj());
         } else {
             var headers = {};
             headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
             if (voltmxRef.reportingheaders_allowed) {
                 if (reportingData != null && reportingData != undefined) {
                     try {
                         headers[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
                     } catch (error) {
                         voltmx.sdk.logsdk.error("### getSessionData::error while parsing metrics payload" + error);
                     }
                 }
             }
             populateHeaderWithFoundryAppVersion(headers);
             networkProvider.get(sessionAttributesEndPointUrl, {}, headers, function(data) {
                 data = voltmx.sdk.formatSuccessResponse(data);
                 voltmx.sdk.verifyAndCallClosure(successCallback, data);
             }, function(err) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getAuthErrObj(err));
             });
         }
     };
     /**
      * Method to refresh the claims token.
      * @private
      */
     var _claimsRefresh = function(options, success, failure) {
         voltmx.sdk.logsdk.debug("### AuthService::_claimsRefresh fetching claims from server for provider " + _providerName);
         var refreshToken = null;
         var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid(voltmx.sdk.constants.GET_BACKEND_TOKEN);
         if (!voltmx.sdk.isNullOrUndefined(voltmxRef.currentRefreshToken)) {
             refreshToken = voltmxRef.currentRefreshToken;
         }
         var _url = _serviceUrl + "/claims";
         if (options && options.requestParams != null) {
             _url = _url + "?";
             for (var i in options.requestParams) {
                 if (options.requestParams.hasOwnProperty(i) && typeof(i) !== 'function') {
                     _url = _url + (i + "=" + options.requestParams[i] + "&");
                 }
             }
             _url = stripTrailingCharacter(_url, "&");
         }
         var bodyParams = {};
         if (!voltmx.sdk.isNullOrUndefined(options) && voltmx.sdk.util.isJsonObject(options[voltmx.sdk.constants.BODY_PARAMS])) {
             bodyParams = options[voltmx.sdk.constants.BODY_PARAMS];
         }
         if (refreshToken) {
             voltmx.sdk.logsdk.info("### AuthService::_claimsRefresh making POST request to claims endpoint");
             var headers = {};
             headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = refreshToken;
             headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
             if (voltmxRef.reportingheaders_allowed) {
                 if (reportingData != null && reportingData != undefined) {
                     try {
                         headers[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
                     } catch (error) {
                         voltmx.sdk.logsdk.error("### _claimsRefresh::error while parsing metrics payload" + error);
                     }
                 }
             }
             populateHeaderWithFoundryAppVersion(headers);
             networkProvider.post(_url, bodyParams, headers, function(data) {
                 data = voltmx.sdk.formatSuccessResponse(data);
                 voltmx.sdk.logsdk.info("### AuthService::_claimsRefresh Fetching claims succcessfull");
                 processMultipleProvidersResponse(data);
                 voltmx.sdk.logsdk.info("### AuthService::_claimsRefresh saved locally. Calling success callback");
                 voltmx.sdk.verifyAndCallClosure(success, data);
             }, function(xhr, status, err) {
                 voltmx.sdk.logsdk.error("### AuthService::_claimsRefresh fetching claims failed. Calling failure callback");
                 voltmx.sdk.verifyAndCallClosure(failure, voltmx.sdk.error.getAuthErrObj(err));
             });
         } else {
             voltmx.sdk.logsdk.info("### AuthService::_claimsRefresh no refreshtoken found. calling failure callback");
             voltmx.sdk.verifyAndCallClosure(failure, voltmx.sdk.error.getNullRefreshTokenErrObj());
         }
     };
     var profileRefresh = function(success, failure) {
         voltmx.sdk.logsdk.trace("Entering profileRefresh");
         voltmx.sdk.logsdk.debug("### AuthService::profileRefresh fetching profile from server for provider " + _providerName);
         var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid(voltmx.sdk.constants.GET_PROFILE);
         var refreshToken = null;
         if (!voltmx.sdk.isNullOrUndefined(voltmxRef.currentRefreshToken)) {
             refreshToken = voltmxRef.currentRefreshToken;
         }
         var _url = _serviceUrl + "/profile?provider=" + _providerName;
         if (refreshToken) {
             voltmx.sdk.logsdk.info("### AuthService::profileRefresh making POST request to profile endpoint");
             var headers = {};
             headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = refreshToken;
             headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
             if (voltmxRef.reportingheaders_allowed) {
                 if (reportingData != null && reportingData != undefined) {
                     try {
                         headers[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
                     } catch (error) {
                         voltmx.sdk.logsdk.error("### profileRefresh::error while parsing metrics payload" + error);
                     }
                 }
             }
             populateHeaderWithFoundryAppVersion(headers);
             networkProvider.get(_url, null, headers, function(data) {
                 data = voltmx.sdk.formatSuccessResponse(data);
                 voltmxRef.tokens[_providerName].profile = data;
                 voltmx.sdk.logsdk.info("### AuthService::profileRefresh Fetching profile succcessfull, Calling success callback");
                 voltmx.sdk.verifyAndCallClosure(success, data);
             }, function(xhr, status, err) {
                 voltmx.sdk.logsdk.error("### AuthService::profileRefresh fetching profile failed. Calling failure callback");
                 voltmx.sdk.verifyAndCallClosure(failure, voltmx.sdk.error.getAuthErrObj(err));
             });
         } else {
             voltmx.sdk.logsdk.info("### AuthService::profileRefresh no refreshtoken found. calling failure callback");
             voltmx.sdk.verifyAndCallClosure(failure, voltmx.sdk.error.getNullRefreshTokenErrObj());
         }
     };
 }

 function voltmxSdkLogger() {
     this.INDIRECTIONLEVEL = 1;
     this.trace = function(msg, params) {
         this.getInstance().trace(msg, params);
     };
     this.debug = function(msg, params) {
         this.getInstance().debug(msg, params);
     };
     this.info = function(msg, params) {
         this.getInstance().info(msg, params);
     };
     this.perf = function(msg, params) {
         this.getInstance().perf(msg, params);
     };
     this.warn = function(msg, params) {
         this.getInstance().warn(msg, params);
     };
     this.error = function(msg, params) {
         this.getInstance().error(msg, params);
     };
     this.fatal = function(msg, params) {
         this.getInstance().fatal(msg, params);
     };
     this.loggerEngineInit = function() {
         VoltmxSDKLoggerObj = voltmx.logger.createNewLogger(voltmx.sdk.constants.LOGGER_NAME, null);
         VoltmxSDKLoggerObj.setIndirectionLevel(VoltmxSDKLoggerObj.getIndirectionLevel() + this.INDIRECTIONLEVEL);
     };
     this.getInstance = function() {
         if (typeof(VoltmxSDKLoggerObj) === 'undefined') this.loggerEngineInit();
         return VoltmxSDKLoggerObj;
     }
 }
 /**
  * Method to create the logic service instance with the provided service name.
  * @param {string} serviceName - Name of the service
  * @returns The url to connect to the logic service
  * @throws Exception if the serviceName or access is invalid.
  */
 voltmx.sdk.prototype.getLogicService = function(serviceName) {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.prototype.getLogicService");
     if (!voltmx.sdk.isInitialized) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + " Logic service - " + serviceName);
     }
     if (this.logicsvc != null) {
         if (this.logicsvc[serviceName] != null) {
             voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.getLogicService");
             voltmx.sdk.logsdk.debug("### getLogicService::found Logic service" + this.logicsvc[serviceName]);
             return new voltmx.sdk.LogicService(this, serviceName);
         }
     }
     throw new Exception(voltmx.sdk.errorConstants.LOGIC_SERVICE_FAILURE, "Invalid serviceName:" + serviceName);
 };
 voltmx.sdk.LogicService = function(voltmxRef, serviceName) {
     this.voltmxRef = voltmxRef;
     this.serviceName = serviceName;
     this.logicServiceUrl = null;
     this.getLogicServiceUrl = function() {
         if (this.logicServiceUrl == null) {
             this.logicServiceUrl = stripTrailingCharacter(voltmxRef.logicsvc[serviceName], "/");
         }
         return this.logicServiceUrl;
     };
     voltmx.sdk.logsdk.info(" ###LogicService Created & LogicService Url = " + this.getLogicServiceUrl());
     var networkProvider = new voltmxNetworkProvider();
     this.invokeOperation = function(serviceName, path, methodType, headers, data, successCallback, failureCallback, options) {
         function invokeOperationHandler() {
             _invokeOperation(serviceName, path, methodType, headers, data, true, successCallback, failureCallback, options);
         }
         voltmx.sdk.claimsRefresh(invokeOperationHandler, failureCallback);
     };

     function invokeOperationRetry(serviceName, path, methodType, headers, data, successCallback, failureCallback, options) {
         function invokeOperationRetryHandler() {
             _invokeOperation(serviceName, path, methodType, headers, data, false, successCallback, failureCallback, options);
         }
         voltmx.sdk.claimsAndProviderTokenRefresh(invokeOperationRetryHandler, failureCallback);
     }

     function retryServiceCall(errorResponse) {
         if (errorResponse[voltmx.sdk.constants.MF_CODE]) {
             // check for the mf code for which,
             // retry should be done.
         } else {
             if (errorResponse[voltmx.sdk.constants.HTTP_STATUS_CODE] && errorResponse[voltmx.sdk.constants.HTTP_STATUS_CODE] === 401) {
                 return true;
             }
         }
     }

     function _invokeOperation(serviceName, path, methodType, headers, data, isRetryNeeded, successCallback, failureCallback, options) {
         var requestData = {};
         voltmx.sdk.logsdk.trace("Executing _invokeOperation servicePath: " + serviceName + ", methodType: " + methodType + ", path" + path + ", isRetryNeeded: " + isRetryNeeded);
         var reportingData = voltmx.sdk.getPayload(voltmxRef);
         var sessionId = voltmx.ds.read(voltmx.sdk.constants.KONYUUID);
         if (sessionId) {
             reportingData.rsid = sessionId[0];
         }
         if (!reportingData.rsid) {
             voltmx.sdk.logsdk.warn("rsid is either empty,null or undefined");
         }
         if (voltmx.sdk.metric) {
             if (voltmx.sdk.metric.reportEventBufferBackupArray.length === 0) {
                 voltmx.sdk.metric.readFromDS();
             }
             voltmx.sdk.metric.pushEventsToBufferArray();
             requestData.events = voltmx.sdk.metric.reportEventBufferBackupArray;
         }
         for (var key in data) {
             requestData[key] = data[key];
         }
         reportingData.svcid = serviceName;
         requestData[voltmx.sdk.constants.REPORTING_PARAMS] = JSON.stringify(reportingData);
         var defaultHeaders = {};
         defaultHeaders[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
         defaultHeaders[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
         if (typeof(svcObj) === 'object' && svcObj.version) {
             defaultHeaders[voltmx.sdk.constants.API_VERSION_HEADER] = svcObj.version;
         }
         // if the user has defined his own headers, use them
         if (headers) {
             for (var header in headers) {
                 defaultHeaders[header] = headers[header];
             }
         }

         function networkSuccessCallback(response) {
             if (voltmx.sdk.metric) {
                 voltmx.sdk.metric.clearBufferEvents();
             }
             voltmx.sdk.logsdk.perf("Executing Finished network operation for methodType : " + methodType);
             voltmx.sdk.logsdk.trace("Executing Finished _invokeOperation servicePath: " + serviceName + ", methodType: " + methodType + ", path" + path + ", isRetryNeeded: " + isRetryNeeded);
             voltmx.sdk.verifyAndCallClosure(successCallback, response);
         }

         function networkFailureCallback(xhr, status, err) {
             if (isRetryNeeded === true && retryServiceCall(xhr) === true) {
                 invokeOperationRetry(serviceName, path, methodType, headers, data, successCallback, failureCallback, options);
                 return;
             }
             voltmx.sdk.logsdk.perf("Executing Finished network operation for methodType : " + methodType);
             voltmx.sdk.logsdk.trace("Executing Finished _invokeOperation servicePath: " + serviceName + ", methodType: " + methodType + ", path" + path + ", isRetryNeeded: " + isRetryNeeded);
             voltmx.sdk.processLogicErrorResponse(xhr, true, failureCallback);
         }
         voltmx.sdk.logsdk.perf("Executing network operation for methodType : " + methodType);
         switch (methodType) {
             case "GET":
                 networkProvider.get(voltmxRef.logicsvc[serviceName] + path, requestData, defaultHeaders, networkSuccessCallback, networkFailureCallback, null, options);
                 break;
             case "PUT":
                 networkProvider.put(voltmxRef.logicsvc[serviceName] + path, requestData, defaultHeaders, networkSuccessCallback, networkFailureCallback, null, options);
                 break;
             case "DELETE":
                 networkProvider.invokeDeleteRequest(voltmxRef.logicsvc[serviceName] + path, requestData, defaultHeaders, networkSuccessCallback, networkFailureCallback, null, options);
                 break;
             default:
                 networkProvider.post(voltmxRef.logicsvc[serviceName] + path, requestData, defaultHeaders, networkSuccessCallback, networkFailureCallback, null, options);
                 break;
         }
     }
     voltmx.sdk.processLogicErrorResponse = function(err, isAsync, callBack) {
         if (voltmx.sdk.metric) {
             if (voltmx.sdk.metric.errorCodeMap[err.opstatus]) {
                 voltmx.sdk.metric.saveInDS();
             }
         }
         if (err[voltmx.sdk.constants.MF_CODE]) {
             var voltmxRef = voltmx.sdk.getCurrentInstance();
             //clear the cache if the error code related to session/token expiry
             if (voltmx.sdk.isSessionOrTokenExpired(err[voltmx.sdk.constants.MF_CODE])) {
                 voltmx.sdk.logsdk.warn("###LogicService::invokeOperationFailure  Session/Token expired. Authenticate and Try again");
                 //voltmx.sdk.resetCacheKeys(voltmxRef);
             }
         }
         if (!isAsync) {
             return voltmx.sdk.error.getLogicErrObj(err);
         } else if (callBack) {
             voltmx.sdk.verifyAndCallClosure(callBack, voltmx.sdk.error.getLogicErrObj(err));
         }
     };
 };
 voltmx.sdk.prototype.registerObjectService = function(objectServiceType, objectServiceClass) {
     voltmx.sdk.logsdk.trace("Entering voltmx.sdk.prototype.registerObjectService");
     voltmx.sdk.registeredobjsvcs = voltmx.sdk.registeredobjsvcs || {};
     voltmx.sdk.registeredobjsvcs[objectServiceType] = objectServiceClass;
 };
 /**
  * Method to create the object service instance with the provided service name.
  * @param {string} serviceName - Name of the service
  * @param {map} options - Map of key values like {"access":"offline"/"online"/"registered Object Service Name"}
  * @returns {@link voltmx.sdk.OnlineObjectService / @link voltmx.sdk.OfflineObjectService} Object service instance
  * @throws Exception if the serviceName or access is invalid.
  */
 voltmx.sdk.prototype.getObjectService = function(serviceName, options) {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.prototype.getObjectService");
     if (!voltmx.sdk.isInitialized) {
         voltmx.sdk.logsdk.perf("Executing finished voltmx.sdk.prototype.getObjectService with an exception");
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + " Object service - " + serviceName);
     }
     var access;
     if (!voltmx.sdk.isNullOrUndefined(options)) {
         access = options["access"];
     }
     if (this.objectsvc != null && this.objectsvc[serviceName] != null) {
         voltmx.sdk.logsdk.debug("### getObjectService::found Object service" + this.objectsvc[serviceName]);
         if (voltmx.sdk.util.isNullOrEmptyString(access) || access.toLowerCase() === "online") {
             voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.getObjectService");
             return new voltmx.sdk.OnlineObjectService(this, serviceName, this.objectsvc[serviceName]);
         } else if (access.toLowerCase() === "offline") {
             voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.getObjectService");
             //This returns SyncV1 object service
             return new voltmx.sdk.OfflineObjectService(this, serviceName);
         }
     } else if (this.offlineObjectsvc != null) {
         if (this.offlineObjectsvc[serviceName] != null) {
             if (voltmx.sdk.util.isNullOrEmptyString(access) || access.toLowerCase() === "online") {
                 voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.getObjectService");
                 // This returns Online Object Service Instance
                 return new voltmx.sdk.OnlineObjectService(this, serviceName, this.offlineObjectsvc[serviceName]);
             } else if (access.toLowerCase() === "offline") {
                 voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.getObjectService");
                 //This returns Offline Enabled or SyncV2 object service
                 return new voltmx.sdk.OfflineEnabledObjectService(this, serviceName);
             }
         }
     }
     voltmx.sdk.registeredobjsvcs = voltmx.sdk.registeredobjsvcs || {};
     voltmx.sdk.logsdk.perf("Executing Finished voltmx.sdk.prototype.getObjectService");
     //verifying if the servicetype available in registeredservices if available initialize and return
     if (voltmx.sdk.registeredobjsvcs[access] != null && voltmx.sdk.registeredobjsvcs[access] != undefined) {
         return new voltmx.sdk.registeredobjsvcs[access](this, serviceName);
     }
     throw new Exception(voltmx.sdk.errorConstants.OBJECT_FAILURE, "Invalid serviceName:" + serviceName + "or access type:" + access);
 };
 /**
  * Method which returns the online ObjectService object
  * @param voltmxRef
  * @param serviceName
  * @constructor
  */
 voltmx.sdk.OnlineObjectService = function(voltmxRef, serviceName, serviceInfo) {
     voltmx.sdk.logsdk.perf("Executing voltmx.sdk.OnlineObjectService");
     this.voltmxRef = voltmxRef;
     this.serviceName = serviceName;
     this.serviceInfo = serviceInfo;
     this.dataUrl = null;
     this.binaryUrl = null;
     this.fileStorageObjectServiceUrl = null;
     this.operationsUrl = null;
     this.metadataUrl = null;
     this.version = null;
     var currentObject = this;
     /**
      * This method is used to create a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject),"headers":<map of http headers>}
      * @param successCallback
      * @param failureCallback
      */
     this.create = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.create");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
             }
         }
         var tmpDataUrl = this.getDataUrl();
         var objName = options["dataObject"].objectName;

         function createOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(result) {
                 _create(options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::create Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             createOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(createOperationHandler, failureCallback);
         }
     };
     /**
      * This method is used to fetch a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject),"headers":<map of http headers>}
      * @param successCallback
      * @param failureCallback
      */
     this.fetch = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.fetch");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
             }
         }
         var tmpDataUrl = this.getDataUrl();
         var objName = options["dataObject"].objectName;

         function fetchOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(result) {
                 _fetch(options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::fetch Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             fetchOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(fetchOperationHandler, failureCallback);
         }
     };
     /**
      * This method is used to update a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject),"headers":<map of http headers>}
      * @param successCallback
      * @param failureCallback
      */
     this.update = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.update");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
                 return;
             }
         }
         var tmpDataUrl = this.getDataUrl();
         var objName = options["dataObject"].objectName;

         function updateOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(result) {
                 _update(options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::update Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             updateOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(updateOperationHandler, failureCallback);
         }
     };
     /**
      * This method is used to partial update a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject),"headers":<map of http headers>}
      * @param successCallback
      * @param failureCallback
      */
     this.partialUpdate = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.partialUpdate");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
                 return;
             }
         }
         var tmpDataUrl = this.getDataUrl();
         var objName = options["dataObject"].objectName;

         function partialUpdateOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(result) {
                 _partialUpdate(options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::partialUpdate Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             partialUpdateOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(partialUpdateOperationHandler, failureCallback);
         }
     };
     /**
      * This method is used to delete a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject),"headers":<map of http headers>}
      * @param successCallback
      * @param failureCallback
      */
     this.deleteRecord = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.deleteRecord");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
                 return;
             }
         }
         var tmpDataUrl = this.getDataUrl();
         var objName = options["dataObject"].objectName;

         function deleteOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(result) {
                 _deleteRecord(options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::delete Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             deleteOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(deleteOperationHandler, failureCallback);
         }
     };
     /**
      * This method is used to for performing custom operation
      * @param {string} verbName -  custom verb identifier
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject),"headers":<map of http headers>}
      * @param successCallback
      * @param failureCallback
      */
     this.customVerb = function(verbName, options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.customVerb");
         if (verbName == null || verbName == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "verbName" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
                 return;
             }
         }
         var tmpDataUrl = this.getOperationsUrl();
         var objName = options["dataObject"].objectName;

         function customVerbHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(result) {
                 _customverb(verbName, options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::customverb Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             customVerbHandler();
         } else {
             voltmx.sdk.claimsRefresh(customVerbHandler, failureCallback);
         }
     };
     /**
      * This method is used to retrive metadata of all objects
      * @param {map} options - includes {"getFromServer":boolean,"headers":<map of http headers>}
      * @param successCallback
      * @param failureCallback
      */
     this.getMetadataOfAllObjects = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.getMetadataOfAllObjects");
         _getMetadataForObjectsOrServiceOnlineUtil(voltmxRef, serviceName, null, options, successCallback, failureCallback);
         voltmx.sdk.logsdk.trace("Exiting voltmx.sdk.OnlineObjectService.getMetadataOfAllObjects");
     };
     /**
      * This method is used to retrive metadata of a specific object
      * @param objectName
      * @param {map} options - includes {"getFromServer":boolean,"headers":<map of http headers>}
      * @param successCallback
      * @param failureCallback
      */
     this.getMetadataOfObject = function(objectName, options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.getMetadataOfObject");
         _getMetadataForObjectsOrServiceOnlineUtil(voltmxRef, serviceName, objectName, options, successCallback, failureCallback);
         voltmx.sdk.logsdk.trace("Exiting voltmx.sdk.OnlineObjectService.getMetadataOfObject");
     };
     this.getDataUrl = function() {
         if (voltmx.sdk.isNullOrUndefined(currentObject.dataUrl)) {
             currentObject.dataUrl = encodeURI(stripTrailingCharacter(currentObject.serviceInfo["url"] + "/objects/", "/"));
         }
         return currentObject.dataUrl;
     };
     this.getFileStorageObjectServiceUrl = function() {
         if (voltmx.sdk.isNullOrUndefined(currentObject.fileStorageObjectServiceUrl)) {
             currentObject.fileStorageObjectServiceUrl = encodeURI(stripTrailingCharacter(currentObject.serviceInfo["url"], "/"));
         }
         return currentObject.fileStorageObjectServiceUrl;
     };
     this.getBinaryUrl = function() {
         if (voltmx.sdk.isNullOrUndefined(currentObject.binaryUrl)) {
             currentObject.binaryUrl = encodeURI(stripTrailingCharacter(currentObject.serviceInfo["url"] + "/binary/", "/"));
         }
         return currentObject.binaryUrl;
     };
     this.getOperationsUrl = function() {
         if (voltmx.sdk.isNullOrUndefined(currentObject.operationsUrl)) {
             currentObject.operationsUrl = encodeURI(stripTrailingCharacter(currentObject.serviceInfo["url"] + "/operations/", "/"));
         }
         return currentObject.operationsUrl;
     };
     this.getMetadataUrl = function() {
         if (voltmx.sdk.isNullOrUndefined(currentObject.metadataUrl)) {
             currentObject.metadataUrl = encodeURI(stripTrailingCharacter(currentObject.serviceInfo["metadata_url"], "/"));
         }
         return currentObject.metadataUrl;
     };
     this.getVersion = function() {
         if (voltmx.sdk.isNullOrUndefined(currentObject.version)) {
             currentObject.version = currentObject.serviceInfo["version"];
         }
         return currentObject.version;
     };
     /*
      *  API for uploading binary data (either file or raw bytes) to backend
      */
     this.uploadBinaryData = function(options, onFileUploadStartedCallback, onChunkUploadCompletedCallback, onFileUploadCompletedCallback, onFileUploadFailureCallback) {
         var fileUploadStartedCallback = null;
         var chunkUploadCompletedCallback = null;
         var fileUploadCompletedCallback = null;
         var fileUploadFailureCallback = null;
         var uploadParams = null;
         /* validations for callbacks */
         // validation for onFileUploadStartedCallback
         if (voltmx.sdk.isNullOrUndefined(onFileUploadStartedCallback) || (typeof(onFileUploadStartedCallback) !== 'function')) {
             voltmx.sdk.logsdk.warn("### OnlineObjectService::uploadBinaryData onFileUploadStartedCallback is null or undefined or not a function");
         } else {
             fileUploadStartedCallback = onFileUploadStartedCallback;
         }
         // validation for onChunkUploadCompletedCallback
         if (voltmx.sdk.isNullOrUndefined(onChunkUploadCompletedCallback) || (typeof(onChunkUploadCompletedCallback) !== 'function')) {
             voltmx.sdk.logsdk.warn("### OnlineObjectService::uploadBinaryData onChunkUploadCompletedCallback is null or undefined or not a function");
         } else {
             chunkUploadCompletedCallback = onChunkUploadCompletedCallback;
         }
         // validation for onFileUploadCompletedCallback
         if (voltmx.sdk.isNullOrUndefined(onFileUploadCompletedCallback) || (typeof(onFileUploadCompletedCallback) !== 'function')) {
             voltmx.sdk.logsdk.warn("### OnlineObjectService::uploadBinaryData onFileUploadCompletedCallback is null or undefined or not a function");
         } else {
             fileUploadCompletedCallback = onFileUploadCompletedCallback;
         }
         // validation for onFileUploadFailureCallback
         if (voltmx.sdk.isNullOrUndefined(onFileUploadFailureCallback) || (typeof(onFileUploadFailureCallback) !== 'function')) {
             voltmx.sdk.logsdk.warn("### OnlineObjectService::uploadBinaryData onFileUploadFailureCallback is null or undefined or not a function");
         } else {
             fileUploadFailureCallback = onFileUploadFailureCallback;
         }
         // validation for options
         if (voltmx.sdk.isNullOrUndefined(options)) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::uploadBinaryData options is null or undefined");
             voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options " + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         var dataObject = options["dataObject"];
         if (voltmx.sdk.isNullOrUndefined(dataObject)) {
             voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(dataObject instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         var objName = dataObject.getObjectName();
         var mfEndpointUrl = this.getDataUrl() + "/" + objName;
         if (voltmx.sdk.isNullOrUndefined(dataObject.getRecord())) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::uploadBinaryData Error: Please provide record to upload Binary content.");
             voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
             return;
         }
         uploadParams = dataObject.getRecord();
         var errorObj = voltmx.sdk.binary.validateUploadParams(uploadParams);
         if (errorObj) {
             voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, errorObj);
             return;
         }
         // if rawbytes are provided, converting to base64 string as FFI can only receive base datatypes
         if (!voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.constants.RAW_BYTES])) {
             var base64String = voltmx.convertToBase64(uploadParams[voltmx.sdk.constants.RAW_BYTES]);
             uploadParams[voltmx.sdk.constants.RAW_BYTES] = base64String;
         }

         function uploadBinaryDataOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(response) {
                 _uploadBinaryData(mfEndpointUrl, uploadParams, fileUploadStartedCallback, chunkUploadCompletedCallback, fileUploadCompletedCallback, fileUploadFailureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::uploadBinaryData Error:", error);
                 voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             uploadBinaryDataOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(uploadBinaryDataOperationHandler, fileUploadFailureCallback);
         }
     };
     /*
      * Helper method to perform file upload
      */
     function _uploadBinaryData(mfEndpointUrl, uploadParams, fileUploadStartedCallback, chunkUploadCompletedCallback, fileUploadCompletedCallback, fileUploadFailureCallback) {
         var uploadOptions = {};
         if (uploadParams) {
             //Extracting Mandatory Params from uploadParams before fetching template
             if (uploadParams[voltmx.sdk.constants.FILE_PATH]) {
                 uploadOptions[voltmx.sdk.constants.FILE_PATH] = uploadParams[voltmx.sdk.constants.FILE_PATH];
                 delete uploadParams[voltmx.sdk.constants.FILE_PATH];
             } else if (uploadParams[voltmx.sdk.constants.RAW_BYTES]) {
                 uploadOptions[voltmx.sdk.constants.RAW_BYTES] = uploadParams[voltmx.sdk.constants.RAW_BYTES];
                 delete uploadParams[voltmx.sdk.constants.RAW_BYTES];
             } else if (uploadParams[voltmx.sdk.constants.FILE_OBJECT]) {
                 uploadOptions[voltmx.sdk.constants.FILE_OBJECT] = uploadParams[voltmx.sdk.constants.FILE_OBJECT];
                 delete uploadParams[voltmx.sdk.constants.FILE_OBJECT]
             }
             uploadOptions["uploadParams"] = uploadParams;
         }
         var headers = {};
         if (!voltmx.sdk.skipAnonymousCall) {
             headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmx.sdk.getCurrentInstance().currentClaimToken;
         }
         uploadOptions["headers"] = headers;
         uploadOptions["URL"] = mfEndpointUrl;
         voltmx.sdk.binary.uploadBinaryData(uploadOptions, fileUploadStartedCallback, chunkUploadCompletedCallback, fileUploadCompletedCallback, fileUploadFailureCallback);
     }
     this.getBinaryData = function(options, arg1, arg2, arg3, arg4, arg5) {
         var externalSource = true;
         var fileDownloadStartedCallback = null;
         var chunkDownloadCompletedCallback = null;
         var fileDownloadCompletedCallback = null;
         var downloadFailureCallback = null;
         var binaryAttributeName = null;
         if (voltmx.sdk.isNullOrUndefined(arg5)) {
             if (voltmx.sdk.isNullOrUndefined(arg1)) {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData fileDownloadStartedCallback is null or undefined");
             } else if (typeof(arg1) === 'function') {
                 fileDownloadStartedCallback = arg1;
             } else {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData invalid param provided for fileDownloadStartedCallback");
             }
             if (voltmx.sdk.isNullOrUndefined(arg2)) {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData chunkDownloadCompletedCallback is null or undefined");
             } else if (typeof(arg2) === 'function') {
                 chunkDownloadCompletedCallback = arg2;
             } else {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData invalid param provided for chunkDownloadCompletedCallback");
             }
             if (voltmx.sdk.isNullOrUndefined(arg3)) {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData fileDownloadCompletedCallback is null or undefined");
             } else if (typeof(arg3) === 'function') {
                 fileDownloadCompletedCallback = arg3;
             } else {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData invalid param provided for fileDownloadCompletedCallback");
             }
             if (voltmx.sdk.isNullOrUndefined(arg4)) {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData downloadFailureCallback is null or undefined");
             } else if (typeof(arg4) === 'function') {
                 downloadFailureCallback = arg4;
             } else {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData invalid param provided for downloadFailureCallback");
             }
         } else {
             binaryAttributeName = arg1;
             externalSource = false;
             if (voltmx.sdk.isNullOrUndefined(arg2)) {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData fileDownloadStartedCallback is null or undefined");
             } else if (typeof(arg2) === 'function') {
                 fileDownloadStartedCallback = arg2;
             } else {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData invalid param provided for fileDownloadStartedCallback");
             }
             if (voltmx.sdk.isNullOrUndefined(arg3)) {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData chunkDownloadCompletedCallback is null or undefined");
             } else if (typeof(arg3) === 'function') {
                 chunkDownloadCompletedCallback = arg3;
             } else {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData invalid param provided for chunkDownloadCompletedCallback");
             }
             if (voltmx.sdk.isNullOrUndefined(arg4)) {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData fileDownloadCompletedCallback is null or undefined");
             } else if (typeof(arg4) === 'function') {
                 fileDownloadCompletedCallback = arg4;
             } else {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData invalid param provided for fileDownloadCompletedCallback");
             }
             if (voltmx.sdk.isNullOrUndefined(arg5)) {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData downloadFailureCallback is null or undefined");
             } else if (typeof(arg5) === 'function') {
                 downloadFailureCallback = arg5;
             } else {
                 voltmx.sdk.logsdk.warn("### OnlineObjectService::getBinaryData invalid param provided for downloadFailureCallback");
             }
         }
         if (voltmx.sdk.getSdkType() !== voltmx.sdk.constants.SDK_TYPE_IDE && voltmx.sdk.getAType() !== voltmx.sdk.constants.SDK_ATYPE_NATIVE) {
             voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_api, voltmx.sdk.errormessages.invalid_api + "platform :" + voltmx.sdk.getSdkType().toString()));
             return;
         }
         if (voltmx.sdk.isNullOrUndefined(options)) {
             voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         var tmpDataUrl = null;
         if (externalSource) {
             tmpDataUrl = this.getDataUrl();
         } else {
             tmpDataUrl = this.getBinaryUrl();
         }
         var dataObject = options["dataObject"];
         if (!(dataObject instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(voltmx.sdk.isNullOrUndefined(options["queryParams"]))) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
                 return;
             }
         }
         var objName = dataObject.getObjectName();
         var streamingFlag = false;
         if (!voltmx.sdk.isNullOrUndefined(options["streaming"]) && options["streaming"] === true) {
             streamingFlag = true;
         }
         if (!externalSource) {
             if (voltmx.sdk.isNullOrUndefined(binaryAttributeName) || typeof(binaryAttributeName) !== "string") {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::getBinaryData Error: Please provide column name to fetch binary content");
                 voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj("90000", "Please provide column name to fetch binary content"));
                 return;
             } else {
                 options["binaryAttrName"] = binaryAttributeName;
             }
         }
         if (voltmx.sdk.isNullOrUndefined(dataObject.getRecord())) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_getBinaryData Error: Please provide primary key details or fileParams to get Binary content.");
             voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
             return;
         }

         function getBinaryDataOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(response) {
                 _getBinaryData(options, tmpDataUrl, externalSource, streamingFlag, fileDownloadStartedCallback, chunkDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::getBinaryData Error:", error);
                 voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             getBinaryDataOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(getBinaryDataOperationHandler, downloadFailureCallback);
         }
     };
     /**
      * Helps to get the binary content of the specified column on the Object
      * @param {map} options - includes {"dataObject":{@link voltmx.sdk.dto.DataObject}, "binaryAttrName":columnName}
      * @param successCallback
      * @param failureCallback
      */
     this.getBinaryContent = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.getBinaryContent");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         var tmpDataUrl = this.getBinaryUrl();
         var dataObject = options["dataObject"];
         if (!(dataObject instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
                 return;
             }
         }
         var objName = dataObject.getObjectName();
         var binaryColName = options["binaryAttrName"];
         if (binaryColName == null || binaryColName == undefined) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::getBinaryContent Error: Please provide column name to fetch binary content");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj("90000", "Please provide column name to fetch binary content"));
             return;
         }

         function getBinaryContentOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(response) {
                 _getBinaryContent(options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::getBinaryContent Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             getBinaryContentOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(getBinaryContentOperationHandler, failureCallback);
         }
     };
     /**
      * Helps to create the binary content of the specified column on the Object
      * @param {map} options - includes {"dataObject": {@link voltmx.sdk.dto.DataObject}, "binaryAttrName":columnName}
      * @param successCallback
      * @param failureCallback
      */
     this.createBinaryContent = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.createBinaryContent");
         var tmpDataUrl = this.getBinaryUrl();
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         var dataObject = options["dataObject"];
         if (!(dataObject instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
                 return;
             }
         }
         var objName = dataObject.getObjectName();
         var binaryColName = options["binaryAttrName"];
         if (binaryColName == null || binaryColName == undefined) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::createBinaryContent Error: Please provide column name to create binary content");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj("900000", "Please provide column name to create binary content"));
             return;
         }

         function createBinaryContentOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(response) {
                 _createBinaryContent(options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::createBinaryContent Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             createBinaryContentOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(createBinaryContentOperationHandler, failureCallback);
         }
     };
     /**
      * Helps to update the binary content of the specified column on the Object
      * @param {map} options - includes {"dataObject": {@link voltmx.sdk.dto.DataObject}, "binaryAttrName":columnName}
      * @param successCallback
      * @param failureCallback
      */
     this.updateBinaryContent = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OnlineObjectService.updateBinaryContent");
         var tmpDataUrl = this.getBinaryUrl();
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         var dataObject = options["dataObject"];
         if (!(dataObject instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         if (!(options["queryParams"] == null || options["queryParams"] == undefined)) {
             if (!(options["queryParams"] instanceof Object)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
                 return;
             }
         }
         var objName = dataObject.getObjectName();
         var binaryColName = options["binaryAttrName"];
         if (binaryColName == null || binaryColName == undefined) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::updateBinaryContent Error: Please provide column name to create binary content");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj("90000", "Please provide column name to create binary content"));
             return;
         }

         function updateBinaryContentOperationHandler() {
             currentObject.getMetadataOfObject(objName, {}, function(response) {
                 _updateBinaryContent(options, tmpDataUrl, successCallback, failureCallback);
             }, function(error) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::updateBinaryContent Error:", error);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             });
         }
         if (voltmx.sdk.skipAnonymousCall) {
             updateBinaryContentOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(updateBinaryContentOperationHandler, failureCallback);
         }
     };

     function _getBinaryContent(options, tmpDataUrl, successCallback, failureCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var binaryColName = options["binaryAttrName"];
         var objName = dataObject.getObjectName();
         var queryParams = options["queryParams"];
         var url = tmpDataUrl + "/" + objName;
         var objMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, objName);
         if (objMetadata.primaryKey != undefined && objMetadata.primaryKey != null) {
             var pkCount = objMetadata.primaryKey.length;
             if (pkCount == 0) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                 return;
             }
             //reading primarykey and framing filter clause
             var pkey = objMetadata.primaryKey[0];
             if (dataObject.getRecord()[pkey] == undefined || dataObject.getRecord()[pkey] == null) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::_getBinaryContent Error: Please provide primary key details to get Binary content.");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                 return;
             }
             url = url + "?" + pkey + "=" + dataObject.getRecord()[pkey];
             //passing binary column name to server
             if (binaryColName != null && binaryColName != undefined) {
                 url = url + "&fieldName=" + binaryColName;
             }
             if (queryParams != undefined && queryParams != null) {
                 url = url + "&" + voltmx.sdk.util.objectToQueryParams(queryParams);
             }
         } else {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
             return;
         }
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_getBinaryContent::invokeSuccessCallback Response:", response);
             voltmx.sdk.verifyAndCallClosure(successCallback, response["data"]);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_getBinaryContent::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
         invokeObjectOperation(url, dataObject.getObjectName(), headers, null, voltmx.sdk.constants.HTTP_METHOD_GET, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function _getBinaryData(options, tmpDataUrl, externalSource, streamingFlag, fileDownloadStartedCallback, chunkDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var binaryColName = options["binaryAttrName"];
         var objName = dataObject.getObjectName();
         var queryParams = options["queryParams"];
         var url = tmpDataUrl + "/" + objName;
         var objMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, objName);
         if (!externalSource) {
             if (!voltmx.sdk.isNullOrUndefined(objMetadata.primaryKey)) {
                 var pkCount = objMetadata.primaryKey.length;
                 if (pkCount == 0) {
                     voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                     return;
                 }
                 //reading primarykey and framing filter clause
                 var pkey = objMetadata.primaryKey[0];
                 if (voltmx.sdk.isNullOrUndefined(dataObject.getRecord()[pkey])) {
                     voltmx.sdk.logsdk.error("### OnlineObjectService::_getBinaryData Error: Please provide primary key details to get Binary content.");
                     voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                     return;
                 }
                 url = url + "?" + pkey + "=" + dataObject.getRecord()[pkey];
                 //passing binary column name to server
                 if (!voltmx.sdk.isNullOrUndefined(binaryColName)) {
                     url = url + "&fieldName=" + binaryColName;
                 }
                 url = url + "&type=bytes";
                 if (!voltmx.sdk.isNullOrUndefined(queryParams)) {
                     url = url + "&" + voltmx.sdk.util.objectToQueryParams(queryParams);
                 }
             } else {
                 voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                 return;
             }
         }
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var headerKey in headers) {
                 if (!voltmx.sdk.isNullOrUndefined(headerKey)) {
                     if (headerKey.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) {
                         isVoltmxApiVersionAvailable = true;
                         headers[voltmx.sdk.constants.API_VERSION_HEADER] = headers[headerKey];
                     }
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
             headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_getBinaryData::invokeSuccessCallback Response:", response);
             var downloadConfig = response["records"][0];
             downloadConfig.httpStatusCode = response.httpStatusCode;
             if (options && options["ChunkSize"]) {
                 downloadConfig.ChunkSize = options["ChunkSize"];
             }
             var fileParams = dataObject.getRecord();
             if (voltmx.sdk.isNullOrUndefined(fileParams["fileId"])) {
                 fileParams["fileId"] = new Date().getTime().toString();
             }
             voltmx.sdk.binary.getBinaryData(fileParams, streamingFlag, downloadConfig, fileDownloadStartedCallback, chunkDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_getBinaryData::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, error);
         }
         if (externalSource) {
             invokeObjectOperation(url, dataObject.getObjectName(), headers, null, voltmx.sdk.constants.HTTP_METHOD_GET, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
         } else {
             var fileParams = dataObject.getRecord();
             if (voltmx.sdk.isNullOrUndefined(fileParams["fileId"])) {
                 fileParams["fileId"] = dataObject.getRecord()[pkey];
             }
             if (!voltmx.sdk.skipAnonymousCall) {
                 headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmx.sdk.getCurrentInstance().currentClaimToken;
             }
             var downloadConfig = {};
             downloadConfig["endpointUrl"] = url;
             downloadConfig["headers"] = headers;
             //for bypasing template call we need to add method and httpstatus code 309
             downloadConfig.method = voltmx.sdk.constants.HTTP_METHOD_GET;
             downloadConfig.httpStatusCode = voltmx.sdk.binary.constants.VALID_HTTP_REDIRECT_CODE;
             if (options && options["ChunkSize"]) {
                 downloadConfig.ChunkSize = options["ChunkSize"];
             }
             voltmx.sdk.binary.getBinaryData(fileParams, streamingFlag, downloadConfig, fileDownloadStartedCallback, chunkDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback);
         }
     }

     function _createBinaryContent(options, tmpDataUrl, successCallback, failureCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var binaryColName = options["binaryAttrName"];
         var objName = dataObject.getObjectName();
         var queryParams = options["queryParams"];
         var url = tmpDataUrl + "/" + objName;
         var objMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, objName);
         var jsonPayload = {};
         var pkey;
         if (objMetadata.primaryKey != undefined && objMetadata.primaryKey != null) {
             var pkCount = objMetadata.primaryKey.length;
             if (pkCount == 0) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                 return;
             }
             //reading primarykey and framing filter clause
             pkey = objMetadata.primaryKey[0];
             if (dataObject.getRecord()[pkey] == undefined || dataObject.getRecord()[pkey] == null) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::_createBinaryContent Error: Please provide primary key details to create Binary content.");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                 return;
             }
             jsonPayload[pkey] = dataObject.getRecord()[pkey];
             jsonPayload["data"] = dataObject.getRecord()[binaryColName];
             jsonPayload["fieldName"] = binaryColName;
         } else {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
             return;
         }
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }
         var formData = new voltmx.sdk.getFormData(jsonPayload);
         if (!voltmx.sdk.isNullOrUndefined(queryParams)) {
             voltmx.sdk.updateFormData(formData, "queryparams", queryParams);
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_createBinaryContent::invokeSuccessCallback Response:", response);
             voltmx.sdk.verifyAndCallClosure(successCallback, response[pkey]);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_createBinaryContent::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
         invokeObjectOperation(url, dataObject.getObjectName(), headers, formData, null, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function _updateBinaryContent(options, tmpDataUrl, successCallback, failureCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var binaryColName = options["binaryAttrName"];
         var objName = dataObject.getObjectName();
         var queryParams = options["queryParams"];
         var url = tmpDataUrl + "/" + objName;
         var objMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, objName);
         var jsonPayload = {};
         var pkey;
         if (objMetadata.primaryKey != undefined && objMetadata.primaryKey != null) {
             var pkCount = objMetadata.primaryKey.length;
             if (pkCount == 0) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                 return;
             }
             //reading primarykey and framing filter clause
             pkey = objMetadata.primaryKey[0];
             if (dataObject.getRecord()[pkey] == undefined || dataObject.getRecord()[pkey] == null) {
                 voltmx.sdk.logsdk.error("### OnlineObjectService::_updateBinaryContent Error: Please provide primary key details to create Binary content.");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                 return;
             }
             jsonPayload[pkey] = dataObject.getRecord()[pkey];
             jsonPayload["data"] = dataObject.getRecord()[binaryColName];
             jsonPayload["fieldName"] = binaryColName;
         } else {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
             return;
         }
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         headers["X-HTTP-Method-Override"] = "PUT";
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }
         var formData = new voltmx.sdk.getFormData(jsonPayload);
         if (queryParams != undefined && queryParams != null) {
             voltmx.sdk.updateFormData(formData, "queryparams", queryParams);
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_updateBinaryContent::invokeSuccessCallback Response:", response);
             voltmx.sdk.verifyAndCallClosure(successCallback, response[pkey]);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_updateBinaryContent::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
         invokeObjectOperation(url, dataObject.getObjectName(), headers, formData, null, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function _create(options, tmpDataUrl, successCallback, failureCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var url = tmpDataUrl + "/" + dataObject.objectName;
         var record = dataObject.getRecord();
         var queryParams = options["queryParams"];
         if (record == null || record == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "record " + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }
         var formData = new voltmx.sdk.getFormData(record);
         if (queryParams != undefined && queryParams != null) {
             voltmx.sdk.updateFormData(formData, "queryparams", queryParams);
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_create::invokeSuccessCallback Response:", response);
             voltmx.sdk.verifyAndCallClosure(successCallback, response);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_create::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error)
         }
         invokeObjectOperation(url, dataObject.objectName, headers, formData, null, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function _fetch(options, tmpDataUrl, successCallback, serviceErrorCallback) {
         var dataObject = options["dataObject"];
         var odataqueryStr = dataObject.getOdataUrl();
         var headers = options["headers"];
         var queryParams = options["queryParams"];
         var url = tmpDataUrl + "/" + dataObject.objectName;
         if (odataqueryStr != undefined && odataqueryStr != null) {
             if (odataqueryStr.charAt(0) === '$') {
                 odataqueryStr = odataqueryStr.substring(1);
             }
             var odatastr = "";
             var odataList = odataqueryStr.split(/&\$(?=(?:(?:[^']*'){2})*[^']*$)/g);
             for (var list of odataList) {
                 var olist = list.split(/=(?=(?:(?:[^']*'){2})*[^']*$)/g)
                 odatastr = odatastr + "&$" + olist[0] + "=" + encodeURIComponent(olist[1]);
             }
             if (odatastr.charAt(0) === '&') {
                 odatastr = odatastr.substring(1);
             }
             url = url + "?" + odatastr;
             if (queryParams != undefined && queryParams != null) {
                 url = url + "&" + voltmx.sdk.util.objectToQueryParams(queryParams);
             }
         } else if (queryParams != undefined && queryParams != null) {
             url = url + "?" + voltmx.sdk.util.objectToQueryParams(queryParams);
         }
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }
         // If useCache is enabled and cacheID is present then network call will be skipped and cached response will be returned.
         if (options && options["useCache"] && options["cacheID"]) {
             var cacheResponse = new voltmx.sdk.ClientCache().get(options["cacheID"]);
             if (cacheResponse) {
                 voltmx.sdk.logsdk.debug("### OnlineObjectService::_fetch:: key found in cache, invokeSuccessCallback Response:", cacheResponse);
                 voltmx.sdk.verifyAndCallClosure(successCallback, cacheResponse);
                 return;
             }
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_fetch::invokeSuccessCallback Response:", response);
             // If useCache is enabled then the response is cached and returned.
             if (options && options["useCache"]) {
                 cacheResponseForKey(options, url, {
                     "objectName": dataObject.objectName
                 }, response);
             }
             voltmx.sdk.verifyAndCallClosure(successCallback, response);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_fetch::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(serviceErrorCallback, error);
         }
         invokeObjectOperation(url, dataObject.objectName, headers, null, voltmx.sdk.constants.HTTP_METHOD_GET, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function _update(options, tmpDataUrl, updateServiceCallback, serviceErrorCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var url = tmpDataUrl + "/" + dataObject.objectName;
         var queryParams = options["queryParams"];
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }
         headers["X-HTTP-Method-Override"] = "PUT";
         var formData = new voltmx.sdk.getFormData(dataObject.getRecord());
         if (queryParams != undefined && queryParams != null) {
             voltmx.sdk.updateFormData(formData, "queryparams", queryParams);
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_update::invokeSuccessCallback Response:", response);
             voltmx.sdk.verifyAndCallClosure(updateServiceCallback, response);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_update::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(serviceErrorCallback, error);
         }
         invokeObjectOperation(url, dataObject.objectName, headers, formData, null, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function _partialUpdate(options, tmpDataUrl, partialUpdateServiceCallback, serviceErrorCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var url = tmpDataUrl + "/" + dataObject.objectName;
         var queryParams = options["queryParams"];
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         headers["X-HTTP-Method-Override"] = "PATCH";
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }
         var formData = new voltmx.sdk.getFormData(dataObject.getRecord());
         if (queryParams != undefined && queryParams != null) {
             voltmx.sdk.updateFormData(formData, "queryparams", queryParams);
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_partialUpdate::invokeSuccessCallback Success Response:", response);
             voltmx.sdk.verifyAndCallClosure(partialUpdateServiceCallback, response);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_partialUpdate::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(serviceErrorCallback, error);
         }
         invokeObjectOperation(url, dataObject.objectName, headers, formData, null, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function _deleteRecord(options, tmpDataUrl, deleteSuccessCallback, serviceErrorCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var objMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, dataObject.objectName);
         var url = tmpDataUrl + "/" + dataObject.objectName;
         var queryParams = options["queryParams"];
         var odataUrl = "";
         if (objMetadata.primaryKey != undefined && objMetadata.primaryKey != null) {
             var pkCount = objMetadata.primaryKey.length;
             for (var i = 0; i < pkCount; i++) {
                 //reading primarykey and framing filter clause
                 var pkey = objMetadata.primaryKey[i];
                 if (dataObject.getRecord()[pkey] == undefined || dataObject.getRecord()[pkey] == null) {
                     voltmx.sdk.logsdk.error("### OnlineObjectService::_delete Error: Please provide all primary keys to process the request");
                     voltmx.sdk.verifyAndCallClosure(serviceErrorCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                     return;
                 }
                 if (i == 0) {
                     odataUrl = "?$filter=" + pkey + " eq '" + dataObject.getRecord()[pkey] + "'";
                 } else {
                     //appending the condition incase of composite primary key
                     odataUrl = odataUrl + " and " + pkey + " eq '" + dataObject.getRecord()[pkey] + "'";
                 }
             }
         }
         url = url + encodeURI(odataUrl);
         if (queryParams != undefined && queryParams != null) {
             if (odataUrl && odataUrl.length != 0) {
                 url = url + "&" + voltmx.sdk.util.objectToQueryParams(queryParams);
             } else {
                 url = url + "?" + voltmx.sdk.util.objectToQueryParams(queryParams);
             }
         }
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }
         headers["X-HTTP-Method-Override"] = "DELETE";

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_delete::invokeSuccessCallback Response:", response);
             voltmx.sdk.verifyAndCallClosure(deleteSuccessCallback, response);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_delete::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(serviceErrorCallback, error);
         }
         invokeObjectOperation(url, dataObject.objectName, headers, null, voltmx.sdk.constants.HTTP_METHOD_GET, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function _customverb(verbName, options, tmpDataUrl, customVerbServiceCallback, serviceErrorCallback) {
         var dataObject = options["dataObject"];
         var headers = options["headers"];
         var url = tmpDataUrl + "/" + dataObject.objectName + "/" + verbName;
         var queryParams = options["queryParams"];
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = currentObject.getVersion();
             }
         }
         var formData = new voltmx.sdk.getFormData(dataObject.getRecord());
         if (queryParams != undefined && queryParams != null) {
             voltmx.sdk.updateFormData(formData, "queryparams", queryParams);
         }

         function invokeSuccessCallback(response) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_customverb::invokeSuccessCallback Success Response:", response);
             voltmx.sdk.verifyAndCallClosure(customVerbServiceCallback, response);
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_customverb::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(serviceErrorCallback, error);
         }
         invokeObjectOperation(url, dataObject.objectName, headers, formData, null, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }
     this.getFileStorage = function() {
         // TODO : Fix this as there are issues with getMetadataOfAllObjects call - that was hanging	
         return voltmx.sdk.FileStorageClasses.import(this.getFileStorageObjectServiceUrl());
     };
 };

 function _getMetadataUrl(voltmxRef, serviceName) {
     var metadataUrl = null;
     if (voltmxRef.objectsvc[serviceName]) {
         metadataUrl = encodeURI(stripTrailingCharacter(voltmxRef.objectsvc[serviceName]["metadata_url"], "/"));
     } else if (voltmxRef.offlineObjectsvc[serviceName]) {
         metadataUrl = encodeURI(stripTrailingCharacter(voltmxRef.offlineObjectsvc[serviceName]["metadata_url"], "/"));
     }
     return metadataUrl;
 }

 function _getVersion(voltmxRef, serviceName) {
     var version = null;
     if (voltmxRef.objectsvc[serviceName]) {
         version = voltmxRef.objectsvc[serviceName]["version"];
     } else if (voltmxRef.offlineObjectsvc[serviceName]) {
         version = voltmxRef.offlineObjectsvc[serviceName]["version"];
     }
     return version;
 }
 /*This method is used to fetch metadata for Object/Objectservice.
  * It is fetched from cache first, if it not available in cache then fetches method data from metadata URL.
  */
 function _getMetadataForObjectsOrServiceOnlineUtil(voltmxRef, serviceName, objectName, options, successCallback, failureCallback) {
     var tmpMetadataUrl = _getMetadataUrl(voltmxRef, serviceName);;
     if (!(voltmx.sdk.isNullOrUndefined(options)) && !(options["queryParams"] == null || options["queryParams"] == undefined)) {
         if (!(options["queryParams"] instanceof Object)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_queryparams_instance, voltmx.sdk.errormessages.invalid_queryparams_instance));
         }
     }

     function getMetadataOfObjectOperationHandler() {
         _getMetadataForObjectOrService(voltmxRef, serviceName, objectName, options, tmpMetadataUrl, successCallback, failureCallback);
     }
     if (voltmx.sdk.skipAnonymousCall) {
         getMetadataOfObjectOperationHandler();
     } else {
         voltmx.sdk.claimsRefresh(getMetadataOfObjectOperationHandler, failureCallback);
     }
 }

 function _getMetadataForObjectOrService(voltmxRef, serviceName, objectName, options, tmpMetadataUrl, successCallback, failureCallback) {
     //if the getFromServer flag is true then get metadata from server even though its available in cache
     var getFromServer = false;
     var headers = null;
     var queryParams = null;
     if (options != null && options != undefined) {
         getFromServer = options["getFromServer"];
         headers = options["headers"];
         queryParams = options["queryParams"];
     }
     var tmpObjOrSvcMetadata = null;
     if (objectName) {
         tmpObjOrSvcMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, objectName);
     } else {
         tmpObjOrSvcMetadata = voltmx.sdk.ObjectServiceUtil.getCachedMetadata(serviceName);
     }
     if (getFromServer != true && tmpObjOrSvcMetadata != null && tmpObjOrSvcMetadata != undefined) {
         voltmx.sdk.logsdk.debug("### OnlineObjectService::_getMetadataOfObject from Volt MX Store:", tmpObjOrSvcMetadata);
         voltmx.sdk.verifyAndCallClosure(successCallback, tmpObjOrSvcMetadata);
     } else {
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         if (typeof(headers) !== 'undefined' && headers !== null) {
             //check for x-voltmx-api-version case insensitive
             for (var header in headers) {
                 if (header !== null && header !== 'undefined') {
                     if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
                 }
             }
             if (!isVoltmxApiVersionAvailable) {
                 headers[voltmx.sdk.constants.API_VERSION_HEADER] = _getVersion(voltmxRef, serviceName);
             }
         }
         var url = tmpMetadataUrl;
         var svcid = "metadata";
         if (objectName) {
             url = url + "/" + objectName;
             svcid = svcid + "_" + objectName;
         }
         if (queryParams != undefined && queryParams != null) {
             url = url + "?" + voltmx.sdk.util.objectToQueryParams(queryParams);
         }

         function invokeSuccessCallback(result) {
             voltmx.sdk.logsdk.debug("### OnlineObjectService::_getMetadataForObjectOrService::invokeSuccessCallback Response:", result);
             if (objectName) {
                 var table = result["Metadata"]["table"];
                 voltmx.sdk.ObjectServiceUtil.cacheObjectMetadata(serviceName, table);
                 var tmpObjMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, objectName);
                 voltmx.sdk.verifyAndCallClosure(successCallback, tmpObjMetadata);
             } else {
                 var tableArray = result["Metadata"]["tables"];
                 voltmx.sdk.ObjectServiceUtil.cacheMetadata(serviceName, tableArray);
                 var tmpMetadata = voltmx.sdk.ObjectServiceUtil.getCachedMetadata(serviceName);
                 voltmx.sdk.verifyAndCallClosure(successCallback, tmpMetadata);
             }
         }

         function invokeFailureCallback(error) {
             voltmx.sdk.logsdk.error("### OnlineObjectService::_getMetadataForObjectOrService::invokeFailureCallback Error:", error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
         invokeObjectOperation(url, svcid, headers, null, voltmx.sdk.constants.HTTP_METHOD_GET, invokeSuccessCallback, invokeFailureCallback, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }
 }
 //Method is used to send http request for ObjectService operations
 function invokeObjectOperation(url, svcid, headers, formData, httpMethod, successCallback, failureCallback, networkProviderOptions) {
     voltmx.sdk.logsdk.perf("Executing invokeObjectOperation");
     var networkProvider = new voltmxNetworkProvider();
     var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid(svcid);
     var defaultHeaders = {};
     if (!httpMethod) {
         //default http method is post
         httpMethod = "POST";
     }
     if (!voltmx.sdk.skipAnonymousCall) {
         // Check to find if the service is public or not, in case of public service no token is required.
         defaultHeaders[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
     }
     defaultHeaders[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
     defaultHeaders[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
     var deviceId = voltmx.sdk.getDeviceId();
     if (!voltmx.sdk.isNullOrUndefined(deviceId)) {
         defaultHeaders[voltmx.sdk.constants.DEVICEID_HEADER] = deviceId;
     }
     if (reportingData != null && reportingData != undefined) {
         try {
             defaultHeaders[voltmx.sdk.constants.REPORTING_HEADER] = reportingData;
         } catch (error) {
             voltmx.sdk.logsdk.error("### invokeObjectOperation::error while parsing metrics payload" + error);
         }
     }
     // if the user has defined his own headers, use them
     if (headers) {
         var tempHeader = "";
         for (var header in headers) {
             if (voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT.toLowerCase() === header.toLowerCase()) {
                 //Accept can be multiple
                 //Reason being client can be programmed to accept more than one type of content from server.
                 tempHeader = voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT;
                 if (defaultHeaders[tempHeader].toLowerCase() !== headers[header].toLowerCase()) {
                     defaultHeaders[header] = defaultHeaders[tempHeader] + "," + headers[header];
                 }
             } else if (voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER.toLowerCase() === header.toLowerCase()) {
                 tempHeader = voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER;
                 if (defaultHeaders[tempHeader] !== headers[header]) {
                     defaultHeaders[tempHeader] = headers[header];
                 }
             } else if ("content-type" === header.toLowerCase()) {
                 tempHeader = voltmx.sdk.constants.HTTP_CONTENT_HEADER;
                 //Content-type can and should be a single value.
                 //Reason being client can only send a single kind of content at a single instance
                 if (defaultHeaders[tempHeader].toLowerCase() !== headers[header].toLowerCase()) {
                     defaultHeaders[tempHeader] = headers[header];
                 }
             } else {
                 if (defaultHeaders[header] !== headers[header]) {
                     defaultHeaders[header] = headers[header];
                 }
             }
         }
     }

     function networksuccess(res) {
         voltmx.sdk.logsdk.perf("Executing Finished invokeObjectOperation");
         voltmx.sdk.verifyAndCallClosure(successCallback, res);
     }

     function networkerror(xhr, status, err) {
         voltmx.sdk.logsdk.trace("Entering networkerror");
         if (xhr && !(status && err)) {
             err = xhr;
         }
         if (err[voltmx.sdk.constants.MF_CODE]) {
             var voltmxRef = voltmx.sdk.getCurrentInstance();
             //clear the cache if the error code related to session/token expiry
             if (voltmx.sdk.isSessionOrTokenExpired(err[voltmx.sdk.constants.MF_CODE])) {
                 voltmx.sdk.logsdk.warn("###ObjectService::invokeObjectOperationFailure  Session/Token expired. Authenticate and Try again");
                 //voltmx.sdk.resetCacheKeys(voltmxRef);
             }
         }
         voltmx.sdk.logsdk.perf("Executing Finished invokeObjectOperation");
         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getObjectServiceErrObj(err));
     }
     if (httpMethod === "GET") {
         networkProvider.get(url, null, defaultHeaders, networksuccess, networkerror, "formdata", networkProviderOptions);
     } else {
         networkProvider.post(url, formData, defaultHeaders, networksuccess, networkerror, "formdata", networkProviderOptions);
     }
 }
 voltmx.sdk.util = voltmx.sdk.util || {};
 voltmx.sdk.ObjectServiceUtil = voltmx.sdk.ObjectServiceUtil || {};
 voltmx.sdk.dto = voltmx.sdk.dto || {};
 voltmx.sdk.constants.DateTimeType = {
     TODAY: "TODAY",
     YESTERDAY: "YESTERDAY",
     TOMORROW: "TOMORROW",
     CURRENTWEEK: "CURRENTWEEK",
     LASTWEEK: "LASTWEEK",
     NEXTWEEK: "NEXTWEEK",
     CURRENTMONTH: "CURRENTMONTH",
     LASTMONTH: "LASTMONTH",
     NEXTMONTH: "NEXTMONTH"
 };
 voltmx.sdk.constants.Aggregation = {
     NONE: "",
     COUNT: "COUNT",
     SUM: "SUM",
     MAX: "MAX",
     MIN: "MIN",
     AVG: "AVG"
 };
 voltmx.sdk.constants.OrderType = {
     ASCENDING: "ASC",
     DESCENDING: "DESC"
 };
 voltmx.sdk.constants.MatchType = {
     EQUALS: {
         value: "=",
         name: "EQUALS"
     },
     GREATER: {
         value: ">",
         name: "GREATER"
     },
     GREATEREQUAL: {
         value: ">=",
         name: "GREATEREQUAL"
     },
     LESS: {
         value: "<",
         name: "LESS"
     },
     LESSEQUAL: {
         value: "<=",
         name: "LESSEQUAL"
     },
     STARTSWITH: {
         value: "LIKE",
         name: "STARTSWITH"
     },
     CONTAINS: {
         value: "LIKE",
         name: "CONTAINS"
     },
     LIKE: {
         value: "LIKE",
         name: "LIKE"
     },
     ENDSWITH: {
         value: "LIKE",
         name: "ENDSWITH"
     },
     NOTEQUAL: {
         value: "<>",
         name: "NOTEQUAL"
     },
     ISNULL: {
         value: "IS NULL",
         name: "ISNULL"
     },
     ISNOTNULL: {
         value: "IS NOT NULL",
         name: "ISNOTNULL"
     }
 };
 voltmx.sdk.constants.JoinType = {
     INNER: "INNER",
     LEFT: "LEFT",
     RIGHT: "RIGHT"
 };
 voltmx.sdk.constants.Operator = {
     AND: "AND",
     OR: "OR"
 };
 voltmx.sdk.constants.ObjectServiceConstants = {
     DATAOBJECT: "dataObject",
     QUERYPARAMS: "queryParams"
 };
 /**
  * This is a utility function used to check whether the two strings provided
  * would match with each other.
  * @param string1
  * @param string2
  * @return boolean
  */
 voltmx.sdk.util.matchIgnoreCase = function(string1, string2) {
     if (string1 === null || string2 === null || string1 === undefined || string2 === undefined) {
         return false;
     }
     return (string1.toUpperCase() === string2.toUpperCase());
 };
 voltmx.sdk.util.isNull = function(val) {
     if (val === null || val === undefined) return true;
     val = val + "";
     return (voltmx.sdk.util.matchIgnoreCase(val, "null"));
 };
 voltmx.sdk.util.isValidNumberType = function(val) {
     if (voltmx.sdk.util.matchIgnoreCase(typeof val, "number")) return true;
     else if (voltmx.sdk.util.matchIgnoreCase(typeof val, "string") && null != voltmx.sdk.util.toNumber(val)) return true;
     else return false;
 };
 voltmx.sdk.util.toNumber = function(arg) {
     if (arguments.length != 1) {
         throw new Error("Invalid argument to voltmx.sdk.util.toNumber");
     }
     if (typeof(arg) === "number") {
         return arg;
     } else if (typeof(arg) === "string") {
         var str = arg.replace(/^\s*/, '').replace(/\s*$/, '');
         if (str === '') {
             return null;
         } else {
             var num = str - 0;
             return (isNaN(num) ? null : num);
         }
     } else {
         return null;
     }
 };
 voltmx.sdk.util.validateCriteriaObject = function(criteria) {
     if (criteria !== null && criteria !== undefined) {
         return (criteria instanceof voltmx.sdk.dto.Criteria || criteria instanceof voltmx.sdk.dto.Match || criteria instanceof voltmx.sdk.dto.Between || criteria instanceof voltmx.sdk.dto.LogicGroup || criteria instanceof voltmx.sdk.dto.And || criteria instanceof voltmx.sdk.dto.Or || criteria instanceof voltmx.sdk.dto.Not || criteria instanceof voltmx.sdk.dto.Expression || criteria instanceof voltmx.sdk.dto.InCriteria || criteria instanceof voltmx.sdk.dto.Exists || criteria instanceof voltmx.sdk.dto.Join);
     } else {
         return false;
     }
 };
 voltmx.sdk.util.checkAndFetchNetworkProviderOptions = function(options, isPassThroughExpected) {
     var providerOptions = {};
     if (!voltmx.sdk.isNullOrUndefined(options)) {
         if (!voltmx.sdk.isNullOrUndefined(options["httpRequestOptions"]) && options["httpRequestOptions"] instanceof Object) {
             providerOptions["httpRequestOptions"] = options["httpRequestOptions"];
         }
         if (!voltmx.sdk.isNullOrUndefined(options["xmlHttpRequestOptions"]) && options["xmlHttpRequestOptions"] instanceof Object) {
             providerOptions["xmlHttpRequestOptions"] = options["xmlHttpRequestOptions"];
         }
         // [APPPLT-6138][MFSDK-4842] Handle passthrough option, if it is set by the user.
         // As Identity Service calls don't expect passthrough enabled, it will be explicitely set as False if it is called by any Identity service API
         // else it tries to add passthrough for other calls if set by the user.
         if (isPassThroughExpected !== false) {
             if (!voltmx.sdk.isNullOrUndefined(options[voltmx.sdk.constants.PASSTHROUGH])) {
                 providerOptions[voltmx.sdk.constants.PASSTHROUGH] = options[voltmx.sdk.constants.PASSTHROUGH];
             }
         }
     }
     return providerOptions;
 };
 voltmx.sdk.ObjectServiceUtil.cacheMetadata = function(serviceName, objects) {
     if (objects !== undefined && objects !== null) {
         voltmx.sdk.dataStore.removeItem(serviceName);
         for (var i = 0; i < objects.length; i++) {
             var object = objects[i];
             //clearing the existing metadata of service and updating it with the latest metadata
             voltmx.sdk.ObjectServiceUtil.cacheObjectMetadata(serviceName, object);
         }
     }
 };
 voltmx.sdk.ObjectServiceUtil.cacheObjectMetadata = function(serviceName, object) {
     if (object !== undefined && object !== null) {
         //getting metadata of servicename
         var metadataOfAllObjs = voltmx.sdk.dataStore.getItem(serviceName);
         var jsonObject = JSON.parse('{}');
         //if metadata available get it
         if (metadataOfAllObjs !== null && metadataOfAllObjs !== undefined && metadataOfAllObjs !== "{}") {
             jsonObject = JSON.parse(metadataOfAllObjs);
         }
         //adding metadata of object to the existing metadata
         jsonObject[object.name] = object;
         var jsonStr = JSON.stringify(jsonObject);
         voltmx.sdk.dataStore.setItem(serviceName, jsonStr);
     }
 };
 voltmx.sdk.ObjectServiceUtil.getCachedMetadata = function(serviceName) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.ObjectServiceUtil.getCachedMetadata");
     var appMetadata = voltmx.sdk.util.getPackagedMetadata();
     if (appMetadata != null && appMetadata != undefined) {
         if (serviceName != undefined && serviceName != null) return appMetadata[serviceName];
     } else {
         //reading metadata from the store
         var jsonObject = null;
         var metadataOfAllObjs = voltmx.sdk.dataStore.getItem(serviceName);
         if (metadataOfAllObjs !== null && metadataOfAllObjs !== undefined && metadataOfAllObjs !== "{}") {
             jsonObject = JSON.parse(metadataOfAllObjs);
         }
         return jsonObject;
     }
     return null;
 };
 voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata = function(serviceName, objectName) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata");
     var objectMetadata;
     if (objectName !== undefined && objectName !== null) {
         var metadataOfAllObjs = voltmx.sdk.ObjectServiceUtil.getCachedMetadata(serviceName);
         var jsonObject = null;
         if (metadataOfAllObjs !== null && metadataOfAllObjs !== undefined && metadataOfAllObjs !== "{}") {
             jsonObject = metadataOfAllObjs;
             //getting the object's metadata from the stored metadata
             objectMetadata = jsonObject[objectName];
         }
     }
     return objectMetadata;
 };
 /**
  * An object used to perform CRUD operations on objects
  * @param objectName
  * @param record
  * @constructor
  */
 voltmx.sdk.dto.DataObject = function(objectName, record) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.DataObject");
     this.objectName = objectName;
     if (record != null && record != undefined) {
         this.record = record;
     } else {
         this.record = {};
     }
     this.odataUrl = null;
     this.selectQueryObject = null;
     this.offlineObjectsOptions = {};
     this.setOfflineObjectsOptions = function(offlineObjectsOptions) {
         this.offlineObjectsOptions = offlineObjectsOptions;
     };
     this.getOfflineObjectsOptions = function() {
         return this.offlineObjectsOptions;
     };
     /**
      * This function is used to add fields and their values to the dataobject
      * @param fieldName
      * @param value
      */
     this.addField = function(fieldName, value) {
         this.record[fieldName] = value;
     };
     /**
      * This function is used to set a map of records to the dataobject
      * @param fieldValuesMap
      */
     this.setRecord = function(fieldValuesMap) {
         this.record = fieldValuesMap;
     };
     /**
      * This function is used to get the map of records present in the DataObject
      * @returns {JSON} record
      */
     this.getRecord = function() {
         return this.record;
     };
     /**
      * This function is used to add a child Dataobject into the data object
      * @param  childDataObject {@link voltmx.sdk.dto.DataObject}
      */
     this.addChildDataObject = function(childDataObject) {
         if (this.record[childDataObject.objectName] == null || this.record[childDataObject.objectName] == undefined) {
             this.record[childDataObject.objectName] = [];
         }
         this.record[childDataObject.objectName].push(childDataObject.getRecord());
     };
     /**
      * This function is used to set the odata url to query
      * @param odataUrl
      */
     this.setOdataUrl = function(odataUrl) {
         this.odataUrl = odataUrl;
     };
     /**
      * This function is used to get the odata url to query
      * @returns {null}
      */
     this.getOdataUrl = function() {
         return this.odataUrl;
     };
     /**
      * This function is used to set a SelectQueryObject {@link voltmx.sdk.dto.SelectQuery}
      * @param selectQueryObject {@link voltmx.sdk.dto.SelectQuery}
      */
     this.setSelectQueryObject = function(selectQueryObject) {
         this.selectQueryObject = selectQueryObject;
     };
     /**
      * This function is used to get a SelectQueryObject {@link voltmx.sdk.dto.SelectQuery}
      * @returns selectQueryObject {@link voltmx.sdk.dto.SelectQuery}
      */
     this.getSelectQueryObject = function() {
         return this.selectQueryObject;
     };
     /**
      * This function is used to get the object name
      * @returns objectName {string}
      */
     this.getObjectName = function() {
         return this.objectName;
     };
 };
 /**
  * This object is used to define a record object used in Offline CRUD
  * @constructor
  */
 voltmx.sdk.dto.RecordObject = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.RecordObject");
     this.tableName = "";
     this.columnValues = {};
     this.childRecords = [];
 };
 voltmx.sdk.util.getSyncDbName = function() {
     return voltmx.sync.getDBName();
 };
 voltmx.sdk.util.getPrimarykeysFromMetadata = function(objMetadata) {
     var tmpSrcAttributes = null;
     if (objMetadata.primaryKey != null && objMetadata.primaryKey != undefined && objMetadata.primaryKey.length > 0) {
         tmpSrcAttributes = {};
         var pkLen = objMetadata.primaryKey.length;
         for (var indx = 0; indx < pkLen; indx++) {
             var pKey = objMetadata.primaryKey[indx];
             //adding primarykey column names in srcattributes which will be useful while deleting children
             tmpSrcAttributes[pKey] = pKey;
         }
     }
     return tmpSrcAttributes;
 };
 /**
  * This is a replaceAll utility function
  * @param string
  * @param toReplace
  * @param replaceWith
  * @return String temp
  */
 voltmx.sdk.util.replaceAll = function(string, toReplace, replaceWith) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.replaceAll");
     var temp = string;
     var index = temp.indexOf(toReplace);
     while (index != -1) {
         temp = temp.replace(toReplace, replaceWith);
         index = temp.indexOf(toReplace);
     }
     return temp;
 };
 voltmx.sdk.util.validateDateTypeInput = function(dateType) {
     return (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.TODAY) || voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.TOMORROW) || voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.YESTERDAY) || voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.CURRENTWEEK) || voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.NEXTWEEK) || voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.LASTWEEK) || voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.CURRENTMONTH) || voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.NEXTMONTH) || voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.LASTMONTH));
 };
 voltmx.sdk.util.getDateRange = function(dateType) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.getDateRange");
     var result = [];
     var currentDate = new Date();
     var formattedDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), currentDate.getHours(), currentDate.getMinutes(), currentDate.getSeconds(), currentDate.getMilliseconds());
     var start;
     var end;
     if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.TODAY)) {
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 23, 59, 59);
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 0, 0, 0);
     } else if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.TOMORROW)) {
         formattedDate.setDate(formattedDate.getDate() + 1);
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 23, 59, 59);
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 0, 0, 0);
     } else if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.YESTERDAY)) {
         formattedDate.setDate(formattedDate.getDate() - 1);
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 23, 59, 59);
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 0, 0, 0);
     } else if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.CURRENTWEEK)) {
         var firstDayofWeek = formattedDate.getDate() - formattedDate.getDay();
         var lastDayofWeek = firstDayofWeek + 6;
         formattedDate.setDate(firstDayofWeek);
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 0, 0, 0);
         formattedDate.setDate(lastDayofWeek);
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 23, 59, 59);
     } else if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.LASTWEEK)) {
         formattedDate.setDate(formattedDate.getDate() - 7);
         var firstDayofWeek = formattedDate.getDate() - formattedDate.getDay();
         var lastDayofWeek = firstDayofWeek + 6;
         formattedDate.setDate(firstDayofWeek);
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 0, 0, 0);
         formattedDate.setDate(lastDayofWeek);
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 23, 59, 59);
     } else if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.NEXTWEEK)) {
         formattedDate.setDate(formattedDate.getDate() + 7);
         var firstDayofWeek = formattedDate.getDate() - formattedDate.getDay();
         var lastDayofWeek = firstDayofWeek + 6;
         formattedDate.setDate(firstDayofWeek);
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 0, 0, 0);
         formattedDate.setDate(lastDayofWeek);
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), formattedDate.getDate(), 23, 59, 59);
     } else if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.CURRENTMONTH)) {
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), 1, 0, 0, 0);
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth() + 1, 0, 23, 59, 59);
     } else if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.LASTMONTH)) {
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth() - 1, 1, 0, 0, 0, 0);
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth(), 0, 23, 59, 59, 999);
     } else if (voltmx.sdk.util.matchIgnoreCase(dateType, voltmx.sdk.constants.DateTimeType.NEXTMONTH)) {
         start = new Date(formattedDate.getFullYear(), formattedDate.getMonth() + 1, 1, 0, 0, 0, 0);
         end = new Date(formattedDate.getFullYear(), formattedDate.getMonth() + 2, 0, 23, 59, 59, 999);
     } else {
         start = 0;
         end = 0;
     }
     result.push(start);
     result.push(end);
     return result;
 };
 //Helps to prepare the primary condition to get binary data
 voltmx.sdk.util.getPkTableForBinary = function(objMetadata, columnValues, failureCallback) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.getPkTableForBinary");
     var pkTable = {};
     var whereClause = [];
     if (!voltmx.sdk.isNullOrUndefined(objMetadata.primaryKey)) {
         for (var indx = 0; indx < objMetadata.primaryKey.length; indx++) {
             var pKey = objMetadata.primaryKey[indx];
             var pKeyValue = columnValues[pKey];
             if (voltmx.sdk.isNullOrUndefined(pKeyValue)) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                 return;
             }
             pkTable[pKey] = pKeyValue;
         }
         return pkTable;
     } else {
         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
     }
 };
 //Helps to provide the Metadata of column in a Object
 voltmx.sdk.util.getMetadataOfColumn = function(objMetadata, colName) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.getMetadataOfColumn");
     if (objMetadata != null && objMetadata != undefined) {
         var columns = objMetadata["columns"];
         if (columns != null && columns != undefined) {
             for (var indx in columns) {
                 var colMeta = columns[indx];
                 if (colMeta["name"] == colName) {
                     return colMeta;
                 }
             }
         }
     }
     return null;
 };
 //Helps in generating voltmx.sdk.dto.RecordObject from a given complex record
 voltmx.sdk.util.populateColumnValues = function(record, childRecords) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.populateColumnValues");
     var columnValues = {};
     var recordsLength = Object.keys(record).length;
     for (var index = 0; index < recordsLength; index++) {
         var colName = Object.keys(record)[index];
         var colVal = record[colName];
         if (colVal instanceof Array) {
             for (var tempIndex = 0; tempIndex < colVal.length; tempIndex++) {
                 var tempRecord = new voltmx.sdk.dto.RecordObject();
                 tempRecord.tableName = colName;
                 tempRecord.columnValues = voltmx.sdk.util.populateColumnValues(record[colName][tempIndex], tempRecord.childRecords);
                 childRecords.push(tempRecord);
             }
         } else {
             columnValues[colName] = colVal;
         }
     }
     return columnValues;
 };
 //Helps in getting the relationship data of an entity from a given relationship list
 voltmx.sdk.util.getRelationOfEntity = function(relationshipList, entityName) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.getRelationOfEntity");
     var i = 0;
     for (; i < relationshipList.length; i++) {
         //considering only OneToMany relationships as it will have parent and child hierarchy
         if (relationshipList[i] != null && relationshipList[i]["relationshipType"] == "OneToMany" && relationshipList[i].relatedEntity.localeCompare(entityName) == 0) {
             return relationshipList[i];
         }
     }
     return null;
 };
 //Helps in finding if a given column name is a primary key
 voltmx.sdk.util.isPrimaryKey = function(primaryKeyList, columnValue) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.isPrimaryKey");
     for (var i = 0; i < primaryKeyList.length; i++) {
         if (primaryKeyList[i] == columnValue) return true;
     }
     return false;
 };
 voltmx.sdk.util.objectToQueryParams = function(valueObject) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.objectToQueryParams ");
     var queryParams = "";
     if (!voltmx.sdk.isNullOrUndefined(valueObject) && valueObject instanceof Object && Object.keys(valueObject).length > 0) {
         var objCount = Object.keys(valueObject).length;
         for (var i = 0; i < objCount; i++) {
             var tempKey = Object.keys(valueObject)[i];
             if (queryParams.length === 0) queryParams = encodeURIComponent(tempKey) + "=" + encodeURIComponent(valueObject[tempKey]);
             else queryParams = queryParams + "&" + encodeURIComponent(tempKey) + "=" + encodeURIComponent(valueObject[tempKey]);
         }
     }
     return queryParams;
 };
 voltmx.sdk.util.getPackagedMetadata = function() {
     voltmx.sdk.logsdk.trace("Entering into   voltmx.sdk.util.getPackagedMetadata");
     if (voltmx.sdk.APP_META === undefined || voltmx.sdk.APP_META === null) {
         voltmx.sdk.APP_META = {};
     }
     return voltmx.sdk.APP_META["objectsvc_meta"];
 };
 /**
  User needs to call this API to prepackage the metadata of the app. The data needs to be passed as json object or a stringified version of json object
  */
 voltmx.sdk.util.setPackagedMetadata = function(metadataJson) {
     voltmx.sdk.logsdk.trace("Entering into   voltmx.sdk.util.setPackagedMetadata");
     try {
         if (typeof metadataJson == "object") {
             voltmx.sdk.APP_META = metadataJson;
         } else if (typeof metadataJson == "string") {
             var parsedMetadata = JSON.parse(metadataJson);
             voltmx.sdk.APP_META = parsedMetadata;
         }
     } catch (error) {
         voltmx.sdk.logsdk.error("### voltmx.sdk.setPackagedMetadata::error while validating the input packaged metadata", error);
     }
 };
 stripTrailingCharacter = function(str, character) {
     voltmx.sdk.logsdk.trace("Entering into stripTrailingCharacter");
     if (str.substr(str.length - 1) === character) {
         return str.substr(0, str.length - 1);
     }
     return str;
 };
 voltmx.sdk.setLogLevelFromServerResponse = function(responseHeaders) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.setLogLevelFromServerResponse");
     var sdkRef = voltmx.sdk.getCurrentInstance();
     if (responseHeaders && responseHeaders[voltmx.logger.deviceLogLevelHeader]) {
         logLevel = responseHeaders[voltmx.logger.deviceLogLevelHeader].toUpperCase();
         if (!logLevel.localeCompare(voltmx.logger.logLevel.NONE.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.NONE) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.NONE;
         else if (!logLevel.localeCompare(voltmx.logger.logLevel.FATAL.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.FATAL) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.FATAL;
         else if (!logLevel.localeCompare(voltmx.logger.logLevel.ERROR.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.ERROR) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.ERROR;
         else if (!logLevel.localeCompare(voltmx.logger.logLevel.WARN.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.WARN) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.WARN;
         else if (!logLevel.localeCompare(voltmx.logger.logLevel.PERF.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.PERF) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.PERF;
         else if (!logLevel.localeCompare(voltmx.logger.logLevel.INFO.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.INFO) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.INFO;
         else if (!logLevel.localeCompare(voltmx.logger.logLevel.DEBUG.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.DEBUG) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.DEBUG;
         else if (!logLevel.localeCompare(voltmx.logger.logLevel.TRACE.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.TRACE) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.TRACE;
         else if (!logLevel.localeCompare(voltmx.logger.logLevel.ALL.code) && voltmx.logger.currentLogLevel !== voltmx.logger.logLevel.ALL) voltmx.logger.currentLogLevel = voltmx.logger.logLevel.ALL;
         else if (!logLevel.localeCompare('OFF')) {
             voltmx.logger.deactivatePersistors(voltmx.logger.networkPersistor);
             voltmx.logger.currentLogLevel = voltmx.logger.logLevel.NONE;
             sdkRef.removeGlobalRequestParam(voltmx.logger.deviceLogLevelHeader, sdkRef.globalRequestParamType.headers);
             return;
         } else {
             return;
         }
         sdkRef.setGlobalRequestParam(voltmx.logger.deviceLogLevelHeader, logLevel, sdkRef.globalRequestParamType.headers);
         voltmx.logger.activatePersistors(voltmx.logger.networkPersistor);
     }
 };
 voltmx.sdk.prototype.enableDebug = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.prototype.enableDebug");
     voltmx.sdk.isDebugEnabled = true;
 };
 voltmx.sdk.prototype.disableDebug = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.prototype.disableDebug");
     voltmx.sdk.isDebugEnabled = false;
 };

 function Exception(name, message) {
     voltmx.sdk.logsdk.error("Exception --> " + name + ": " + message);
     return {
         code: name,
         message: message
     };
 }
 voltmx.sdk.verifyAndCallClosure = function(closure, params) {
     if (typeof(closure) === 'function') {
         closure(params);
     } else {
         voltmx.sdk.logsdk.warn("invalid callback", JSON.stringify(closure));
     }
 };
 voltmx.sdk.overrideUserId = function(userId) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.overrideUserId");
     if (voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE && typeof(voltmx.setUserID) === 'function') {
         voltmx.setUserID(userId, true);
     } else {
         voltmxRef.setCurrentUserId(userId);
     }
 };
 voltmx.sdk.formatCurrentDate = function(inputDateString) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.formatCurrentDate");
     var dateObj = new Date(inputDateString);
     var year = dateObj.getUTCFullYear();
     var month = voltmx.sdk.formatDateComponent(dateObj.getUTCMonth() + 1);
     var date = voltmx.sdk.formatDateComponent(dateObj.getUTCDate());
     var hours = voltmx.sdk.formatDateComponent(dateObj.getUTCHours());
     var minutes = voltmx.sdk.formatDateComponent(dateObj.getUTCMinutes());
     var seconds = voltmx.sdk.formatDateComponent(dateObj.getUTCSeconds());
     var dateSeparator = "-";
     var timeSeparator = ":";
     var dateString = year + dateSeparator + month + dateSeparator + date + " " + hours + timeSeparator + minutes + timeSeparator + seconds;
     return dateString;
 };
 voltmx.sdk.formatDateComponent = function(dateComponent) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.formatDateComponent");
     if (dateComponent < 10) {
         dateComponent = "0" + dateComponent;
     }
     return dateComponent;
 };
 voltmx.sdk.isNullOrUndefined = function(val) {
     if (val === null || val === undefined) {
         return true;
     } else {
         return false;
     }
 };
 voltmx.sdk.constants.reportingType = {
     session: "session",
     custom: "custom"
 };
 voltmx.sdk.isEmptyObject = function(obj) {
     if (typeof(obj) === "boolean" || typeof(obj) === "number") {
         return false;
     } else if (typeof(obj) === "string") {
         return obj.trim().length === 0;
     }
     for (var prop in obj) {
         return false;
     }
     return true;
 };
 voltmx.sdk.util.isNullOrUndefinedOrEmptyObject = function(object) {
     return (voltmx.sdk.isNullOrUndefined(object) || voltmx.sdk.isEmptyObject(object));
 };
 voltmx.sdk.isArray = function(data) {
     if (data && Object.prototype.toString.call(data) === '[object Array]') {
         return true;
     }
     return false;
 };
 voltmx.sdk.formatSuccessResponse = function(data) {
     if (data && data.httpresponse) {
         delete data.httpresponse;
     }
     return data;
 };
 voltmx.sdk.isJson = function(str) {
     try {
         JSON.parse(str);
     } catch (e) {
         return false;
     }
     return true;
 };
 voltmx.sdk.util.getString = function(val) {
     if (!voltmx.sdk.isNullOrUndefined(val) && (val.toString()).toLocaleLowerCase() !== "null") {
         return val.toString();
     }
     return "";
 };
 //private method to identify whether session/token expired or not based on error code
 voltmx.sdk.isSessionOrTokenExpired = function(mfcode) {
     if (mfcode && (mfcode === "Auth-5" || mfcode === "Auth-6" || mfcode === "Gateway-31" || mfcode === "Gateway-33" || mfcode === "Gateway-35" || mfcode === "Gateway-36" || mfcode === "Auth-46" || mfcode === "Auth-55")) {
         return true;
     }
     return false;
 };
 //private method to clear cache
 voltmx.sdk.resetProviderKeys = function(voltmxRef, _providerName) {
     try {
         if (voltmxRef) {
             if (_providerName) {
                 if (voltmxRef.tokens.hasOwnProperty(_providerName)) {
                     voltmxRef.tokens[_providerName] = null;
                 }
             }
         }
     } catch (e) {
         voltmx.sdk.logsdk.error("Error while clearing the cache..");
     }
 };
 //private method to clear cache
 voltmx.sdk.resetCurrentKeys = function(voltmxRef, _providerName) {
     try {
         if (voltmxRef) {
             voltmxRef.currentClaimToken = null;
             voltmxRef.currentBackEndToken = null;
             voltmxRef.claimTokenExpiry = null;
             voltmxRef.currentRefreshToken = null;
             //setting the anonymous provider as true to access the public protected urls without any issue
             voltmxRef.isAnonymousProvider = true;
             if (_providerName) {
                 if (voltmxRef.tokens.hasOwnProperty(_providerName)) {
                     voltmxRef.tokens[_providerName] = null;
                 }
             }
         }
     } catch (e) {
         voltmx.sdk.logsdk.error("Error while clearing the cache..");
     }
 };
 voltmx.sdk.util.populateIndividualServiceLists = function(serviceConfig, objectToPopulate) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.populateIndividualServiceLists");
     var svcMeta = serviceConfig["services_meta"];
     if (voltmx.sdk.isNullOrUndefined(objectToPopulate["objectsvc"])) {
         objectToPopulate["objectsvc"] = {};
     }
     if (voltmx.sdk.isNullOrUndefined(objectToPopulate["offlineObjectsvc"])) {
         objectToPopulate["offlineObjectsvc"] = {};
     }
     if (svcMeta) {
         for (var svc in svcMeta) {
             if (svcMeta.hasOwnProperty(svc)) {
                 var svcObj = svcMeta[svc];
                 if (svcObj && svcObj["type"] === "objectsvc") {
                     if (!voltmx.sdk.isNullOrUndefined(svcObj["offline"])) {
                         if (svcObj["offline"] === false) {
                             objectToPopulate["objectsvc"][svc] = svcObj;
                         } else if (svcObj["offline"] === true) {
                             objectToPopulate["offlineObjectsvc"][svc] = svcObj;
                         }
                     } else {
                         objectToPopulate["objectsvc"][svc] = svcObj;
                         objectToPopulate["offlineObjectsvc"][svc] = svcObj;
                     }
                 } else if (svcObj && svcObj["type"] === "integsvc") {
                     objectToPopulate["integsvc"][svc] = svcObj;
                 }
             }
         }
     }
 };
 /**
  * Generates hash code for the URL by sha512 algorithm
  * @param url
  * @param requestParams
  * @return {*}
  */
 voltmx.sdk.util.generateHashcodeForURL = function(url, requestParams) {
     var concatenatedResult = "";
     var hashID = null;
     if (!voltmx.sdk.isNullOrUndefined(url)) concatenatedResult += url;
     if (!voltmx.sdk.isNullOrUndefined(requestParams)) {
         concatenatedResult += JSON.stringify(requestParams);
     }
     if (voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE && !voltmx.sdk.util.isNullOrEmptyString(concatenatedResult)) {
         hashID = voltmx.crypto.createHash("sha512", concatenatedResult);
     }
     return hashID;
 };
 /**
  * Utility function to save the response in the cache.
  * @param options {object} save the response with key options["cacheID"]. If not provided then we will calculate hashcode by url and requestData.
  * @param url {string}
  * @param requestData {object}
  * @param response {object}
  */
 function cacheResponseForKey(options, url, requestData, response) {
     var hashCode = null;
     if (options["cacheID"]) hashCode = options["cacheID"];
     else hashCode = voltmx.sdk.util.generateHashcodeForURL(url, requestData);
     if (hashCode) {
         if (typeof(hashCode) !== "string") {
             hashCode = hashCode.toString();
         }
         var expiry = options["expiryTime"] ? options["expiryTime"] : voltmx.sdk.constants.DEFAULT_CACHE_EXPIRY_TIME;
         response["cacheID"] = hashCode;
         new voltmx.sdk.ClientCache().add(hashCode, response, expiry);
     }
 }
 voltmx.sdk.util.isNullOrEmptyString = function(val) {
     if (voltmx.sdk.isNullOrUndefined(val) || (typeof(val) === "string" && val.trim() === "")) {
         return true;
     }
     return false;
 };

 function doesMFSupportsAppversioning() {
     // In case of IDE platforms we will check the existence of appConfig.svcDoc.service_doc_etag for compatibility of app version with the MF.
     // In case of plain-js & phone gap initOptions should not be sent during init call.
     // In case of manual init initially appConfig.svcDoc.service_doc_etag will be undefined. so checking appConfig.isMFApp flag for manual init.
     // Note: With the latest codes changes as part of APPPLT-7480 in 9.3 version for plainjs voltmx.sdk.constants.SDK_TYPE_IDE will have 'js'.
     if (voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE && !voltmx.sdk.isNullOrUndefined(appConfig)) {
         if ((!voltmx.sdk.isNullOrUndefined(appConfig.svcDoc) && !voltmx.sdk.isNullOrUndefined(appConfig.svcDoc.service_doc_etag)) || !appConfig.isMFApp) {
             return true;
         } else {
             return false;
         }
     } else if (voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_PHONEGAP) {
         return true;
     } else {
         return false;
     }
 }

 function populateHeaderWithFoundryAppVersion(headers) {
     if (doesMFSupportsAppversioning() && !voltmx.sdk.isNullOrUndefined(headers) && !voltmx.sdk.isNullOrUndefined(voltmx.sdk.getFoundryAppVersion())) {
         headers[voltmx.sdk.constants.APP_VERSION_HEADER] = voltmx.sdk.getFoundryAppVersion();
     }
 }
 /*
  * Utility method to check whether options has browserWidget or not
  * @return true if it supports
  * */
 voltmx.sdk.util.hasBrowserWidget = function(options) {
     return options && options[voltmx.sdk.constants.BROWSER_WIDGET] && voltmx.sdk.util.type(options[voltmx.sdk.constants.BROWSER_WIDGET]) === "voltmx.ui.Browser";
 };
 /*
  * Utility method to check whether binary is supported
  * @return true if it supports
  * */
 voltmx.sdk.util.isBinarySupported = function() {
     return voltmx.sdk.getSdkType() === voltmx.sdk.constants.SDK_TYPE_IDE && voltmx.sdk.getAType() === voltmx.sdk.constants.SDK_ATYPE_NATIVE;
 };
 /**
  * Utility method to populate authorization headers for Login
  *
  * @params headers map for adding authorization headers
  * @params _providerName provider name for SSO
  * */
 voltmx.sdk.util.populateAuthorizationHeaderForLogin = function(headers, _providerName) {
     if (voltmx.sdk.sso.isSSOEnabled === true) {
         var ssotoken = voltmx.sdk.util.getSSOTokenForProvider(_providerName);
         if (!voltmx.sdk.util.isNullOrEmptyString(ssotoken)) {
             headers[voltmx.sdk.constants.AUTHORIZATION_HEADER] = ssotoken;
         } else {
             voltmx.sdk.logsdk.warn("SSO Token retrieved is empty.");
         }
     }
     if (!voltmx.sdk.isNullOrUndefined(voltmxRef.currentClaimToken) && !voltmx.sdk.isClaimsTokenExpired(voltmxRef.claimTokenExpiry)) {
         headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
     }
 };
 /**
  * Returns the SSO token for the provider.
  *
  *@param _providerName provider for which token is to be deleted
  * @return SSO token
  */
 voltmx.sdk.util.getSSOTokenForProvider = function(_providerName) {
     voltmx.sdk.logsdk.trace("Entered Method : getSSOTokenForProvider.");
     var tokenString = voltmx.sdk.util.getSSOToken();
     if (voltmx.sdk.util.isNullOrEmptyString(tokenString)) {
         voltmx.sdk.logsdk.warn("SSO token is either empty,null or undefined for provider:" + _providerName);
         return null;
     }
     var tokenJSON = JSON.parse(tokenString);
     return tokenJSON[_providerName.toLowerCase()];
 };
 /**
  * Add/Replace and Returns the stringified SSO JSON with
  * the new token and provider or
  * updates the existing one.
  *
  * @param ssoToken token to be added or updated
  * @param _providerName for which the token has to be added
  *
  * @return  Stringified SSO token JSON"{*}"
  */
 voltmx.sdk.util.addOrUpdateSSOTokenWithProvider = function(ssoToken, _providerName) {
     voltmx.sdk.logsdk.trace("Entered Method : addOrUpdateSSOTokenWithProvider.");
     var tokenJSON = {};
     var tokenString = voltmx.sdk.util.getSSOToken();
     if (!voltmx.sdk.util.isNullOrEmptyString(tokenString)) {
         tokenJSON = JSON.parse(tokenString);
     }
     tokenJSON[_providerName.toLowerCase()] = ssoToken;
     return JSON.stringify(tokenJSON);
 };
 /**
  * Deletes the SSO Token for the
  *
  * @parmas _providerName for which the token has to be deleted
  */
 voltmx.sdk.util.deleteSSOTokenForProvider = function(_providerName) {
     voltmx.sdk.logsdk.trace("Entered Method: deleteSSOTokenForProvider.");
     var tokenString = voltmx.sdk.util.getSSOToken();
     if (voltmx.sdk.util.isNullOrEmptyString(tokenString)) {
         voltmx.sdk.logsdk.warn("SSO token is either empty,null or undefined for provider:" + _providerName);
         return null;
     }
     var tokenJSON = JSON.parse(tokenString);
     delete tokenJSON[_providerName.toLowerCase()];
     voltmx.sdk.util.saveSSOToken(JSON.stringify(tokenJSON));
 };
 /*
  ** Utility method to clone any object
  *  @return cloned object
  */
 voltmx.sdk.cloneObject = function(obj) {
     var clonedObject;
     try {
         clonedObject = JSON.parse(JSON.stringify(obj));
     } catch (err) {
         voltmx.sdk.logsdk.error("cloning object failed, reverting back to copy");
         clonedObject = obj;
     }
     return clonedObject;
 };
 /**
  * Utility method to check if a given variable is JSON Object
  * @param obj
  * @returns {boolean}
  */
 voltmx.sdk.util.isJsonObject = function(obj) {
     if (obj === null || obj === undefined) {
         return false;
     }
     return obj.constructor === {}.constructor;
 };
 /**
  * Utility method to check whether the given variable is a valid string
  * @param str
  * @returns {boolean}
  */
 voltmx.sdk.util.isValidString = function(str) {
     if (str === null || str === undefined || str.constructor !== "".constructor) {
         return false;
     }
     return str.trim() !== ""
 };
 /**
  * Utility method to convert JSON object keys to lower case
  * @param obj {Object} - JSON object
  * @returns convertedJSON {Object} - JSON object keys in lower case and values assigned to respective keys.
  */
 voltmx.sdk.util.convertJsonKeysToLowerCase = function(obj) {
     var convertedJSON = {};
     if (!voltmx.sdk.util.isJsonObject(obj)) {
         return obj;
     }
     var keys = Object.keys(obj);
     for (var i = 0; i < keys.length; i++) {
         convertedJSON[keys[i].toLowerCase()] = obj[keys[i]];
     }
     return convertedJSON;
 };
 /**
  * Utility method to get JSON property case-insensitively
  * @param {Object} jsonObject
  * @param {String} key
  * @returns {*}
  */
 voltmx.sdk.util.getValueForKeyAndIgnoreCase = function(jsonObject, key) {
     var keysInJSON = Object.keys(jsonObject);
     var index = 0;
     for (var jsonKey in keysInJSON) {
         if (keysInJSON[jsonKey].toLocaleLowerCase() === key.toLocaleLowerCase()) {
             return Object.values(jsonObject)[index];
         } else {
             index++
         }
     }
     return null;
 };
 /**
  * Utility method to populate JSON Template
  * @param {String} template
  * @param {Object} templateParams : Input Params provided by the User
  * @return Object containing processed template and missing variables
  */
 voltmx.sdk.util.populateTemplate = function(template, templateParams) {
     if (voltmx.sdk.util.isNullOrEmptyString(template) || !voltmx.sdk.util.isJsonObject(templateParams)) {
         voltmx.sdk.logsdk.error(voltmx.sdk.errorConstants.populating_template_failed + " " + voltmx.sdk.errormessages.populating_template_failed);
         return null;
     }
     var DOLLAR_VARIABLE_PATTERN = /(\${)+(\w.*?)+(})/g;
     var templateVariables = [];
     var missingVariables = [];
     var resultSet = {};
     var populatedTemplate = voltmx.sdk.cloneObject(template);
     var inputTemplateVariables = populatedTemplate.match(DOLLAR_VARIABLE_PATTERN);
     //Match returns Array of all the matches.
     //Iterating over the array and extracting all template variables.
     for (var iteratorVariable in inputTemplateVariables) {
         var inputVariable = inputTemplateVariables[iteratorVariable].toString();
         var templateParameter = inputVariable.slice(2, (inputVariable.length) - 1);
         templateVariables.push(templateParameter);
     }
     //Populating the template with user inputs.
     for (var iterateVariable = 0; iterateVariable < templateVariables.length; iterateVariable++) {
         var inputParameter = templateVariables[iterateVariable];
         if (templateParams.hasOwnProperty(inputParameter)) {
             populatedTemplate = populatedTemplate.replace("${" + inputParameter + "}", templateParams[inputParameter]);
         } else {
             missingVariables.push(inputParameter);
         }
     }
     resultSet[voltmx.sdk.constants.PROCESSED_TEMPLATE] = populatedTemplate;
     resultSet[voltmx.sdk.constants.MISSING_VARIABLES] = missingVariables;
     return resultSet;
 };
 /**
  * Checks if the browser is IE11
  * @returns {boolean}
  */
 voltmx.sdk.util.checkForIE11 = function() {
     //Checking if this is being run in DesktopWeb
     if (typeof(XMLHttpRequest) !== 'undefined') {
         var ua = window.navigator.userAgent;
         var trident = ua.indexOf('Trident/');
         if (trident > 0) {
             // IE 11 => return version number
             var rv = ua.indexOf('rv:');
             return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10) === 11;
         }
     }
     return false;
 };
 /**
  * Based on interactive or non-interactive session info from license, returning session type
  * @return {string}
  */
 voltmx.sdk.util.getSessionType = function() {
     var sessionType;
     if (voltmx.licensevar && voltmx.licensevar.isInteractive != undefined) {
         sessionType = voltmx.licensevar.isInteractive ? voltmx.sdk.constants.APP_SESSION_INTERACTIVE : voltmx.sdk.constants.APP_SESSION_NON_INTERACTIVE;
     } else {
         /**
          *In case of phonegap and plain js, we are sending interacting session.
          */
         voltmx.sdk.logsdk.trace("Updating interacting session in Volt MX reporting params by default");
         sessionType = voltmx.sdk.constants.APP_SESSION_INTERACTIVE;
     }
     return sessionType;
 };
 /**
  * Utility method to get Volt MX reporting params in encoded string
  * @return {string}
  */
 voltmx.sdk.getEncodedReportingParamsForSvcid = function(svcid) {
     var reportingData = voltmx.sdk.getPayload(voltmxRef);
     reportingData.rsid = voltmx.sdk.currentInstance.getSessionId();
     if (svcid) {
         reportingData.svcid = svcid;
     } else {
         voltmx.sdk.logsdk.warn("### voltmx.sdk.getEncodedReportingParamsForSvcid:: svcid is either null or undefined");
     }
     return encodeURI(JSON.stringify(reportingData));
 };
 /**
  * Utility method to know if PWA app's display mode is standalone or fullscreen
  * @returns {boolean}
  */
 voltmx.sdk.util.isPWAStandaloneOrFullscreen = function() {
         if (!voltmx.sdk.isNullOrUndefined(window) && window.matchMedia && ((window.matchMedia('(display-mode: standalone)').matches) || (window.matchMedia('(display-mode: fullscreen)').matches) || (window.navigator && window.navigator.standalone))) {
             return true;
         } else {
             return false;
         }
     }
     /**
      * Utility method to know if the device is a mobile device
      * @returns {boolean}
      */
 voltmx.sdk.util.isMobileDevice = function() {
         if (!voltmx.sdk.isNullOrUndefined(navigator) && (/mobile/gi).test(navigator.userAgent)) {
             return true;
         } else {
             return false;
         }
     }
     /**
      * Utility method to open a new browser window as popup in the center of device screen
      * @returns {Object} WindowProxyObject on success of window open and null on failure
      */
 voltmx.sdk.util.openPopupWindow = function(url, title) {
     var height = (screen.height * 75) / 100;
     var width = (screen.width * 40) / 100;
     var left = (screen.width / 2) - (width / 2);
     var top = (screen.height / 2) - (height / 2);
     return window.open(url, title, 'width=' + width + ', height=' + height + ', top=' + top + ', left=' + left);
 };
 /**
  * Utility method to prefix appId to a string
  * @param {String} str
  * @returns {String}
  */
 voltmx.sdk.util.prefixAppid = function(str) {
     return appConfig.appId + "_" + str;
 };
 /**
  * Utility method to clear any existing internal objects
  */
 voltmx.sdk.util.clearExistingWebsocketObject = function() {
     var options = {};
     options[voltmx.sdk.constants.SERVER_EVENTS_CLOSE_CONNECTION] = true;
     if (voltmx.sdk.websocket && voltmx.sdk.websocket.isWebSocketAvailable()) {
         voltmx.sdk.websocket.unSubscribeServerEvents("", function() {
             voltmx.sdk.logsdk.info("Existing websocket connection closed!");
         }, options);
     }
 };
 /**
  * Utility method to get key from value of an object
  */
 voltmx.sdk.util.getKeyByValue = function(obj, value) {
     for (var prop in obj) {
         if (obj.hasOwnProperty(prop)) {
             if (obj[prop] === value) return prop;
         }
     }
 };
 /***
  * Utility function to populate custom oAuth params in body params
  * @param {Object} bodyParams : body params to be populated
  * @param {Object} customOAuthParams : custom oAuth params to populate
  */
 voltmx.sdk.util.populateCustomOAuthParams = function(bodyParams, customOAuthParams) {
     if (voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(customOAuthParams)) {
         return;
     }
     if (voltmx.sdk.isNullOrUndefined(bodyParams)) {
         bodyParams = {};
     }
     for (var customOAuthParamKey in customOAuthParams) {
         var customOAuthParamValue = customOAuthParams[customOAuthParamKey];
         if (typeof customOAuthParamValue === "boolean") {
             customOAuthParamValue = customOAuthParamValue.toString();
             bodyParams[customOAuthParamKey] = customOAuthParamValue;
         } else if (!voltmx.sdk.util.isNullOrEmptyString(customOAuthParamValue)) {
             bodyParams[customOAuthParamKey] = customOAuthParamValue;
         }
     }
 };
 voltmx.sdk.serviceDoc = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.serviceDoc");
     var appId = "";
     var baseId = "";
     var services_meta = {};
     var name = "";
     var selflink = "";
     var login = null;
     var integsvc = {};
     var reportingsvc = {};
     var messagingsvc = {};
     var sync = {};
     var objectsvc = {};
     var logicsvc = {};
     this.toJSON = function() {
         servConfig = {};
         servConfig.appId = this.getAppId();
         servConfig.baseId = this.getBaseId();
         servConfig.name = this.getAppName();
         servConfig.selflink = this.getSelfLink();
         servConfig.services_meta = this.getServicesMeta();
         servConfig.login = this.getAuthServices();
         servConfig.integsvc = this.getIntegrationServices();
         servConfig.messagingsvc = this.getMessagingServices();
         servConfig.sync = this.getSyncServices();
         servConfig.reportingsvc = this.getReportingServices();
         servConfig.objectsvc = this.getObjectServices();
         servConfig.logicsvc = this.getLogicServices();
         voltmx.sdk.util.populateIndividualServiceLists(this, servConfig);
         return servConfig;
     }
     this.setAppId = function(appIdStr) {
         appId = appIdStr;
     };
     this.getAppId = function() {
         return appId;
     };
     this.setBaseId = function(baseIdStr) {
         baseId = baseIdStr;
     };
     this.getBaseId = function() {
         return baseId;
     };
     this.setAppName = function(appName) {
         name = appName;
     };
     this.getAppName = function() {
         return name;
     };
     this.setSelfLink = function(selfLinkStr) {
         selflink = selfLinkStr;
     };
     this.getSelfLink = function() {
         return selflink;
     };

     function setEndPoints(providerType, providerValues) {
         for (var provider in providerValues) {
             providerType[provider] = providerValues[provider];
         }
     }
     this.setAuthService = function(loginProvider) {
         if (login === null) {
             login = [];
         }
         login.push(loginProvider);
     };
     //what will this return? name?
     this.getAuthServiceByName = function(authServiceProvider) {
         if (login === null) {
             return null;
         }
         for (var i in login) {
             var provider = login[i];
             if (provider.prov == authServiceProvider) {
                 return provider;
             }
         }
     };
     this.getAuthServices = function() {
         return login;
     };
     this.setIntegrationService = function(providerName, endPointUrl) {
         integsvc[providerName] = endPointUrl;
     };
     this.getIntegrationServiceByName = function(integrationServiceProviderName) {
         return integsvc[integrationServiceProviderName];
     };
     this.getIntegrationServices = function() {
         return integsvc;
     };
     this.setObjectService = function(providerName, endPointUrl) {
         objectsvc[providerName] = endPointUrl;
     };
     this.getObjectServiceByName = function(objectServiceProviderName) {
         return objectsvc[objectServiceProviderName];
     };
     this.getObjectServices = function() {
         return objectsvc;
     };
     this.getLogicServices = function() {
         return logicsvc;
     };
     this.getServicesMeta = function() {
         return services_meta;
     };
     this.setReportingService = function(reportingType, url) {
         if (reportingType == voltmx.sdk.constants.reportingType.session || reportingType == voltmx.sdk.constants.reportingType.custom) {
             reportingsvc[reportingType] = url;
         } else {
             throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "invalid reporting type " + reportingType);
         }
     }
     this.getReportingServiceByType = function(reportingServiceProviderType) {
         return reportingsvc[reportingServiceProviderType];
     };
     this.getReportingServices = function() {
         return reportingsvc;
     };
     this.setMessagingService = function(appId, url) {
         messagingsvc[appId] = url;
     };
     this.getMessagingServiceByName = function(messagingServiceProviderName) {
         return messagingsvc[messagingServiceProviderName];
     };
     this.getMessagingServices = function() {
         return messagingsvc;
     }
     this.setSyncService = function(syncServiceProvider) {
         sync = syncServiceProvider;
     };
     this.getSyncServices = function() {
         return sync;
     };
 };
 voltmx.logger = voltmx.logger || {};
 voltmx.logger = {
     // Logger constants
     networkPersistorUrlEndpoint: "deviceLogs",
     deviceLogLevelHeader: "X-VOLTMX-DEVICE-LOG-LEVEL",
     filePersistor: 1,
     consolePersistor: 2,
     networkPersistor: 4,
     // Log Level Block which gives all the handle for setting and getting
     //ALL(0) < TRACE(1) < DEBUG(2) < INFO(4) < PEF(8) < WARN(16) < ERROR(32) < FATAL(64) < NONE(127)
     logLevel: {
         NONE: {
             value: 127,
             name: "none",
             code: "NONE"
         },
         FATAL: {
             value: 64,
             name: "fatal",
             code: "FATAL"
         },
         ERROR: {
             value: 32,
             name: "error",
             code: "ERROR"
         },
         WARN: {
             value: 16,
             name: "warn",
             code: "WARN"
         },
         PERF: {
             value: 8,
             name: "perf",
             code: "PERF"
         },
         INFO: {
             value: 4,
             name: "info",
             code: "INFO"
         },
         DEBUG: {
             value: 2,
             name: "debug",
             code: "DEBUG"
         },
         TRACE: {
             value: 1,
             name: "trace",
             code: "TRACE"
         },
         ALL: {
             value: 0,
             name: "all",
             code: "ALL"
         }
     },
     get currentLogLevel() {
         if (typeof(currentLevel) === 'undefined') currentLevel = voltmx.logger.logLevel.NONE;
         if (voltmx.logger.isNativeLoggerAvailable()) {
             var logLevelValue = KonyLogger.getLogLevel();
             for (var key in voltmx.logger.logLevel) {
                 if (voltmx.logger.logLevel.hasOwnProperty(key)) {
                     if (voltmx.logger.logLevel[key].value == logLevelValue) {
                         currentLevel = voltmx.logger.logLevel[key];
                         break;
                     }
                 }
             }
         }
         return currentLevel;
     },
     set currentLogLevel(level) {
         currentLevel = level;
         if (voltmx.logger.isNativeLoggerAvailable()) KonyLogger.setLogLevel(currentLevel.value);
     },
     isNativeLoggerAvailable: function() {
         if (typeof(KonyLogger) === 'undefined') return false;
         else return true;
     },
     flush: function() {
         if (voltmx.logger.isNativeLoggerAvailable()) KonyLogger.flush();
     },
     // Persister block for activating and deactivating
     activatePersistors: function(activatedList) {
         if (voltmx.logger.isNativeLoggerAvailable()) KonyLogger.activatePersistors(activatedList);
     },
     deactivatePersistors: function(deactivatedList) {
         if (voltmx.logger.isNativeLoggerAvailable()) KonyLogger.deactivatePersistors(deactivatedList);
     },
     subscribeLogListener: function(logListener) {
         if (voltmx.logger.isNativeLoggerAvailable()) {
             if (typeof(logListener) === 'function') {
                 KonyLogger.subscribeLogListener(logListener);
             } else {
                 voltmx.sdk.logsdk.warn("loglistener is not a type of function", JSON.stringify(logListener));
             }
         }
     },
     unsubscribeLogListener: function() {
         if (voltmx.logger.isNativeLoggerAvailable()) KonyLogger.unsubscribeLogListener();
     },
     //setting claims token after referesh
     setClaimsToken: function() {
         var token = voltmx.sdk.getCurrentInstance().currentClaimToken;
         if (voltmx.logger.isNativeLoggerAvailable()) KonyLogger.setClaimsToken(token);
     },
     setConfig: function(loggerConfig) {
         if (voltmx.logger.isNativeLoggerAvailable()) {
             KonyLogger.setConfig(loggerConfig.getLoggerConfig());
         }
     },
     setPersistorConfig: function(persistor) {
         if (voltmx.logger.isNativeLoggerAvailable()) {
             KonyLogger.setPersistorConfig(persistor.getPersistorConfig());
         }
     },
     //Setting, removing and resetting global params
     setGlobalRequestParam: function(paramName, paramValue, paramType) {
         if (voltmx.logger.isNativeLoggerAvailable()) {
             KonyLogger.setGlobalRequestParam(paramName, paramValue, paramType);
         }
     },
     removeGlobalRequestParam: function(paramName, paramType) {
         if (voltmx.logger.isNativeLoggerAvailable()) {
             KonyLogger.removeGlobalRequestParam(paramName, paramType);
         }
     },
     resetGlobalRequestParams: function() {
         if (voltmx.logger.isNativeLoggerAvailable()) {
             KonyLogger.resetGlobalRequestParams();
         }
     },
     createLoggerObject: function(loggerName, loggerConfig) {
         var loggerObj = {};
         loggerObj.config = parseConfig(loggerConfig);
         loggerObj.trace = function(msg, params) {
             logMessage(loggerObj, voltmx.logger.logLevel.TRACE, msg, params);
         };
         loggerObj.debug = function(msg, params) {
             logMessage(loggerObj, voltmx.logger.logLevel.DEBUG, msg, params);
         };
         loggerObj.info = function(msg, params) {
             logMessage(loggerObj, voltmx.logger.logLevel.INFO, msg, params);
         };
         loggerObj.perf = function(msg, params) {
             logMessage(loggerObj, voltmx.logger.logLevel.PERF, msg, params);
         };
         loggerObj.warn = function(msg, params) {
             logMessage(loggerObj, voltmx.logger.logLevel.WARN, msg, params);
         };
         loggerObj.error = function(msg, params) {
             logMessage(loggerObj, voltmx.logger.logLevel.ERROR, msg, params);
         };
         loggerObj.fatal = function(msg, params) {
             logMessage(loggerObj, voltmx.logger.logLevel.FATAL, msg, params);
         };
         var indirectionLevel = 0;
         loggerObj.setIndirectionLevel = function(_indirectionLevel) {
             indirectionLevel = _indirectionLevel;
         }
         loggerObj.getIndirectionLevel = function() {
             return indirectionLevel;
         }
         loggerObj.loggerName = loggerName;
         return loggerObj;
     },
     createLoggerConfig: function() {
         var formatC = {};
         var logFilterC = {};
         var accConfig = {};
         var overrideConfig = true;
         var persistorList = [];
         logFilterC.logLevel = voltmx.logger.logLevel.NONE;
         var config = {
             //formatterConfig
             //timeformat
             set timeFormat(val) {
                 formatC.timeFormat = val;
             },
             //timeZone
             set timeZone(val) {
                 formatC.timeZone = val;
             },
             //FilterConfig
             //logLevel
             set logLevel(val) {
                 logFilterC.logLevel = val;
             },
             //accumulatorConfig
             //bytesLimit
             set bytesLimit(val) {
                 accConfig.bytesLimit = val;
             },
             //statementsLimit
             set statementsLimit(val) {
                 accConfig.statementsLimit = val;
             },
             //overrideConfig
             set overrideConfig(val) {
                 overrideConfig = val;
             },
             //peristorList
             get persistorList() {
                 return persistorList;
             },
             addPersistor: function(val) {
                 persistorList.push(val.getPersistorConfig());
             },
             getLoggerConfig: function() {
                 var loggerConfig = {};
                 if (Object.keys(formatC).length > 0) loggerConfig.formatterConfig = formatC;
                 if (Object.keys(logFilterC).length > 0) loggerConfig.logFilterConfig = logFilterC;
                 if (Object.keys(accConfig).length > 0) loggerConfig.accumulatorConfig = accConfig;
                 if (overrideConfig !== null) loggerConfig.overrideConfig = overrideConfig;
                 loggerConfig.persistors = persistorList;
                 return loggerConfig;
             }
         };
         return config;
     },
     createFilePersistor: function() {
         var prop = {};
         var persistorProperties = {
             //Persistor properites
             get persistorType() {
                 return voltmx.logger.filePersistor;
             },
             //maxNumberOfLogFiles
             set maxNumberOfLogFiles(val) {
                 prop.maxNumberOfLogFiles = val;
             },
             //maxFileSize
             set maxFileSize(val) {
                 prop.maxFileSize = val;
             },
             getPersistorConfig: function() {
                 var perConfig = {};
                 perConfig.type = this.persistorType;
                 if (Object.keys(prop).length > 0) perConfig.properties = prop;
                 return perConfig;
             }
         };
         return persistorProperties;
     },
     createNetworkPersistor: function() {
         var prop = {};
         var persistorProperties = {
             //persistorType
             get persistorType() {
                 return voltmx.logger.networkPersistor;
             },
             //URL
             set URL(val) {
                 prop.URL = val;
             },
             getPersistorConfig: function() {
                 var perConfig = {};
                 perConfig.type = this.persistorType;
                 if (Object.keys(prop).length > 0) perConfig.properties = prop;
                 return perConfig;
             }
         };
         return persistorProperties;
     },
     appLoggerInitialisation: function() {
         var loggerObj = {};
         loggerObj = new voltmx.logger.createNewLogger(voltmx.sdk.constants.APP_LOGGER_NAME, null);
         return loggerObj;
     },
     isValidJSTable: function(inputTable) {
         if (voltmx.sdk.isNullOrUndefined(inputTable)) {
             return false;
         }
         if (typeof inputTable === "object" || typeof inputTable === "Object" || typeof inputTable === "Array" || typeof inputTable === "array") {
             return true;
         } else {
             return false;
         }
     }
 };
 voltmx.sdk.KNYObj = voltmx.sdk.VMXObj = function(name, objectServiceName, namespace) {
     var LOG_PREFIX = "VMXObj";
     voltmx.sdk.logsdk.info(LOG_PREFIX + ": Creating VMXObj with name " + name);
     var sdkObjectSync = voltmx.sdk.VMXObj.createSDKObjectSync(name, objectServiceName, namespace);
     this.name = name;
     this.getSdkObjectSync = function() {
         return sdkObjectSync;
     }
     this.startSync = function(syncConfig, successCallback, failureCallback, progressCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing sync on " + this.name + " object");
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Refreshing claims token");
         voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
             voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Finished Refresh claims token : status SUCCESS");
             var token = voltmx.sdk.getCurrentInstance().currentClaimToken;
             voltmx.sdk.OfflineObjects.setToken(token);
             voltmx.sdk.OfflineObjects.setReportingParams(voltmx.sdk.getReportingParamsForOfflineObjects());
             voltmx.sdk.VMXObj.startSync(this, syncConfig, successCallback, failureCallback, progressCallback)
         }.bind(this), function(error) { //claims refresh failure callback
             voltmx.sdk.logsdk.error(LOG_PREFIX + ": Executing Finished Refresh claims token : status FAILED");
             failureCallback(error);
         });
     };
     this.getPendingRecordsForUpload = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Fetching PendingEditSyncRecords in " + this.name + " object");
         voltmx.sdk.VMXObj.getPendingRecordsForUpload(this, options, successCallback, failureCallback);
     };
     this.create = function(record, options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Create record in " + this.name + " object");
         voltmx.sdk.VMXObj.create(this, record, options, successCallback, failureCallback);
     };
     this.update = function(record, options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Update record in " + this.name + " object");
         voltmx.sdk.VMXObj.update(this, record, options, successCallback, failureCallback);
     };
     this.updateByPK = function(record, options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Update record by PK in " + this.name + " object");
         voltmx.sdk.VMXObj.updateByPK(this, record, options, successCallback, failureCallback);
     };
     this.delete = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Delete record in " + this.name + " object");
         voltmx.sdk.VMXObj.delete(this, options, successCallback, failureCallback);
     };
     this.deleteByPK = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Delete record by PK in " + this.name + " object");
         voltmx.sdk.VMXObj.deleteByPK(this, options, successCallback, failureCallback);
     };
     this.get = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Get record from " + this.name + " object");
         voltmx.sdk.VMXObj.get(this, options, successCallback, failureCallback);
     };
     this.getBinary = function(options, fileDownloadStartedCallback, chunkDownloadCompletedCallback, streamDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Get binary for " + this.name + " object");
         voltmx.sdk.VMXObj.getBinary(this, options, fileDownloadStartedCallback, chunkDownloadCompletedCallback, streamDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback);
     };
     this.getBinaryStatus = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing getBinaryStatus for " + this.name + " object");
         voltmx.sdk.VMXObj.getBinaryStatus(this, options, successCallback, failureCallback);
     };
     this.rollback = function(primaryKeyValueMap, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Rollback for " + this.name + " object");
         voltmx.sdk.VMXObj.rollback(this, primaryKeyValueMap, successCallback, failureCallback);
     };
     this.markForUpload = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing MarkForUpload for " + this.name + " object");
         voltmx.sdk.VMXObj.markForUpload(this, options, successCallback, failureCallback);
     };
     this.getUploadDeferredRecordKeys = function(successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Get deferred record primary keys in " + this.name + " object");
         voltmx.sdk.VMXObj.getUploadDeferredRecordKeys(this, successCallback, failureCallback);
     };
     this.cancelSync = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Cancel for " + this.name + " object");
         voltmx.sdk.VMXObj.cancelSync(this, options, successCallback, failureCallback);
     };
     this.clearOfflineData = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing clearOfflineData for " + this.name + " object");
         voltmx.sdk.VMXObj.clearOfflineData(this, options, successCallback, failureCallback);
     };
 };
 voltmx.sdk.KNYObjSvc = voltmx.sdk.VMXObjSvc = function(name) {
     var LOG_PREFIX = "VMXObjSvc";
     voltmx.sdk.logsdk.debug(LOG_PREFIX + ": Creating VMXObjSvc with name " + name);
     var sdkObjectServiceSync = voltmx.sdk.VMXObjSvc.createSDKObjectServiceSync(name);
     this.name = name;
     this.getSdkObjectServiceSync = function() {
         return sdkObjectServiceSync;
     }
     this.getSdkObjectByName = function(name) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Creating VMXObj with name " + name + " and objectServiceName " + this.name);
         var result = new voltmx.sdk.VMXObj(name, this.name);
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing finished for creation of VMXObj with name " + name + " and objectServiceName " + this.name);
         return result;
     }
     this.startSync = function(syncConfig, successCallback, failureCallback, progressCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Starting sync on " + this.name + " object service");
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Refreshing claims token");
         voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
             voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Finished Refresh claims token : status SUCCESS");
             var token = voltmx.sdk.getCurrentInstance().currentClaimToken;
             voltmx.sdk.OfflineObjects.setToken(token);
             voltmx.sdk.OfflineObjects.setReportingParams(voltmx.sdk.getReportingParamsForOfflineObjects());
             voltmx.sdk.VMXObjSvc.startSync(this, syncConfig, successCallback, failureCallback, progressCallback)
         }.bind(this), function(error) { //claims refresh failure callback
             voltmx.sdk.logsdk.error(LOG_PREFIX + ": Executing Finished Refresh claims token : status FAILED");
             failureCallback(error);
         });
     };
     this.rollback = function(successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Rollback on " + this.name + " object service");
         voltmx.sdk.VMXObjSvc.rollback(this, successCallback, failureCallback)
     }
     this.cancelSync = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Cancel for " + this.name + " object service");
         voltmx.sdk.VMXObjSvc.cancelSync(this, options, successCallback, failureCallback);
     }
     this.clearOfflineData = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Clearing Offline Data for " + this.name + " object service.");
         voltmx.sdk.VMXObjSvc.clearOfflineData(this, options, successCallback, failureCallback);
     }
 };
 voltmx.sdk.OfflineObjects = function(objServiceList) {
     var LOG_PREFIX = "OfflineObjects";
     voltmx.sdk.logsdk.trace(LOG_PREFIX + ": Creating OfflineObjects");
     this.setup = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing OfflineObjects.setup()");
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Refreshing claims token");
         voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
             voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Finished Refresh claims token : status SUCCESS");
             var token = voltmx.sdk.getCurrentInstance().currentClaimToken;
             //voltmx.sdk.logsdk.debug(LOG_PREFIX+": Token : "+token);
             voltmx.sdk.OfflineObjects.setToken(token);
             voltmx.sdk.OfflineObjects.setReportingParams(voltmx.sdk.getReportingParamsForOfflineObjects());
             voltmx.sdk.OfflineObjects.setup(objServiceList, options, successCallback, failureCallback);
         }, function() { //claims refresh failure callback
             voltmx.sdk.logsdk.error(LOG_PREFIX + ": Executing Finished Refresh claims token : status FAILED. Setup offline started.");
             voltmx.sdk.OfflineObjects.setup(objServiceList, options, successCallback, failureCallback);
         });
     };
     this.incrementalSetup = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing OfflineObjects incrementalSetup");
         if (!options) {
             options = {};
         }
         options.incrementalSetup = true;
         this.setup(options, successCallback, failureCallback);
     }
     this.drop = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing OfflineObjects.drop()");
         voltmx.sdk.OfflineObjects.drop(options, successCallback, failureCallback);
     }
     this.reset = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing OfflineObjects.reset");
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Refresh claims token");
         voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
             voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Finished Refresh claims token : status SUCCESS");
             var token = voltmx.sdk.getCurrentInstance().currentClaimToken;
             //voltmx.sdk.logsdk.debug(LOG_PREFIX+": Token : "+token);
             voltmx.sdk.OfflineObjects.setToken(token);
             voltmx.sdk.OfflineObjects.setReportingParams(voltmx.sdk.getReportingParamsForOfflineObjects());
             voltmx.sdk.OfflineObjects.reset(objServiceList, options, successCallback, failureCallback);
         }, function(error) { //claims refresh failure callback
             voltmx.sdk.logsdk.error(LOG_PREFIX + ": Executing Finished Refresh claims token : status FAILED");
             failureCallback(error);
         });
     }
     this.rollback = function(successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing OfflineObjects.rollback()");
         voltmx.sdk.OfflineObjects.rollback(successCallback, failureCallback);
     }
     this.executeSelectQuery = function(query, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing OfflineObjects.executeSelectQuery()");
         voltmx.sdk.OfflineObjects.executeSelectQuery(query, successCallback, failureCallback);
     }
     this.startSync = function(options, successCallback, failureCallback, progressCallback) {
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing OfflineObjects.startSync");
         voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Refresh claims");
         voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
             voltmx.sdk.logsdk.perf(LOG_PREFIX + ": Executing Finished Refresh claims token : status SUCCESS");
             var token = voltmx.sdk.getCurrentInstance().currentClaimToken;
             voltmx.sdk.OfflineObjects.setToken(token);
             voltmx.sdk.OfflineObjects.setReportingParams(voltmx.sdk.getReportingParamsForOfflineObjects());
             voltmx.sdk.OfflineObjects.startSync(options, successCallback, failureCallback, progressCallback);
         }, function(error) { //claims refresh failure callback
             voltmx.sdk.logsdk.error(LOG_PREFIX + "Executing Finished Application Sync : Refresh claims token : status FAILED");
             failureCallback(error);
         });
     }
 };
 voltmx.sdk.OfflineObjects.BinaryStatus = {
         "pending": 2,
         "completed": 4,
         "errored": 8
     }
     /*
     JS Bindings to SyncV2 native classes
     */
 voltmx.sdk.SyncV2Classes = (function() {
     var instance = null;
     var LOG_PREFIX = "voltmx.sdk.SyncV2Classes";

     function createInstance() {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Creating instance of SyncV2Classes");
         var obj = {};
         obj.ApplicationSync = java.import("sync.kony.com.syncv2library.Android.SyncMFInterface.ApplicationSync");
         obj.SDKObjectSync = java.import("sync.kony.com.syncv2library.Android.SyncMFInterface.SDKObjectSync");
         obj.VoltmxMain = java.import("com.konylabs.android.KonyMain");
         obj.SDKObjectServiceSync = java.import("sync.kony.com.syncv2library.Android.SyncMFInterface.SDKObjectServiceSync");
         obj.ApplicationSync.setApplicationContext(obj.VoltmxMain.getAppContext());
         obj.SyncCallback = java.newClass("SyncCallback", "java.lang.Object", ["sync.kony.com.syncv2library.Android.SyncMFInterface.SyncCallback"], {
             successCallback: undefined,
             successLog: "onSuccess",
             failureLog: "onFailure",
             failureCallback: undefined,
             onSuccess: function(obj) {
                 voltmx.sdk.logsdk.info("SyncCallback : " + this.successLog);
                 this.successCallback(obj);
             },
             onFailure: function(error) {
                 voltmx.sdk.logsdk.error("SyncCallback : " + this.failureLog);
                 var err = new Exception(error.getErrorCode(), error.getLocalizedMessage());
                 var syncErrors = error.getSyncErrors();
                 var callStack = error.getCallStack();
                 var domain = error.getDomain();
                 var userInfo = error.getUserInfo();
                 if (syncErrors) {
                     err.syncErrors = syncErrors;
                 }
                 if (callStack) {
                     err.callStack = callStack;
                 }
                 if (domain) {
                     err.domain = domain;
                 }
                 if (userInfo) {
                     var JavaClasses = voltmx.sdk.JavaClasses.import();
                     var gson = new JavaClasses.GsonBuilder().serializeNulls().create();
                     var infoJson = gson.toJson(userInfo);
                     err.userInfo = JSON.parse(infoJson);
                 }
                 this.failureCallback(err);
             }
         });
         obj.VoltmxSyncProgressCallback = java.newClass("SyncProgressCallback", "java.lang.Object", ["sync.kony.com.syncv2library.Android.SyncMFInterface.SyncProgressCallback"], {
             progressCallback: undefined,
             progressLog: "onProgress",
             onProgress: function(obj) {
                 voltmx.sdk.logsdk.trace("VoltmxSyncProgressCallback : " + this.progressLog);
                 this.progressCallback(obj);
             }
         });
         obj.BinaryDownloadCallback = java.newClass("BinaryDownloadCallback", "java.lang.Object", ["sync.kony.com.syncv2library.Android.SyncMFInterface.BinaryDownloadCallback"], {
             fileDownloadStartedCompletionBlock: undefined,
             streamDownloadCompletionBlock: undefined,
             chunkDownloadCompletedCompletionBlock: undefined,
             fileDownloadCompletedCompletionBlock: undefined,
             downloadFailureCompletionBlock: undefined,
             onFileDownloadStartedLog: "onFileDownloadStarted",
             onStreamDownloadCompletedLog: "onStreamDownloadCompleted",
             onChunkDownloadCompletedLog: "onChunkDownloadCompleted",
             onFileDownloadCompletedLog: "onFileDownloadCompleted",
             onDownloadFailureLog: "onDownloadFailure",
             onFileDownloadStarted: function(obj) {
                 voltmx.sdk.logsdk.trace("BinaryDownloadCallback : " + this.onFileDownloadStartedLog);
                 this.fileDownloadStartedCompletionBlock(obj);
             },
             onStreamDownloadCompleted: function(obj) {
                 voltmx.sdk.logsdk.trace("BinaryDownloadCallback : " + this.onStreamDownloadCompletedLog);
                 this.streamDownloadCompletionBlock(obj);
             },
             onChunkDownloadCompleted: function(obj) {
                 voltmx.sdk.logsdk.trace("BinaryDownloadCallback : " + this.onChunkDownloadCompletedLog);
                 this.chunkDownloadCompletedCompletionBlock(obj);
             },
             onFileDownloadCompleted: function(obj) {
                 voltmx.sdk.logsdk.trace("BinaryDownloadCallback : " + this.onFileDownloadCompletedLog);
                 this.fileDownloadCompletedCompletionBlock(obj);
             },
             onDownloadFailure: function(error) {
                 voltmx.sdk.logsdk.trace("BinaryDownloadCallback : " + this.onDownloadFailureLog);
                 var err = new Exception(error.getErrorCode(), error.getLocalizedMessage());
                 var syncErrors = error.getSyncErrors();
                 var callStack = error.getCallStack();
                 var domain = error.getDomain();
                 var userInfo = error.getUserInfo();
                 if (syncErrors) {
                     err.syncErrors = syncErrors;
                 }
                 if (callStack) {
                     err.callStack = callStack;
                 }
                 if (domain) {
                     err.domain = domain;
                 }
                 if (userInfo) {
                     var JavaClasses = voltmx.sdk.JavaClasses.import();
                     var gson = new JavaClasses.GsonBuilder().serializeNulls().create();
                     var infoJson = gson.toJson(userInfo);
                     err.userInfo = JSON.parse(infoJson);
                 }
                 this.downloadFailureCompletionBlock(err);
             }
         });
         return obj;
     }
     return {
         import: function() {
             voltmx.sdk.logsdk.info(LOG_PREFIX + ": Importing native SyncV2 Classes");
             if (instance === null) {
                 instance = createInstance();
             }
             return instance;
         }
     };
 })();
 voltmx.sdk.FileStorageClasses = (function() {
     var mapOfInstanceToURL = {};
     var LOG_PREFIX = "voltmx.FileStorageAdapter";

     function createInstance(url) {
         voltmx.sdk.logsdk.trace(LOG_PREFIX + ": Creating instance of FileStorageClasses");
         var obj = {};
         obj.BinaryFileStorageInterface = java.import("com.kony.binarydatamanager.BinaryFileAdapterWithMetadata.FileAdapterInterface.BinaryFileStorageInterface");
         obj.VoltmxMain = java.import("com.konylabs.android.KonyMain");
         obj.BinaryFileStorageInterface.setApplicationContext(obj.VoltmxMain.getAppContext());
         obj.SuccessCallback = java.newClass("ISuccessCallback", "java.lang.Object", ["com.kony.binarydatamanager.BinaryFileAdapterWithMetadata.callback.ISuccessCallback"], {
             successCallback: undefined,
             successLog: "onSuccess",
             onSuccess: function(res) {
                 voltmx.sdk.logsdk.trace("Binary Success Callback : " + this.successLog);
                 this.successCallback(res);
             }
         });
         obj.FailureCallback = java.newClass("IFailureCallback", "java.lang.Object", ["com.kony.binarydatamanager.BinaryFileAdapterWithMetadata.callback.IFailureCallback"], {
             failureCallback: undefined,
             failureLog: "onFailure",
             onFailure: function(err) {
                 voltmx.sdk.logsdk.trace("Binary Failure Callback : " + this.failureLog);
                 this.failureCallback(err);
             }
         });
         obj.ProgressCallback = java.newClass("IProgressCallback", "java.lang.Object", ["com.kony.binarydatamanager.BinaryFileAdapterWithMetadata.callback.IProgressCallback"], {
             progressCallback: undefined,
             progressLog: "onProgress",
             onProgress: function(res) {
                 voltmx.sdk.logsdk.trace("Binary Progress Callback : " + this.progressLog);
                 this.progressCallback(res);
             }
         });
         obj.listFiles = function(filter, headers, successCallback, failureCallback, options) {
             voltmx.sdk.FileStorageClasses.listFiles(url, filter, headers, successCallback, failureCallback, options);
         };
         obj.upload = function(uploadInputType, uploadParams, successCallback, failureCallback, options) {
             voltmx.sdk.FileStorageClasses.upload(url, uploadInputType, uploadParams, successCallback, failureCallback, options);
         };
         obj.download = function(downloadParams, successCallback, failureCallback, options) {
             voltmx.sdk.FileStorageClasses.download(url, downloadParams, successCallback, failureCallback, options);
         };
         obj.deleteById = function(fileId, deleteParams, headers, successCallback, failureCallback, options) {
             voltmx.sdk.FileStorageClasses.deleteById(url, fileId, deleteParams, headers, successCallback, failureCallback, options);
         };
         obj.deleteByCriteria = function(deleteParams, headers, successCallback, failureCallback, options) {
             voltmx.sdk.FileStorageClasses.deleteByCriteria(url, deleteParams, headers, successCallback, failureCallback, options);
         };
         obj.update = function(updateParams, successCallback, failureCallback, options) {
             voltmx.sdk.FileStorageClasses.update(url, updateParams, successCallback, failureCallback, options);
         };
         obj.abort = function(fileId, abortParams, headers, successCallback, failureCallback, options) {
             voltmx.sdk.FileStorageClasses.abort(url, fileId, abortParams, headers, successCallback, failureCallback, options);
         };
         return obj;
     }
     return {
         import: function(url) {
             voltmx.sdk.logsdk.trace(LOG_PREFIX + ": Importing native FileStorageClasses");
             var instance = mapOfInstanceToURL[url];
             if (instance === undefined) {
                 instance = createInstance(url);
                 mapOfInstanceToURL[url] = instance;
             }
             return instance;
         }
     };
 })();
 /*
 JS Bindings to Java native classes
 */
 voltmx.sdk.JavaClasses = (function() {
     var instance = null;
     var LOG_PREFIX = "voltmx.sdk.JavaClasses";

     function createInstance() {
         voltmx.sdk.logsdk.trace(LOG_PREFIX + ": Creating instance of SyncV2Classes");
         var obj = {};
         obj.HashMap = java.import("java.util.HashMap");
         obj.Gson = java.import("com.google.gson.Gson");
         obj.GsonBuilder = java.import("com.google.gson.GsonBuilder");
         return obj;
     }
     return {
         import: function() {
             voltmx.sdk.logsdk.info(LOG_PREFIX + ": Importing native Java Classes");
             if (instance === null) {
                 instance = createInstance();
             }
             return instance;
         }
     };
 })();
 voltmx.sdk.messageIntegrityManager = (function() {
     var instance = null;
     var LOG_PREFIX = "voltmx.sdk.messageIntegrityManager";

     function createInstance() {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Creating instance of messageIntegrityManager");
         var obj = {};
         obj.httpMessageIntegrityManager = java.import("com.kony.sdkcommons.Network.NetworkCore.KNYHTTPMessageIntegrityManager");
         return obj;
     }
     return {
         import: function() {
             voltmx.sdk.logsdk.info(LOG_PREFIX + ": Importing native classes for HTTP message integrity.");
             if (instance === null) {
                 instance = createInstance();
             }
             return instance;
         }
     };
 })();
 voltmx.sdk.clientCertificatesManager = (function() {
     var instance = null;
     var LOG_PREFIX = "voltmx.sdk.clientCertificatesManager";

     function createInstance() {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Creating instance of VMXClientCertificatesManager");
         var obj = {};
         obj.clientCertificatesManager = java.import("com.kony.sdkcommons.Network.NetworkCore.KNYClientCertificatesManager");
         return obj;
     }
     return {
         import: function() {
             voltmx.sdk.logsdk.info(LOG_PREFIX + ": Importing native classes for SSL Pinning");
             if (instance === null) {
                 instance = createInstance();
             }
             return instance;
         }
     };
 })();
 /*
  *JSBindings for VMXWebSocket
  */
 voltmx.sdk.VoltmxWebSocketClasses = (function() {
     var instance = null;
     var LOG_PREFIX = "voltmx.WebSocket";

     function createInstance() {
         voltmx.sdk.logsdk.trace(LOG_PREFIX + ": Creating instance of VoltmxWebSocketClasses");
         var obj = {};
         obj.VoltmxWebSocketInterface = java.import("com.kony.konywebsocket.websocketinterface.KonyWebSocket");
         obj.MessageCallback = java.newClass("IMessageCallback", "java.lang.Object", ["com.kony.konywebsocket.callbacks.IMessageCallback"], {
             onMessageCallback: undefined,
             onMessageLog: "onMessage",
             onMessage: function(res) {
                 voltmx.sdk.logsdk.trace("Volt MX Websocket onMessage Callback : " + this.onMessageLog);
                 this.onMessageCallback(res);
             }
         });
         obj.ErrorCallback = java.newClass("IErrorCallback", "java.lang.Object", ["com.kony.konywebsocket.callbacks.IErrorCallback"], {
             onErrorCallback: undefined,
             onErrorLog: "onError",
             onError: function(err) {
                 voltmx.sdk.logsdk.trace("Volt MX Websocket onError Callback : " + this.onErrorLog);
                 this.onErrorCallback(err);
             }
         });
         obj.CloseCallback = java.newClass("ICloseCallback", "java.lang.Object", ["com.kony.konywebsocket.callbacks.ICloseCallback"], {
             onCloseCallback: undefined,
             onCloseLog: "onClose",
             onClose: function(res) {
                 voltmx.sdk.logsdk.trace("Volt MX Websocket onClose Callback : " + this.onCloseLog);
                 this.onCloseCallback(res);
             }
         });
         obj.SubscribeCallback = java.newClass("ISubscribeCallback", "java.lang.Object", ["com.kony.konywebsocket.callbacks.ISubscribeCallback"], {
             onSubscribeCallback: undefined,
             onSubscribeLog: "onSubscribe",
             onSubscribe: function(res) {
                 voltmx.sdk.logsdk.trace("Volt MX Websocket onSubscribe Callback : " + this.onSubscribeLog);
                 this.onSubscribeCallback(res);
             }
         });
         obj.UnSubscribeCallback = java.newClass("IUnSubscribeCallback", "java.lang.Object", ["com.kony.konywebsocket.callbacks.IUnSubscribeCallback"], {
             onUnSubscribeCallback: undefined,
             onUnSubscribeLog: "onUnsubscribe",
             onUnsubscribe: function(res) {
                 voltmx.sdk.logsdk.trace("Volt MX WebSocket onUnSubscribe Callback : " + this.onUnSubscribeLog);
                 this.onUnSubscribeCallback(res);
             }
         });
         obj.PublishCallback = java.newClass("IPublishCallback", "java.lang.Object", ["com.kony.konywebsocket.callbacks.IPublishCallback"], {
             onPublishCallback: undefined,
             onPublishLog: "onPublish",
             onPublish: function(res) {
                 voltmx.sdk.logsdk.trace("Volt MX WebSocket onPublish Callback : " + this.onPublish);
                 this.onPublishCallback(res);
             }
         });
         return obj;
     }
     return {
         import: function() {
             voltmx.sdk.logsdk.trace(LOG_PREFIX + ": Importing native VMXWebSocket");
             if (instance === null) {
                 instance = createInstance();
             }
             return instance;
         }
     };
 })();
 voltmx.sdk.globalRequestParams = (function() {
     var instance = null;
     var LOG_PREFIX = "voltmx.sdk.GlobalRequestParams";

     function createInstance() {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Creating instance of GlobalRequestParams");
         var obj = {};
         obj.clientGlobalRequestParams = java.import("com.kony.sdkcommons.Network.KNYGlobalRequestParams");
         return obj;
     }
     return {
         import: function() {
             voltmx.sdk.logsdk.info(LOG_PREFIX + ": Importing native classes for GlobalRequestParams");
             if (instance === null) {
                 instance = createInstance();
             }
             return instance;
         }
     };
 })();
 voltmx.sdk.httpIntegrity = voltmx.sdk.httpIntegrity || {};
 voltmx.sdk.httpIntegrity.getHTTPIntegrityManager = function() {
     var LOG_PREFIX = "voltmx.sdk.httpIntegrity.getHTTPIntegrityManager";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var httpIntegrityManager = voltmx.sdk.messageIntegrityManager.import();
     return httpIntegrityManager;
 };
 voltmx.sdk.httpIntegrity.setIntegrityCheck = function(propertiesForIntegrity) {
     var LOG_PREFIX = "voltmx.sdk.httpIntegrity.setIntegrityCheck";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var importedClasses = voltmx.sdk.httpIntegrity.getHTTPIntegrityManager();
     try {
         var propertiesForIntegrityHashMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(propertiesForIntegrity, "Properties being created.");
         importedClasses.httpMessageIntegrityManager.setIntegrityCheck(propertiesForIntegrityHashMap);
     } catch (error) {
         var exception = new Exception(error.code, error.message);
         if (error.domain) {
             exception.domain = error.domain;
         }
         if (error.userInfo && error.userInfo.callStack) {
             exception.callStack = error.userInfo.callStack;
         }
         throw exception;
     }
 };
 voltmx.sdk.httpIntegrity.removeIntegrityCheck = function() {
     var LOG_PREFIX = "voltmx.sdk.httpIntegrity.removeIntegrityCheck";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var importedClasses = voltmx.sdk.httpIntegrity.getHTTPIntegrityManager();
     importedClasses.httpMessageIntegrityManager.removeIntegrityCheck();
 };
 /*
  * Overriding the logic of frameworks implementation to support 2-way SSL Pinning
  * API - voltmx.net.loadClientCertificate
  */
 var voltmxNetLoadClientCertificates = voltmx.net.loadClientCertificate;
 voltmx.net.loadClientCertificate = function(certParams) {
     function voltmxSDKLoadClientCertificate(certParams) {
         var LOG_PREFIX = "voltmx.SDK.loadClientCertificate";
         voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
         var importedClasses = voltmx.sdk.clientCertificatesManager.import();
         return importedClasses.clientCertificatesManager.loadClientCertificate(certParams);
     }
     var cert = "cert";
     if (voltmx.type(certParams[cert]) === "voltmx.types.RawBytes") {
         var rawBytes = certParams[cert];
         var base64 = voltmx.convertToBase64(rawBytes);
         certParams[cert] = base64;
     }
     //Calling SDK's API
     var certParamsHashMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(certParams, "Cert Params for SSL Pinning");
     voltmxSDKLoadClientCertificate(certParamsHashMap);
     // Calling Framework's API
     return voltmxNetLoadClientCertificates(certParams);
 };
 /*
  * Overriding the logic of frameworks implementation to support 2-way SSL Pinning
  * API - voltmx.net.removeClientCertificate
  */
 var voltmxNetRemoveClientCertificate = voltmx.net.removeClientCertificate;
 voltmx.net.removeClientCertificate = function() {
     function voltmxSDKRemoveClientCertificate() {
         var LOG_PREFIX = "voltmxSDKRemoveClientCertificate";
         voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
         var importedClasses = voltmx.sdk.clientCertificatesManager.import();
         importedClasses.clientCertificatesManager.removeClientCertificate();
     }
     // Calling Native SDK's API
     voltmxSDKRemoveClientCertificate();
     // Calling Framework's API
     return voltmxNetRemoveClientCertificate();
 };
 /*
  * API - Related to global request params.
  */
 voltmx.sdk.sdkCommons = voltmx.sdk.sdkCommons || {};
 voltmx.sdk.sdkCommons.getClientGlobalRequestParams = function() {
     var LOG_PREFIX = "voltmx.sdk.sdkCommons.getClientGlobalRequestParams";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var globalRequestParams = voltmx.sdk.globalRequestParams.import();
     return globalRequestParams;
 };
 voltmx.sdk.sdkCommons.setGlobalRequestParam = function(paramName, paramValue, paramType) {
     var LOG_PREFIX = "voltmx.sdk.sdkCommons.setGlobalRequestParam";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var importedClasses = voltmx.sdk.sdkCommons.getClientGlobalRequestParams();
     importedClasses.clientGlobalRequestParams.setGlobalRequestParam(paramName, paramValue, paramType);
 };
 voltmx.sdk.sdkCommons.removeGlobalRequestParam = function(paramName, paramType) {
     var LOG_PREFIX = "voltmx.sdk.sdkCommons.removeGlobalRequestParam";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var importedClasses = voltmx.sdk.sdkCommons.getClientGlobalRequestParams();
     importedClasses.clientGlobalRequestParams.removeGlobalRequestParam(paramName, paramType);
 };
 voltmx.sdk.sdkCommons.resetGlobalRequestParams = function() {
     var LOG_PREFIX = "voltmx.sdk.sdkCommons.resetGlobalRequestParam";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var importedClasses = voltmx.sdk.sdkCommons.getClientGlobalRequestParams();
     importedClasses.clientGlobalRequestParams.resetGlobalRequestParams();
 };
 voltmx.sdk.OfflineObjects.setToken = function(token) {
     var LOG_PREFIX = "voltmx.sdk.OfflineObjects.setToken";
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     syncV2Classes.ApplicationSync.setToken(token);
 };
 voltmx.sdk.OfflineObjects.setReportingParams = function(reportingParams) {
     var LOG_PREFIX = "voltmx.sdk.OfflineObjects.setReportingParams";
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     syncV2Classes.ApplicationSync.setReportingParams(reportingParams);
 };
 voltmx.sdk.OfflineObjects.createSyncCallback = function(successLog, successCallback, failureLog, failureCallback) {
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     var syncCallback = new syncV2Classes.SyncCallback();
     syncCallback.successCallback = successCallback;
     syncCallback.successLog = successLog;
     syncCallback.failureCallback = failureCallback;
     syncCallback.failureLog = failureLog;
     return syncCallback;
 };
 voltmx.sdk.OfflineObjects.createVoltmxSyncProgressCallback = function(progressLog, progressCallback) {
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     var voltmxSyncProgressCallback = new syncV2Classes.VoltmxSyncProgressCallback();
     voltmxSyncProgressCallback.progressCallback = progressCallback;
     voltmxSyncProgressCallback.progressLog = progressLog;
     return voltmxSyncProgressCallback;
 };
 voltmx.sdk.OfflineObjects.createVoltmxBinaryDownloadCallback = function(onFileDownloadStartedLog, fileDownloadStartedCompletionBlock, onChunkDownloadCompletedLog, streamDownloadCompletionBlock, onStreamDownloadCompletedLog, chunkDownloadCompletedCompletionBlock, onFileDownloadCompletedLog, fileDownloadCompletedCompletionBlock, onDownloadFailureLog, downloadFailureCompletionBlock) {
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     var voltmxSyncBinaryDownloadCallback = new syncV2Classes.BinaryDownloadCallback();
     voltmxSyncBinaryDownloadCallback.fileDownloadStartedCompletionBlock = fileDownloadStartedCompletionBlock;
     voltmxSyncBinaryDownloadCallback.streamDownloadCompletionBlock = streamDownloadCompletionBlock;
     voltmxSyncBinaryDownloadCallback.chunkDownloadCompletedCompletionBlock = chunkDownloadCompletedCompletionBlock;
     voltmxSyncBinaryDownloadCallback.fileDownloadCompletedCompletionBlock = fileDownloadCompletedCompletionBlock;
     voltmxSyncBinaryDownloadCallback.downloadFailureCompletionBlock = downloadFailureCompletionBlock;
     return voltmxSyncBinaryDownloadCallback;
 };
 voltmx.sdk.OfflineObjects.createHashMapFromJSONObject = function(json, logPrefix) {
     if (!json) return null;
     var jsonString = JSON.stringify(json);
     voltmx.sdk.logsdk.debug(logPrefix + " : " + jsonString);
     var JavaClasses = voltmx.sdk.JavaClasses.import();
     return new JavaClasses.Gson().fromJson(jsonString, JavaClasses.HashMap.class);
 }
 voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap = function(hashMap, logPrefix) {
     if (!hashMap) return null;
     var JavaClasses = voltmx.sdk.JavaClasses.import();
     var gson = new JavaClasses.GsonBuilder().serializeNulls().create();
     var records = gson.toJson(hashMap);
     voltmx.sdk.logsdk.debug(logPrefix + " : " + records);
     records = JSON.parse(records);
     return records;
 }
 voltmx.sdk.OfflineObjects.setup = function(objServiceList, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.OfflineObjects.setup";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var objectServiesMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(objServiceList, "Object Service List to setup with");
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Setup Success", successCallback, "Setup Failed", onFailure);
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Setup with connection options");
     syncV2Classes.ApplicationSync.syncSetup(objectServiesMap, optionsMap, syncCallback);

     function onFailure(error) {
         if (error && error.userInfo && error.userInfo.setupStatus) {
             error.setupStatus = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(error.userInfo.setupStatus, "Setup : FailureCallbackObject");
         }
         failureCallback(error);
     }
 };
 voltmx.sdk.OfflineObjects.reset = function(objServiceList, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.OfflineObjects.reset";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var objectServiesMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(objServiceList, "Object Service List to reset with");
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Reset Success", successCallback, "Reset Failed", onFailure);
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Reset with connection options");
     syncV2Classes.ApplicationSync.reset(objectServiesMap, optionsMap, syncCallback);

     function onFailure(error) {
         if (error && error.userInfo && error.userInfo.setupStatus) {
             error.setupStatus = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(error.userInfo.setupStatus, "Reset : FailureCallbackObject");
         }
         failureCallback(error);
     }
 };
 voltmx.sdk.OfflineObjects.drop = function(options, successCallback, failureCallback) {
     voltmx.sdk.logsdk.trace("Invoking DROP operation from function voltmx.sdk.OfflineObjects.drop");
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Drop Success", successCallback, "Drop Failed", failureCallback);
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Drop with connection options");
     syncV2Classes.ApplicationSync.drop(optionsMap, syncCallback);
 }
 voltmx.sdk.OfflineObjects.rollback = function(successCallback, failureCallback) {
     voltmx.sdk.logsdk.trace("Invoking Rollback operation from function voltmx.sdk.OfflineObjects.Rollback");
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Rollback Success", successCallback, "Rollback Failed", failureCallback);
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     syncV2Classes.ApplicationSync.rollback(syncCallback);
 }
 voltmx.sdk.OfflineObjects.executeSelectQuery = function(query, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.OfflineObjects.executeSelectQuery";
     voltmx.sdk.logsdk.trace("Invoking executeSelectQuery operation from function voltmx.sdk.OfflineObjects.executeSelectQuery");
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("ExecuteSelectQuery Success", onSuccess, "ExecuteSelectQuery Failed", failureCallback);
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     syncV2Classes.ApplicationSync.executeSelectQuery(query, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Execute Select Query records success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "Records");
         successCallback(jsonObject);
     }
 }
 voltmx.sdk.OfflineObjects.startSync = function(options, successCallback, failureCallback, progressCallback) {
     var LOG_PREFIX = "voltmx.sdk.OfflineObjects.startSync";
     voltmx.sdk.logsdk.trace("Invoking start sync operation from function voltmx.sdk.OfflineObjects.startSync");
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("ApplicationSync Success", onSuccess, "ApplicationSync Failed", onFailure);
     var voltmxProgressCallback = voltmx.sdk.OfflineObjects.createVoltmxSyncProgressCallback("Sync Progress Callback Called", onProgress);
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "ApplicationSync with object service sync options");
     syncV2Classes.ApplicationSync.startSync(optionsMap, syncCallback, voltmxProgressCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Application Sync success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "applicationSyncSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         if (error.userInfo && error.userInfo.failureResponse) {
             error.failureResponse = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(error.userInfo.failureResponse, "applicationSync : FailureCallbackObject");
         }
         if (error.userInfo && error.userInfo.successResponse) {
             error.successResponse = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(error.userInfo.successResponse, "applicationSync : SuccessCallbackObject");
         }
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Application Sync failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }

     function onProgress(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Application Sync Progress Callback");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "applicationSyncProgressCallbackObject");
         progressCallback(jsonObject);
     }
 };
 voltmx.sdk.VMXObj.createSDKObjectSync = function(name, objectServiceName, namespace) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.createSDKObjectSync";
     var sdkObjectSync;
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     try {
         if (!voltmx.sdk.util.isNullOrEmptyString(objectServiceName)) {
             sdkObjectSync = new syncV2Classes.SDKObjectSync(name, objectServiceName);
         } else {
             sdkObjectSync = new syncV2Classes.SDKObjectSync(name);
         }
     } catch (error) {
         var exception = new Exception(error.code, error.message);
         if (error.domain) {
             exception.domain = error.domain;
         }
         if (error.userInfo && error.userInfo.callStack) {
             exception.callStack = error.userInfo.callStack;
         }
         throw exception;
     }
     return sdkObjectSync;
 };
 voltmx.sdk.VMXObj.startSync = function(vmxObj, syncConfig, successCallback, failureCallback, progressCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.startSync";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Syncing " + vmxObj.name + " object success", onSuccess, "Syncing " + vmxObj.name + " object failed", onFailure);
     var voltmxProgressCallback = voltmx.sdk.OfflineObjects.createVoltmxSyncProgressCallback("Sync Progress Callback Called", onProgress);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(syncConfig, "Object sync options");
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.startSync(optionsMap, syncCallback, voltmxProgressCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Sync success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "syncSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         if (error.syncErrors) {
             error.syncErrors = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(error.syncErrors, "syncFailureCallbackObject");
         }
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Sync failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }

     function onProgress(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Sync Progress Callback");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "syncProgressCallbackObject");
         progressCallback(jsonObject);
     }
 };
 voltmx.sdk.VMXObj.getPendingRecordsForUpload = function(vmxObj, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.getPendingRecordsForUpload";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Fetching pending records for upload of object " + vmxObj.name + " success", onSuccess, "Fetching pending records for upload of object " + vmxObj.name + " object failed", onFailure);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "getPendingRecordsForUpload with options");
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.getPendingRecordsForUpload(optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Fetching pending records for upload of object success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "Fetching pending records for upload of object ");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Fetching pending records for upload of object failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 };
 voltmx.sdk.VMXObj.create = function(vmxObj, record, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.create";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Creating record in " + vmxObj.name + " object success", onSuccess, "Creating record in " + vmxObj.name + " object failed", onFailure);
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     var syncRecordHashMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(record, "Records being created");
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Creating Records with options");
     sdkObjectSync.create(syncRecordHashMap, optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Creating records success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "Created Records PKs");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Creating records failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 };
 voltmx.sdk.VMXObj.update = function(vmxObj, record, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.update";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Updating record in " + vmxObj.name + " object success", onSuccess, "Updating record in " + vmxObj.name + " object failed", onFailure);
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     var syncRecordHashMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(record, "Records being updated");
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Updating records with options");
     sdkObjectSync.update(syncRecordHashMap, optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Updating records success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "Updated Records PKs");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Updating records failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObj.updateByPK = function(vmxObj, record, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.updateByPK";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Updating record by PK in " + vmxObj.name + " object success", onSuccess, "Updating record in " + vmxObj.name + " object failed", onFailure);
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     var syncRecordHashMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(record, "Records being updated");
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Updating records with options");
     sdkObjectSync.updateByPK(syncRecordHashMap, optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Updating records by PK success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "Updated Records PKs");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Updating records by PK failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObj.delete = function(vmxObj, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.delete";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Deleting record in " + vmxObj.name + " object success", successCallback, "Deleting record in " + vmxObj.name + " object failed", failureCallback);
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Deleting records with options");
     sdkObjectSync.delete(optionsMap, syncCallback);
 }
 voltmx.sdk.VMXObj.deleteByPK = function(vmxObj, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.deleteByPK";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Deleting record by PK in " + vmxObj.name + " object success", successCallback, "Deleting record in " + vmxObj.name + " object failed", failureCallback);
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Deleting record by PK with options");
     sdkObjectSync.deleteByPK(optionsMap, syncCallback);
 }
 voltmx.sdk.VMXObj.get = function(vmxObj, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.get";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Retrieving record from " + vmxObj.name + " object success", onSuccess, "Retrieving record from " + vmxObj.name + " object failed", onFailure);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Getting records with options");
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.get(optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Getting records success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "Records");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Getting records failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObj.rollback = function(vmxObj, primaryKeyValueMap, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.rollback";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Rollback on " + vmxObj.name + " object success", onSuccess, "Rollback on " + vmxObj.name + " object failed", onFailure);
     var primaryKeys = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(primaryKeyValueMap, "Getting primaryKeys");
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.rollback(primaryKeys, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Rollback success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "rollbackSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Rollback failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObj.getBinary = function(vmxObj, options, fileDownloadStartedCompletionBlock, chunkDownloadCompletedCompletionBlock, streamDownloadCompletionBlock, fileDownloadCompletedCompletionBlock, downloadFailureCompletionBlock) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.getBinary";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var binaryCallback = voltmx.sdk.OfflineObjects.createVoltmxBinaryDownloadCallback("Get binary on " + vmxObj.name + " object started", onFileDownloadStarted, "Get binary on " + vmxObj.name + " object: chunk download completed", onChunkDownloadCompleted, "Get binary on " + vmxObj.name + " object: stream download completed", onStreamDownloadCompleted, "Get binary on " + vmxObj.name + " object: file download completed", onFileDownloadCompleted, "Get binary on " + vmxObj.name + " object failed", onDownloadFailure);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Updating records with options");
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.getBinary(optionsMap, binaryCallback);

     function onFileDownloadStarted(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": File download started");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "getBinary");
         fileDownloadStartedCompletionBlock(jsonObject);
     }

     function onStreamDownloadCompleted(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Stream download completed");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "getBinary");
         streamDownloadCompletionBlock(jsonObject);
     }

     function onChunkDownloadCompleted(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Chunk download completed");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "getBinary");
         chunkDownloadCompletedCompletionBlock(jsonObject);
     }

     function onFileDownloadCompleted(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": File download completed");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "getBinary");
         fileDownloadCompletedCompletionBlock(jsonObject);
     }

     function onDownloadFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": File download failed with error: " + JSON.stringify(error));
         downloadFailureCompletionBlock(error);
     }
 }
 voltmx.sdk.VMXObj.getBinaryStatus = function(vmxObj, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.getBinaryStatus";
     voltmx.sdk.logsdk.trace("Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("getBinaryStatus on " + vmxObj.name + " object success", onSuccess, "getBinaryStatus on " + vmxObj.name + " object failed", onFailure);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "getBinaryStatus with options");
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.getBinaryStatus(optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": getBinaryStatus success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "getBinaryStatusSuccessCallBack");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": getBinaryStatus failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObj.markForUpload = function(vmxObj, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.markForUpload";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("MarkForUpload on " + vmxObj.name + " object success", onSuccess, "MarkForUpload on " + vmxObj.name + " object failed", onFailure);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "Mark for upload records with options");
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.markForUpload(optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": MarkForUpload success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "MarkForUploadSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": MarkForUpload failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObj.cancelSync = function(vmxObj, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.cancelSync";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("cancel on " + vmxObj.name + " object success", onSuccess, "Cancel on " + vmxObj.name + " object failed", onFailure);
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.cancelSync(syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Cancel success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "cancelSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Cancel failed with error : " + error);
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObj.getUploadDeferredRecordKeys = function(vmxObj, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.getUploadDeferredRecordKeys";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Retrieving record from " + vmxObj.name + " object success", onSuccess, "Retrieving record from " + vmxObj.name + " object failed", onFailure);
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.getUploadDeferredRecordKeys(syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Getting deffered records primary keys success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "Records");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Getting deffered records failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObj.clearOfflineData = function(vmxObj, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObj.clearOfflineData";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "clearOfflineData options");
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Successfully cleared offline data in " + vmxObj.name + " object.", onSuccess, "Failed to clear offline data in " + vmxObj.name + " object.", onFailure);
     var sdkObjectSync = vmxObj.getSdkObjectSync();
     sdkObjectSync.clearData(optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Successfully cleared offline data.");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "clearDataSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Clearing offline data failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObjSvc.createSDKObjectServiceSync = function(name) {
     var LOG_PREFIX = "voltmx.sdk.VMXObjSvc.createSDKObjectServiceSync";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncV2Classes = voltmx.sdk.SyncV2Classes.import();
     try {
         var sdkObjectServiceSync = new syncV2Classes.SDKObjectServiceSync(name);
     } catch (error) {
         var exception = new Exception(error.code, error.message);
         if (error.domain) {
             exception.domain = error.domain;
         }
         if (error.userInfo && error.userInfo.callStack) {
             exception.callStack = error.userInfo.callStack;
         }
         throw exception;
     }
     return sdkObjectServiceSync;
 };
 voltmx.sdk.VMXObjSvc.startSync = function(vmxObjSvc, syncConfig, successCallback, failureCallback, progressCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObjSvc.startSync";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Syncing " + vmxObjSvc.name + " object service success", onSuccess, "Syncing " + vmxObjSvc.name + " object service failed", onFailure);
     var voltmxProgressCallback = voltmx.sdk.OfflineObjects.createVoltmxSyncProgressCallback("Sync Progress Callback Called", onProgress);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(syncConfig, "Object service sync options");
     var sdkObjectServiceSync = vmxObjSvc.getSdkObjectServiceSync();
     sdkObjectServiceSync.startSync(optionsMap, syncCallback, voltmxProgressCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Sync success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "syncSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         if (error.syncErrors) {
             error.syncErrors = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(error.syncErrors, "syncFailureCallbackObject");
         }
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Sync failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }

     function onProgress(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Sync Progress Callback");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "syncProgressCallbackObject");
         progressCallback(jsonObject);
     }
 };
 voltmx.sdk.VMXObjSvc.rollback = function(vmxObjSvc, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObjSvc.rollback";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Rollback on " + vmxObjSvc.name + " object service success", onSuccess, "Rollback on " + vmxObjSvc.name + " object service failed", onFailure);
     var sdkObjectServiceSync = vmxObjSvc.getSdkObjectServiceSync();
     sdkObjectServiceSync.rollback(syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Rollback success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "rollbackSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Rollback failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 };
 voltmx.sdk.VMXObjSvc.cancelSync = function(vmxObjSvc, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObjSvc.cancelSync";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("cancel on " + vmxObjSvc.name + " object service success", onSuccess, "Cancel on " + vmxObjSvc.name + " object service failed", onFailure);
     var sdkObjectServiceSync = vmxObjSvc.getSdkObjectServiceSync();
     sdkObjectServiceSync.cancelSync(syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Cancel success");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "cancelSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Cancel failed with error : " + error);
         failureCallback(error);
     }
 }
 voltmx.sdk.VMXObjSvc.clearOfflineData = function(vmxObjSvc, options, successCallback, failureCallback) {
     var LOG_PREFIX = "voltmx.sdk.VMXObjSvc.clearOfflineData";
     voltmx.sdk.logsdk.trace(" Entering " + LOG_PREFIX);
     var optionsMap = voltmx.sdk.OfflineObjects.createHashMapFromJSONObject(options, "clearOfflineData options");
     var syncCallback = voltmx.sdk.OfflineObjects.createSyncCallback("Successfully cleared offline data in " + vmxObjSvc.name + " object service.", onSuccess, "Failed to clear offline data in " + vmxObjSvc.name + " object service.", onFailure);
     var sdkObjectServiceSync = vmxObjSvc.getSdkObjectServiceSync();
     sdkObjectServiceSync.clearData(optionsMap, syncCallback);

     function onSuccess(obj) {
         voltmx.sdk.logsdk.info(LOG_PREFIX + ": Successfully cleared offline data.");
         var jsonObject = voltmx.sdk.OfflineObjects.createJSONObjectFromHashMap(obj, "clearDataSuccessCallbackObject");
         successCallback(jsonObject);
     }

     function onFailure(error) {
         voltmx.sdk.logsdk.error(LOG_PREFIX + ": Clearing offline data failed with error: " + JSON.stringify(error));
         failureCallback(error);
     }
 };
 //
 //Binary FFI related functions
 //
 if (voltmx.sdk) {
     voltmx.sdk.binary = {};
 }
 voltmx.sdk.binary.constants = {
     ENDPOINT_URL: "endpointUrl",
     DOMAIN: "domain",
     RELATIVE_PATH: "relativepath",
     URL: "URL",
     HEADERS: "headers",
     METHOD: "method",
     UPLOAD_MODE: "uploadMode",
     BLOB: "blob",
     FILE_CONTENT: "${fileContent}",
     FILE: "file",
     HTTP_STATUS_CODE: "httpStatusCode",
     VALID_HTTP_REDIRECT_CODE: "309",
     UPLOAD_MODE_BINARY: "binary",
     UPLOAD_MODE_MULTIPART: "multipart",
     UPLOAD_PARAMS: "uploadParams",
     BLOB_ID: "BlobID",
     CONTEXT: "Context",
     SESSION_ID: "SessionID",
     BLOB_OBJECT: "BlobObject",
     ERROR: "Error",
     FILE_DETAILS: "FileDetails",
     HTTP_METHOD_PUT: "PUT",
     HTTP_METHOD_POST: "POST"
 };
 voltmx.sdk.binary.addMandatoryInternalOptions = function(options) {
     if (voltmx.sdk.isNullOrUndefined(options)) {
         options = {};
     }
     options[voltmx.sdk.binary.constants.DOMAIN] = voltmxRef.sessionReportingURL.split("/IST")[0];
     if (!voltmx.sdk.isNullOrUndefined(voltmxRef.currentClaimToken)) {
         options[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
     }
     return options;
 };
 voltmx.sdk.binary.validateUploadParams = function(uploadParams) {
     //Validating user input.
     if (!voltmx.sdk.util.isJsonObject(uploadParams)) {
         voltmx.sdk.logsdk.error("### voltmx.sdk.binary.validateUploadParams :: Error: Upload params should be supplied as valid JSON object");
         return voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_params_instance, "Invalid datatype of uploadParams " + voltmx.sdk.util.type(uploadParams) + " " + voltmx.sdk.errormessages.invalid_params_instance)
     }
     // check for fileName
     if (!voltmx.sdk.util.isValidString(uploadParams[voltmx.sdk.constants.FILE_NAME])) {
         voltmx.sdk.logsdk.error("### voltmx.sdk.binary.validateUploadParams :: Error: fileName : expected string not found");
         return voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_params_instance, "" + "Invalid datatype of fileName " + voltmx.sdk.util.type(uploadParams[voltmx.sdk.constants.FILE_NAME]) + " " + voltmx.sdk.errormessages.invalid_params_instance);
     }
     // check if both are defined
     if (!voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.constants.FILE_PATH]) && !voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.constants.RAW_BYTES])) {
         voltmx.sdk.logsdk.error("### voltmx.sdk.binary.validateUploadParams :: Error: BOTH FilePath and rawBytes are provided - please" + " provide only one of them");
         return voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_params_instance, "BOTH FilePath and rawBytes are provided " + " " + voltmx.sdk.errormessages.invalid_params_instance)
     }
     // check if neither are defined
     if (voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.constants.FILE_PATH]) && voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.constants.RAW_BYTES])) {
         voltmx.sdk.logsdk.error("### voltmx.sdk.binary.validateUploadParams :: Error: Neither FilePath nor rawBytes is provided - please" + " provide one of them");
         return voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_params_instance, "Neither FilePath nor rawBytes is provided " + " " + voltmx.sdk.errormessages.invalid_params_instance);
     }
     // check for datatype of filePath (if defined)
     if (!voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.constants.FILE_PATH]) && !voltmx.sdk.util.isValidString(uploadParams[voltmx.sdk.constants.FILE_PATH])) {
         voltmx.sdk.logsdk.error("### voltmx.sdk.binary.validateUploadParams :: Error: FilePath : expected string and found " + voltmx.sdk.util.type(uploadParams[voltmx.sdk.constants.FILE_PATH]));
         return voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_params_instance, "Invalid datatype of FilePath " + voltmx.sdk.util.type(uploadParams[voltmx.sdk.constants.FILE_PATH]) + " " + voltmx.sdk.errormessages.invalid_params_instance);
     }
     // check for datatype of rawBytes
     if (!voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.constants.RAW_BYTES]) && voltmx.sdk.util.type(uploadParams[voltmx.sdk.constants.RAW_BYTES]) !== "voltmx.types.RawBytes") {
         voltmx.sdk.logsdk.error("### voltmx.sdk.binary.validateUploadParams :: Error: rawBytes : expected voltmx.types.RawBytes object and found " + voltmx.sdk.util.type(uploadParams[voltmx.sdk.constants.RAW_BYTES]));
         return voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_params_instance, "Invalid datatype of rawBytes " + voltmx.sdk.util.type(uploadParams[voltmx.sdk.constants.RAW_BYTES]) + " " + voltmx.sdk.errormessages.invalid_params_instance);
     }
     return null;
 };
 voltmx.sdk.binary.getBinaryData = function(inputParams, streaming, downloadConfig, fileDownloadStartedCallback, chunkDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback, options) {
     if (voltmx.sdk.isNullOrUndefined(downloadConfig[voltmx.sdk.binary.constants.ENDPOINT_URL]) && voltmx.sdk.isNullOrUndefined(downloadConfig[voltmx.sdk.binary.constants.DOMAIN]) && voltmx.sdk.isNullOrUndefined(downloadConfig[voltmx.sdk.binary.constants.RELATIVE_PATH])) {
         voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, "endpointUrl or domain and relative path is required in order to download a file");
         return;
     }
     options = voltmx.sdk.binary.addMandatoryInternalOptions(options);
     if (typeof(binarydata) !== "undefined") {
         binarydata.getOnlineBinaryData(inputParams, streaming, downloadConfig, fileDownloadStartedCallback, chunkDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback, options);
     } else {
         voltmx.sdk.verifyAndCallClosure(downloadFailureCallback, "FFI is not configured to use Binary Apis");
     }
 };
 voltmx.sdk.binary.uploadBinaryData = function(uploadParams, fileUploadStartedCallback, chunkUploadCompletedCallback, fileUploadCompletedCallback, fileUploadFailureCallback, options) {
     if (voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.binary.constants.URL])) {
         voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, "URL is required in order to download a file");
         return;
     }
     options = voltmx.sdk.binary.addMandatoryInternalOptions(options);
     if (typeof(binarydata) !== "undefined") {
         binarydata.uploadBinaryData(uploadParams, fileUploadStartedCallback, chunkUploadCompletedCallback, fileUploadCompletedCallback, fileUploadFailureCallback, options);
     } else {
         voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, "FFI is not configured to use Binary Apis");
     }
 };
 if (typeof(voltmx.sdk.metric) === "undefined") {
     voltmx.sdk.metric = {};
 }
 voltmx.sdk.metric.eventFlowTag = "";
 voltmx.sdk.metric.eventConfig = {
     "confType": "BUFFER",
     "eventBufferAutoFlushCount": voltmx.sdk.metric.eventBufferAutoFlushValue,
     "eventBufferMaxCount": voltmx.sdk.metric.eventBufferMaxValue
 };
 voltmx.sdk.metric.eventBufferMaxValue = 1000;
 voltmx.sdk.metric.eventBufferAutoFlushValue = 15;
 voltmx.sdk.metric.characterLengthLimit = 256;
 voltmx.sdk.metric.reportEventBufferArray = [];
 voltmx.sdk.metric.reportEventBufferBackupArray = [];
 voltmx.sdk.metric.retrievedDS = false;
 voltmx.sdk.metric.eventBufferCount = 0;
 voltmx.sdk.metric.eventTypeMap = {
     "formentry": "FormEntry",
     "touch": "Touch",
     "servicecall": "ServiceCall",
     "gesture": "Gesture",
     "orientation": "Orientation",
     "custom": "Custom"
 };
 voltmx.sdk.metric.errorCodeMap = {
     "1000": true,
     "1011": true,
     "1012": true,
     "1014": true,
     "1015": true,
     "1016": true
 };
 voltmx.sdk.metric.setEventFlowTag = function(flowTag) {
     if (voltmx.sdk.isNullOrUndefined(flowTag)) {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid value for event flow tag");
     } else if (flowTag.length <= voltmx.sdk.metric.characterLengthLimit) {
         voltmx.sdk.metric.eventFlowTag = flowTag;
     } else {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event flow tag is " + voltmx.sdk.metric.characterLengthLimit + " characters");
     }
 };
 voltmx.sdk.metric.clearEventFlowTag = function() {
     voltmx.sdk.metric.eventFlowTag = "";
 };
 voltmx.sdk.metric.getEventFlowTag = function() {
     return voltmx.sdk.metric.eventFlowTag;
 };
 voltmx.sdk.metric.setEventConfig = function(confType, eventBufferAutoFlushCount, eventBufferMaxCount) {
     if (voltmx.sdk.isNullOrUndefined(confType)) {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Config Type can not be null");
     } else {
         confType = confType.toUpperCase();
     }
     if (confType === "BUFFER") {
         voltmx.sdk.metric.eventConfig["confType"] = confType;
     } else {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid value for config type");
     }
     if (!voltmx.sdk.isNullOrUndefined(eventBufferMaxCount) && typeof(eventBufferMaxCount) === "number" && eventBufferMaxCount > 0) {
         voltmx.sdk.metric.eventConfig["eventBufferMaxCount"] = eventBufferMaxCount;
     } else {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "eventBufferMaxCount has to be a Number and greater than 0");
     }
     if (!voltmx.sdk.isNullOrUndefined(eventBufferAutoFlushCount) && typeof(eventBufferAutoFlushCount) === "number" && eventBufferAutoFlushCount > 0 && eventBufferAutoFlushCount <= eventBufferMaxCount) {
         voltmx.sdk.metric.eventConfig["eventBufferAutoFlushCount"] = eventBufferAutoFlushCount;
     } else if (eventBufferAutoFlushCount >= eventBufferMaxCount) {
         voltmx.sdk.metric.eventConfig["eventBufferMaxCount"] = 1000;
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "eventBufferAutoFlushCount can not be greater than eventBufferMaxCount");
     } else {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "eventBufferAutoFlushCount has to be a Number and greater than 0");
     }
 };
 voltmx.sdk.metric.reportEvent = function(evttype, evtSubType, formID, widgetID, flowTag) {
     if (voltmx.sdk.metric.reportEventBufferBackupArray.length === 0) {
         voltmx.sdk.metric.readFromDS();
     }
     voltmx.sdk.metric.eventBufferCount = voltmx.sdk.metric.reportEventBufferBackupArray.length + voltmx.sdk.metric.reportEventBufferArray.length;
     if (voltmx.sdk.metric.eventBufferCount === voltmx.sdk.metric.eventConfig["eventBufferMaxCount"]) {
         throw new Exception(voltmx.sdk.errorConstants.DATA_STORE_EXCEPTION, "Reached maximum limit to store events");
         return;
     }
     var reportEventMap = {};
     reportEventMap.ts = voltmx.sdk.formatCurrentDate(new Date());
     evttype = evttype.toLowerCase();
     if (voltmx.sdk.isNullOrUndefined(voltmx.sdk.metric.eventTypeMap[evttype])) {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid value for event type");
         return;
     } else {
         reportEventMap["evttype"] = voltmx.sdk.metric.eventTypeMap[evttype];
     }
     if (voltmx.sdk.isNullOrUndefined(evtSubType)) {
         reportEventMap["evtSubType"] = "";
     } else if (evtSubType.length <= voltmx.sdk.metric.characterLengthLimit) {
         reportEventMap["evtSubType"] = evtSubType;
     } else {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event flow tag is " + voltmx.sdk.metric.characterLengthLimit + " characters");
         return;
     }
     if (voltmx.sdk.isNullOrUndefined(formID)) {
         reportEventMap["formID"] = voltmx.application.getCurrentForm().id;
     } else if (formID.length <= voltmx.sdk.metric.characterLengthLimit) {
         reportEventMap["formID"] = formID;
     } else {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event flow tag is " + voltmx.sdk.metric.characterLengthLimit + " characters");
         return;
     }
     if (voltmx.sdk.isNullOrUndefined(widgetID)) {
         reportEventMap["widgetID"] = "";
     } else if (widgetID.length <= voltmx.sdk.metric.characterLengthLimit) {
         reportEventMap["widgetID"] = widgetID;
     } else {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event flow tag is " + voltmx.sdk.metric.characterLengthLimit + " characters");
         return;
     }
     if (voltmx.sdk.isNullOrUndefined(flowTag)) {
         reportEventMap["flowTag"] = voltmx.sdk.metric.getEventFlowTag();
     } else if (flowTag.length <= voltmx.sdk.metric.characterLengthLimit) {
         reportEventMap["flowTag"] = flowTag;
     } else {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event flow tag is " + voltmx.sdk.metric.characterLengthLimit + " characters");
         return;
     }
     reportEventMap.SID = voltmx.ds.read(voltmx.sdk.constants.KONYUUID)[0];
     voltmx.sdk.metric.reportEventBufferArray.push(reportEventMap);
     if (voltmx.sdk.metric.reportEventBufferArray.length % voltmx.sdk.metric.eventConfig["eventBufferAutoFlushCount"] === 0) {
         voltmx.sdk.metric.flushEvents();
     }
 };
 voltmx.sdk.metric.flushEvents = function() {
     if (voltmx.sdk.metric.reportEventBufferBackupArray.length === 0) {
         voltmx.sdk.metric.readFromDS();
     }
     if (voltmx.sdk.metric.reportEventBufferBackupArray.length === 0 && voltmx.sdk.metric.reportEventBufferArray.length === 0) {
         voltmx.sdk.logsdk.warn("There are no events to flush");
         return;
     }
     var payload = voltmx.sdk.getPayload(voltmx.sdk.getCurrentInstance());
     var params = {};
     if (voltmx.sdk.metric.reportEventBufferArray.length !== 0) {
         voltmx.sdk.metric.pushEventsToBufferArray();
     }
     var headers = {};
     headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
     params.httpheaders = headers;
     payload.events = voltmx.sdk.metric.reportEventBufferBackupArray;
     payload.svcid = "SendEvents";
     payload.rsid = voltmx.sdk.metric.reportEventBufferBackupArray[0].SID;
     params[voltmx.sdk.constants.REPORTING_PARAMS] = JSON.stringify(payload);
     voltmx.net.invokeServiceAsync(voltmx.sdk.currentInstance.customReportingURL, params, flushCallback);

     function flushCallback(status, response) {
         if (status === 400) {
             if (response.opstatus == 0) {
                 voltmx.sdk.metric.clearBufferEvents();
             } else if (voltmx.sdk.metric.errorCodeMap[response.opstatus]) {
                 voltmx.sdk.metric.saveInDS();
             } else {
                 voltmx.sdk.metric.clearBufferEvents();
             }
         } else if (status === 300) {
             voltmx.sdk.metric.saveInDS();
         }
     }
 };
 /*Stores event data in Data Store on failure of service Call*/
 voltmx.sdk.metric.saveInDS = function() {
     if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.metric.reportEventBufferBackupArray) && voltmx.sdk.metric.reportEventBufferBackupArray.length > 0) {
         var eventsToSave = [];
         eventsToSave.push(JSON.stringify(voltmx.sdk.metric.reportEventBufferBackupArray));
         voltmx.ds.save(eventsToSave, "konyMetricsBuffer");
         voltmx.sdk.metric.reportEventBufferBackupArray = [];
     }
 };
 /*Clearing events sent to server */
 voltmx.sdk.metric.clearBufferEvents = function() {
     voltmx.sdk.metric.reportEventBufferBackupArray = [];
     voltmx.ds.remove("konyMetricsBuffer");
 };
 /*Reading any pending events from Data Store */
 voltmx.sdk.metric.readFromDS = function() {
     var eventsFromDS = voltmx.ds.read("konyMetricsBuffer");
     if (eventsFromDS !== null) {
         var pushToArray = [];
         pushToArray.push(JSON.parse(eventsFromDS[0]));
         voltmx.sdk.metric.reportEventBufferBackupArray.push.apply(voltmx.sdk.metric.reportEventBufferBackupArray, pushToArray);
     }
 };
 /*Pushes events received from user to BufferBackupArray which will be flushed to server */
 voltmx.sdk.metric.pushEventsToBufferArray = function() {
     voltmx.sdk.metric.reportEventBufferBackupArray.push.apply(voltmx.sdk.metric.reportEventBufferBackupArray, voltmx.sdk.metric.reportEventBufferArray);
     voltmx.sdk.metric.reportEventBufferArray = [];
 };
 voltmx.sdk.metric.getEventsInBuffer = function() {
     var eventsFromDS = voltmx.ds.read("konyMetricsBuffer");
     var eventsToReturn = [];
     if (!voltmx.sdk.isNullOrUndefined(eventsFromDS)) {
         eventsToReturn.push(JSON.parse(eventsFromDS[0]));
     }
     if (voltmx.sdk.metric.reportEventBufferArray.length !== 0) {
         eventsToReturn.push.apply(eventsToReturn, voltmx.sdk.metric.reportEventBufferArray);
     }
     if (eventsToReturn.length !== 0) {
         return eventsToReturn;
     } else {
         return null;
     }
 };
 voltmx.logger = voltmx.logger || {};
 voltmx.logger.createNewLogger = function(loggerName, loggerConfig) {
     parseConfig = function(loggerConfig) {
         //private methods
         if (loggerConfig === null || typeof(loggerConfig) === 'undefined') {
             loggerConfig = {};
         } else {
             loggerConfig = loggerConfig.getLoggerConfig();
         }
         if (typeof(appConfig) != 'undefined') {
             appDetails = {
                 appID: appConfig.appId,
                 appVersion: appConfig.appVersion,
                 sessionID: voltmx.license.getSessionId()
             };
             //appInfo
             loggerConfig.appInfo = appDetails;
         }
         return loggerConfig;
     };
     logMessage = function(loggerObj, logLevel, msg, params) {
         logMessageInFFI = function(NativeLoggerObject, logLevel, message) {
             switch (logLevel) {
                 case voltmx.logger.logLevel.TRACE:
                     NativeLoggerObject.logTrace(message);
                     break;
                 case voltmx.logger.logLevel.DEBUG:
                     NativeLoggerObject.logDebug(message);
                     break;
                 case voltmx.logger.logLevel.INFO:
                     NativeLoggerObject.logInfo(message);
                     break;
                 case voltmx.logger.logLevel.PERF:
                     NativeLoggerObject.logPerf(message);
                     break;
                 case voltmx.logger.logLevel.WARN:
                     NativeLoggerObject.logWarning(message);
                     break;
                 case voltmx.logger.logLevel.ERROR:
                     NativeLoggerObject.logError(message);
                     break;
                 case voltmx.logger.logLevel.FATAL:
                     NativeLoggerObject.logFatal(message);
                     break;
                 default:
                     voltmx.print("Implementation not found for the specified log level " + logLevel);
                     return;
             }
         };
         formatLineInfo = function(callerInformation) {
             /*
               sample callerInformation's value can look like -> "http://kh2321.kitspl.com:8443/apps/IDETestDriver8/1570111366904/desktopweb/appjs/app.js:40569:23" or "Module.js:40569:23"
               value associated with last colon is column number
               value associated with second last colon is line number
             */
             var lineInfo = "";
             var firstLastIndexOfColon = callerInformation.lastIndexOf(':');
             var secondLastIndexOfColon = callerInformation.lastIndexOf(':', firstLastIndexOfColon - 1);
             lineInfo = callerInformation.substring(secondLastIndexOfColon + 1, firstLastIndexOfColon);
             return lineInfo;
         };
         formatFileAndLineInfoMeta = function(callerInformation) {
             //callerInformation's value can look like -> "(http://kh2321.kitspl.com:8443/apps/IDETestDriver8/1570111366904/desktopweb/appjs/app.js:40569:23)" or "Module.js:40569:23"
             var formattedInfo = '';
             if (!voltmx.sdk.isNullOrUndefined(callerInformation)) {
                 formattedInfo = callerInformation.replace('(', '');
                 formattedInfo = formattedInfo.replace(')', '');
             }
             return formattedInfo;
         };
         formatFileInfo = function(fileInfo) {
             //sample fileInfo's value can look like -> "http://kh2321.kitspl.com:8443/apps/IDETestDriver8/1570111366904/desktopweb/appjs/app.js:40569:23" or "Module.js:40569:23"
             var firstLastIndexOfColon = fileInfo.lastIndexOf(':');
             var secondLastIndexOfColon = fileInfo.lastIndexOf(':', firstLastIndexOfColon - 1);
             fileInfo = fileInfo.substring(0, secondLastIndexOfColon);
             //fileInfo's value can look like "http://kh2321.kitspl.com:8443/apps/IDETestDriver8/1570111366904/desktopweb/appjs/app.js" or "Module.js"
             var indexOfSlashInProcessedFileInfo = fileInfo.lastIndexOf('/');
             fileInfo = indexOfSlashInProcessedFileInfo > 0 ? fileInfo.substring(indexOfSlashInProcessedFileInfo + 1, fileInfo.length) : fileInfo;
             return fileInfo;
         };
         formatMethodInformation = function(callerInformation) {
             //callerInformation's value can look like ->  ["", "", "", "", "at", "logTest.testDeviceConsoleLogs", "(http://kh2321.kitspl.com:8443/apps/IDETestDriver8/1570111366904/desktopweb/appjs/app.js:40569:23)"]
             if (callerInformation.length > 1) return callerInformation[callerInformation.length - 2];
         };
         formatCallerInformation = function(callerInformation) {
             //JSCore syntax: <methodName>@<fileName>:<row>:<col>
             //V8 syntax: at <methodName> (<fileName>:<row>:<col>)
             //Chakra syntax: at (<methodURL> <fileURL>:<row>:<col>)
             if (!voltmx.sdk.isNullOrUndefined(callerInformation)) {
                 formattedCallerInformation = callerInformation.split(seperator);
                 return formattedCallerInformation;
             }
             return [];
         };
         getCallerInformationFromCallStack = function(callStack, indirectionLevel) {
             var processedOffset = offsetIndex + indirectionLevel;
             if (callStack.length >= processedOffset) return callStack[processedOffset];
             return null;
         };
         generateCallerInformation = function(indirectionLevel) {
             var errorObject = new Error();
             var callStack;
             /* In IE, Error object doesn't contain stack information, hence can't provide caller info right away
             we need to throw the error and catch it to get the stack*/
             if ('stack' in errorObject) {
                 callStack = errorObject.stack.split('\n');
             } else {
                 callStack = function() {
                     try {
                         throw new Error('');
                     } catch (n) {
                         return n.stack;
                     }
                 }();
                 callStack = callStack != undefined ? callStack.split('\n') : [];
             }
             var callerInformation = getCallerInformationFromCallStack(callStack, indirectionLevel);
             // sample value of callerInformation can be -> "    at logTest.testDeviceConsoleLogs (http://kh2321.kitspl.com:8443/apps/IDETestDriver8/1570111366904/desktopweb/appjs/app.js:40569:23)"
             return formatCallerInformation(callerInformation);
         };
         parseMessage = function(loggerObj, logLevel, msg, params) {
             var logLevelVal = (voltmx.logger.isNativeLoggerAvailable()) ? KonyLogger.getLogLevel() : voltmx.logger.currentLogLevel.value;
             if (logLevel.value >= logLevelVal) {
                 var metaData = {};
                 params = (typeof(params) === "undefined") ? "" : params;
                 //Stringify object
                 if (voltmx.logger.isValidJSTable(params)) {
                     params = JSON.stringify(params, null, " ");
                 }
                 metaData.message = msg + params;
                 metaData.callerInformation = generateCallerInformation(loggerObj.getIndirectionLevel());
                 metaData.methodName = formatMethodInformation(metaData.callerInformation);
                 /*
                     logs in browser can logged by browser by their style of implementation
                     sample console logs in chrome & opera
                     [Test][TRACE][9/24/2019 7:43:11 PM][app.js][logTest.testDeviceConsoleLogs][55000] : console message in level-trace
                     sample console logs in ie & safari
                     [TestLogger][TRACE][10/3/2019 4:43:45 PM][app.js][testDeviceConsoleLogs][36953] : console message in level-trace
                     sample console logs in firefox
                     [TestLogger][TRACE][10/3/2019 7:21:14 PM][app.js][logTest/this.testDeviceConsoleLogs][40569] : console message in level-trace
                  */
                 var fileAndLineInfoMeta = formatFileAndLineInfoMeta(metaData.callerInformation.pop());
                 metaData.fileName = formatFileInfo(fileAndLineInfoMeta);
                 metaData.lineNo = formatLineInfo(fileAndLineInfoMeta);
                 if (voltmx.logger.isNativeLoggerAvailable()) {
                     if (!loggerObj.NativeLoggerObject) {
                         loggerObj.NativeLoggerObject = new KonyLogger.InitializeLogger(loggerObj.loggerName);
                         KonyLogger.setConfig(loggerObj.config);
                     }
                     if (loggerObj.NativeLoggerObject) {
                         logMessageInFFI(loggerObj.NativeLoggerObject, logLevel, metaData);
                     } else {
                         var date = new Date().toLocaleDateString();
                         var time = new Date().toLocaleTimeString();
                         var level = logLevel.code;
                         var formattedMessage = "[" + loggerObj.loggerName + "][" + level + "][" + date + " " + time + "][" + metaData.fileName + "][" + metaData.methodName + "][" + metaData.lineNo + "] : " + metaData.message;
                         voltmx.print(formattedMessage);
                     }
                 } else {
                     var date = new Date().toLocaleDateString();
                     var time = new Date().toLocaleTimeString();
                     var level = logLevel.code;
                     var formattedMessage = "[" + loggerObj.loggerName + "][" + level + "][" + date + " " + time + "][" + metaData.fileName + "][" + metaData.methodName + "][" + metaData.lineNo + "] : " + metaData.message;
                     voltmx.print(formattedMessage);
                 }
             }
         };
         parseMessage(loggerObj, logLevel, msg, params);
     };
     //Exposed object and it's methods
     var loggerObj = voltmx.logger.createLoggerObject(loggerName, loggerConfig);
     if (loggerObj.config !== null && loggerObj.config.overrideConfig === true) {
         for (var key in voltmx.logger.logLevel) {
             if (voltmx.logger.logLevel.hasOwnProperty(key)) {
                 if (voltmx.logger.logLevel[key].value == loggerObj.config.logFilterConfig.logLevel) {
                     voltmx.logger.currentLogLevel = voltmx.logger.logLevel[key];
                     break;
                 }
             }
         }
     }
     var seperator = " ";
     var offsetIndex = 5;
     var browser = voltmx.os.deviceInfo().category;
     if (voltmx.sdk.util.isValidString(browser)) {
         browser = browser.toLowerCase();
         switch (browser) {
             case 'ie':
                 offsetIndex += 1;
                 break;
             case 'safari':
             case 'firefox':
                 seperator = '@';
                 offsetIndex += -1;
                 //the default value is already set to 0
         }
     }
     //Native object creation
     if (voltmx.logger.isNativeLoggerAvailable()) {
         loggerObj.NativeLoggerObject = new KonyLogger.InitializeLogger(loggerName);
         KonyLogger.setConfig(loggerObj.config);
     }
     return loggerObj;
 }
 voltmx.logger["appLogger"] = voltmx.logger.appLoggerInitialisation();
 /**
  * MFSDK
  * Created by KH2204.
  * Copyright © 2018 Kony. All rights reserved.
  */
 /**
  * Method to create the integration service instance with the provided service name.
  * @param {string} serviceName - Name of the service
  * @returns {IntegrationService} Integration service instance
  */
 voltmx.sdk.prototype.getIntegrationService = function(serviceName) {
     if (!voltmx.sdk.isInitialized) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + "integration service :" + serviceName);
     }
     var voltmxRef = voltmx.sdk.getCurrentInstance();
     if (!voltmx.sdk.skipAnonymousCall && !this.currentClaimToken && !voltmxRef.isAnonymousProvider) {
         throw new Exception(voltmx.sdk.errorConstants.AUTH_FAILURE, "Valid claims token is not found, login using identity service before performing an operation on this integration service :" + serviceName);
     }
     if (this.integsvc != null) {
         if (this.integsvc[serviceName] != null) {
             voltmx.sdk.logsdk.debug("found integration service" + this.integsvc[serviceName]);
             return new IntegrationService(this, serviceName);
         }
     }
     throw new Exception(voltmx.sdk.errorConstants.INTEGRATION_FAILURE, "Integration service is not found or invalid :" + serviceName);
 };
 /**
  * Method should not be called by developer.
  * @class
  * @classdesc Integration service instance for invoking the integration services.
  */
 function IntegrationService(voltmxRef, serviceName) {
     var serviceUrl = "";
     var svcObj = voltmxRef.integsvc[serviceName];
     if (typeof(svcObj) === "object") {
         serviceUrl = svcObj["url"];
     } else {
         serviceUrl = svcObj;
     }
     var networkProvider = new voltmxNetworkProvider();
     if (voltmx.sdk.util.isNullOrEmptyString(serviceName) || voltmx.sdk.util.isNullOrEmptyString(serviceUrl)) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "Invalid serviceUrl and serviceName");
     }
     serviceUrl = stripTrailingCharacter(serviceUrl, "/");
     this.getUrl = function() {
         return serviceUrl;
     };
     /**
      * Integration service success callback method.
      * @callback integrationSuccessCallback
      * @param {json} response - Integration service response
      */
     /**
      * Integration service failure callback method.
      * @callback integrationFailureCallback
      * @param {json} error - Error information
      */
     /**
      * invoke the specified operation
      * @param {string} operationName - Name of the operation
      * @param {object} headers - Input headers for the operation
      * @param {object} data - Input data for the operation
      * @param {integrationSuccessCallback} successCallback  - Callback method on success
      * @param {integrationFailureCallback} failureCallback - Callback method on failure
      * @param {object} options - XMLHttpRequest options like withCredentials value.
      */
     this.invokeOperation = function(operationName, headers, data, successCallback, failureCallback, options) {
         function invokeOperationHandler() {
             _invokeOperation(operationName, headers, data, true, successCallback, failureCallback, options);
         }
         if (voltmx.sdk.skipAnonymousCall) {
             invokeOperationHandler();
         } else {
             voltmx.sdk.claimsRefresh(invokeOperationHandler, failureCallback);
         }
     };
     /**
      * Integration service API to upload binaries based on adapter template
      * @param {string} operationName - Name of the operation
      * @param {Object} uploadParams - InputContext or template variables
      * @param {callback} fileUploadStartedCallback - Callback which is invoked on start of file upload
      * @param {callback} chunkUploadCompletedCallback - Callback which is invoked on chunk upload
      * @param {callback} fileUploadCompletedCallback - Callback which is invoked on complete of file upload
      * @param {callback} fileUploadFailureCallback - Callback which is invoked in case of error during upload
      * @param {Object} options - Provision for user to send additional options
      */
     this.uploadBinaryData = function(operationName, uploadParams, fileUploadStartedCallback, chunkUploadCompletedCallback, fileUploadCompletedCallback, fileUploadFailureCallback, options) {
         //With V9-P2 release, Volt MX Foundry server sends X-Volt-MX-Integrity header for binary calls as well. So, to ignore
         //integrity check at network (voltmxNetHttpRequest) layer passing ignoreintegrity as true.
         if (voltmx.sdk.isNullOrUndefined(options)) {
             options = {};
             options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
         }
         var errorObj = voltmx.sdk.binary.validateUploadParams(uploadParams);
         if (errorObj) {
             voltmx.sdk.verifyAndCallClosure(fileUploadFailureCallback, errorObj);
             return;
         }
         // if rawbytes are provided, converting to base64 string as can only receive base datatypes
         if (!voltmx.sdk.isNullOrUndefined(uploadParams[voltmx.sdk.constants.RAW_BYTES])) {
             var base64String = voltmx.convertToBase64(uploadParams[voltmx.sdk.constants.RAW_BYTES]);
             uploadParams[voltmx.sdk.constants.RAW_BYTES] = base64String;
         }

         function uploadBinaryDataHandler() {
             var uploadOptions = {};
             uploadOptions["URL"] = serviceUrl + "/" + operationName;
             var headers = {};
             if (!voltmx.sdk.skipAnonymousCall) {
                 headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmx.sdk.getCurrentInstance().currentClaimToken;
             }
             uploadOptions["headers"] = headers;
             //Extracting Mandatory Params from uploadParams before fetching template
             if (uploadParams[voltmx.sdk.constants.FILE_PATH]) {
                 uploadOptions[voltmx.sdk.constants.FILE_PATH] = uploadParams[voltmx.sdk.constants.FILE_PATH];
                 delete uploadParams[voltmx.sdk.constants.FILE_PATH];
             } else if (uploadParams[voltmx.sdk.constants.RAW_BYTES]) {
                 uploadOptions[voltmx.sdk.constants.RAW_BYTES] = uploadParams[voltmx.sdk.constants.RAW_BYTES];
                 delete uploadParams[voltmx.sdk.constants.RAW_BYTES];
             } else if (uploadParams[voltmx.sdk.constants.FILE_OBJECT]) {
                 uploadOptions[voltmx.sdk.constants.FILE_OBJECT] = uploadParams[voltmx.sdk.constants.FILE_OBJECT];
                 delete uploadParams[voltmx.sdk.constants.FILE_OBJECT]
             }
             uploadOptions["uploadParams"] = uploadParams;
             voltmx.sdk.binary.uploadBinaryData(uploadOptions, fileUploadStartedCallback, chunkUploadCompletedCallback, fileUploadCompletedCallback, fileUploadFailureCallback, options);
         }
         if (voltmx.sdk.skipAnonymousCall) {
             uploadBinaryDataHandler();
         } else {
             voltmx.sdk.claimsRefresh(uploadBinaryDataHandler, fileUploadFailureCallback);
         }
     };
     /**
      * Integration service API to download binaries based on adapter template
      * @param {string} operationName - Name of the operation
      * @param {Object} fileparams - InputContext or template variables
      * @param {boolean} streaming - Boolean value to determine, whether chunks need to be saved to file or sent in callbacks
      * @param {Object} headers - Provision for custom headers
      * @param {callback} fileDownloadStartedCallback - Callback which is invoked on start of file download
      * @param {callback} chunkDownloadCompletedCallback - Callback which is invoked on stream/chunk download
      * @param {callback} fileDownloadCompletedCallback - Callback which is invoked on complete of file download
      * @param {callback} downloadFailureCallback - Callback which is invoked in case of error during download
      * @param {Object} options - Provision for user to send additional options
      */
     this.getBinaryData = function(operationName, fileparams, streaming, headers, fileDownloadStartedCallback, chunkDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback, options) {
         //With V9-P2 release, Volt MX Foundry server sends X-Volt-MX-Integrity header for binary calls as well. So, to ignore
         //integrity check at network (voltmxNetHttpRequest) layer passing ignoreintegrity as true.
         if (voltmx.sdk.isNullOrUndefined(options)) {
             options = {};
             options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
         }

         function getBinaryDataHandler() {
             _invokeOperation(operationName, headers, fileparams, true, function(downloadConfig) {
                 if (voltmx.sdk.isNullOrUndefined(downloadConfig)) {
                     downloadConfig = {};
                 }
                 if (options && options["ChunkSize"]) {
                     downloadConfig.ChunkSize = options["ChunkSize"];
                 }
                 if (headers) {
                     if (voltmx.sdk.isNullOrUndefined(downloadConfig.headers)) {
                         downloadConfig.headers = {};
                     }
                     for (var header in headers) {
                         if (headers.hasOwnProperty(header)) {
                             downloadConfig.headers[header] = headers[header];
                         }
                     }
                 }
                 voltmx.sdk.binary.getBinaryData(fileparams, streaming, downloadConfig, fileDownloadStartedCallback, chunkDownloadCompletedCallback, fileDownloadCompletedCallback, downloadFailureCallback, options);
             }, downloadFailureCallback, options);
         }
         if (voltmx.sdk.skipAnonymousCall) {
             // Check to find if the service is public or not, in case of public service anonymous login is not required.
             getBinaryDataHandler();
         } else {
             voltmx.sdk.claimsRefresh(getBinaryDataHandler, downloadFailureCallback);
         }
     };

     function invokeOperationRetry(operationName, headers, data, successCallback, failureCallback, options) {
         function invokeOperationRetryHandler() {
             _invokeOperation(operationName, headers, data, false, successCallback, failureCallback, options);
         }
         if (voltmx.sdk.skipAnonymousCall) {
             invokeOperationRetryHandler();
         } else {
             voltmx.sdk.claimsAndProviderTokenRefresh(invokeOperationRetryHandler, failureCallback);
         }
     }

     function retryServiceCall(errorResponse) {
         if (errorResponse[voltmx.sdk.constants.MF_CODE]) {
             // check for the mfcode for which,
             // retry should be done.
         } else {
             if (errorResponse[voltmx.sdk.constants.HTTP_STATUS_CODE] && errorResponse[voltmx.sdk.constants.HTTP_STATUS_CODE] === 401) {
                 voltmx.sdk.logsdk.debug("### IntegrationService::retryServiceCall received 401 from foundry, trying to refresh backend token");
                 return true;
             }
         }
     }

     function _invokeOperation(operationName, headers, data, isRetryNeeded, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing _invokeOperation : " + operationName);
         var requestData = voltmx.sdk.getEncodedReportingParamsForSvcid(operationName);
         var dataToSend = {};
         for (var key in data) {
             if (data.hasOwnProperty(key)) {
                 dataToSend[key] = data[key];
             }
         }
         var defaultHeaders = {};
         defaultHeaders[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
         defaultHeaders["X-Voltmx-ReportingParams"] = requestData;
         if (!voltmx.sdk.skipAnonymousCall) {
             // Check to find if the service is public or not, in case of public service no token is required.
             var token = voltmxRef.currentClaimToken;
             if (!token) {
                 token = voltmx.sdk.getCurrentInstance().currentClaimToken;
             }
             defaultHeaders[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = token;
         }
         var deviceId = voltmx.sdk.getDeviceId();
         if (!voltmx.sdk.isNullOrUndefined(deviceId)) {
             defaultHeaders["X-Voltmx-DeviceId"] = deviceId;
         }
         if (typeof(svcObj) === 'object' && svcObj.version) {
             defaultHeaders["X-Voltmx-API-Version"] = svcObj.version;
         }
         // if the user has defined his own headers, use them
         if (!voltmx.sdk.isNullOrUndefined(headers)) {
             if ((Object.keys(headers)).length !== 0 && typeof(headers) === "object") {
                 var defaultKeys = Object.keys(defaultHeaders);
                 var lowerCaseHeaders = defaultKeys.map(function(x) {
                     return x.toLowerCase()
                 });
                 for (var header in headers) {
                     var headerConst = header;
                     if (lowerCaseHeaders.indexOf(headerConst.toLowerCase()) !== -1) {
                         for (var i = 0; i < defaultKeys.length; i++) {
                             var tempKey = defaultKeys[i];
                             if (tempKey.toLowerCase() === headerConst.toLowerCase()) {
                                 defaultHeaders[tempKey] = headers[header];
                             }
                         }
                     } else {
                         defaultHeaders[header] = headers[header];
                     }
                 }
             }
         }
         // If useCache is enabled and cacheID is present then network call will be skipped and cached response will be returned.
         if (options && options["useCache"] && options["cacheID"]) {
             var cacheResponse = new voltmx.sdk.ClientCache().get(options["cacheID"]);
             if (cacheResponse) {
                 voltmx.sdk.logsdk.debug("Key found in hash, returning cached response.");
                 voltmx.sdk.verifyAndCallClosure(successCallback, cacheResponse);
                 return;
             }
         }

         function networkSuccessCallback(res) {
             // If useCache is enabled then the response is cached and returned.
             if (options && options["useCache"]) {
                 cacheResponseForKey(options, serviceUrl + "/" + operationName, requestData, res);
             }
             voltmx.sdk.logsdk.perf("Executing Finished network call for _invokeOperation : " + operationName);
             voltmx.sdk.logsdk.perf("Executing Finished _invokeOperation : " + operationName);
             voltmx.sdk.verifyAndCallClosure(successCallback, res);
         }

         function networkFailureCallback(xhr, status, err) {
             if (xhr && !(status && err)) {
                 err = xhr;
             }
             if (isRetryNeeded === true && retryServiceCall(err) === true) {
                 voltmx.sdk.logsdk.debug("errorCallback, retrying the operation: " + operationName);
                 invokeOperationRetry(operationName, headers, data, successCallback, failureCallback);
                 return;
             }
             voltmx.sdk.logsdk.perf("Executing Finished network call for _invokeOperation : " + operationName);
             voltmx.sdk.logsdk.perf("Executing Finished _invokeOperation : " + operationName);
             voltmx.sdk.processIntegrationErrorResponse(err, true, failureCallback);
         }
         voltmx.sdk.logsdk.perf("Executing network call for _invokeOperation : " + operationName);
         networkProvider.post(serviceUrl + "/" + operationName, dataToSend, defaultHeaders, networkSuccessCallback, networkFailureCallback, null, options);
     }
     voltmx.sdk.processIntegrationErrorResponse = function(err, isAsync, callBack) {
         if (err[voltmx.sdk.constants.MF_CODE]) {
             //clear the cache if the error code related to session/token expiry
             if (voltmx.sdk.isSessionOrTokenExpired(err[voltmx.sdk.constants.MF_CODE])) {
                 voltmx.sdk.logsdk.info("###IntegrationService::invokeOperationFailure  Session/Token expired. Authenticate and Try again");
                 //TODO: Start a conversation with Suhas and Krishna regarding the scenario wherein one auth session expired and other is still valid.
             }
         }
         if (!isAsync) {
             return voltmx.sdk.error.getIntegrationErrObj(err);
         } else if (callBack) {
             voltmx.sdk.verifyAndCallClosure(callBack, voltmx.sdk.error.getIntegrationErrObj(err));
         }
     };
     //This is an internal api to invoke an service synchronously
     this.invokeOperationSync = function(operationName, headers, data) {
         var res = null;
         res = voltmx.sdk.claimsRefreshSync();
         if (res && res.message && res.message === "success") {
             return _invokeOperationSync(operationName, headers, data);
         } else {
             return res;
         }
     };

     function _invokeOperationSync(operationName, headers, data) {
         var requestData = {};
         var voltmxRef = voltmx.sdk.getCurrentInstance();
         var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid(operationName);
         for (var key in data) {
             if (data.hasOwnProperty(key)) {
                 requestData[key] = data[key];
             }
         }
         var token;
         for (var tempToken in voltmxRef.tokens) {
             if (voltmxRef.tokens.hasOwnProperty(tempToken) && typeof(tempToken) !== 'function') {
                 token = voltmxRef.tokens[tempToken];
                 break;
             }
         }
         requestData[voltmx.sdk.constants.REPORTING_PARAMS] = reportingData;
         var defaultHeaders = {}
         defaultHeaders[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
         defaultHeaders[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
         if (typeof(svcObj) === 'object' && svcObj.version) {
             defaultHeaders["X-Voltmx-API-Version"] = svcObj.version;
         }
         // if the user has defined his own headers, use them
         if ((Object.keys(headers)).length !== 0) {
             var defaultKeys = [];
             defaultKeys = Object.keys(defaultHeaders);
             var defaultkeyLower = {};
             defaultkeyLower = defaultKeys.map(function(x) {
                 return x.toLowerCase()
             });
             for (var header in headers) {
                 var headerConst = header;
                 if (defaultkeyLower.indexOf(headerConst.toLowerCase()) !== -1) {
                     for (var i = 0; i < defaultKeys.length; i++) {
                         var tempKey = defaultKeys[i];
                         if (tempKey.toLowerCase() === headerConst.toLowerCase()) {
                             defaultHeaders[tempKey] = headers[header];
                         }
                     }
                 } else {
                     defaultHeaders[header] = headers[header];
                 }
             }
         }
         var res = null;
         res = networkProvider.postSync(serviceUrl + "/" + operationName, requestData, defaultHeaders);
         if (res.opstatus == 0) {
             return res;
         } else {
             return voltmx.sdk.processIntegrationErrorResponse(res, false);
         }
     }
 }
 voltmx.sdk.claimsRefreshSync = function() {
     var voltmxRef = voltmx.sdk.getCurrentInstance();
     var networkProvider = new voltmxNetworkProvider();
     var loginWithAnonymousProvider = function() {
         var identityObject = voltmxRef.getIdentityService("$anonymousProvider");
         var res = identityObject.anonymousLoginSync(null);
         if (res && JSON.stringify(res) == "{}") {
             return {
                 "message": "success"
             };
         } else {
             return voltmx.sdk.error.getAuthErrObj(res);
         }
     };
     if (voltmxRef.currentClaimToken === null) {
         voltmx.sdk.logsdk.info("claims Token is Unavialable");
         if (voltmxRef.isAnonymousProvider) {
             return loginWithAnonymousProvider();
         } else {
             return voltmx.sdk.error.getNullClaimsTokenErrObj();
         }
     } else if (voltmxRef.claimTokenExpiry && new Date().getTime() > voltmxRef.claimTokenExpiry) {
         if (voltmxRef.isAnonymousProvider) {
             return loginWithAnonymousProvider();
         } else {
             voltmx.sdk.logsdk.info("claims token has expired. fetching new token..");
             var _serviceUrl = stripTrailingCharacter(voltmxRef.rec.url, "/");
             var _url = _serviceUrl + "/claims";
             voltmx.sdk.logsdk.debug("service url is " + _url);
             if (voltmxRef.currentRefreshToken === null) {
                 return voltmx.sdk.error.getNullRefreshTokenErrObj();
             } else {
                 var headers = {};
                 headers[voltmx.sdk.constants.AUTHORIZATION_HEADER] = voltmxRef.currentRefreshToken;
                 headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
                 var data = networkProvider.postSync(_url, {}, headers);
                 if (data.opstatus == 0) {
                     voltmx.sdk.logsdk.info("refresh success..acquiring new tokens");
                     return voltmx.sdk.processClaimsSuccessResponse(data, voltmxRef, false);
                 } else {
                     voltmx.sdk.logsdk.info("failed to acquire refresh token");
                     return voltmx.sdk.processClaimsErrorResponse(data, voltmxRef, false);
                 }
             }
         }
     } else {
         return {
             "message": "success"
         };
     }
 };
 /**
  * Method to create the messaging service instance.
  * @returns {MessagingService} Messaging service instance
  */
 voltmx.sdk.prototype.getMessagingService = function() {
     if (!voltmx.sdk.isInitialized) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + " Messaging service.");
     }
     KNYMessagingService = VMXMessagingService = voltmx.sdk.isNullOrUndefined(VMXMessagingService) ? new MessagingService(this) : VMXMessagingService;
     if ((this.messagingsvc.url !== VMXMessagingService.getUrl()) || (this.messagingsvc.appId !== VMXMessagingService.getKmsAppId())) {
         KNYMessagingService = VMXMessagingService = new MessagingService(this);
     }
     return VMXMessagingService;
 };
 var KNYGeoBoundariesOptions = VMXGeoBoundariesOptions = {};
 /**
  * Should not be called by the developer.
  * @class
  * @classdesc Messaging service instance for invoking the Messaging services.
  * @param voltmxRef - reference to Volt MX object
  */
 function MessagingService(voltmxRef) {
     var homeUrl = voltmxRef.messagingsvc.url;
     var appId = voltmxRef.messagingsvc.appId;
     var networkProvider = new voltmxNetworkProvider();
     var dsKey_KSID = appId + "_KSID";
     var dsKey_authToken = appId + "_AUTHTOKEN";
     var currentObject = this;
     var geoBoundaryData;
     var KSID;
     var AUTHTOKEN;
     geoBoundariesOptions = {};
     this.setGeoBoundariesOptions = function(options) {
         KNYGeoBoundariesOptions = VMXGeoBoundariesOptions = options;
     };
     this.getGeoBoundariesOptions = function() {
         return VMXGeoBoundariesOptions;
     };
     this.getUrl = function() {
         return homeUrl;
     };
     this.setKSID = function(ksid) {
         voltmx.sdk.dataStore.setItem(dsKey_KSID, ksid);
         KSID = ksid;
     };
     this.getKSID = function() {
         if (!KSID) {
             KSID = voltmx.sdk.dataStore.getItem(dsKey_KSID);
         }
         return KSID;
     };
     this.setAuthToken = function(authToken) {
         voltmx.sdk.dataStore.setItem(dsKey_authToken, authToken);
         AUTHTOKEN = authToken
     };
     this.getAuthToken = function(options) {
         if (options && options[voltmx.sdk.constants.AUTH_TOKEN]) {
             AUTHTOKEN = options[voltmx.sdk.constants.AUTH_TOKEN];
         } else {
             //retrieving from local store if user given token is null
             AUTHTOKEN = voltmx.sdk.dataStore.getItem(dsKey_authToken);
         }
         return AUTHTOKEN;
     };
     var setGeoBoundaryData = function(data) {
         voltmx.sdk.dataStore.setItem("geoBoundaryData", data);
         geoBoundaryData = data;
     };
     var getGeoBoundaryDataForBoundaryId = function(boundaryId) {
         if (!geoBoundaryData) {
             geoBoundaryData = voltmx.sdk.dataStore.getItem("geoBoundaryData")
         }
         return geoBoundaryData[boundaryId];
     };
     this.setKmsAppId = function(id) {
         appId = id;
     };
     this.getKmsAppId = function() {
         return appId;
     };
     KSID = currentObject.getKSID();
     AUTHTOKEN = currentObject.getAuthToken();
     var registerForMessagingService = function(osType, deviceId, pnsToken, email, authToken, successCallback, failureCallback) {
         var uri = homeUrl + "/subscribers";
         var subscribeParamsJson = {
             "sid": pnsToken,
             "appId": appId,
             "ufid": email,
             "osType": osType,
             "deviceId": deviceId
         };
         if (authToken != undefined && authToken != null) {
             subscribeParamsJson[voltmx.sdk.constants.AUTH_TOKEN] = authToken;
         }
         var jsonParam = {
             "subscriptionService": {
                 "subscribe": subscribeParamsJson
             }
         };
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON_CHARSET_UTF8;
         var payload = jsonParam;
         var networkOptions = {};
         networkOptions["disableIntegrity"] = true;
         voltmx.sdk.logsdk.perf("Executing registerForMessagingService's network call");
         networkProvider.post(uri, payload, headers, function(data) {
             voltmx.sdk.logsdk.perf("Executing finished registerForMessagingService's network success");
             currentObject.setKSID(data.id);
             currentObject.setAuthToken(authToken);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(data, status, error) {
             voltmx.sdk.logsdk.perf("Executing finished registerForMessagingService's network failure");
             voltmx.sdk.logsdk.error("ERROR: Failed to register device for KMS");
             var errorObj = {};
             errorObj.data = data;
             errorObj.status = status;
             errorObj.error = error;
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         }, voltmx.sdk.constants.CONTENT_TYPE_JSON, networkOptions);
     };
     var subscribeAudienceOrUpdate = function(firstName, lastName, emailId, mobileNumber, country, state, options, successCallback, failureCallback) {
         var uri = homeUrl + voltmx.sdk.constants.SUBSCRIBE_AUDIENCE;
         var subscribeAudienceJson = {
             "ksid": KSID,
             "firstName": firstName,
             "lastName": lastName,
             "email": emailId,
             "mobileNumber": mobileNumber,
             "country": country,
             "state": state
         };
         var currentdate = new Date();
         //toLocaleString gives current time in below format
         //6/25/2018, 12:38:21 PM
         var datetime = currentdate.toLocaleString('en-US', {
             timeZone: 'UTC'
         });
         //remove , in the current UTC time
         datetime = datetime.replace(",", "");
         subscribeAudienceJson[voltmx.sdk.constants.LAST_ACTIVE_DATE] = datetime;
         if (!voltmx.sdk.isNullOrUndefined(options)) {
             for (var key in options) {
                 if (options.hasOwnProperty(key)) {
                     if (key === voltmx.sdk.constants.AUTH_TOKEN) {
                         subscribeAudienceJson[key] = currentObject.getAuthToken(options);
                     } else {
                         subscribeAudienceJson[key] = options[key];
                     }
                 }
             }
         }
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON_CHARSET_UTF8;
         var payload = subscribeAudienceJson;
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing subscribeAudienceOrUpdate's network call");
         networkProvider.post(uri, payload, headers, function(data) {
             //override data store auth token with user given token
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudienceOrUpdate's network success");
             overrideAuthToken(options);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(data, status, error) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudienceOrUpdate's network failure");
             voltmx.sdk.logsdk.error("ERROR: Failed to create or update audience", errorObj);
             var errorObj = {};
             errorObj.data = data;
             errorObj.status = status;
             errorObj.error = error;
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         }, voltmx.sdk.constants.CONTENT_TYPE_JSON, networkOptions);
     };
     /**
     * register to messaging service
     * @param {string} osType - Type of the operating system
     * @param {string} deviceId - Device Id
     * @param {string} pnsToken - Token value
     * @param {string} ufid - UFID can be email-id,mobile number or
	 						any dynamic attribute configured as reconciliation key in Engagement console
     * @param {function} successCallback - Callback method on success
     * @param {function} failureCallback - Callback method on failure
     * @param {dictionary} options - {authToken: <Auth Token>}
     */
     this.register = function(osType, deviceId, pnsToken, ufid, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing register");
         var authToken = null;
         if (voltmx.sdk.isNullOrUndefined(pnsToken)) {
             voltmx.sdk.logsdk.perf("Executing finished register finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid pnsToken/sId, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(osType)) {
             voltmx.sdk.logsdk.perf("Executing finished register finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid osType, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(deviceId)) {
             voltmx.sdk.logsdk.perf("Executing finished register finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid deviceId, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(ufid)) {
             voltmx.sdk.logsdk.perf("Executing finished register finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid email, it cannot be null");
         }
         authToken = currentObject.getAuthToken(options);
         registerForMessagingService(osType, deviceId, pnsToken, ufid, authToken, function(data) {
             //override data store auth token with user given token
             voltmx.sdk.logsdk.perf("Executing finished register finished with success");
             overrideAuthToken(options);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(errorObj) {
             voltmx.sdk.logsdk.perf("Executing finished register finished with failure");
             voltmx.sdk.logsdk.error("Register :: Register for messaging service failed with error", errorObj);
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         });
     };
     /**
      * register to messaging service
      * @param {string} osType - Type of the operating system
      * @param {string} deviceId - Device Id
      * @param {string} authToken - Authorization Token
      * @param {string} pnsToken - Token value
      * @param {string} email - email
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     /**
      * @deprecated This method is deprecated because authToken can be given as input through options param of
      * register method.
      */
     this.registerWithAuthToken = function(osType, deviceId, pnsToken, email, authToken, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf("Executing registerWithAuthToken");
         if (voltmx.sdk.isNullOrUndefined(pnsToken)) {
             voltmx.sdk.logsdk.perf("Executing finished registerWithAuthToken finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid pnsToken/sId,it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(osType)) {
             voltmx.sdk.logsdk.perf("Executing finished registerWithAuthToken finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid osType, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(deviceId)) {
             voltmx.sdk.logsdk.perf("Executing finished registerWithAuthToken finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid deviceId, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(email)) {
             voltmx.sdk.logsdk.perf("Executing finished registerWithAuthToken finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid email, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(authToken)) {
             voltmx.sdk.logsdk.perf("Executing finished registerWithAuthToken finished with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid authToken, it cannot be null");
         }
         registerForMessagingService(osType, deviceId, pnsToken, email, authToken, function(data) {
             voltmx.sdk.logsdk.perf("Executing finished registerWithAuthToken finished with success");
             voltmx.sdk.verifyAndCallClosure(successCallback, data)
         }, function(errorObj) {
             voltmx.sdk.logsdk.perf("Executing finished registerWithAuthToken finished with failure");
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         });
     };
     var unregisterFromMessagingService = function(authToken, successCallback, failureCallback) {
         var uri = homeUrl + "/subscribers";
         var unsubscribeObj = {
             "ksid": currentObject.getKSID()
         };
         if (authToken != undefined && authToken != null) {
             unsubscribeObj[voltmx.sdk.constants.AUTH_TOKEN] = authToken;
         }
         var inp = {
             "subscriptionService": {
                 "unsubscribe": unsubscribeObj
             }
         };
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON_CHARSET_UTF8;
         var payload = inp;
         voltmx.sdk.logsdk.info("unsubscribe uri:" + uri);
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing unregisterFromMessagingService's network call");
         networkProvider.post(uri, payload, headers, function(data) {
             voltmx.sdk.logsdk.perf("Executing finished unregisterFromMessagingService's network success");
             voltmx.sdk.dataStore.removeItem(dsKey_KSID);
             voltmx.sdk.dataStore.removeItem(dsKey_authToken);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(data, status, error) {
             voltmx.sdk.logsdk.perf("Executing finished unregisterFromMessagingService's network failure");
             voltmx.sdk.logsdk.error("ERROR: Failed to unregister device for KMS");
             var errorObj = {};
             errorObj.data = data;
             errorObj.status = status;
             errorObj.error = error;
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         }, voltmx.sdk.constants.CONTENT_TYPE_JSON, networkOptions);
     };
     /**
      * unregister to messaging service
      * @param {dictionary} options - {authToken: <Auth Token>}
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     this.unregister = function(successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing unregister");
         var tempKSID = currentObject.getKSID();
         var authToken = null;
         if (typeof(tempKSID) === 'undefined' || tempKSID === null) {
             voltmx.sdk.logsdk.perf("Executing finished unregister with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "KSID not available, Register and try again.");
         }
         authToken = currentObject.getAuthToken(options);
         unregisterFromMessagingService(authToken, function(res) {
             voltmx.sdk.logsdk.perf("Executing finished unregister with success");
             successCallback(res);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished unregister with failure");
             failureCallback(err);
         });
     };
     /**
      * unregister to messaging service
      * @param {string} authToken - Authorization Token
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     /**
      * @deprecated This method is deprecated because authToken can be given as input through options param of
      * unregister method.
      */
     this.unregisterWithAuthToken = function(authToken, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf("Executing unregisterWithAuthToken");
         var tempKSID = currentObject.getKSID();
         if (typeof(tempKSID) === 'undefined' || tempKSID === null) {
             voltmx.sdk.logsdk.perf("Executing finished unregisterWithAuthToken with execption");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "KSID not available, Register and try again.");
         }
         if (typeof(authToken) === 'undefined' || authToken === null) {
             voltmx.sdk.logsdk.perf("Executing finished unregisterWithAuthToken with execption");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid authToken.");
         }
         unregisterFromMessagingService(authToken, function(res) {
             voltmx.sdk.logsdk.perf("Executing finished unregisterWithAuthToken with success");
             successCallback(res);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished unregisterWithAuthToken with failure");
             failureCallback(err);
         });
     };
     /**
      * Fetch all messages
      * @param {number} startIndex - starting index
      * @param {number} pageSize - page size
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {dictionary} options - {authToken: <Auth Token>}
      */
     this.fetchAllMessages = function(startIndex, pageSize, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing fetchAllMessages");
         var tempKSID = currentObject.getKSID();
         if (typeof(tempKSID) === 'undefined' || tempKSID === null) {
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "KSID not available, Register and try again.");
         }
         var uri = homeUrl + "/messages/fetch";
         var data = {
             "ksid": tempKSID,
             "startElement": startIndex,
             "elementsPerPage": pageSize
         };
         data[voltmx.sdk.constants.AUTH_TOKEN] = currentObject.getAuthToken(options);
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON_CHARSET_UTF8;
         var payload = data;
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing fetchAllMessages's network call");
         networkProvider.post(uri, payload, headers, function(data) {
             voltmx.sdk.logsdk.perf("Executing finished fetchAllMessages's network call with success");
             overrideAuthToken(options);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(errorObj) {
             voltmx.sdk.logsdk.perf("Executing finished fetchAllMessages's network call with failure");
             voltmx.sdk.logsdk.error("FetchAllMessages :: FetchAllMessages for messaging service failed with error", errorObj);
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         }, voltmx.sdk.constants.CONTENT_TYPE_JSON, networkOptions);
     };
     var updateGeoLocationForMessagingService = function(latitude, longitude, locationName, authToken, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf("Executing updateGeoLocationForMessagingService");
         var uri = homeUrl + "/location";
         var data = {
             "ksid": currentObject.getKSID(),
             "latitude": latitude,
             "longitude": longitude
         };
         if (typeof(locationName) === "string") {
             data["locname"] = locationName;
         }
         if (authToken != null && authToken != undefined) {
             data[voltmx.sdk.constants.AUTH_TOKEN] = authToken;
         }
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON_CHARSET_UTF8;
         var payload = data;
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing updateGeoLocationForMessagingService's network call");
         networkProvider.post(uri, payload, headers, function(data) {
             //override data store auth token with user given token
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocationForMessagingService with network success");
             currentObject.setAuthToken(authToken);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(errorObj) {
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocationForMessagingService with network failure");
             voltmx.sdk.logsdk.error("UpdateGeoLocation :: UpdateGeoLocation for messaging service failed with error", errorObj);
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         }, voltmx.sdk.constants.CONTENT_TYPE_JSON, networkOptions);
     };
     /**
      * Update the location
      * @param {string} latitude - Latitude value
      * @param {string} longitude - Longitude value
      * @param {string} locationName - Location name
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {dictionary} options - {authToken: <Auth Token>}
      */
     this.updateGeoLocation = function(latitude, longitude, locationName, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing updateGeoLocation");
         var tempKSID = currentObject.getKSID();
         var authToken = null;
         if (typeof(tempKSID) === 'undefined' || tempKSID === null) {
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocation with execption");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "KSID not available, Register and try again.");
         }
         if (typeof(latitude) === 'undefined' || latitude === null) {
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocation with execption");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid latitude.");
         }
         if (typeof(longitude) === 'undefined' || longitude === null) {
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocation with execption");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid longitude.");
         }
         authToken = currentObject.getAuthToken(options);
         updateGeoLocationForMessagingService(latitude, longitude, locationName, authToken, function(res) {
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocation with success");
             successCallback(res);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocation with failure");
             failureCallback(err);
         });
     };
     /**
      * Update the location
      * @param {string} latitude - Latitude value
      * @param {string} longitude - Longitude value
      * @param {string} locationName - Location name
      * @param {string} authToken - Authorization Token
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     /**
      * @deprecated This method is deprecated because authToken can be given as a input through options param of
      * updateGeoLocation method
      */
     this.updateGeoLocationWithAuthToken = function(latitude, longitude, locationName, authToken, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf("Executing updateGeoLocationWithAuthToken");
         var tempKSID = currentObject.getKSID();
         if (typeof(tempKSID) === 'undefined' || tempKSID === null) {
             voltmx.sdk.logsdk.perf("Executing finshed updateGeoLocationWithAuthToken with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "KSID not available, Register and try again.");
         }
         if (typeof(latitude) === 'undefined' || latitude === null) {
             voltmx.sdk.logsdk.perf("Executing finshed updateGeoLocationWithAuthToken with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid latitude.");
         }
         if (typeof(longitude) === 'undefined' || longitude === null) {
             voltmx.sdk.logsdk.perf("Executing finshed updateGeoLocationWithAuthToken with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid longitude.");
         }
         if (typeof(authToken) === 'undefined' || authToken === null) {
             voltmx.sdk.logsdk.perf("Executing finshed updateGeoLocationWithAuthToken with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid authToken.");
         }
         updateGeoLocationForMessagingService(latitude, longitude, locationName, authToken, function(res) {
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocationWithAuthToken with success");
             successCallback(res);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished updateGeoLocationWithAuthToken with failure");
             failureCallback(err);
         });
     };
     /**
      * Mark the message as read for a given message id
      * @param {string} fetchId - Message id
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {dictionary} options - {authToken: <Auth Token>}
      */
     this.markMessageRead = function(fetchId, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing markMessageRead");
         if (typeof(fetchId) === 'undefined' || fetchId === null) {
             voltmx.sdk.logsdk.perf("Executing finshed markMessageRead with exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid FetchId, it cannot be null");
         }
         var headers = {};
         headers["X-HTTP-Method-Override"] = "get";
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON_CHARSET_UTF8;
         var uri = homeUrl + "/messages/open/" + fetchId;
         headers[voltmx.sdk.constants.DEVICE_AUTHTOKEN_HEADER] = currentObject.getAuthToken(options);
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing markMessageRead's network call");
         networkProvider.get(uri, null, headers, function(data) {
             //override data store auth token with user given token
             voltmx.sdk.logsdk.perf("Executing finished markMessageRead with network success");
             overrideAuthToken(options);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(errorObj) {
             voltmx.sdk.logsdk.perf("Executing finished markMessageRead with network failure");
             voltmx.sdk.logsdk.error("MarkMessageRead :: MarkMessageRead for messaging service failed with error", errorObj);
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         }, null, networkOptions);
     };
     /**
      * Fetches the message conetent for a given message id
      * @param {string} fetchId - Message id
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {dictionary} options - {authToken: <Auth Token>}
      */
     this.fetchMessageContent = function(fetchId, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing fetchMessageContent");
         if (typeof(fetchId) === 'undefined' || fetchId === null) {
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid FetchId, it cannot be null");
         }
         var uri = homeUrl + "/messages/content/" + fetchId;
         var headers = {};
         headers[voltmx.sdk.constants.DEVICE_AUTHTOKEN_HEADER] = currentObject.getAuthToken(options);
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing fetchMessageContent's network call");
         networkProvider.get(uri, null, headers, function(data) {
             //override data store auth token with user given token
             voltmx.sdk.logsdk.perf("Executing finished fetchMessageContent with network success");
             overrideAuthToken(options);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(errorObj) {
             voltmx.sdk.logsdk.perf("Executing finished fetchMessageContent with network failure");
             voltmx.sdk.logsdk.error("FetchMessageContent :: FetchMessageContent for messaging service failed with error", errorObj);
             voltmx.sdk.verifyAndCallClosure(failureCallback, errorObj);
         }, null, networkOptions);
     };
     /**
      * subscribeAudience to create a audience for subscribed device
      * @param {string} firstName - audience firstName
      * @param {string} lastName - audience lastName
      * @param {string} emailId - audience emailId
      * @param {string} mobileNumber - audience mobileNumber
      * @param {string} country - country
      * @param {string} state - state
      * @param {Object] options - {authToken: <Auth Token>} and user defined attributes like PAN no,SSN.
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      */
     this.subscribeAudience = function(firstName, lastName, emailId, mobileNumber, country, state, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing subscribeAudience");
         if (voltmx.sdk.isNullOrUndefined(KSID)) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudience wih an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Register for messaging service before creating or updating");
         }
         if (voltmx.sdk.isNullOrUndefined(firstName)) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudience wih an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid first name, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(lastName)) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudience wih an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid last name, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(mobileNumber)) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudience wih an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid mobile number, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(emailId)) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudience wih an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid email Id, it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(country)) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudience wih an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid country, it cannot be null");
         }
         subscribeAudienceOrUpdate(firstName, lastName, emailId, mobileNumber, country, state, options, function(res) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudience with success");
             successCallback(res);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished subscribeAudience with failure");
             failureCallback(err);
         });
     };
     /**
      * delete subscribed audience
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {dictionary} options - {authToken: <Auth Token>}
      **/
     this.unSubscribeAudience = function(successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing unSubscribeAudience");
         if (voltmx.sdk.isNullOrUndefined(KSID)) {
             voltmx.sdk.logsdk.perf("Executing finished unSubscribeAudience with an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Register for messaging service before unsubscribe audience");
         }
         var uri = homeUrl + voltmx.sdk.constants.SUBSCRIBE_AUDIENCE + "/" + KSID;
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_OVERRIDE_HEADER] = voltmx.sdk.constants.HTTP_METHOD_DELETE;
         headers[voltmx.sdk.constants.DEVICE_AUTHTOKEN_HEADER] = currentObject.getAuthToken(options);
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing unSubscribeAudience's network call");
         networkProvider.post(uri, null, headers, function(data) {
             //override data store auth token with user given token
             voltmx.sdk.logsdk.perf("Executing finished unSubscribeAudience with network success");
             overrideAuthToken(options);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished unSubscribeAudience with network failure");
             voltmx.sdk.logsdk.error("MessagingService::unSubscribeAudience failed to unsubscribe audience", err);
             voltmx.sdk.verifyAndCallClosure(failureCallback, err);
         }, null, networkOptions);
     };
     /*
      * get subscribed audience details
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure
      * @param {dictionary} options - {authToken: <Auth Token>}
      */
     this.getSubscribedAudienceDetails = function(successCallback, failureCallback, options) {
             voltmx.sdk.logsdk.perf("Executing getSubscribedAudienceDetails");
             if (voltmx.sdk.isNullOrUndefined(KSID)) {
                 voltmx.sdk.logsdk.perf("Executing finished getSubscribedAudienceDetails with an exception");
                 throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Register for messaging service before get subscribed audience details");
             }
             var uri = homeUrl + voltmx.sdk.constants.SUBSCRIBE_AUDIENCE + "/" + KSID;
             var headers = {};
             headers[voltmx.sdk.constants.HTTP_OVERRIDE_HEADER] = voltmx.sdk.constants.HTTP_METHOD_GET;
             headers[voltmx.sdk.constants.DEVICE_AUTHTOKEN_HEADER] = currentObject.getAuthToken(options);
             var networkOptions = {};
             networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
             voltmx.sdk.logsdk.perf("Executing getSubscribedAudienceDetails's network call");
             networkProvider.get(uri, null, headers, function(data) {
                 //override data store auth token with user given token
                 voltmx.sdk.logsdk.perf("Executing finished getSubscribedAudienceDetails with network success");
                 overrideAuthToken(options);
                 voltmx.sdk.verifyAndCallClosure(successCallback, data);
             }, function(err) {
                 voltmx.sdk.logsdk.perf("Executing finished getSubscribedAudienceDetails with network failure");
                 voltmx.sdk.logsdk.error("MessagingService::getSubscribedAudienceDetails failed to get audience details", err);
                 voltmx.sdk.verifyAndCallClosure(failureCallback, err);
             }, null, networkOptions);
         }
         /*
          * get rich push content
          * @param pushId {string} - pushId for getting rich push content.Which we get after registering
          * for push notifications.
          * @param {function} successCallback - Callback method on success
          * @param {function} failureCallback - Callback method on failure
          * @param {dictionary} options - {authToken: <Auth Token>}
          */
     this.getRichPushContent = function(pushId, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing getRichPushContent");
         if (voltmx.sdk.isNullOrUndefined(KSID)) {
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Register for messaging service to get rich push content");
         }
         if (voltmx.sdk.isNullOrUndefined(pushId)) {
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid PushId,it cannot be null");
         }
         var uri = homeUrl + voltmx.sdk.constants.RICH_PUSH_MESSAGE + pushId;
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_OVERRIDE_HEADER] = voltmx.sdk.constants.HTTP_METHOD_GET;
         headers[voltmx.sdk.constants.DEVICE_AUTHTOKEN_HEADER] = currentObject.getAuthToken(options);
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing getRichPushContent's network call");
         networkProvider.get(uri, null, headers, function(data) {
             //override data store auth token with user given token
             voltmx.sdk.logsdk.perf("Executing finished getRichPushContent with network success");
             overrideAuthToken(options);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished getRichPushContent with network failure");
             voltmx.sdk.logsdk.error("MESSAGING SERVICE :: getRichPushContent failed to get rich content with error", err);
             voltmx.sdk.verifyAndCallClosure(failureCallback, err);
         }, null, networkOptions);
     };
     /*
      * Update the list of beacons
      * @param {string} uuId - Universally Unique Identifier to identify a beacon in a network
      * @param {string} major - major id to identity and distinguish a group
      * @param {string} minor - distinguishing individual beacons within a group of beacons assigned a major value.
      * @param {function} successCallback - Callback method called on success.
      * @param {function} failureCallback - Callback method called on failure.
      * @param {object} options - options which accepts optional parameters such as ufid,appid and {authToken: <Auth Token>}
      */
     this.updateListOfBeacons = function(uuId, major, minor, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing updateListOfBeacons");
         if (voltmx.sdk.isNullOrUndefined(KSID)) {
             voltmx.sdk.logsdk.perf("Executing finished updateListOfBeacons due to an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Register for messaging service before updating list of beacons");
         }
         if (voltmx.sdk.isNullOrUndefined(uuId)) {
             voltmx.sdk.logsdk.perf("Executing finished updateListOfBeacons due to an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid UUID,it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(major)) {
             voltmx.sdk.logsdk.perf("Executing finished updateListOfBeacons due to an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid major,it cannot be null");
         }
         if (voltmx.sdk.isNullOrUndefined(minor)) {
             voltmx.sdk.logsdk.perf("Executing finished updateListOfBeacons due to an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Invalid minor,it cannot be null");
         }
         var uri = homeUrl + voltmx.sdk.constants.BEACON_UPDATE;
         var payload = {};
         payload[voltmx.sdk.constants.KSID] = KSID;
         var beaconsList = {};
         //beacon object has beacon details like uuid,major and minor
         var beacon = {};
         beacon["uuid"] = uuId;
         beacon["major"] = major;
         beacon["minor"] = minor;
         beaconsList["beacon"] = beacon;
         payload["beacons"] = beaconsList;
         payload[voltmx.sdk.constants.AUTH_TOKEN] = currentObject.getAuthToken(options);
         //appid and ufid are optional
         if (options && options["ufid"]) {
             payload["ufid"] = options["ufid"];
         }
         if (options && options["appid"]) {
             payload["appid"] = options["appid"];
         }
         var data = payload;
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON_CHARSET_UTF8;
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing updateListOfBeacons's network call");
         networkProvider.post(uri, data, headers, function(data) {
             //override data store auth token with user given token
             voltmx.sdk.logsdk.perf("Executing finished updateListOfBeacons with network success");
             overrideAuthToken(options);
             voltmx.sdk.verifyAndCallClosure(successCallback, data);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished updateListOfBeacons with network failure");
             voltmx.sdk.logsdk.error("MESSAGING SERVICE :: updateListOfBeacons failed to update with error", err);
             voltmx.sdk.verifyAndCallClosure(failureCallback, err);
         }, voltmx.sdk.constants.CONTENT_TYPE_JSON, networkOptions);
     };
     /*
      * Utility method to override datastore authtoken with user given auth token.
      */
     var overrideAuthToken = function(options) {
         var authToken;
         if (options && options[voltmx.sdk.constants.AUTH_TOKEN]) {
             currentObject.setAuthToken(options[voltmx.sdk.constants.AUTH_TOKEN]);
         }
     };
     this.manageGeoBoundariesCallback = function(data) {
         var geoBoundariesOptions = VMXMessagingService.getGeoBoundariesOptions();
         if (data.state.toLocaleUpperCase() === "ENTRY" || data.state.toLocaleUpperCase() === "ENTER") {
             if (data.geofenceID !== "refreshBoundary") {
                 var action = getGeoBoundaryDataForBoundaryId(parseInt(data.geofenceID));
                 if (action && action.clientAction === "notifyEngagementServer") {
                     VMXMessagingService.updateGeoLocation(data.lat, data.lon, action.locationName, function(res) {
                         voltmx.sdk.logsdk.info("MessagingService::manageGeoBoundariesCallback successfully notified KMS");
                     }, function(err) {
                         voltmx.sdk.logsdk.error("MessagingService::manageGeoBoundariesCallback error in notifying KMS");
                     });
                 } else if (action && action.clientAction === "localNotification") {
                     try {
                         //Setting time to invoke after 1 second
                         var date = new Date().getTime() + 1000;
                         var dateString;
                         var format;
                         if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_WINDOWS) {
                             dateString = new Date(date).toString().slice(4, 24);
                             format = "MMM dd yyyy HH:mm:ss";
                         } else {
                             dateString = new Date(date).toString().slice(4, 24) + " " + new Date().toString().match(/([-\+][0-9]+)\s/)[1];
                             format = "MMM dd yyyy HH:mm:ss Z";
                         }
                         voltmx.sdk.logsdk.trace("MessagingService::manageGeoBoundariesCallback invoking local notification");
                         voltmx.localnotifications.create({
                             "id": date.toString(),
                             "dateTime": {
                                 "date": dateString,
                                 "format": format
                             },
                             "message": action.message,
                             "title": appId.toString(),
                             "categoryId": "geoBoundary"
                         });
                     } catch (e) {
                         voltmx.sdk.logsdk.error("Exception while creating localNotification " + e);
                     }
                 } else if (action && action.clientAction === "customLogic") {
                     if (!voltmx.sdk.isNullOrUndefined(geoBoundariesOptions["customLogicCallback"]) && typeof(geoBoundariesOptions["customLogicCallback"]) == voltmx.sdk.constants.FUNCTION_STRING) {
                         voltmx.sdk.logsdk.info("MessagingService::manageGeoBoundariesCallback invoking customLogicCallback defined by user");
                         //Appending current location to the kms data obtained from the server
                         action["CurrentLocation"] = {
                             "latitude": data.lat,
                             "longitude": data.lon
                         };
                         voltmx.sdk.verifyAndCallClosure(geoBoundariesOptions["customLogicCallback"], action);
                     } else {
                         voltmx.sdk.logsdk.info("MessagingService::manageGeoBoundariesCallback customLogicCallback is not defined by user");
                     }
                 }
             }
         } else if (data.state.toLocaleUpperCase() === "EXIT") {
             var options = {};
             options[voltmx.sdk.constants.AUTH_TOKEN] = VMXMessagingService.getAuthToken();
             if (data.geofenceID === "refreshBoundary") {
                 VMXMessagingService.updateGeoLocation(data.lat, data.lon, data.geofenceID, function(res) {
                     voltmx.sdk.logsdk.info("MessagingService::manageGeoBoundariesCallback successfully notified KMS");
                     getAndRefreshBoundaries(geoBoundariesOptions, function(res1) {
                         voltmx.sdk.logsdk.info("MessagingService::manageGeoBoundariesCallback successfully refreshed geoBoundaries");
                     }, function(err1) {
                         voltmx.sdk.logsdk.error("MessagingService::manageGeoBoundariesCallback failed to refresh geoBoundaries");
                         voltmx.sdk.verifyAndCallClosure(VMXMessagingService.refreshBoundariesFailureCallback, err1);
                     }, options);
                 }, function(err) {
                     voltmx.sdk.logsdk.error("MessagingService::manageGeoBoundariesCallback error in notifying KMS");
                 });
             }
         }
     };
     var getAndRefreshBoundaries = function(geoBoundaryOptions, successCallback, failureCallback, options) {
         voltmx.sdk.logsdk.perf("Executing getAndRefreshBoundaries");

         function formGeoBoundariesInput(id, latitude, longitude, distance) {
             return {
                 "geofenceID": id.toString(),
                 "lat": latitude,
                 "lon": longitude,
                 "radius": Number(distance.toFixed(4))
             }
         }
         var url = homeUrl + "/geolocations/nearest/" + KSID;
         var flag = true;
         if (!voltmx.sdk.isNullOrUndefined(geoBoundaryOptions["radius"]) && typeof(geoBoundaryOptions["radius"]) == "number") {
             if (flag) {
                 url = url + "?radius=" + geoBoundaryOptions["radius"];
                 flag = false;
             } else {
                 url = url + "&radius=" + geoBoundaryOptions["radius"];
             }
         }
         if (!voltmx.sdk.isNullOrUndefined(geoBoundaryOptions["pageSize"]) && typeof(geoBoundaryOptions["pageSize"]) == "number") {
             if (flag) {
                 url = url + "?pageSize=" + geoBoundaryOptions["pageSize"];
                 flag = false;
             } else {
                 url = url + "&pageSize=" + geoBoundaryOptions["pageSize"];
             }
         }
         if (!voltmx.sdk.isNullOrUndefined(geoBoundaryOptions["tags"])) {
             if (flag) {
                 url = url + "?tags=" + encodeURI(geoBoundaryOptions["tags"]);
                 flag = false;
             } else {
                 url = url + "&tags=" + encodeURI(geoBoundaryOptions["tags"]);
             }
         }
         var headers = {};
         headers[voltmx.sdk.constants.DEVICE_AUTHTOKEN_HEADER] = currentObject.getAuthToken(options);
         voltmx.sdk.logsdk.info("MessagingService::getAndRefreshBoundaries invoking refreshGeoBoundaries with url: " + url);
         var networkOptions = {};
         networkOptions[voltmx.sdk.constants.DISABLE_INTEGRITY] = true;
         voltmx.sdk.logsdk.perf("Executing getAndRefreshBoundaries's network call");
         networkProvider.get(url, null, headers, function(res) {
             voltmx.sdk.logsdk.perf("Executing finished getAndRefreshBoundaries with network success");
             var geoBoundaries = [];
             var boundaryActions = {};
             var boundariesLimit;
             //override data store auth token with user given token
             overrideAuthToken(options);
             if (!voltmx.sdk.isNullOrUndefined(geoBoundaryOptions["pageSize"]) && typeof(geoBoundaryOptions["pageSize"]) == "number") {
                 boundariesLimit = geoBoundaryOptions["pageSize"];
             } else {
                 if (voltmx.sdk.getPlatformName() == voltmx.sdk.constants.PLATFORM_ANDROID) {
                     boundariesLimit = 99;
                 } else {
                     boundariesLimit = 19;
                 }
             }
             geoBoundaries.push(formGeoBoundariesInput("refreshBoundary", res["refreshBoundary"].latitude, res["refreshBoundary"].longitude, Math.abs(res["refreshBoundary"].distance * 1609.34)));
             var locations = res["locations"];
             for (var i = 0; i < locations.length && i < boundariesLimit; i++) {
                 var boundaryid = locations[i].id;
                 geoBoundaries.push(formGeoBoundariesInput(boundaryid, locations[i].latitude, locations[i].longitude, Math.abs(locations[i].radius * 1609.34)));
                 boundaryActions[boundaryid] = locations[i];
             }
             setGeoBoundaryData(boundaryActions);
             voltmx.sdk.logsdk.debug("MessagingService::getAndRefreshBoundaries registering " + geoBoundaries.length + " boundaries with frameworks for monitoring.");
             // voltmx.location.setGeofencesCallback method should be called in PreAppInit for IOS to receive the callbacks. Other platforms do not have such rule.
             if (voltmx.sdk.getPlatformName() !== voltmx.sdk.constants.PLATFORM_IOS) {
                 voltmx.location.setGeofencesCallback(voltmx.sdk.getCurrentInstance().getMessagingService().manageGeoBoundariesCallback);
             }
             voltmx.location.createGeofences(geoBoundaries);
             voltmx.sdk.verifyAndCallClosure(successCallback, res);
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished getAndRefreshBoundaries with network failure");
             voltmx.sdk.logsdk.error("MessagingService::getAndRefreshBoundaries failed to get geoBoundaries from KMS");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getMessagingError("Failed to get geoBoundaries from KMS"));
         }, null, networkOptions);
     };
     /**
      * Register for registerGeoBoundaries with given radius
      * @param {object} options - JSON Object with radius, pageSize, tags and customLogicCallback
      * @param {function} successCallback - Callback method on success
      * @param {function} failureCallback - Callback method on failure of registerGeoBoundary and refreshGeoBoundariesFailure
      */
     this.registerGeoBoundaries = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.perf("Executing registerGeoBoundaries");
         var tempKSID = currentObject.getKSID();
         var geoBoundaryOptions = {};
         if (!voltmx.sdk.isNullOrUndefined(options)) {
             if (!voltmx.sdk.isNullOrUndefined(options["radius"])) {
                 geoBoundaryOptions["radius"] = options["radius"];
             }
             if (!voltmx.sdk.isNullOrUndefined(options["pageSize"])) {
                 geoBoundaryOptions["pageSize"] = options["pageSize"];
             }
             if (!voltmx.sdk.isNullOrUndefined(options["tags"]) && options["tags"] instanceof Array) {
                 geoBoundaryOptions["tags"] = options["tags"];
             }
             if (!voltmx.sdk.isNullOrUndefined(options["customLogicCallback"]) && typeof(failureCallback) == voltmx.sdk.constants.FUNCTION_STRING) {
                 geoBoundaryOptions["customLogicCallback"] = options["customLogicCallback"];
             } else {
                 voltmx.sdk.logsdk.warn("MessagingService::registerGeoBoundaries customLogicCallback not provided by user");
             }
         }
         currentObject.geoBoundaryOptions = geoBoundaryOptions;
         VMXMessagingService.setGeoBoundariesOptions(geoBoundaryOptions);
         if (typeof(tempKSID) === 'undefined' || tempKSID === null) {
             voltmx.sdk.logsdk.perf("Executing finished registerGeoBoundaries with an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "KSID not available, Register and try again.");
         }
         if (!typeof(failureCallback) == voltmx.sdk.constants.FUNCTION_STRING) {
             voltmx.sdk.logsdk.perf("Executing finished registerGeoBoundaries with an exception");
             throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "failureCallback is not provided");
         } else {
             currentObject.refreshBoundariesFailureCallback = failureCallback;
         }
         voltmx.sdk.logsdk.perf("Executing getCurrentPosition");
         voltmx.location.getCurrentPosition(function(res) {
             voltmx.sdk.logsdk.perf("Executing finished getCurrentPosition's success");
             if (voltmx.sdk.getPlatformName() !== voltmx.sdk.constants.PLATFORM_WINDOWS) {
                 var accept = voltmx.notificationsettings.createAction({
                     "id": voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT,
                     "label": voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT,
                     "pspConfig": {
                         "activationMode": voltmx.notificationsettings.ACTIVATION_MODE_FORWARDS,
                         "authenticationRequired": true,
                         "destructive": false
                     }
                 });
                 var reject = voltmx.notificationsettings.createAction({
                     "id": "Reject",
                     "label": "Reject",
                     "pspConfig": {
                         "activationMode": voltmx.notificationsettings.ACTIVATION_MODE_BACKWARDS,
                         "authenticationRequired": false,
                         "destructive": false
                     }
                 });
                 var categoryObj = voltmx.notificationsettings.createCategory({
                     "categoryId": "geoBoundary",
                     "actions": [accept, reject],
                     "pspConfig": {
                         "minimalActions": [accept, reject]
                     }
                 });
                 var categoryArr = [categoryObj];
                 voltmx.notificationsettings.registerCategory({
                     "categories": categoryArr,
                     "pspConfig": {
                         "types": [0, 1, 2]
                     }
                 });
             }
             var currentLocation = res.coords;
             var authToken = null;
             authToken = currentObject.getAuthToken(options);
             updateGeoLocationForMessagingService(currentLocation.latitude, currentLocation.longitude, "fetchBoundaries", authToken, function(res) {
                 voltmx.sdk.logsdk.perf("Executing finished registerGeoBoundaries with success");
                 voltmx.sdk.logsdk.trace("MessagingService::registerGeoBoundaries updated current location, fetching geoBoundaries from server.");
                 getAndRefreshBoundaries(currentObject.geoBoundaryOptions, successCallback, failureCallback, options);
             }, function(err) {
                 voltmx.sdk.logsdk.perf("Executing finished registerGeoBoundaries with a failure");
                 voltmx.sdk.logsdk.error("MessagingService::registerGeoBoundaries Failed to update current location with KMS.");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getMessagingError("Failed to update current location with KMS"));
             });
         }, function(err) {
             voltmx.sdk.logsdk.perf("Executing finished getCurrentPosition's failure");
             voltmx.sdk.logsdk.perf("Executing finished registerGeoBoundaries with an exception");
             if (err.code === 1) {
                 throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Permission to access location is not enabled");
             } else if (err.code === 2) {
                 throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Enable location and try again");
             } else if (err.code === 3) {
                 voltmx.sdk.logsdk.error("MessagingService::registerGeoBoundaries Unable to retrieve current location.");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getMessagingError("Unable to retrieve current location"));
             } else if (err.code === 5) {
                 throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Permission to access location in background is denied.");
             } else if (err.code === 6) {
                 throw new Exception(voltmx.sdk.errorConstants.MESSAGING_FAILURE, "Permission to access location is denied with Don't Ask Again.");
             }
         }, {
             requireBackgroundAccess: true
         });
     }
 }
 /**
  * Method to create the Metrics service instance with the provided service name.
  * @returns {MetricsService} Metrics service instance
  */
 voltmx.sdk.prototype.getMetricsService = function() {
     if (!voltmx.sdk.isInitialized) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + " Metrics service.");
     }
     if (!voltmx.sdk.isLicenseUrlAvailable) {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "metrics is not enabled");
     }
     //var metricsServiceObject = null;
     if (this.metricsServiceObject) {
         return this.metricsServiceObject;
     }
     if (this.internalSdkObject) {
         //framework implementation
         this.metricsServiceObject = this.internalSdkObject.getMetricsService();
     } else {
         //sdk local implementation
         this.metricsServiceObject = new MetricsService(this);
     }
     return this.metricsServiceObject;
 };
 /**
  * Should not be called by the developer.
  * @class
  * @classdesc Metrics service instance for invoking the Metrics services.
  */
 function MetricsService(voltmxRef) {
     var url = voltmxRef.customReportingURL;
     if (typeof(url) === 'undefined') {
         throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "reporting url is undefined");
     }
     var networkProvider = new voltmxNetworkProvider();
     /**
      * invoke the getUserId operation
      */
     this.getUserId = function() {
         return voltmxRef.getUserId();
     };
     //start of event api
     var eventFlowTag = "";
     var eventBufferMaxValue = 1000;
     var eventBufferAutoFlushValue = 15;
     var characterLengthLimit = 256;
     var eventConfig = {
         "confType": "BUFFER",
         "eventBufferAutoFlushCount": eventBufferAutoFlushValue,
         "eventBufferMaxCount": eventBufferMaxValue
     };
     var reportEventBufferArray = [];
     var reportEventBufferBackupArray = [];
     var retrievedDS = false;
     var eventBufferCount = 0;
     var eventTypeMap = {
         "formentry": "FormEntry",
         "formexit": "FormExit",
         "touch": "Touch",
         "servicerequest": "ServiceRequest",
         "serviceresponse": "ServiceResponse",
         "gesture": "Gesture",
         "orientation": "Orientation",
         "error": "Error",
         "exception": "Exception",
         "crash": "Crash",
         "custom": "Custom",
         "servicecall": "ServiceCall",
         "apptransition": "AppTransition",
         "appload": "AppLoad",
         "component": "Component"
     };
     var errorCodeMap = {
         "1000": true,
         "1011": true,
         "1012": true,
         "1014": true,
         "1015": true,
         "1016": true
     };
     /**
      * This method will take the a String to set a Flow Tag for the reported events.
      * @param {string} flowTag - sets flow tag for reporting the events.
      */
     this.setFlowTag = function(flowTag) {
         if (voltmx.sdk.isNullOrUndefined(flowTag)) {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid value for event flow tag");
         } else if (flowTag.length <= characterLengthLimit) {
             eventFlowTag = flowTag;
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event flow tag is " + characterLengthLimit + " characters");
         }
     };
     /**
      * This method will clear the flow tag set by the user previously.
      */
     this.clearFlowTag = function() {
         eventFlowTag = "";
     };
     /**
      * This method will return the a String to set a Flow Tag for the reported events.
      * @return {string} flowTag - flow tag set by the user for reporting the events.
      */
     this.getFlowTag = function() {
         return eventFlowTag;
     };
     /**
      * This method will take the required values to set the event Configuration values.
      * @param {string} confType - sets the Current Configuration Type
      * 					possible values BUFFER or INSTANT.
      * @param {number} eventBufferAutoFlushCount - event buffer count to auto flush the events
      * 								possible values any positive integer
      * 								Default value 15
      * @param {number} eventBufferMaxCount - Maximum event buffer count to store the events
      * 								possible values any positive integer
      * 								Default value 1000
      */
     this.setEventConfig = function(confType, eventBufferAutoFlushCount, eventBufferMaxCount) {
         if (voltmx.sdk.isNullOrUndefined(confType)) {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Config Type can not be null");
         } else {
             confType = confType.toUpperCase();
         }
         if (confType === "BUFFER") {
             eventConfig["confType"] = confType;
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid value for config type");
         }
         if (!voltmx.sdk.isNullOrUndefined(eventBufferMaxCount) && typeof(eventBufferMaxCount) === "number" && eventBufferMaxCount > 0) {
             eventConfig["eventBufferMaxCount"] = eventBufferMaxCount;
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "eventBufferMaxCount has to be a Number and greater than 0");
         }
         if (!voltmx.sdk.isNullOrUndefined(eventBufferAutoFlushCount) && typeof(eventBufferAutoFlushCount) === "number" && eventBufferAutoFlushCount > 0 && eventBufferAutoFlushCount <= eventBufferMaxCount) {
             eventConfig["eventBufferAutoFlushCount"] = eventBufferAutoFlushCount;
         } else if (eventBufferAutoFlushCount >= eventBufferMaxCount) {
             eventConfig["eventBufferMaxCount"] = 1000;
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "eventBufferAutoFlushCount can not be greater than eventBufferMaxCount");
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "eventBufferAutoFlushCount has to be a Number and greater than 0");
         }
     };
     /**
      * This method takes the event details from the developer and schedule it for sending to server as per Configuration values set by the developer.
      * @param {string} evttype - Event Type for the reported event.
      * @param {string} evtSubType - string literal for eventSubType(max 256 Chars)
      * @param {string} formID -   string literal for formID(max 256 Chars)
      * @param {string} widgetID - string literal for widgetID(max 256 Chars)
      * @param {string} flowTag - string literal to override flow tag (max 256 Chars)
      * @param {string} metaData - string to describe metaData
      * @throws Exception
      */
     this.sendEvent = function(evttype, evtSubType, formID, widgetID, flowTag, metaData) {
         if (reportEventBufferBackupArray.length === 0) {
             this.readFromDS();
         }
         eventBufferCount = reportEventBufferBackupArray.length + reportEventBufferArray.length;
         if (eventBufferCount === eventConfig["eventBufferMaxCount"]) {
             voltmx.sdk.logsdk.warn("Reached maximum limit of '" + eventBufferCount + "' events in buffer, No more events will be stored");
             return;
         }
         var reportEventMap = {};
         reportEventMap.ts = voltmx.sdk.formatCurrentDate(new Date());
         evttype = evttype.toLowerCase();
         if (voltmx.sdk.isNullOrUndefined(eventTypeMap[evttype])) {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid value for event type");
         } else {
             reportEventMap["evttype"] = eventTypeMap[evttype];
         }
         if (voltmx.sdk.isNullOrUndefined(evtSubType)) {
             reportEventMap["evtSubType"] = "";
         } else if (evtSubType.length <= characterLengthLimit) {
             reportEventMap["evtSubType"] = evtSubType;
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event evtSubType is " + characterLengthLimit + " characters");
         }
         if (voltmx.sdk.isNullOrUndefined(formID)) {
             reportEventMap["formID"] = voltmx.application.getCurrentForm().id;
         } else if (formID.length <= characterLengthLimit) {
             reportEventMap["formID"] = formID;
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event formID is " + characterLengthLimit + " characters");
         }
         if (voltmx.sdk.isNullOrUndefined(widgetID)) {
             reportEventMap["widgetID"] = "";
         } else if (widgetID.length <= characterLengthLimit) {
             reportEventMap["widgetID"] = widgetID;
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event widgetID is " + characterLengthLimit + " characters");
         }
         if (voltmx.sdk.isNullOrUndefined(flowTag)) {
             reportEventMap["flowTag"] = this.getFlowTag();
         } else if (flowTag.length <= characterLengthLimit) {
             reportEventMap["flowTag"] = flowTag;
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Length exceeded, Maximum length of event flowTag is " + characterLengthLimit + " characters");
         }
         reportEventMap.SID = this.getSessionId();
         reportEventMap.metaData = metaData;
         //checking each event data is a proper json or not
         // 	throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid json string passed for events data");
         // }
         reportEventBufferArray.push(reportEventMap);
         if (reportEventBufferArray.length % eventConfig["eventBufferAutoFlushCount"] === 0 || evttype == eventTypeMap.crash) {
             this.flushEvents();
         }
     };
     /**
      * This method will send the buffered events to the server at once.
      */
     this.flushEvents = function() {
         var url = voltmx.sdk.currentInstance.customReportingURL;
         var ref = this;
         if (reportEventBufferBackupArray.length === 0) {
             ref.readFromDS();
         }
         if (reportEventBufferBackupArray.length === 0 && reportEventBufferArray.length === 0) {
             voltmx.sdk.logsdk.warn("There are no events to flush");
             return;
         }
         var payload = voltmx.sdk.getPayload(voltmx.sdk.getCurrentInstance());
         var params = {};
         if (reportEventBufferArray.length !== 0) {
             ref.pushEventsToBufferArray();
         }
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED_CHARSET_UTF8;
         payload.events = reportEventBufferBackupArray;
         payload.svcid = "SendEvents";
         payload.rsid = this.getSessionId();
         params[voltmx.sdk.constants.REPORTING_PARAMS] = JSON.stringify(payload);
         var options = {};
         options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
         networkProvider.post(url, params, headers, flushSuccessCallback, flushErrorCallback, null, options);

         function flushSuccessCallback(response) {
             if (response.opstatus == 0) {
                 ref.clearBufferEvents();
             } else if (errorCodeMap[response.opstatus]) {
                 ref.saveInDS();
             } else {
                 ref.clearBufferEvents();
             }
         }

         function flushErrorCallback(response) {
             voltmx.sdk.logsdk.error("Unable to flush events");
             voltmx.sdk.logsdk.info("Application Events: " + JSON.stringify(reportEventBufferBackupArray));
             ref.saveInDS();
         }
     };
     /*Stores event data in Data Store on failure of service Call*/
     this.saveInDS = function() {
         var eventsToSave = [];
         eventsToSave.push(JSON.stringify(reportEventBufferBackupArray));
         voltmx.ds.save(eventsToSave, "konyMetricsBuffer");
         reportEventBufferBackupArray = [];
     };
     /*Clearing events sent to server */
     this.clearBufferEvents = function() {
         reportEventBufferBackupArray = [];
         voltmx.ds.remove("konyMetricsBuffer");
     };
     /*Reading any pending events from Data Store */
     this.readFromDS = function() {
         var eventsFromDS = voltmx.ds.read("konyMetricsBuffer");
         if (eventsFromDS !== null) {
             var pushToArray = [];
             pushToArray.push(JSON.parse(eventsFromDS[0]));
             reportEventBufferBackupArray.push.apply(reportEventBufferBackupArray, pushToArray);
         }
     };
     /*Pushes events received from user to BufferBackupArray which will be flushed to server */
     this.pushEventsToBufferArray = function() {
         reportEventBufferBackupArray.push.apply(reportEventBufferBackupArray, reportEventBufferArray);
         reportEventBufferArray = [];
     };
     /**
      * This method will return the a List of the buffered events.
      * @return {object} events - list of events stored in buffer.
      */
     this.getEventsInBuffer = function() {
         var eventsFromDS = voltmx.ds.read("konyMetricsBuffer");
         var eventsToReturn = [];
         if (!voltmx.sdk.isNullOrUndefined(eventsFromDS)) {
             eventsToReturn.push(JSON.parse(eventsFromDS[0]));
         }
         if (reportEventBufferArray.length !== 0) {
             eventsToReturn.push.apply(eventsToReturn, reportEventBufferArray);
         }
         if (eventsToReturn.length !== 0) {
             return eventsToReturn;
         } else {
             return null;
         }
     };
     /**
      * invoke the sendCustomMetrics operation
      * @param {string} reportingGroupID - reporting Group ID
      * @param {object} metrics - metrics being reported
      */
     this.sendCustomMetrics = function(reportingGroupID, metrics) {
         if (typeof(metrics) !== "object") {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid type for metrics data.");
         }
         var reportData = voltmx.sdk.dataStore.getItem("konyCustomReportData");
         if (!reportData) {
             reportData = [];
         } else {
             reportData = JSON.parse(reportData);
         }
         voltmx.sdk.dataStore.removeItem("konyCustomReportData");
         var currentData = {};
         currentData.ts = voltmx.sdk.formatCurrentDate(new Date().toString());
         currentData.fid = reportingGroupID;
         currentData.metrics = metrics;
         currentData.rsid = this.getSessionId();
         reportData.push(currentData);
         //nyRef.getDataStore().setItem("konyCustomReportData",JSON.stringify(reportData));
         var payload = voltmx.sdk.getPayload(voltmxRef);
         if (voltmx.sdk.metric) {
             if (voltmx.sdk.metric.reportEventBufferBackupArray.length === 0) {
                 voltmx.sdk.metric.readFromDS();
             }
             voltmx.sdk.metric.pushEventsToBufferArray();
             payload.events = voltmx.sdk.metric.reportEventBufferBackupArray;
         }
         payload.reportData = reportData;
         payload.rsid = this.getSessionId();
         payload.svcid = "CaptureKonyCustomMetrics";
         var newData = {};
         newData[voltmx.sdk.constants.REPORTING_PARAMS] = JSON.stringify(payload);
         var options = {};
         options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
         var headers = {};
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED_CHARSET_UTF8;
         networkProvider.post(url, newData, headers, function(res) {
             //successcallback
             //voltmxRef.getDataStore().removeItem("konyCustomReportData");
             if (voltmx.sdk.metric) {
                 voltmx.sdk.metric.clearBufferEvents();
             }
             voltmx.sdk.logsdk.info("metric data successfully sent" + JSON.stringify(res));
         }, function(res) {
             var storeData = voltmx.sdk.dataStore.getItem("konyCustomReportData");
             if (!storeData) {
                 storeData = reportData;
             } else {
                 storeData = JSON.parse(storeData);
                 reportData.forEach(function(e) {
                     storeData.push(e);
                 });
             }
             if (voltmx.sdk.metric) {
                 if (voltmx.sdk.metric.errorCodeMap[res.opstatus]) {
                     voltmx.sdk.metric.saveInDS();
                 }
             }
             voltmx.sdk.dataStore.setItem("konyCustomReportData", JSON.stringify(storeData));
             voltmx.sdk.logsdk.error("Unable to send metric report" + JSON.stringify(res));
         }, null, options);
     };
     /**
      * This method takes the event details from the developer and schedule it for sending to server as per Configuration values set by the developer.
      * @param {string} errorCode - errorCode of the reported error. Can be empty if not applicable
      * @param {string} errorType -   errorType of the reported error. Can be empty if not applicable
      * @param {string} errorMessage - errorMessage of the reported error. Can be empty if not applicable
      * @param {json} errorDetails - errorDetails of the reported error as a json string that can have key-value pairs for the following
     				keys errfile, errmethod, errline, errstacktrace, formID, widgetID, flowTag.
      * @throws Exception
      */
     this.reportError = function(errorCode, errorType, errorMessage, errorDetails) {
         var metaData = {};
         metaData.errcode = errorCode ? errorCode : "";
         metaData.errmsg = errorMessage ? errorMessage : "";
         if (errorDetails && voltmx.sdk.isJson(errorDetails)) {
             errorDetails = JSON.parse(errorDetails);
             metaData.errfile = errorDetails.errfile ? errorDetails.errfile : "";
             metaData.errmethod = errorDetails.errmethod ? errorDetails.errmethod : "";
             metaData.errline = errorDetails.errline ? errorDetails.errline : "";
             metaData.errstacktrace = errorDetails.errstacktrace ? errorDetails.errstacktrace : "";
             metaData.errcustommsg = errorDetails.errcustommsg ? errorDetails.errcustommsg : "";
             var formID = errorDetails.formID ? errorDetails.formID : "";
             var widgetID = errorDetails.widgetID ? errorDetails.widgetID : "";
             var flowTag = errorDetails.flowTag ? errorDetails.flowTag : "";
             var evtSubType = errorType ? errorType : "";
             this.sendEvent("Error", evtSubType, formID, widgetID, flowTag, JSON.stringify(metaData));
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid json string passed for error details.");
         }
     };
     /**
      * This method takes the event details from the developer and schedule it for sending to server as per Configuration values set by the developer.
      * @param {string} exceptionCode - Code for the reported exception. Can be empty if not applicable
      * @param {string} exceptionType -   Type of the reported exception. Can be empty if not applicable
      * @param {string} exceptionMessage - Message of the reported exception. Can be empty if not applicable
      * @param {json}   exceptionDetails - Details of the reported exception as a JSON string that can have key-value pairs for the
     				following keys exceptioncode, exceptionfile, exceptionmethod, exceptionline,
     				exceptionstacktrace, formID, widgetID, flowTag.
      * @throws Exception
      */
     this.reportHandledException = function(exceptionCode, exceptionType, exceptionMessage, exceptionDetails) {
         var metaData = {};
         metaData.exceptioncode = exceptionCode ? exceptionCode : "";
         metaData.exceptionmsg = exceptionMessage ? exceptionMessage : "";
         if (exceptionDetails && voltmx.sdk.isJson(exceptionDetails)) {
             exceptionDetails = JSON.parse(exceptionDetails);
             metaData.exceptionfile = exceptionDetails.errfile ? exceptionDetails.errfile : "";
             metaData.exceptionmethod = exceptionDetails.errmethod ? exceptionDetails.errmethod : "";
             metaData.exceptionline = exceptionDetails.errline ? exceptionDetails.errline : "";
             metaData.exceptionstacktrace = exceptionDetails.errstacktrace ? exceptionDetails.errstacktrace : "";
             metaData.exceptioncustommsg = exceptionDetails.errcustommsg ? exceptionDetails.errcustommsg : "";
             var formID = exceptionDetails.formID ? exceptionDetails.formID : "";
             var widgetID = exceptionDetails.widgetID ? exceptionDetails.widgetID : "";
             var flowTag = exceptionDetails.flowTag ? exceptionDetails.flowTag : "";
             var evtSubType = exceptionType ? exceptionType : "";
             this.sendEvent("Exception", evtSubType, formID, widgetID, flowTag, JSON.stringify(metaData));
         } else {
             throw new Exception(voltmx.sdk.errorConstants.METRICS_FAILURE, "Invalid json string passed for exception details.");
         }
     };
     /**
      * sets the current sessionId
      * @param {string} sessionId
      */
     this.setSessionId = function(sessionId) {
         if (sessionId) {
             voltmx.sdk.currentInstance.setSessionId(sessionId);
         }
     };
     /**
      * get the current sessionID
      *
      */
     this.getSessionId = function() {
         return voltmx.sdk.currentInstance.getSessionId();
     };
     /**
      * stub method used for event tracking
      *
      */
     this.setEventTracking = function(eventTypes) {
         // Stub.  This is implemented in native->js binding
     }
 }
 voltmx.sdk.initiateSession = function() {};
 /**
  * Method which returns the offline enabled ObjectService object
  * @param voltmxRef
  * @param serviceName
  * @constructor
  */
 voltmx.sdk.OfflineEnabledObjectService = function(voltmxRef, serviceName) {
     this.serviceName = serviceName;
     this.voltmxRef = voltmxRef;
     /**
      * This method is used to fetch records on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject)}
      * @param successCallback
      * @param failureCallback
      */
     this.fetch = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineEnabledObjectService.fetch");
         if (!areOptionsValid(options, failureCallback)) {
             return;
         }
         try {
             var dataObject = options[voltmx.sdk.constants.ObjectServiceConstants.DATAOBJECT];
             var objectName = dataObject.getObjectName();

             function fetchHandler(objMetadata) {
                 var obj = new voltmx.sdk.VMXObj(objectName);
                 var readOptions = dataObject.getOfflineObjectsOptions();
                 /* If read options are not supplied, caller such as fetchDataForColumns model API would provide a select query object and some callers provide query params.
                  *  We parse the select query or queryParams to suite offline objects read API.
                  */
                 if (!readOptions || Object.keys(readOptions).length == 0) {
                     var selectQueryObject = dataObject.getSelectQueryObject();
                     var queryParams = options[voltmx.sdk.constants.ObjectServiceConstants.QUERYPARAMS];
                     if (selectQueryObject) {
                         readOptions.projectionColumns = [];
                         var columns = selectQueryObject.getColumns();
                         for (var column in columns) {
                             readOptions.projectionColumns.push(columns[column].getName());
                         }
                         var criteriaList = selectQueryObject.getCriterias();
                         var primaryKeys = {};
                         for (var criteria in criteriaList) {
                             var colObj = criteriaList[criteria].getColumn();
                             if (colObj) {
                                 primaryKeys[colObj.getName()] = criteriaList[criteria].getValue();
                             }
                         }
                         readOptions.primaryKeys = primaryKeys;
                     } else if (queryParams) {
                         var primaryKeys = {};
                         if (objMetadata.primaryKey != null && objMetadata.primaryKey != undefined) {
                             for (var indx = 0; indx < objMetadata.primaryKey.length; indx++) {
                                 var pKey = objMetadata.primaryKey[indx];
                                 var pKeyValue = queryParams[pKey];
                                 if (pKeyValue == null || pKeyValue == undefined || pKeyValue == "") {
                                     voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: fetch Error: Primarykey details missing so unable to fetch");
                                     voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                                     return;
                                 }
                                 primaryKeys[pKey] = pKeyValue;
                             }
                             readOptions.primaryKeys = primaryKeys;
                         } else {
                             voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: fetch Error: Primarykey details missing so unable to fetch");
                             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                             return;
                         }
                     }
                 }

                 function fetchSuccessHandler(res) {
                     var response = {};
                     response.records = res;
                     successCallback(response);
                 }
                 obj.get(readOptions, fetchSuccessHandler, failureCallback);
             }
             this.getMetadataOfObject(objectName, {}, fetchHandler, failureCallback);
         } catch (error) {
             voltmx.sdk.logsdk.error("Fetch on offline enabled object failed with error: " + error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
     };
     /**
      * This method is used to create a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject)}
      * @param successCallback
      * @param failureCallback
      */
     this.create = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineEnabledObjectService.create");
         if (!areOptionsValid(options, failureCallback)) {
             return;
         }
         try {
             var dataObject = options[voltmx.sdk.constants.ObjectServiceConstants.DATAOBJECT];
             var objectName = dataObject.getObjectName();
             var obj = new voltmx.sdk.VMXObj(objectName);
             var createOptions = dataObject.getOfflineObjectsOptions();
             var records = dataObject.getRecord();
             obj.create(records, createOptions, successCallback, failureCallback);
         } catch (error) {
             voltmx.sdk.logsdk.error("Create on offline enabled object failed with error: " + error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
     };
     /**
      * This method is used to update a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject)}
      * @param successCallback
      * @param failureCallback
      */
     this.update = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineEnabledObjectService.update");
         if (!areOptionsValid(options, failureCallback)) {
             return;
         }
         try {
             var dataObject = options[voltmx.sdk.constants.ObjectServiceConstants.DATAOBJECT];
             var objectName = dataObject.getObjectName();

             function updateHandler(objMetadata) {
                 var obj = new voltmx.sdk.VMXObj(objectName);
                 var updateOptions = dataObject.getOfflineObjectsOptions();
                 var records = dataObject.getRecord();
                 // If primary keys are not supplied through options, they are picked from the user supplied record.
                 if (!updateOptions || Object.keys(updateOptions).length == 0 || !updateOptions['primaryKeys']) {
                     if (records) {
                         var primaryKeys = {};
                         if (objMetadata.primaryKey != null && objMetadata.primaryKey != undefined) {
                             for (var indx = 0; indx < objMetadata.primaryKey.length; indx++) {
                                 var pKey = objMetadata.primaryKey[indx];
                                 var pKeyValue = records[pKey];
                                 if (pKeyValue == null || pKeyValue == undefined || pKeyValue == "") {
                                     voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: Update Error: Primarykey details missing so unable to update");
                                     voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                                     return;
                                 }
                                 primaryKeys[pKey] = pKeyValue;
                                 delete records[pKey];
                             }
                             updateOptions.primaryKeys = primaryKeys;
                         } else {
                             voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: Update Error: Primarykey details missing so unable to update");
                             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                             return;
                         }
                     } else {
                         voltmx.sdk.logsdk.error("Update Failed: primaryKeys key missing. Please use dataObject setOfflineObjectsOptions to set primaryKeys for update operation.");
                         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                         return;
                     }
                 }
                 obj.updateByPK(records, updateOptions, successCallback, failureCallback);
             }
             this.getMetadataOfObject(objectName, {}, updateHandler, failureCallback);
         } catch (error) {
             voltmx.sdk.logsdk.error("Update on offline enabled object failed with error: " + error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
     };
     /**
      * This method is used to delete a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject)}
      * @param successCallback
      * @param failureCallback
      */
     this.deleteRecord = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineEnabledObjectService.deleteRecord");
         if (!areOptionsValid(options, failureCallback)) {
             return;
         }
         try {
             var dataObject = options[voltmx.sdk.constants.ObjectServiceConstants.DATAOBJECT];
             var objectName = dataObject.getObjectName();

             function deleteHandler(objMetadata) {
                 var obj = new voltmx.sdk.VMXObj(objectName);
                 var deleteOptions = dataObject.getOfflineObjectsOptions();
                 // If primary keys are not supplied through options, they are picked from the user supplied record
                 if (!deleteOptions || Object.keys(deleteOptions).length == 0 || !deleteOptions['primaryKeys']) {
                     var records = dataObject.getRecord();
                     if (records) {
                         var primaryKeys = {};
                         if (objMetadata.primaryKey != null && objMetadata.primaryKey != undefined) {
                             for (var indx = 0; indx < objMetadata.primaryKey.length; indx++) {
                                 var pKey = objMetadata.primaryKey[indx];
                                 var pKeyValue = records[pKey];
                                 if (pKeyValue == null || pKeyValue == undefined || pKeyValue == "") {
                                     voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: Delete Error: Primarykey details missing so unable to delete");
                                     voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                                     return;
                                 }
                                 primaryKeys[pKey] = pKeyValue;
                             }
                             deleteOptions.primaryKeys = primaryKeys;
                         } else {
                             voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: Delete Error: Primarykey details missing so unable to delete");
                             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                             return;
                         }
                     } else {
                         voltmx.sdk.logsdk.error("Delete Failed: primaryKeys key missing. Please use dataObject setOfflineObjectsOptions to set primaryKeys for delte operation.");
                         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                         return;
                     }
                 }
                 obj.deleteByPK(deleteOptions, successCallback, failureCallback);
             }
             this.getMetadataOfObject(objectName, {}, deleteHandler, failureCallback);
         } catch (error) {
             voltmx.sdk.logsdk.error("Delete on offline enabled object failed with error: " + error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
     };
     /**
      * This method is used to retrieve metadata of all objects
      * @param options
      * @param successCallback
      * @param failureCallback
      */
     this.getMetadataOfAllObjects = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineEnabledObjectService.getMetadataOfAllObjects");
         _getMetadataForObjectsOrServiceOnlineUtil(voltmxRef, serviceName, null, options, successCallback, failureCallback);
         voltmx.sdk.logsdk.trace("EXiting voltmx.sdk.OfflineEnabledObjectService.getMetadataOfAllObjects");
     };
     /**
      * This method is used to retrive metadata of a specific object
      * @param objectName
      * @param options
      * @param successCallback
      * @param failureCallback
      */
     this.getMetadataOfObject = function(objectName, options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineEnabledObjectService.getMetadataOfObject");
         _getMetadataForObjectsOrServiceOnlineUtil(voltmxRef, serviceName, objectName, options, successCallback, failureCallback);
         voltmx.sdk.logsdk.trace("Exiting voltmx.sdk.OfflineEnabledObjectService.getMetadataOfObject");
     };
     /**
      * This method is used to validate options
      * @param options
      * @param failureCallback
      */
     function areOptionsValid(options, failureCallback) {
         if (options == null || options == undefined) {
             voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: Options Validity check: options null or undefined");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return false;
         }
         if (!(options[voltmx.sdk.constants.ObjectServiceConstants.DATAOBJECT] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: Options Validity check: invalid data object");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return false;
         }
         var dataObject = options[voltmx.sdk.constants.ObjectServiceConstants.DATAOBJECT];
         var objectName = dataObject.getObjectName();
         if (objectName == null || objectName == undefined) {
             voltmx.sdk.logsdk.error("### OfflineEnabledObjectService:: Options Validity check: objectname null or undefined");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "objectName" + voltmx.sdk.errormessages.null_or_undefined));
             return false;
         }
         return true;
     };
 };
 /**
  * Method which returns the offline ObjectService object
  * @param voltmxRef
  * @param serviceName
  * @constructor
  */
 voltmx.sdk.OfflineObjectService = function(voltmxRef, serviceName) {
     voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineObjectService");
     this.voltmxRef = voltmxRef;
     this.serviceName = serviceName;
     /**
      * This method is used to create a record on the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject)}
      * @param successCallback
      * @param failureCallback
      */
     this.create = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineObjectService.create");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         var dataObject = options["dataObject"];

         function createHandler(objMetadata) {
             _invokeOfflineCreate(dataObject, successCallback, failureCallback, options);
         }
         this.getMetadataOfObject(dataObject.getObjectName(), {}, createHandler, failureCallback);
     };
     /**
      * This method is used to fetch records from the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject)}
      * @param successCallback
      * @param failureCallback
      */
     this.fetch = function(options, successCallback, failureCallback) {
         throw "This method is not implemented.Instead use executeSelectQuery";
     };
     /**
      * This method is used to update a record in the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject)}
      * @param successCallback
      * @param failureCallback
      */
     this.update = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineObjectService.update");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         var dataObject = options["dataObject"];

         function updateHandler(objMetadata) {
             function updateSuccessCallback(response) {
                 voltmx.sdk.verifyAndCallClosure(successCallback, response);
             }

             function updateFailureCallback(error) {
                 if (error != null && error != undefined) {
                     //if the errorcode is equivalent to transaction failed then giving some generic error message to the client.
                     if (error["errorCode"] == 7010) {
                         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.transaction_failed, voltmx.sdk.errormessages.transaction_failed));
                         return;
                     }
                 }
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             }
             _invokeOfflineUpdate(dataObject, updateSuccessCallback, updateFailureCallback, options);
         }
         this.getMetadataOfObject(dataObject.getObjectName(), {}, updateHandler, failureCallback);
     };
     /**
      * This method is used to delete a record in the object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject)}
      * @param successCallback
      * @param failureCallback
      */
     this.deleteRecord = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineObjectService.deleteRecord");
         if (options == null || options == undefined) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         if (!(options["dataObject"] instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         var dataObject = options["dataObject"];

         function deleteHandler(objMetadata) {
             function deleteSuccessCallback(response) {
                 //verifying delete response contains deleted records count as 0
                 if (response != null && response != undefined) {
                     if (response["rowsdeleted"] == 0) {
                         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.norecords_to_delete, voltmx.sdk.errormessages.norecords_to_delete));
                         return;
                     }
                 }
                 voltmx.sdk.verifyAndCallClosure(successCallback, response);
             }

             function deleteFailureCallback(error) {
                 voltmx.sdk.verifyAndCallClosure(failureCallback, error);
             }
             _invokeOfflineDelete(dataObject, deleteSuccessCallback, deleteFailureCallback, options);
         }
         this.getMetadataOfObject(dataObject.getObjectName(), {}, deleteHandler, failureCallback);
     };
     /**
      * This method is used to retrieve metadata of all objects
      * @param options
      * @param successCallback
      * @param failureCallback
      */
     this.getMetadataOfAllObjects = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineObjectService.getMetadataOfAllObjects");
         _getMetadataForObjectsOrServiceOnlineUtil(voltmxRef, serviceName, null, options, successCallback, failureCallback);
         voltmx.sdk.logsdk.trace("Exiting voltmx.sdk.OfflineObjectService.getMetadataOfAllObjects");
     };
     /**
      * This method is used to retrive metadata of a specific object
      * @param objectName
      * @param options
      * @param successCallback
      * @param failureCallback
      */
     this.getMetadataOfObject = function(objectName, options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineObjectService.getMetadataOfObject");
         _getMetadataForObjectsOrServiceOnlineUtil(voltmxRef, serviceName, objectName, options, successCallback, failureCallback);
         voltmx.sdk.logsdk.trace("Exiting voltmx.sdk.OfflineObjectService.getMetadataOfObject");
     };
     /**
      * This method is used to execute an sql query
      * @param queryStr
      * @param successCallback
      * @param failureCallback
      */
     this.executeSelectQuery = function(queryStr, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineObjectService.executeSelectQuery");

         function selctSuccess(response) {
             voltmx.sdk.logsdk.debug("### OfflineObjectService::executeSelectQuery::selectSuccess Response:", response);
             voltmx.sdk.verifyAndCallClosure(successCallback, response);
         }

         function selectError(error) {
             voltmx.sdk.logsdk.error("### OfflineObjectService::executeSelectQuery::selectError Error:", error);
             voltmx.sdk.verifyAndCallClosure(failureCallback, error);
         }
         voltmx.sync.single_select_execute(voltmx.sdk.util.getSyncDbName(), queryStr, null, selctSuccess, selectError);
     };
     /**
      * Helps to get the binary content of the specified column on the Object
      * @param {map} options - includes {"dataObject":(@link voltmx.sdk.dto.DataObject), "responsetype":"base64string/filepath(Default)", "binaryAttrName":columnName}
      * @param successCallback
      * @param failureCallback
      */
     this.getBinaryContent = function(options, successCallback, failureCallback) {
         voltmx.sdk.logsdk.trace("Entering voltmx.sdk.OfflineObjectService.getBinaryContenttion");
         if (voltmx.sdk.isNullOrUndefined(options)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.null_or_undefined, "options" + voltmx.sdk.errormessages.null_or_undefined));
             return;
         }
         var dataObject = options["dataObject"];
         if (!(dataObject instanceof voltmx.sdk.dto.DataObject)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.invalid_dataobject_instance, voltmx.sdk.errormessages.invalid_dataobject_instance));
             return;
         }
         var binaryColName = options["binaryAttrName"];
         if (voltmx.sdk.isNullOrUndefined(binaryColName)) {
             voltmx.sdk.logsdk.error("### OfflineObjectService::getBinaryContent Error: Please provide column name to fetch binary content");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj("90000", "Please provide column name to fetch binary content"));
             return;
         }
         var getBase64 = options["responsetype"] === "base64string" ? true : false;
         var config = options["config"];

         function getBinaryDataHandler(objMetadata) {
             function selectSuccessCallback(response) {
                 voltmx.sdk.logsdk.debug("### OfflineObjectService::getBinaryContent::selectSuccessCallback Response", response);
                 var filePath = response["FilePath"];
                 if (getBase64) {
                     getBase64BasedOnFileType(filePath, successCallback, failureCallback);
                 } else {
                     //get filepath from response
                     voltmx.sdk.verifyAndCallClosure(successCallback, filePath);
                 }
             }

             function selectErrorCallback(error) {
                 voltmx.sdk.logsdk.error("### OfflineObjectService::getBinaryContent::selectErrorCallback Error:", error);
                 _invokeOfflineErrorCallback(failureCallback, error);
             }

             function getBase64BasedOnFileType(filePath, successCallback, failureCallback) {
                 var id = filePath.substring(filePath.lastIndexOf("/") + 1, filePath.length);
                 var query = "Select type from " + voltmx.sync.blobStoreManagerTable + " where id = " + id;
                 sync.executeSelectQuery(query, function(res) {
                     var base64String;
                     try {
                         if (res[0].type && res[0].type === voltmx.sync.blobTypeBase64) {
                             //get base64 from base64 file using SDK's FFI BlobStoreUtil
                             base64String = binary.util.getBase64FromFile(filePath);
                         } else {
                             //get base64 from binary file using FW APIs
                             var tempFile = new voltmx.io.File(filePath);
                             if (!voltmx.sdk.isNullOrUndefined(tempFile) && tempFile.exists() && tempFile.readable) {
                                 var tempRawBytes = tempFile.read();
                                 base64String = voltmx.convertToBase64(tempRawBytes);
                             } else {
                                 invokeFailureCallbackForGetBinaryContent(filePath, failureCallback);
                             }
                         }
                     } catch (ex) {
                         invokeFailureCallbackForGetBinaryContent(JSON.stringify(ex), failureCallback);
                     }
                     voltmx.sdk.verifyAndCallClosure(successCallback, base64String);
                 }, function(err) {
                     invokeFailureCallbackForGetBinaryContent(JSON.stringify(err), failureCallback);
                 });
             }

             function invokeFailureCallbackForGetBinaryContent(msg, failureCallback) {
                 voltmx.sdk.logsdk.error("Error in creating base64 string from local file : ", msg);
                 var errorCode = voltmx.sdk.errorcodes.invalid_blob;
                 var errorMessage = voltmx.sdk.errormessages.invalid_blob;
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(errorCode, errorMessage));
             }
             var dbName = voltmx.sdk.util.getSyncDbName();
             var objName = dataObject.getObjectName();
             var columnValues = voltmx.sdk.util.populateColumnValues(dataObject.getRecord(), null);
             var colMeta = voltmx.sdk.util.getMetadataOfColumn(objMetadata, binaryColName);
             if (voltmx.sdk.isNullOrUndefined(colMeta)) {
                 voltmx.sdk.logsdk.warn("### OfflineObjectService::getBinaryContent Error: Invalid binary attribute name.");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj("90000", "Invalid binary attribute name."));
                 return;
             }
             if (colMeta["datatype"] !== voltmx.sdk.constants.BINARY_DATATYPE) {
                 voltmx.sdk.logsdk.warn("### OfflineObjectService::getBinaryContent Error: Datatype is not binary for the specified binary attribute name");
                 voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj("90000", "Datatype is not binary for the specified binary attribute name"));
                 return;
             }
             var pkTable = voltmx.sdk.util.getPkTableForBinary(objMetadata, columnValues, failureCallback);
             voltmx.sync.getBinary(dbName, objName, binaryColName, pkTable, config, selectSuccessCallback, selectErrorCallback);
         }
         this.getMetadataOfObject(dataObject.getObjectName(), {}, getBinaryDataHandler, failureCallback);
     };

     function _invokeOfflineErrorCallback(failureCallback, errorObject) {
         //call the failureCallback after adding opstatus to the errorObject.
         var errorCode, errorMessage;
         if (errorObject) {
             errorCode = (errorObject.hasOwnProperty("errorCode")) ? errorObject["errorCode"] : voltmx.sdk.errorcodes.transaction_failed;
             errorMessage = (errorObject.hasOwnProperty("errorMessage")) ? errorObject["errorMessage"] : voltmx.sdk.errormessages.transaction_failed;
         } else {
             errorCode = voltmx.sdk.errorcodes.transaction_failed;
             errorMessage = voltmx.sdk.errormessages.transaction_failed;
         }
         voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(errorCode, errorMessage));
     }

     function _invokeOfflineCreate(dataObject, successCallback, failureCallback, options) {
         var dbname = voltmx.sdk.util.getSyncDbName();
         voltmx.sync.single_insert_execute(dbname, dataObject.getObjectName(), dataObject.getRecord(), successCallback, function(err) {
             _invokeOfflineErrorCallback(failureCallback, err);
         }, true, options);
     }

     function _invokeOfflineUpdate(dataObject, successCallback, failureCallback, options) {
         var objectName = dataObject.getObjectName();
         var columnValues = dataObject.getRecord();
         var objMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, objectName);
         var pkTable = {};
         var whereClause = [];
         if (objMetadata.primaryKey != null && objMetadata.primaryKey != undefined) {
             for (var indx = 0; indx < objMetadata.primaryKey.length; indx++) {
                 var pKey = objMetadata.primaryKey[indx];
                 var pKeyValue = columnValues[pKey];
                 if (pKeyValue == null || pKeyValue == undefined || pKeyValue == "") {
                     //TODO change to error object
                     voltmx.sdk.logsdk.error("### OfflineObjectService::_invokeOfflineUpdate Error: Primarykey details missing so unable to update");
                     voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                     return;
                 }
                 pkTable.pKey = {
                     "key": pKey,
                     "value": pKeyValue
                 };
                 var condition = {};
                 condition.key = pKey;
                 condition.value = pKeyValue;
                 whereClause.push(condition);
             }
         } else {
             //TODO change to error object
             voltmx.sdk.logsdk.error("### OfflineObjectService::_invokeOfflineUpdate Error: Primarykey details missing so unable to update");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
             return;
         }
         var dbName = voltmx.sdk.util.getSyncDbName();
         voltmx.sync.single_update_execute(dbName, objectName, columnValues, whereClause, successCallback, function(err) {
             _invokeOfflineErrorCallback(failureCallback, err);
         }, false, true, null, options);
     }

     function _invokeOfflineDelete(dataObject, successCallback, failureCallback, options) {
         var isError = false;
         var markForUpload = false;
         var tbname = dataObject.getObjectName();
         var errMsg = null;
         var wcs = [];
         var objMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, dataObject.getObjectName());
         var dbName = voltmx.sdk.util.getSyncDbName();
         var srcAttributes = voltmx.sdk.util.getPrimarykeysFromMetadata(objMetadata);
         if (srcAttributes != null && srcAttributes != undefined) {
             var pkLen = Object.keys(srcAttributes).length;
             for (var indx = 0; indx < pkLen; indx++) {
                 var pKey = Object.keys(srcAttributes)[indx];
                 var pKeyValue = dataObject.getRecord()[pKey];
                 if (pKeyValue == null || pKeyValue == undefined || pKeyValue == "") {
                     //TODO
                     //throw error
                     voltmx.sdk.logsdk.error("### _invokeOfflineDelete:: Error Primarykey details missing so unable to delete");
                     voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
                     return;
                 }
                 var whereClause = {};
                 whereClause.key = pKey;
                 whereClause.value = pKeyValue;
                 voltmx.table.insert(wcs, whereClause);
             }
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### _invokeOfflineDelete:: Error Primarykey details missing so unable to delete");
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.primarykey_unavailable, voltmx.sdk.errormessages.primarykey_unavailable));
             return;
         }
         voltmx.sync.single_delete_execute(dbName, tbname, wcs, successCallback, function(err) {
             _invokeOfflineErrorCallback(failureCallback, err);
         }, false, false, true, options);
     }
 };
 //Utils specific to MVVM/MDA/MVC SDK
 // This function is responsible for checking if the array contains the object based on object's name property.
 // returns the array element if the object matches
 voltmx.sdk.util.getExtendedFieldsFromArray = function(array, object) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.getExtendedFieldsFromArray");
     if (array instanceof Array) {
         for (var i = 0; i < array.length; i++) {
             if (array[i] instanceof voltmx.sdk.dto.FieldMetadata && object instanceof voltmx.sdk.dto.Column) {
                 if (voltmx.sdk.util.matchIgnoreCase(array[i].name, object.getName()) && voltmx.sdk.util.matchIgnoreCase(array[i].type, "extendedfield")) {
                     return array[i];
                 }
             }
         }
         return null;
     }
 };
 /**
  * This Object represent picklist values
  * @constructor
  */
 voltmx.sdk.dto.PickList = function() {
         voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.PickList");
         this.id = null;
         this.active = null;
         this.label = null;
         this.value = null;
         this.validFor = null;
         this.defaultValue = null;
         this.fieldMappingId = null;
         this.setId = function(id) {
             this.id = id;
         }
         this.getId = function() {
             return this.id;
         }
         this.setActive = function(active) {
             this.active = active;
         }
         this.isActive = function() {
             return this.active;
         }
         this.setLabel = function(label) {
             this.label = label;
         }
         this.getLabel = function() {
             return this.label;
         }
         this.setValue = function(value) {
             this.value = value;
         }
         this.getValue = function() {
             return this.value;
         }
         this.setValidFor = function(validFor) {
             this.validFor = validFor;
         }
         this.getValidFor = function() {
             return this.validFor;
         }
         this.setDefaultValue = function(defaultValue) {
             this.defaultValue = defaultValue;
         }
         this.getDefaultValue = function() {
             return this.defaultValue;
         }
         this.setFieldMappingId = function(fieldMappingId) {
             this.fieldMappingId = fieldMappingId;
         }
         this.getFieldMappingId = function() {
             return this.fieldMappingId;
         }
     }
     /**
      * The structure of Object Metadata obtained from server
      * @constructor
      */
 voltmx.sdk.dto.ObjectMetadata = function() {
         //variables to store metadata of the object.
         this.custom;
         this.customizable;
         this.displayName;
         this.entityTypeID;
         this.columns;
         this.junction;
         this.name;
         this.primaryKey;
         this.relationshipList;
         this.sourceEntityName;
         this.updateable;
         this.uniqueKeys;
     }
     /**
      * The structure of Field Metadata obtained from server
      * @constructor
      */
 voltmx.sdk.dto.FieldMetadata = function() {
         this.auditColumn;
         this.createable;
         this.custom;
         this.customizable;
         this.type;
         this.defaultValue;
         this.displayName;
         this.fieldMappingId;
         this.hasIndex;
         this.name;
         this.nameField;
         this.nullable;
         this.primaryKey;
         this.sourceFieldName;
         this.table;
         this.updateable;
         // array of picklistValueDto objects to hold the pick list values. This will be populated only when the data type is of picklist type
         this.pickListValues;
     }
     /**
      * The structure of Object Relationship in metadata obtained from server
      * @constructor
      */
 voltmx.sdk.dto.ObjectRelationship = function() {
         this.entityName;
         this.entityPageTemplateId;
         this.id;
         this.junctionTableName;
         this.operationType;
         this.relatedEntity;
         this.relationshipFields;
         this.relationshipName;
         this.relationshipType;
         this.custom;
     }
     /**
      * The Object used to define select query object, in order to fetch data
      * @param serviceName
      * @param tableObj {@link voltmx.sdk.dto.Table}
      * @constructor
      */
 voltmx.sdk.dto.SelectQuery = function(serviceName, tableObj) {
     this.tables = [];
     this.columnList = [];
     this.criteriaList = [];
     this.isDistinct = false;
     this.orderList = [];
     this.joinList = [];
     this.groupList = [];
     this.limit = null;
     this.skip = null;
     this.oDataURL = null;
     if (tableObj instanceof voltmx.sdk.dto.Table) {
         this.tables.push(tableObj);
     }
     /**
      * This function is used to set Limit value
      * @param val
      */
     this.setLimit = function(val) {
         this.limit = val;
     };
     /**
      * This function is used to set Skip value
      * @param val
      */
     this.setSkip = function(val) {
         this.skip = val;
     };
     /**
      * This function is used to get the Limit Value
      * @returns {integer} limit
      */
     this.getLimit = function() {
         return this.limit;
     };
     /**
      * This function is used to get the Skip Value
      * @returns {integer} skip
      */
     this.getSkip = function() {
         return this.skip;
     };
     /**
      * This function is used to add a column object into the select query
      * @param columnObj {@Link voltmx.sdk.dto.Column}
      * @returns {Array}
      */
     this.addColumn = function(columnObj) {
         if (columnObj instanceof voltmx.sdk.dto.Column) {
             this.columnList.push(columnObj);
             return this.columnList;
         }
     };
     /**
      * This function is used to add a criteria object to the select query
      * @param criteriaObj
      * @returns {Array}
      */
     this.addCriteria = function(criteriaObj) {
         if (voltmx.sdk.util.validateCriteriaObject(criteriaObj)) {
             this.criteriaList.push(criteriaObj);
             return this.criteriaList;
         }
     };
     /**
      * This function is used to add a group object to select query
      * @param groupObj
      */
     this.addGroup = function(groupObj) {
         if (groupObj instanceof voltmx.sdk.dto.Group) {
             this.groupList.push(groupObj);
             for (var i = 0; i < this.tables.length; i++) {
                 if (this.tables[i].getName().toUpperCase() === groupObj.getColumn().getTable().getName().toUpperCase()) {
                     return;
                 }
             }
             this.tables.push(groupObj.getColumn().getTable());
         }
     };
     /**
      * This function is used to add a join object
      * @param joinObj
      */
     this.addJoin = function(joinObj) {
         if (joinObj instanceof voltmx.sdk.dto.Join) {
             this.joinList.push(joinObj);
             for (var i = 0; i < this.tables.length; i++) {
                 if (this.tables[i].getName().toUpperCase() === joinObj.getTable().getName().toUpperCase()) {
                     if (this.tables[i].getAlias() != null || joinObj.getTable().getAlias() != null || this.tables[i].getAlias() != undefined || joinObj.getTable().getAlias() != undefined) {
                         if (this.tables[i].getAlias().toUpperCase() === joinObj.getTable().getAlias().toUpperCase()) {
                             return;
                         } else {
                             this.tables.push(joinObj.getTable());
                             return;
                         }
                     } else {
                         return;
                     }
                 }
             }
             this.tables.push(joinObj.getTable());
         }
     };
     /**
      * This function is used to add order object to a select query
      * @param orderObj
      */
     this.addOrder = function(orderObj) {
         var currentobject = this;
         if (orderObj instanceof voltmx.sdk.dto.Order) {
             this.orderList.push(arguments[0]);
             for (var i = 0; i < this.tables.length; i++) {
                 if (this.tables[i].getName().toUpperCase() === arguments[0].getColumn().getTable().getName().toUpperCase()) {
                     return;
                 }
             }
             this.tables.push(orderObj.getColumn().getTable());
         }
     };
     /**
      * This function is used to return tables in select query
      * @returns {Array} Tables
      */
     this.getTables = function() {
         return this.tables;
     };
     /**
      * This function is used to get isDistinct flag
      * @returns {boolean}
      */
     this.getDistinct = function() {
         return this.isDistinct;
     };
     /**
      * This function is used to return columns in select query
      * @returns {Array} Columns
      */
     this.getColumns = function() {
         return this.columnList;
     };
     /**
      * This function is used to get criteria objects in the select query
      * @returns {Array} Criterias
      */
     this.getCriterias = function() {
         return this.criteriaList;
     };
     /**
      * This function is used to get the group objects in the select query
      * @returns {Array} GroupObjs
      */
     this.getGroups = function() {
         return this.groupList;
     };
     /**
      * This function is used to get the Join objects in the select query
      * @returns {Array} Joins
      */
     this.getJoins = function() {
         return this.joinList;
     };
     /**
      * This function is used to get the Order Objects in the select query
      * @returns {Array} OrderObjs
      */
     this.getOrders = function() {
         return this.orderList;
     };
     /**
      * This function is used to remove columnobject set in select query
      * @param columnObj {@link voltmx.sdk.dto.Column}
      */
     this.removeColumn = function(columnObj) {
         if (columnObj instanceof voltmx.sdk.dto.Column) {
             this.columnList.splice(this.columnList.indexOf(columnObj), 1);
         }
     };
     /**
      * This function is used to remove criteriaObject from select query
      * @param criteriaObj
      */
     this.removeCriteria = function(criteriaObj) {
         if (criteriaObj instanceof Criteria) {
             this.criteriaList.splice(this.criteriaList.indexOf(criteriaObj), 1);
         }
     };
     /**
      * This function is used to remove group set from select query
      * @param groupObj
      */
     this.removeGroup = function(groupObj) {
         if (groupObj instanceof voltmx.sdk.dto.Group) {
             this.groupList.splice(this.groupList.indexOf(groupObj), 1);
         }
     };
     /**
      * This function is used to remove Join set in select query
      * @param joinObj
      */
     this.removeJoin = function(joinObj) {
         if (joinObj instanceof voltmx.sdk.dto.Criteria) {
             this.joinList.splice(this.joinList.indexOf(joinObj), 1);
         }
     };
     /**
      * This function is used to remove OrderObj set in SelectQuery
      * @param orderObj
      */
     this.removeOrder = function(orderObj) {
         if (orderObj instanceof voltmx.sdk.dto.Order) {
             this.orderList.splice(this.orderList.indexOf(orderObj), 1);
         }
     };
     /**
      * This function is used to set isDistinct
      * @param isDistinct
      */
     this.setDistinct = function(isDistinct) {
         this.isDistinct = isDistinct;
     };
     /**
      * This function is used to get the select query in the form of a string
      * @returns {string}
      */
     this.toString = function() {
         var selectQueryDto = this;
         var query = "";
         query = query + "SELECT ";
         if (this.getDistinct() == true || this.getDistinct() == "true") {
             query = query + " DISTINCT ";
         }
         // Fetch the metadata for the base table and see if there are any extended fields associated with it
         // If there are any, create a join between the base table and the corresponding parent table and fetch it
         var columns = this.columnList;
         var extendedFields = [];
         var columnsArr = [];
         var extendedJoins = [];
         var baseTable = this.getTables()[0];
         var objectMetadata = voltmx.sdk.ObjectServiceUtil.getCachedObjectMetadata(serviceName, baseTable.getName());
         if (columns.length !== 0) {
             var field = null;
             for (var colIndex = 0; colIndex < columns.length; colIndex++) {
                 field = voltmx.sdk.util.getExtendedFieldsFromArray(objectMetadata.columns, columns[colIndex]);
                 if (field !== null && field !== undefined) {
                     selectQueryDto.columnList[colIndex].dataType = field.type;
                     selectQueryDto.columnList[colIndex].parentFieldName = field.parentFieldName;
                     extendedFields.push(field);
                     field = null;
                 } else {
                     columnsArr.push(columns[colIndex]);
                 }
             }
         } else {
             var col = null;
             var field = null;
             for (var colIndex = 0; colIndex < objectMetadata.columns.length; colIndex++) {
                 field = objectMetadata.columns[colIndex];
                 col = new voltmx.sdk.dto.Column(baseTable, field.name);
                 col.dataType = field.type;
                 col.parentFieldName = field.parentFieldName;
                 selectQueryDto.columnList.push(col);
                 if (field !== null && field !== undefined && voltmx.sdk.util.matchIgnoreCase(field.type, "extendedfield")) {
                     extendedFields.push(field);
                     field = null;
                 } else {
                     columnsArr.push(columns[colIndex]);
                 }
             }
         }
         var columnStr = selectQueryDto.appendListToQuery(columnsArr, ", ", 0);
         if (columnStr !== null && columnStr !== "") {
             query = query + columnStr;
         }
         //TODO have to modify the code based on latest metadata
         if (extendedFields !== null && extendedFields !== undefined && extendedFields.length !== 0) {
             var join = null;
             var table = null;
             var srcCol = null;
             var destCol = null;
             var joinType = voltmx.sdk.constants.JoinType.LEFT;
             var col = null;
             var colList = [];
             var extendedTablesAdded = {};
             for (var extIndex = 0; extIndex < extendedFields.length; extIndex++) {
                 if (extendedTablesAdded !== null && extendedTablesAdded.hasOwnProperty(extendedFields[extIndex].parentTableName)) {
                     extendedTablesAdded["" + extendedFields[extIndex].parentTableName] = ++extendedTablesAdded["" + extendedFields[extIndex].parentTableName];
                 } else {
                     extendedTablesAdded["" + extendedFields[extIndex].parentTableName] = 0;
                 }
                 table = new voltmx.sdk.dto.Table(extendedFields[extIndex].parentTableName);
                 // Now add all extended field columns to the query
                 col = new voltmx.sdk.dto.Column(table, extendedFields[extIndex].parentFieldName);
                 colList.push(col);
                 // Need to fetch the source table's primary key name from the metadata. For now hard coding it to 'id'
                 //TODO
                 srcCol = new voltmx.sdk.dto.Column(baseTable, extendedFields[extIndex].foreignKeyFieldName);
                 destCol = new voltmx.sdk.dto.Column(table, extendedFields[extIndex].referencedField || "id");
                 join = new voltmx.sdk.dto.Join(table, srcCol, destCol, joinType);
                 if (join !== null && join !== undefined && extendedTablesAdded["" + extendedFields[extIndex].parentTableName] === 0) {
                     extendedJoins.push(join);
                 }
             }
             var extColStr = "";
             for (var i = 0; i < colList.length; i++) {
                 extColStr = extColStr + colList[i].toString();
                 if (i < colList.length - 1) {
                     extColStr = extColStr + ",";
                 }
             }
             if (extColStr !== null && extColStr !== "") {
                 query = query + "," + extColStr;
             }
             if (extendedJoins !== null && extendedJoins !== undefined) {
                 for (var joinIndex = 0; joinIndex < extendedJoins.length; joinIndex++) {
                     selectQueryDto.addJoin(extendedJoins[joinIndex]);
                 }
             }
         }
         query = query + " FROM ";
         query = query + selectQueryDto.getTables()[0].toString();
         if (selectQueryDto.getJoins().length !== 0) {
             var joinStr = selectQueryDto.appendListToQuery(selectQueryDto.joinList, " ", -1);
             query = query + joinStr;
         }
         if (!(selectQueryDto.criteriaList.length == 0)) {
             query = query + " WHERE ";
             query = query + selectQueryDto.appendListToQuery(selectQueryDto.criteriaList, " AND ", -1);
         }
         if (!(selectQueryDto.groupList.length == 0)) {
             query = query + " GROUP BY ";
             query = query + selectQueryDto.appendListToQuery(selectQueryDto.groupList, ", ", -1);
         }
         if (!(selectQueryDto.orderList.length == 0)) {
             query = query + " ORDER BY ";
             query = query + selectQueryDto.appendListToQuery(selectQueryDto.orderList, " ,", -1);
         }
         if (selectQueryDto.limit !== null && selectQueryDto.limit !== undefined && voltmx.sdk.util.isValidNumberType(selectQueryDto.limit) && selectQueryDto.limit !== 0) {
             query = query + " LIMIT " + selectQueryDto.limit;
         }
         if (selectQueryDto.skip !== null && selectQueryDto.skip !== undefined && voltmx.sdk.util.isValidNumberType(selectQueryDto.skip) && selectQueryDto.skip !== 0) {
             query = query + " OFFSET " + selectQueryDto.skip;
         }
         return query;
     };
     this.appendListToQuery = function(objectList, seperator, mode) {
         voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.appendListToQuery");
         var listBuffer = "";
         for (var i = 0; i < objectList.length; i++) {
             var obj = objectList[i];
             if (mode > -1) {
                 if (obj !== null) {
                     if (obj instanceof voltmx.sdk.dto.Column) {
                         listBuffer = listBuffer.concat(obj.toString());
                     } else {
                         listBuffer = listBuffer.concat(obj.toString());
                     }
                 }
             } else if (obj !== null && obj !== undefined) {
                 listBuffer = listBuffer.concat(obj.toString());
             }
             if (i < objectList.length - 1) {
                 listBuffer = listBuffer.concat(seperator);
             }
         }
         return listBuffer;
     };
 };
 /**
  * This function is the Table constructor.
  * @param tableName
  * @param tableAlias
  * @param junctionType
  * @constructor
  */
 voltmx.sdk.dto.Table = function(tableName, tableAlias, junctionType) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Table");
     this.name = tableName;
     this.alias = tableAlias;
     this.isjunction = junctionType;
     this.getAlias = function() {
         return this.alias;
     };
     /**
      * This function is used to set alias.
      *
      * @param alias
      */
     this.setAlias = function(alias) {
         this.alias = alias;
     };
     this.getName = function() {
         return this.name;
     };
     /**
      * This function is used to set name.
      *
      * @param name
      */
     this.setName = function(name) {
         this.name = name;
     };
     /**
      * This function is used to check object equality.
      *
      * @param obj
      * @return Boolean
      */
     this.equals = function(obj) {
         var areObjectsEqual = false;
         if (obj === null || obj === undefined) {
             areObjectsEqual = false;
         } else if (typeof(this) === typeof(obj)) {
             areObjectsEqual = true;
             if (this.hasAlias() && obj.hasAlias()) {
                 areObjectsEqual = this.getAlias() === obj.getAlias();
             } else {
                 areObjectsEqual = this.getName() === obj.getName();
             }
         } else {
             areObjectsEqual = false;
         }
         return areObjectsEqual;
     };
     this.getColumn = function(columnName) {
         return new voltmx.sdk.dto.Column(this, columnName);
     };
     /**
      * This function is used to check if alias is present or not.
      *
      * @return Boolean
      */
     this.hasAlias = function() {
         return (this.alias !== null && this.alias !== undefined);
     };
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         return this.getName() + (this.hasAlias() ? " " + this.getAlias() : "");
     };
     /**
      * This function is used to return if the table is a junction table.
      *
      * @return boolean
      */
     this.isJunction = function() {
         return (this.isjunction && this.isjunction == true);
     };
     /**
      * This function is used to set the type of table junction/non-junction table.
      *
      * @param junctionType
      */
     this.setJunction = function(junctionType) {
         this.isjunction = junctionType;
     };
 };
 /**
  * This function is a Column constructor
  * @param tableObj {@link voltmx.sdk.dto.Table}
  * @param colName
  * @constructor
  */
 voltmx.sdk.dto.Column = function(tableObj, colName) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Column");
     if (tableObj instanceof voltmx.sdk.dto.Table) {
         this.aggregation = null;
         this.alias = null;
         this.dataType = null;
         this.name = null;
         this.table = null;
         if (colName !== undefined && colName !== null && typeof(colName) === "string") {
             this.name = colName;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Column:: Error: colName is undefined");
         }
         this.table = tableObj;
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Column:: Error: tableObj is not an instance of voltmx.sdk.dto.Table");
     }
     this.getAggregation = function() {
         return this.aggregation;
     };
     this.setAggregation = function(aggregation) {
         this.aggregation = aggregation;
     };
     this.getAlias = function() {
         return this.alias;
     };
     this.setAlias = function(alias) {
         this.alias = alias;
     };
     this.getDataType = function() {
         return this.dataType;
     };
     this.setDataType = function(dataType) {
         this.dataType = dataType;
     };
     this.isComputedField = function() {
         return this.fieldComputed;
     };
     this.setComputedField = function(fieldComputed) {
         this.fieldComputed = fieldComputed;
     };
     this.getName = function() {
         return this.name;
     };
     this.setName = function(name) {
         if (name !== undefined && name !== null && typeof(name) === "string") {
             this.name = name;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Column::setName:: Error: name is undefined");
         }
     };
     this.getTable = function() {
         return this.table;
     };
     this.setTable = function(table) {
         if (table instanceof voltmx.sdk.dto.Table) {
             this.table = table;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Column:: Error: setTable is undefined");
         }
     };
     this.toStringByMode = function(mode) {
         var tableName = (this.getTable().getAlias() !== null && this.getTable().getAlias() !== undefined) ? this.getTable().getAlias() : this.getTable().getName();
         var constructedColumn = null;
         var constructDataType = null;
         var constructAlias = null;
         var constructAggregation = null;
         switch (mode) {
             case 0:
                 if (this.getDataType() !== null && this.getDataType() !== undefined) {
                     if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "Integer")) {
                         constructDataType = "CAST (" + tableName + "." + this.getName() + " AS INTEGER)";
                     } else if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "Numeric")) {
                         constructDataType = "CAST (" + tableName + "." + this.getName() + " AS NUMERIC)";
                     } else if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "Date")) {
                         constructDataType = "date(" + tableName + "." + this.getName() + ")";
                     } else {
                         constructDataType = tableName + "." + this.getName();
                     }
                 } else {
                     constructDataType = tableName + "." + this.getName();
                 }
                 constructAlias = (this.getAlias() !== null && this.getAlias() !== undefined && this.getAlias() !== "") ? " AS " + this.getAlias() : "";
                 constructAggregation = (this.getAggregation() === voltmx.sdk.constants.Aggregation.NONE || (this.getAggregation() === null || this.getAggregation() === undefined)) ? constructDataType : (this.isComputedField() ? this.getAggregation() : this.getAggregation() + "(" + constructDataType + ")");
                 constructedColumn = constructAggregation + constructAlias;
                 break;
             case 1:
                 if (this.getDataType() !== null && this.getDataType() !== undefined) {
                     if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "STRING")) this.setDataType("text");
                 }
                 constructDataType = (this.getDataType() !== null && this.getDataType() !== undefined) ? "CAST (" + tableName + "." + this.getName() + " AS " + this.getDataType() + ")" : tableName + "." + this.getName();
                 constructAggregation = (this.getAggregation() === voltmx.sdk.constants.Aggregation.NONE || (this.getAggregation() === null || this.getAggregation() === undefined)) ? constructDataType : (this.isComputedField() ? this.getAggregation() : this.getAggregation() + "(" + constructDataType + ")");
                 constructedColumn = constructAggregation;
                 break;
             case 2:
                 constructedColumn = this.getName();
                 break;
             case 3:
                 constructedColumn = this.getName();
                 break;
             default:
                 if (this.getDataType() !== null && this.getDataType() !== undefined) {
                     if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "STRING")) this.setDataType("text");
                 }
                 constructDataType = (this.getDataType() !== null && this.getDataType() !== undefined) ? "CAST (" + tableName + "." + this.getName() + " AS " + this.getDataType() + ")" : tableName + "." + this.getName();
                 constructAlias = (this.getAlias() !== null && this.getAlias() !== undefined) ? " AS " + this.getAlias() : "";
                 constructAggregation = (this.getAggregation() === voltmx.sdk.constants.Aggregation.NONE || (this.getAggregation() === null || this.getAggregation() === undefined)) ? constructDataType : (this.isComputedField() ? this.getAggregation() : this.getAggregation() + "(" + constructDataType + ")");
                 constructedColumn = constructAggregation + constructAlias;
                 break;
         }
         return constructedColumn;
     };
     this.toString = function() {
         // To be removed later from here
         if (this.getDataType() !== null && this.getDataType() !== undefined) {
             if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "STRING")) dataType = "text";
         }
         var tableName = (this.getTable().getAlias() !== null && this.getTable().getAlias() !== undefined && this.getTable().getAlias() !== "") ? this.getTable().getAlias() : this.getTable().getName();
         var constructedColumn = null;
         var constructDataType = null;
         var constructAggregation = null;
         if (this.getDataType() !== null && this.getDataType() !== undefined) {
             if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "Integer")) {
                 constructDataType = "CAST (" + tableName + "." + this.getName() + " AS INTEGER)";
             } else if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "Numeric")) {
                 constructDataType = "CAST (" + tableName + "." + this.getName() + " AS NUMERIC)";
             } else if (voltmx.sdk.util.matchIgnoreCase(this.getDataType(), "Date")) {
                 constructDataType = "date(" + tableName + "." + this.getName() + ")";
             } else {
                 if (!this.isComputedField()) constructDataType = tableName + "." + this.getName();
             }
         } else {
             if (!this.isComputedField()) constructDataType = tableName + "." + this.getName();
         }
         var constructAlias = (this.getAlias() !== null && this.getAlias() !== undefined && this.getAlias() !== "") ? " AS " + this.getAlias() : "";
         constructAggregation = (this.getAggregation() === voltmx.sdk.constants.Aggregation.NONE || (this.getAggregation() === null || this.getAggregation() === undefined)) ? constructDataType : (this.isComputedField() ? this.getAggregation() : this.getAggregation() + "(" + constructDataType + ")");
         constructedColumn = constructAggregation + constructAlias;
         return constructedColumn;
     };
     this.toStringByTablePrefix = function(includeTablePrefix) {
         if (includeTablePrefix) {
             return this.toString();
         } else {
             return this.getName();
         }
     }
 };
 /**
  * This Object represents a groupby clause in select query
  * @param columnObj {@link voltmx.sdk.dto.Column}
  * @constructor
  */
 voltmx.sdk.dto.Group = function(columnObj) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Group");
     if (columnObj instanceof voltmx.sdk.dto.Column) {
         this.column = columnObj;
     }
     this.getColumn = function() {
         return this.column;
     };
     this.setColumn = function(column) {
         if (column instanceof voltmx.sdk.dto.Column) {
             this.column = column;
         }
     };
     this.toString = function() {
         var tableName = (this.column.getTable().getAlias() !== null && this.column.getTable().getAlias() !== undefined) ? this.column.getTable().getAlias() : this.column.getTable().getName();
         return tableName + "." + this.column.getName();
     };
 };
 /**
  * This Object represents JOINS used in voltmx.sdk.dto.SelectQuery
  * @constructor
  */
 voltmx.sdk.dto.Join = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Join");
     this.criteria;
     this.table;
     this.joinType;
     var currentObject = this;
     if (arguments.length === 3) {
         getJoinByTableCriteriaAndJoinType(arguments[0], arguments[1], arguments[2]);
     } else if (arguments.length === 4) {
         getJoinByDestTableAndSrcColumnAndDestColumnAndJoinType(arguments[0], arguments[1], arguments[2], arguments[3]);
     }
     /**
      * This function is the Join constructor which has 3 arguments.
      *
      * @param table
      * @param criteria
      * @param joinType
      */
     function getJoinByTableCriteriaAndJoinType(table, criteria, joinType) {
         voltmx.sdk.logsdk.trace("Entering into getJoinByTableCriteriaAndJoinType");
         if (table instanceof voltmx.sdk.dto.Table && voltmx.sdk.util.validateCriteriaObject(criteria) && joinType !== null && joinType !== undefined && (joinType === voltmx.sdk.constants.JoinType.INNER || joinType === voltmx.sdk.constants.JoinType.LEFT)) {
             currentObject.table = table;
             currentObject.joinType = joinType;
             currentObject.criteria = criteria;
             return currentObject;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Join::getJoinByTableCriteriaAndJoinType:: Error: Validation error at getJoinByTableCriteriaAndJoinType");
         }
     }
     /**
      * This function is the Join constructor which has 4 arguments.
      *
      * @param destTable
      * @param srcColumn
      * @param destColumn
      * @param joinTypeObj
      */
     function getJoinByDestTableAndSrcColumnAndDestColumnAndJoinType(destTable, srcColumn, destColumn, joinTypeObj) {
         voltmx.sdk.logsdk.trace("Entering into getJoinByDestTableAndSrcColumnAndDestColumnAndJoinType");
         if (destTable instanceof voltmx.sdk.dto.Table && srcColumn instanceof voltmx.sdk.dto.Column && destColumn instanceof voltmx.sdk.dto.Column && joinTypeObj !== null && joinTypeObj !== undefined && joinTypeObj !== '' && (joinTypeObj === voltmx.sdk.constants.JoinType.INNER || joinTypeObj === voltmx.sdk.constants.JoinType.LEFT)) {
             currentObject.table = destTable;
             currentObject.joinType = joinTypeObj;
             var criteria = new voltmx.sdk.dto.Match(srcColumn, voltmx.sdk.constants.MatchType.EQUALS, destColumn);
             currentObject.criteria = criteria;
             return currentObject;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Join::getJoinByDestTableAndSrcColumnAndDestColumnAndJoinType:: Error: Validation error at getJoinByDestTableAndSrcColumnAndDestColumnAndJoinType");
         }
     }
     this.getCriteria = function() {
         return this.criteria;
     };
     this.setCriteria = function(criteria) {
         if (voltmx.sdk.util.validateCriteriaObject(criteria)) {
             this.criteria = criteria;
         }
     };
     this.getTable = function() {
         return this.table;
     };
     this.setTable = function(table) {
         if (table instanceof voltmx.sdk.dto.Table) {
             this.table = table;
         }
     };
     this.getJoinType = function() {
         return this.joinType;
     };
     this.setJoinType = function(joinType) {
         if (joinType !== null) {
             this.joinType = joinType;
         }
     };
     this.initCriteria = function(srcColumn, destColumn) {
         if ((srcColumn instanceof voltmx.sdk.dto.Column) && (destColumn instanceof voltmx.sdk.dto.Column)) {
             var criteria = new voltmx.sdk.dto.Match(srcColumn, voltmx.sdk.constants.MatchType.EQUALS, destColumn);
             this.setCriteria(criteria);
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Join::initCriteria:: Error: srcColumn or destColumn is not an isntanceof voltmx.sdk.dto.Column");
         }
     };
     this.toString = function() {
         var returnString = null;
         var temp = null;
         var join;
         if (voltmx.sdk.constants.JoinType.INNER == this.getJoinType()) {
             join = "INNER";
         } else if (voltmx.sdk.constants.JoinType.LEFT == this.getJoinType()) {
             join = "LEFT";
         } else if (voltmx.sdk.constants.JoinType.RIGHT == this.getJoinType()) {
             join = "RIGHT";
         }
         returnString = " " + join + " JOIN " + this.getTable().toString() + " ON ";
         temp = this.getCriteria().toString();
         returnString = returnString + temp;
         return returnString;
     };
 };
 /**
  * This function is the Order constructor.
  * @param columnObj
  * @param orderTypeObj
  */
 voltmx.sdk.dto.Order = function(columnObj, orderTypeObj) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Order");
     if ((columnObj instanceof voltmx.sdk.dto.Column) && (orderTypeObj == voltmx.sdk.constants.OrderType.ASCENDING || orderTypeObj == voltmx.sdk.constants.OrderType.DESCENDING)) {
         this.column = columnObj;
         this.type = orderTypeObj;
         return this;
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Order:: Error: Validation error")
     }
     this.getColumn = function() {
         return this.column;
     };
     /**
      * This function is used to set column.
      *
      * @param column
      */
     this.setColumn = function(column) {
         if (column instanceof voltmx.sdk.dto.Column) {
             this.column = column;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Order::setColumn: Error: column is not an instance of voltmx.sdk.dto.Column");
         }
     };
     this.getType = function() {
         return this.type;
     };
     /**
      * This function is used to set type.
      *
      * @param type
      */
     this.setType = function(type) {
         this.type = type;
     };
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         return this.column.toString() + " " + (this.type);
     };
 };
 /**
  * This function is used to check the range of values of columnObj
  * @param columnObj {@link voltmx.sdk.dto.Column}
  * @param colRange
  * @constructor
  */
 voltmx.sdk.dto.Between = function(columnObj, colRange) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Between");
     this.column;
     this.range;
     if (columnObj instanceof voltmx.sdk.dto.Column && (colRange instanceof voltmx.sdk.dto.DateRange || colRange instanceof voltmx.sdk.dto.StringRange || colRange instanceof voltmx.sdk.dto.IntegerRange || colRange instanceof voltmx.sdk.dto.FloatRange)) {
         this.column = columnObj;
         this.range = colRange;
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Between:: Error: Vaildation error");
     }
     this.quote = function(str) {
         if (voltmx.sdk.util.isNull(str)) {
             return "null";
         }
         // var str1 = new String(str);
         var strBuf = [];
         strBuf.push('\'');
         for (var index = 0; index < str.length; index++) {
             var charItem = str.charAt(index);
             if (charItem == '\\' || charItem == '\"' || charItem == '\'') {
                 // strBuf.concat('\\');
                 strBuf.push('\\');
             }
             strBuf.push(charItem);
         }
         strBuf.push('\'');
         return strBuf.join("");
     };
     this.setColumn = function(column) {
         if (column instanceof voltmx.sdk.dto.Column) {
             this.column = column;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Between::setColumn: Error:column is not an instance of voltmx.sdk.dto.Column");
         }
     };
     this.setRange = function(range) {
         if (range instanceof voltmx.sdk.dto.DateRange || range instanceof voltmx.sdk.dto.StringRange || range instanceof voltmx.sdk.dto.IntegerRange || range instanceof voltmx.sdk.dto.FloatRange) {
             this.range = range;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Between::setRange: Error: Validation Error");
         }
     };
     this.getColumn = function() {
         return this.column;
     };
     this.getRange = function() {
         return this.range;
     };
     this.toString = function() {
         var returnStr = "";
         returnStr = this.getColumn().toString() + " Between " + this.getRange().toString();
         return returnStr;
     };
 };
 /**
  * This function is the DateRange constructor.
  * @param startDate
  * @param endDate
  */
 voltmx.sdk.dto.DateRange = function() {
     this.end;
     this.start;
     if (arguments.length === 2) {
         var startDate = arguments[0];
         var endDate = arguments[1];
         if (startDate instanceof Date && endDate instanceof Date) {
             this.start = startDate;
             this.end = endDate;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.DataRange:: Error: startDate or endDate is not an instance of Date");
         }
     } else if (arguments.length === 1) {
         var dateType = arguments[0];
         if (voltmx.sdk.util.validateDateTypeInput(dateType)) {
             var range = voltmx.sdk.util.getDateRange(dateType);
             if (range.length !== 2 || range[0] === 0 || range[1] === 0) {
                 //TODO
                 //throw error
                 voltmx.sdk.logsdk.error("### voltmx.sdk.dto.DateRange:: Error: Validation Error");
             } else {
                 this.start = range[0];
                 this.end = range[1];
             }
         }
     }
     this.getEnd = function() {
         return this.end;
     };
     /**
      * This function is used to set End value.
      *
      * @param end
      */
     this.setEnd = function(end) {
         if (end instanceof Date) {
             var month = end.getMonth() + 1;
             var date = end.getDate();
             var hr = end.getHours();
             var min = end.getMinutes();
             var sec = end.getSeconds();
             if (month < 10) {
                 month = "0" + month;
             }
             if (date < 10) {
                 date = "0" + date;
             }
             if (hr < 10) {
                 hr = "0" + hr;
             }
             if (min < 10) {
                 min = "0" + min;
             }
             if (sec < 10) {
                 sec = "0" + sec;
             }
             var endDate = end.getFullYear() + "-" + month + "-" + date + " " + hr + ":" + min + ":" + sec;
             this.end = endDate;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.DateRange::setEnd:: Error: end is not an instance of Date");
         }
     };
     this.getStart = function() {
         return this.start;
     };
     /**
      * This function is used to set start value.
      *
      * @param start
      */
     this.setStart = function(start) {
         if (start instanceof Date) {
             var month = start.getMonth() + 1;
             var date = start.getDate();
             var hr = start.getHours();
             var min = start.getMinutes();
             var sec = start.getSeconds();
             if (month < 10) {
                 month = "0" + month;
             }
             if (date < 10) {
                 date = "0" + date;
             }
             if (hr < 10) {
                 hr = "0" + hr;
             }
             if (min < 10) {
                 min = "0" + min;
             }
             if (sec < 10) {
                 sec = "0" + sec;
             }
             var startDate = start.getFullYear() + "-" + month + "-" + date + " " + hr + ":" + min + ":" + sec;
             this.start = startDate;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.DateRange::setStart:: Error: start is not an instance of Date");
         }
     };
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         var returnString = null;
         returnString = "'" + this.start + "'" + " AND " + "'" + this.end + "'";
         return returnString;
     };
 };
 /**
  * This function is the DecimalRange constructor.
  * @param startDecimal
  * @param endDecimal
  */
 voltmx.sdk.dto.DecimalRange = function(startDecimal, endDecimal) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.DecimalRange");
     if ((endDecimal !== null && endDecimal !== undefined && typeof endDecimal === 'number') && (startDecimal !== null && startDecimal !== undefined && typeof startDecimal === 'number')) {
         this.end = endDecimal;
         this.start = startDecimal;
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.DecimalRange:: Error: Validation Error");
     }
     this.getEnd = function() {
         return this.end;
     };
     /**
      * This function is used to set End value.
      *
      * @param end
      */
     this.setEnd = function(end) {
         if (end !== null && end !== undefined && typeof end === 'number') {
             this.end = end;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.DecimalRange::setEnd:: Error: Validation Error");
         }
     };
     this.getStart = function() {
         return this.start;
     };
     /**
      * This function is used to set start value.
      *
      * @param start
      */
     this.setStart = function(start) {
         if (start !== null && start !== undefined && typeof start === 'number') {
             this.start = start;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.DecimalRange::setStart:: Error: Validation Error");
         }
     };
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         var returnString = null;
         returnString = this.start + " AND " + this.end;
         return returnString;
     };
 };
 /**
  * This function is the FloatRange constructor.
  * @param startFloat
  * @param endFloat
  */
 voltmx.sdk.dto.FloatRange = function(startFloat, endFloat) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.FloatRange");
     this.end = endFloat;
     this.start = startFloat;
     this.getEnd = function() {
         return this.end;
     };
     /**
      * This function is used to set End value.
      *
      * @param end
      */
     this.setEnd = function(end) {
         if (end !== null && end !== undefined && typeof end === 'number') {
             this.end = end;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.FloatRange::setEnd:: Error: Validation Error");
         }
     };
     this.getStart = function() {
         return this.start;
     };
     /**
      * This function is used to set start value.
      *
      * @param start
      */
     this.setStart = function(start) {
         if (start !== null && start !== undefined && typeof start === 'number') {
             this.start = start;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.FloatRange::setStart:: Error: Validation Error");
         }
     };
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         var returnString = null;
         returnString = this.start + " AND " + this.end;
         return returnString;
     };
 };
 /**
  * This function is the IntegerRange constructor.
  * @param startInt
  * @param endInt
  */
 voltmx.sdk.dto.IntegerRange = function(startInt, endInt) {
     if ((endInt !== null && endInt !== undefined && typeof endInt === 'number') && (startInt !== null && startInt !== undefined && typeof startInt === 'number')) {
         this.end = endInt;
         this.start = startInt;
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.IntegerRange:: Error: Validation Error");
     }
     this.getEnd = function() {
         return this.end;
     };
     /**
      * This function is used to set End value.
      *
      * @param end
      */
     this.setEnd = function(end) {
         if (end !== null && end !== undefined && typeof end === 'number') {
             this.end = end;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.IntegerRange::setEnd:: Error: Validation Error");
         }
     };
     this.getStart = function() {
         return this.start;
     };
     /**
      * This function is used to set start value.
      *
      * @param start
      */
     this.setStart = function(start) {
         if (start !== null && start !== undefined && typeof start === 'number') {
             this.start = start;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.IntegerRange::setStart:: Error: Validation Error");
         }
     };
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         var returnString = null;
         returnString = this.start.toFixed() + " AND " + this.end.toFixed();
         return returnString;
     };
 };
 /**
  * This function is the StringRange constructor.
  * @param startString
  * @param endString
  */
 voltmx.sdk.dto.StringRange = function(startString, endString) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.StringRange");
     if ((endString !== null && endString !== undefined && typeof endString === 'string') && (startString !== null && startString !== undefined && typeof startString === 'string')) {
         this.end = endString;
         this.start = startString;
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.StringRange:: Error: Validation Error");
     }
     this.getEnd = function() {
         return this.end;
     };
     /**
      * This function is used to set End value.
      *
      * @param end
      */
     this.setEnd = function(end) {
         if (end !== null && end !== undefined && typeof end === 'string') {
             this.end = end;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.StringRange::setEnd:: Error: Validation Error");
         }
     };
     this.getStart = function() {
         return this.start;
     };
     /**
      * This function is used to set start value.
      *
      * @param start
      */
     this.setStart = function(start) {
         if (start !== null && start !== undefined && typeof start === 'string') {
             this.start = start;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.StringRange::setStart:: Error: Validation Error");
         }
     };
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         var returnString = null;
         var crit = new voltmx.sdk.dto.Criteria();
         returnString = crit.quote(this.start) + " AND " + crit.quote(this.end);
         return returnString;
     };
 };
 /**
  * This function helps in preparing And {@link voltmx.sdk.dto.And} and Or {@Link voltmx.sdk.dto.Or} clauses
  * @param operatorLg
  * @param leftOp
  * @param rightOp
  * @constructor
  */
 voltmx.sdk.dto.LogicGroup = function(operatorLg, leftOp, rightOp) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.LogicGroup");
     this.left = leftOp;
     this.operator = operatorLg;
     this.right = rightOp;
     /**
      * This function is used to initialize LogicGroup.
      *
      * @param operator
      * @param left
      * @param right
      */
     this.initializeLogicGroup = function(operator, left, right) {
         this.left = left;
         this.operator = operator;
         this.right = right;
     };
     this.getLeft = function() {
         return this.left;
     };
     /**
      * This function is used to set left.
      *
      * @param val
      */
     this.setLeft = function(val) {
         this.val = val;
     };
     this.getOperator = function() {
         return this.operator;
     };
     /**
      * This function is used to set Operator.
      *
      * @param val
      */
     this.setOperator = function(val) {
         this.operator = val;
     };
     this.getRight = function() {
         return this.right;
     };
     /**
      * This function is used to set Right.
      *
      * @param val
      */
     this.setRight = function(val) {
         this.right = val;
     };
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         var leftOperator = (this.getLeft() !== null && this.getLeft !== undefined) ? this.getLeft().toString() : "";
         var rightOperator = (this.getRight() !== null && this.getRight() !== undefined) ? this.getRight().toString() : "";
         return "(" + leftOperator + " " + this.getOperator() + " " + rightOperator + ")";
     };
 };
 /**
  * This function is the And constructor.
  *
  * @param left
  * @param right
  */
 voltmx.sdk.dto.And = function(left, right) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.And");
     if (arguments.length !== 2) {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.And:: Error: invalid number of arguments, expected are left and right");
     }
     if ((right !== null && left !== null && right !== undefined && left !== undefined && voltmx.sdk.util.validateCriteriaObject(left) && voltmx.sdk.util.validateCriteriaObject(right))) {
         voltmx.sdk.dto.LogicGroup.call(this, 'AND', left, right);
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.And:: Error: Validation Error");
     }
     this.initializeAnd = function(left, right) {
         voltmx.sdk.dto.LogicGroup.call(this, 'AND', left, right);
     };
 };
 /**
  * This function is the Or constructor.
  *
  * @param left
  * @param right
  */
 voltmx.sdk.dto.Or = function(left, right) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Or");
     if (arguments.length !== 2) {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Or:: Error: invalid number of arguments, expected are left and right");
     }
     if ((right !== null && left !== null && right !== undefined && left !== undefined && voltmx.sdk.util.validateCriteriaObject(left) && voltmx.sdk.util.validateCriteriaObject(right))) {
         voltmx.sdk.dto.LogicGroup.call(this, 'OR', left, right);
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Or:: Error: Validation Error");
     }
     this.initializeOr = function(left, right) {
         voltmx.sdk.dto.LogicGroup.call(this, 'OR', left, right);
     };
 };
 /**
  * This function is the Not constructor.
  *
  * @param right
  */
 voltmx.sdk.dto.Not = function(right) {
     if (arguments.length !== 1) {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Not:: Error: invalid number of arguments, expected right");
     }
     if (right !== null && right !== undefined && voltmx.sdk.util.validateCriteriaObject(right)) {
         voltmx.sdk.dto.LogicGroup.call(this, 'NOT', null, right);
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Not:: Error: Validation Error");
     }
     this.initializeNot = function(right) {
         voltmx.sdk.dto.LogicGroup.call(this, 'NOT', null, right);
     };
 };
 /**
  * This function is a constructor for Expression Object
  * @constructor
  */
 voltmx.sdk.dto.Expression = function() {
     this.term;
     this.operator;
     this.expression;
     var currentExpObj = this;
     if (arguments.length === 1) {
         if (voltmx.sdk.util.validateCriteriaObject(arguments[0])) {
             setTerm(arguments[0]);
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Expression:: Error: Validation Error");
         }
     } else if (arguments.length === 2) {
         initExpression(arguments[0], arguments[1]);
     } else if (arguments.length === 3) {
         initExpressionByExpression(arguments[0], arguments[1], arguments[2]);
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Expression:: Error: invalid number of arguments, atleast 'term' is expected");
     }
     /**
      * Recursively generates a Expression from a given list of
      * criteria and an infix operator to join each criteria with the
      * next in the list. Operator AND or Operator OR that joins each
      * criteria term with the next in the list.
      *
      * @param criterias
      *            the list of criteria terms from which the
      *            constructor generates the new criteria expression.
      * @param operator
      *            the infix operator
      */
     function initExpression(criterias, operator) {
         if (operator === voltmx.sdk.constants.Operator.OR) {
             setOperator(voltmx.sdk.constants.Operator.OR);
         } else if (operator === voltmx.sdk.constants.Operator.AND) {
             setOperator(voltmx.sdk.constants.Operator.AND);
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Expression::initExpression:: Error: Invalid Operator");
         }
         if (criterias !== null && criterias !== undefined && criterias instanceof Array && criterias.length > 0) {
             if (voltmx.sdk.util.validateCriteriaObject(criterias[0])) {
                 setTerm(criterias[0]);
             }
             if (criterias.length > 1) {
                 var tmpOperator = operator;
                 criterias.shift();
                 setExpression(new voltmx.sdk.dto.Expression(criterias, tmpOperator));
             }
         } else {
             if (voltmx.sdk.util.validateCriteriaObject(criterias)) {
                 setTerm(criterias);
                 // return currentExpObj;
             } else {
                 //TODO
                 //throw error
                 voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Expression::initExpression:: Error: Validation Error");
             }
         }
     }

     function setExpression(expression) {
         if (expression instanceof voltmx.sdk.dto.Expression) {
             currentExpObj.expression = expression;
             // return currentExpObj;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Expression::setExpression:: Error: expression not an instance of voltmx.sdk.do.Expression");
         }
     }

     function setTerm(term) {
         if (voltmx.sdk.util.validateCriteriaObject(term)) {
             currentExpObj.term = term;
             // return currentExpObj;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Expression::setTerm:: Error: Validation Error");
         }
     }
     /**
      * Initializes a Expression with an initial criteria term, an
      * operator, and a another trailing criteria expression.
      *
      * @param criterias
      *            the starting criteria to assign to the new
      *            criteria expression.
      * @param operator
      *            the infix operator
      * @param expression
      *            the trailing expression to assign to the new
      *            criteria expression.
      */
     function initExpressionByExpression(criterias, operator, expression) {
         if (operator === voltmx.sdk.constants.Operator.OR) {
             initExpression(criterias, voltmx.sdk.constants.Operator.OR);
         } else if (operator === voltmx.sdk.constants.Operator.AND) {
             initExpression(criterias, voltmx.sdk.constants.Operator.AND);
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Expression::initExpressionByExpression:: Error: Invalid Operator");
         }
         setExpression(expression);
         // return currentExpObj;
     }

     function setOperator(operator) {
         currentExpObj.operator = operator;
     }
     this.getTerm = function() {
         return this.term;
     };
     this.getOperator = function() {
         return this.operator;
     };
     this.getExpression = function() {
         return this.expression;
     };
     this.toString = function() {
         var returnString = null;
         if ((this.getTerm() === null || this.getTerm() === undefined) && (this.getExpression() === null || this.getExpression() === undefined)) {
             returnString = "";
         } else if (this.getExpression() === null || this.getExpression() === undefined) {
             returnString = this.getTerm().toString();
         } else if (this.getOperator() === voltmx.sdk.constants.Operator.AND) {
             returnString = (new voltmx.sdk.dto.And(this.getTerm(), this.getExpression())).toString();
         } else if (this.getOperator() === voltmx.sdk.constants.Operator.OR) {
             returnString = (new voltmx.sdk.dto.Or(this.getTerm(), this.getExpression())).toString();
         }
         return returnString;
     }
 };
 /**
  * This function is a constructor for InCriteria Object
  * @constructor
  */
 voltmx.sdk.dto.InCriteria = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.InCriteria");
     this.column;
     this.values;
     var currentInCriteriaObj = this;
     if (arguments.length === 2) {
         getInCriteriaByColumnAndCollection(arguments[0], arguments[1]);
     } else if (arguments.length === 3) {
         getInCriteriaByTableAndCollection(arguments[0], arguments[1], arguments[2]);
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.InCriteria:: Error: invalid number of arguments, atleast column,values are expected");
     }
     /**
      * This function is the InCriteria constructor which has 3
      * arguments.
      *
      * @param table
      * @param columnname
      * @param values
      */
     function getInCriteriaByTableAndCollection(table, columnname, values) {
         voltmx.sdk.logsdk.trace("Entering into getInCriteriaByTableAndCollection");
         if (table instanceof voltmx.sdk.dto.Table) {
             currentInCriteriaObj.column = new voltmx.sdk.dto.Column(table, columnname);
             currentInCriteriaObj.values = values;
             return currentInCriteriaObj;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.InCriteria::getInCriteriaByTableAndCollection:: Error: table is not an instance of voltmx.sdk.dto.Table");
         }
     }
     /**
      * This function is the InCriteria constructor which has 2
      * arguments.
      *
      * @param column
      * @param values
      */
     function getInCriteriaByColumnAndCollection(column, values) {
         voltmx.sdk.logsdk.trace("Entering into getInCriteriaByColumnAndCollection");
         if (column instanceof voltmx.sdk.dto.Column && values instanceof Array && values.length > 0) {
             currentInCriteriaObj.column = column;
             currentInCriteriaObj.values = values;
             return currentInCriteriaObj;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.InCriteria::getInCriteriaByColumnAndCollection:: Error: Validation Error");
         }
     }
     this.getColumnForTable = function(table, columnName) {
         if (table instanceof voltmx.sdk.dto.Table) {
             var column = new voltmx.sdk.dto.Column(table, columnName);
             return column;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.InCriteria::getColumnForTable:: Error: table not an instance of voltmx.sdk.dto.Table");
         }
     };
     this.getColumn = function() {
         return this.column;
     };
     this.setColumn = function(column) {
         if (column instanceof voltmx.sdk.dto.Column) {
             this.column = column;
         }
     };
     this.setValues = function(valuesCollection) {
         this.values = valuesCollection;
     };
     this.getValues = function() {
         return this.values;
     };
     this.toString = function() {
         var result = "";
         result = this.column.toString() + " IN (";
         if (this.values !== null && this.values !== undefined && this.values.length > 0) {
             for (var index = 0; index < this.values.length; index++) {
                 var value;
                 var criteria = new voltmx.sdk.dto.Criteria();
                 if (typeof(this.values[index]) === "string") {
                     value = criteria.quote(this.values[index]);
                 } else {
                     value = this.values[index];
                 }
                 result = result + value;
                 if (index !== (this.values.length - 1)) {
                     result = result + ", ";
                 }
             }
         }
         /*
          * else if (this.subSelect !== null && this.subSelect !==
          * undefined) { result = result + this.subSelect; }
          */
         result = result + ")";
         return result;
     };
 };
 /**
  * This function is used to in set Exists param in select query
  * @param subSelectQuery {@link voltmx.sdk.dto.SelectQuery}
  * @constructor
  */
 voltmx.sdk.dto.Exists = function(subSelectQuery) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Exists");
     if (subSelectQuery instanceof voltmx.sdk.dto.SelectQuery) {
         this.subSelect = subSelectQuery;
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Exists:: Error: subSelectQuery is not an instance of voltmx.sdk.dto.SelectQuery");
     }
     this.getSubSelect = function() {
         return this.subSelect;
     };
     this.setSubSelect = function(subSelect) {
         if (subSelect instanceof voltmx.sdk.dto.SelectQuery) {
             this.subSelect = subSelect;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Exists::subSelectQuery:: Error: subSelectQuery is not an instance of voltmx.sdk.dto.SelectQuery");
         }
     };
     this.toString = function() {
         return "EXISTS ( " + this.subSelect.toString() + " )";
     };
 };
 /**
  * This is Interface to define where clauses
  * @constructor
  */
 voltmx.sdk.dto.Criteria = function() {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.dto.Criteria");
     this.quote = function(str) {
         if (str === null || str === undefined) {
             return "null";
         }
         // var str1 = new String(str);
         var strBuf = [];
         strBuf.push('\'');
         for (var index = 0; index < str.length; index++) {
             var charItem = str.charAt(index);
             if (charItem == '\\' || charItem == '\"' || charItem == '\'') {
                 // strBuf.concat('\\');
                 strBuf.push('\\');
             }
             strBuf.push(charItem);
         }
         strBuf.push('\'');
         return strBuf.join("");
     };
 };
 /**
  * This function is used to define where clause
  * @constructor
  */
 voltmx.sdk.dto.Match = function() {
     this.column;
     this.matchType;
     this.value;
     var currentMatchObj = this;
     if (arguments.length === 3) {
         initMatchByColumn(arguments[0], arguments[1], arguments[2]);
     } else if (arguments.length === 4) {
         initMatchByTableAndColName(arguments[0], arguments[1], arguments[2], arguments[3]);
     } else {
         //TODO
         //throw error
         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match:: Error: Invalid number of arguments, atleast columnObj,matchType,value is required")
     }
     /**
      * This function is the Match constructor which has 3 arguments.
      *
      * @param columnObj
      * @param matchType
      * @param value
      */
     function initMatchByColumn(columnObj, matchType, value) {
         if (columnObj instanceof voltmx.sdk.dto.Column) {
             currentMatchObj.column = columnObj;
             if (matchType !== voltmx.sdk.constants.MatchType.EQUALS && matchType !== voltmx.sdk.constants.MatchType.GREATER && matchType !== voltmx.sdk.constants.MatchType.GREATEREQUAL && matchType !== voltmx.sdk.constants.MatchType.LESS && matchType !== voltmx.sdk.constants.MatchType.LESSEQUAL && matchType !== voltmx.sdk.constants.MatchType.STARTSWITH && matchType !== voltmx.sdk.constants.MatchType.CONTAINS && matchType !== voltmx.sdk.constants.MatchType.LIKE && matchType !== voltmx.sdk.constants.MatchType.ENDSWITH && matchType !== voltmx.sdk.constants.MatchType.NOTEQUAL && matchType !== voltmx.sdk.constants.MatchType.ISNULL && matchType !== voltmx.sdk.constants.MatchType.ISNOTNULL) {
                 //TODO
                 //throw error
                 voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::initMatchByColumn:: Error: Invalid MatchType");
             } else {
                 if (matchType !== voltmx.sdk.constants.MatchType.ISNULL && matchType !== voltmx.sdk.constants.MatchType.ISNOTNULL) {
                     // check if the value is passed or not except
                     // for NULL and NOT NULL cases.
                     if (value !== null && value !== undefined) {
                         if (value instanceof Array && value.length <= 0) {
                             //TODO
                             //throw error
                             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::initMatchByColumn:: Error: value is undefined ,null or empty object");
                         }
                         currentMatchObj.value = value;
                     } else {
                         //TODO
                         //throw error
                         voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::initMatchByColumn:: Error: Invalid MatchType");
                     }
                 }
                 currentMatchObj.matchType = matchType;
                 return currentMatchObj;
             }
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::initMatchByColumn:: Error: columnObj is not an instance of voltmx.sdk.dto.Column");
         }
     }
     /**
      * This function is the Match constructor which has 4 arguments.
      *
      * @param tableObj
      * @param columnName
      * @param matchType
      * @param value
      */
     function initMatchByTableAndColName(tableObj, columnName, matchType, value) {
         // check for validity of tableObj
         if (tableObj instanceof voltmx.sdk.dto.Table) {
             // columnName should not empty or null or undefined.
             if (columnName !== null && columnName !== undefined && typeof(columnName) === 'string' && columnName.trim().length > 0) {
                 currentMatchObj.column = tableObj.getColumn(columnName);
                 if (matchType !== voltmx.sdk.constants.MatchType.EQUALS && matchType !== voltmx.sdk.constants.MatchType.GREATER && matchType !== voltmx.sdk.constants.MatchType.GREATEREQUAL && matchType !== voltmx.sdk.constants.MatchType.LESS && matchType !== voltmx.sdk.constants.MatchType.LESSEQUAL && matchType !== voltmx.sdk.constants.MatchType.STARTSWITH && matchType !== voltmx.sdk.constants.MatchType.CONTAINS && matchType !== voltmx.sdk.constants.MatchType.LIKE && matchType !== voltmx.sdk.constants.MatchType.ENDSWITH && matchType !== voltmx.sdk.constants.MatchType.NOTEQUAL && matchType !== voltmx.sdk.constants.MatchType.ISNULL && matchType !== voltmx.sdk.constants.MatchType.ISNOTNULL) {
                     //TODO
                     //throw error
                     voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::initMatchByTableAndColName:: Error: Invalid MatchType");
                 } else {
                     if (matchType !== voltmx.sdk.constants.MatchType.ISNULL && matchType !== voltmx.sdk.constants.MatchType.ISNOTNULL) {
                         // check if the value is passed or not
                         // except for NULL and NOT NULL cases.
                         if (value !== null && value !== undefined) {
                             currentMatchObj.value = value;
                         } else {
                             //TODO
                             //throw error
                             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::initMatchByTableAndColName:: Error: value is undefined ,null or empty object");
                         }
                     }
                     currentMatchObj.matchType = matchType;
                 }
                 return currentMatchObj;
             } else {
                 //TODO
                 //throw error
                 voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::initMatchByTableAndColName:: Error: Invalid MatchType");
             }
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match:: Error: columnObj is not an instance of voltmx.sdk.dto.Column");
         }
     }
     this.getColumn = function() {
         if (this.column !== null && this.column !== undefined) {
             return this.column;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::getColumn:: Error: column is null or undefined");
         }
     };
     this.getMatchType = function() {
         if (this.matchType !== null && this.matchType !== undefined) {
             return this.matchType;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::getMatchType:: Error: matchType is null or undefined");
         }
     };
     /**
      * This function is used to set match type.
      *
      * @param matchType
      */
     this.setMatchType = function(matchType) {
         this.matchType = matchType;
     };
     this.getValue = function() {
         return this.value;
     };
     /*
      * quote=function(value){ return "'"+value+"'"; }
      */
     /**
      * This function is used to convert to String.
      *
      * @return string
      */
     this.toString = function() {
         if (this.matchType !== null && this.matchType !== undefined && this.column !== null && this.column !== undefined) {
             var constructedMatch = null;
             var constructedValue = null;
             var type = this.matchType;
             var val = this.matchType.name;
             if (this.value instanceof Date) {
                 var dateStr = "";
                 var month = this.getValue().getMonth() + 1;
                 var date = this.getValue().getDate();
                 if (month < 10) {
                     month = "0" + month;
                 }
                 if (date < 10) {
                     date = "0" + date;
                 }
                 dateStr = this.getValue().getFullYear() + "-" + month + "-" + date;
                 constructedMatch = "date(substr(" + this.getColumn().toString() + ",0,11)) " + this.getMatchType().value + "'" + dateStr + "'";
                 return constructedMatch;
             }
             if (typeof(this.getValue()) === 'boolean') {
                 if (this.getValue() === true) {
                     return "(" + this.getColumn().toString() + " = 'true' OR " + this.getColumn().toString() + " = 1)";
                 } else if (this.getValue() === false) {
                     return "(" + this.getColumn().toString() + " = 'false' OR " + this.getColumn().toString() + " = 0)";
                 } else {
                     this.value = "'" + this.value + "'";
                 }
             }
             constructedMatch = this.getColumn().toString() + " " + this.getMatchType().value + " ";
             if (typeof(this.getValue()) === 'string') {
                 constructedValue = voltmx.sdk.util.replaceAll(this.getValue(), "'", "");
                 if (voltmx.sdk.util.matchIgnoreCase(type.name, "STARTSWITH")) {
                     constructedValue = constructedValue + "%";
                 } else if (voltmx.sdk.util.matchIgnoreCase(type.name, "CONTAINS")) {
                     constructedValue = "%" + constructedValue + "%";
                 } else if (voltmx.sdk.util.matchIgnoreCase(type.name, "ENDSWITH")) {
                     constructedValue = "%" + constructedValue;
                 } else if (voltmx.sdk.util.matchIgnoreCase(type.name, "ISNULL")) {
                     return "(lower(" + this.getColumn().toString() + ") = 'null' OR " + this.getColumn().toString() + " IS NULL)";
                 } else if (voltmx.sdk.util.matchIgnoreCase(type.name, "ISNOTNULL")) {
                     return "(lower(" + this.getColumn().toString() + ") != 'null' OR " + this.getColumn().toString() + " IS NOT NULL)";
                 }
                 constructedValue = new voltmx.sdk.dto.Criteria().quote(constructedValue);
             } else {
                 if (voltmx.sdk.util.matchIgnoreCase(type.name, "ISNULL")) {
                     return "(lower(" + this.getColumn().toString() + ") = 'null' OR " + this.getColumn().toString() + " IS NULL)";
                 } else if (voltmx.sdk.util.matchIgnoreCase(type.name, "ISNOTNULL")) {
                     return "(lower(" + this.getColumn().toString() + ") != 'null' OR " + this.getColumn().toString() + " IS NOT NULL)";
                 }
                 constructedValue = this.getValue().toString();
             }
             if (!(voltmx.sdk.util.matchIgnoreCase(type.name, "ISNULL") || voltmx.sdk.util.matchIgnoreCase(type.name, "ISNOTNULL"))) {
                 constructedMatch = constructedMatch + constructedValue;
             }
             return constructedMatch;
         } else {
             //TODO
             //throw error
             voltmx.sdk.logsdk.error("### voltmx.sdk.dto.Match::toString:: Error: matchType is undefined");
         }
     }
 };
 /**
  * Method to create the sync service instance.
  * @returns {SyncService} sync service instance
  */
 voltmx.sdk.prototype.getSyncService = function() {
     if (!voltmx.sdk.isInitialized) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + " Sync service.");
     }
     return new voltmxSdkSyncService(this);
 }

 function voltmxSdkSyncService(voltmxRef) {
     var SyncProvider = voltmxRef.sync;
     if (voltmx.sdk.isNullOrUndefined(voltmx.sdk.syncService)) {
         voltmx.sdk.syncService = sync;
     }
     var syncServiceHandler = voltmx.sdk.syncService;
     if (!SyncProvider) {
         throw new Exception(voltmx.sdk.errorConstants.SYNC_FAILURE, "invalid sync provider in serviceDoc");
     }
     //mapping the sync logger to mbaassyncservice logger
     this.log = syncServiceHandler.log;
     //generic apis
     this.init = function(initSuccess, initFailure) {
         syncServiceHandler.init(initSuccess, initFailure);
     };
     this.reset = function(resetSuccess, resetFailure) {
         syncServiceHandler.reset(resetSuccess, resetFailure);
     };
     this.cancelPendingChunkRequests = function(successCallback, errorCallback) {
         syncServiceHandler.cancelPendingChunkRequests(successCallback, errorCallback);
     };
     this.stopSession = function(successCallback) {
         syncServiceHandler.stopSession(successCallback);
     };
     this.rollbackPendingLocalChanges = function(successCallback, errorCallback) {
         syncServiceHandler.rollbackPendingLocalChanges(successCallback, errorCallback);
     };
     this.getPendingAcknowledgement = function(successCallback, errorCallback) {
         syncServiceHandler.getPendingAcknowledgement(successCallback, errorCallback);
     };
     this.getPendingUpload = function(successCallback, errorCallback) {
         syncServiceHandler.getPendingUpload(successCallback, errorCallback);
     };
     this.getDeferredUpload = function(successCallback, errorCallback) {
         syncServiceHandler.getDeferredUpload(successCallback, errorCallback);
     };
     this.getAllPendingUploadInstances = function(retrieveOnlyCount, successcallback, errorcallback) {
         syncServiceHandler.getAllPendingUploadInstances(retrieveOnlyCount, successcallback, errorcallback);
     };
     this.executeSelectQuery = function(query, successcallback, errorcallback) {
         syncServiceHandler.executeSelectQuery(query, successcallback, errorcallback);
     };
     //adding the binary apis
     this.getFailedBinaryRecords = function(isDownload, tablename, columnname, successCallback, errorCallback) {
         syncServiceHandler.getFailedBinaryRecords(isDownload, tablename, columnname, successCallback, errorCallback);
     };
     this.getStatusForBinary = function(tbname, columnName, pks, successCallback, errorCallback) {
         syncServiceHandler.getStatusForBinary(tbname, columnName, pks, successCallback, errorCallback);
     };
     this.getBinaryBase64 = function(tbname, columnName, pks, config, successCallback, errorCallback) {
         syncServiceHandler.getBinaryBase64(tbname, columnName, pks, config, successCallback, errorCallback);
     };
     this.getBinaryFilepath = function(tbname, columnName, pks, config, successCallback, errorCallback) {
         syncServiceHandler.getBinaryFilepath(tbname, columnName, pks, config, successCallback, errorCallback);
     };
     //binary chunking apis
     this.createDownloadTask = function(tbname, columnName, pks, config, successCallback, errorCallback) {
         syncServiceHandler.createDownloadTask(tbname, columnName, pks, config, successCallback, errorCallback);
     };
     this.startDownload = function(downloadID, successCallback, errorCallback) {
         syncServiceHandler.startDownload(downloadID, successCallback, errorCallback);
     };
     this.pauseDownload = function(downloadID, successCallback, errorCallback) {
         syncServiceHandler.pauseDownload(downloadID, successCallback, errorCallback);
     };
     this.resumeDownload = function(downloadID, successCallback, errorCallback) {
         syncServiceHandler.resumeDownload(downloadID, successCallback, errorCallback);
     };
     this.getBinaryDataFilePath = function(tbname, columnName, pks, successCallback, errorCallback) {
         syncServiceHandler.getBinaryDataFilePath(tbname, columnName, pks, successCallback, errorCallback);
     };
     this.getBinary = function(tableName, binaryColumnName, primaryKeyTable, config, successCallback, errorCallback) {
         syncServiceHandler.getBinary(tableName, binaryColumnName, primaryKeyTable, config, successCallback, errorCallback);
     };
     this.deleteBinaryObject = function(tableName, binaryColumnName, primaryKeyTable, options, successCallback, errorCallback) {
         syncServiceHandler.deleteBinaryObject(tableName, binaryColumnName, primaryKeyTable, options, successCallback, errorCallback);
     };
     var syncServiceAppid = SyncProvider["appId"];
     var syncServiceUrl = SyncProvider["url"] + "/";

     function genericErrorCallback(res) {
         voltmx.sdk.logsdk.error("error occurred in refreshing claims token.. Please call login again " + JSON.stringify(res));
     }
     //modified api
     this.startSession = function(config) {
         var errorCallback;
         if (config.onsyncerror) {
             errorCallback = config.onsyncerror;
         } else {
             errorCallback = genericErrorCallback;
         }
         voltmx.sdk.claimsRefresh(sdkStartSession, errorCallback);

         function sdkStartSession() {
             config = processConfig(config);
             syncServiceHandler.startSession(config);
         }
     }
     this.performUpgrade = function(config) {
         var errorCallback;
         if (config.onperformupgradeerror) {
             errorCallback = config.onperformupgradeerror;
         } else {
             errorCallback = genericErrorCallback;
         }
         voltmx.sdk.claimsRefresh(sdkPerformUpgrade, errorCallback);

         function sdkPerformUpgrade() {
             config = processConfig(config);
             syncServiceHandler.performUpgrade(config);
         }
     }
     this.isUpgradeRequired = function(config) {
         var errorCallback;
         if (config.isupgraderequirederror) {
             errorCallback = config.isupgraderequirederror;
         } else {
             errorCallback = genericErrorCallback;
         }
         voltmx.sdk.claimsRefresh(sdkIsUpgradeRequired, errorCallback);

         function sdkIsUpgradeRequired() {
             config = processConfig(config);
             syncServiceHandler.isUpgradeRequired(config);
         }
     }

     function processConfig(config) {
         var tempConfig = config;
         tempConfig.serverurl = syncServiceUrl;
         tempConfig.appid = syncServiceAppid;
         tempConfig.authtoken = voltmxRef.currentClaimToken;
         return tempConfig;
     }
     this.startReconciliation = function(config) {
         if (!syncServiceHandler.startReconciliation) throw new Exception(voltmx.sdk.errorConstants.SYNC_FAILURE, "sync provider doesnot support reconciliation");
         syncServiceHandler.startReconciliation(config);
     }
 }

 function OAuthHandler(serviceUrl, providerName, appkey, callback, type, options, isMFVersionCompatible) {
     if (options[voltmx.sdk.constants.IS_ENABLE_IDENTITY_PKCE] === true) {
         voltmx.sdk.pkceUtilityInstance = voltmx.sdk.util.getUtilityForPKCE();
         if (!voltmx.sdk.pkceUtilityInstance.initializePKCEObject()) {
             var err = voltmx.sdk.error.getErrObj(voltmx.sdk.errorcodes.pkce_params_generation_failed, voltmx.sdk.errormessages.pkce_params_generation_failed);
             var isErr = true;
             callback(null, null, null, isErr, err);
             return;
         }
     }
     var urlType = "/" + type + "/";
     var isSuccess = true;
     var isLogout = false;
     // This will make sure the scheduler to request tokens will be instantiated only once in the method handleRequestCallback.
     // In case of Google OAuth changes Identity returns the success_url, so page gets refreshed twice which will fail in instantiating the scheduler twice.
     var isLoginCallbackInvoked = false;
     if (options && options.hasOwnProperty("logout") && options["logout"] === true) {
         isLogout = true;
     }
     var slo = false;
     if (options && options.hasOwnProperty("slo") && options["slo"] === true) {
         slo = options["slo"];
     }
     var customQueryParamsForOAuth;
     if (options && options.hasOwnProperty(voltmx.sdk.constants.CUSTOM_QUERY_PARAMS_FOR_OAUTH)) {
         customQueryParamsForOAuth = voltmx.sdk.util.objectToQueryParams(options[voltmx.sdk.constants.CUSTOM_QUERY_PARAMS_FOR_OAUTH]);
     }
     var requestUrl;

     function appendCustomOAuthParamsToURL(url) {
         if (!voltmx.sdk.util.isNullOrEmptyString(customQueryParamsForOAuth)) {
             url = url + "&" + customQueryParamsForOAuth;
         }
         return url;
     }

     function constructURLIE11(crossPlatformBaseURL, identityOAuthUrl) {
         //Protocol param is to differentiate between http and https
         var protocolParam = 0;
         //Identity Server will route the final result be it success or error to Injected callback page
         if (identityOAuthUrl.indexOf("https") !== -1) {
             protocolParam = 1;
         }
         identityOAuthUrl = identityOAuthUrl.replace(/^https?:\/\//, '');
         //Invoking the identity through the injected Redirect Page to overcome IE imposed cross domain security restrictions.
         var finalRequestUrl = crossPlatformBaseURL + "/" + voltmx.sdk.constants.KNY_OAUTH_REDIRECT_HTML + "?" + voltmx.sdk.constants.KNY_OAUTH_REDIRECT_URL + "=" + encodeURIComponent(identityOAuthUrl) + "&" + voltmx.sdk.constants.KNY_OAUTH_PROTOCOL_PARAM + "=" + protocolParam;
         return finalRequestUrl;
     }
     if (typeof(XMLHttpRequest) !== 'undefined') {
         var _window = window;
         var _popup = null;
         var _listener = function(event) {
             var eventOrigin = event.origin;
             //checking whether the message(event) gets posted from the same origin as service url. This avoids handling of irrelevant
             //message. Without this check, any message with valid string content posted on window was getting processed. But, we
             //need to process the message posted from service url origin only
             if (!voltmx.sdk.util.isValidString(eventOrigin) || (serviceUrl.toLowerCase().indexOf(eventOrigin.toLowerCase()) < 0)) {
                 return;
             }
             var _contents = event.data;
             /**
              MFSDK-3431 - Recieving post message event from other endpoints.
              This is a short term fix. Currently Identity sends us only string in post message event, later on they have to
              send json with some more keys giving us the knowledge of source
              */
             if (voltmx.sdk.util.isValidString(_contents) && !voltmx.sdk.isJson(_contents)) {
                 _popup.close();
                 _detachEvent();
                 try {
                     voltmx.sdk.logsdk.debug("### OAuthHandler::_listener received authorization code as " + _contents);
                     var headers = {};
                     if (type === "oauth2" || type === "saml") {
                         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED
                     }
                     var bodyParams = {
                         code: _contents
                     };
                     if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance)) {
                         bodyParams = voltmx.sdk.pkceUtilityInstance.appendAppVerifierInBodyParams(bodyParams);
                     }
                     callback(urlType + "token", bodyParams, headers);
                 } catch (err) {
                     voltmx.sdk.logsdk.error("exception ::" + err);
                     failureCallback();
                 }
             } else if (voltmx.sdk.isJson(_contents) || voltmx.sdk.util.isJsonObject(_contents)) {
                 voltmx.sdk.logsdk.debug("### OAuthHandler::_listener received event.data in unknown format as " + JSON.stringify(_contents));
                 //TODO - After Identity changes check for desired key in the json.
             }
         };
         var _attachEvent = function() {
             if (_window.addEventListener) {
                 _window.addEventListener('message', _listener, false);
             } else if (_window.attachEvent) {
                 _window.attachEvent('message', _listener);
             } else {
                 throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "environment doesn't support event attaching");
             }
         };
         var _detachEvent = function() {
             if (_window.detachEvent) {
                 _window.detachEvent('message', _listener);
             } else if (_window.removeEventListener) {
                 _window.removeEventListener('message', _listener);
             } else {
                 throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, "environment doesn't support detaching an event");
             }
         };
         _attachEvent();
         if (isLogout) {
             requestUrl = serviceUrl + urlType + "logout?provider=" + providerName + "&appkey=" + appkey + "&slo=" + slo;
             // Due to the non-stickiness of SAML sessions, SID (session id) has to be passed
             // to identity server for logout to fetch session specific context.
             if (type == voltmx.sdk.constants.AUTH_PROVIDER_TYPE_SAML) {
                 requestUrl += "&session_id=" + voltmxRef.idSid;
             }

             function handleLogoutInSPA() {
                 callback(1);
                 _popup.close();
                 _detachEvent();
             }
             voltmx.timer.schedule("SPALogout", handleLogoutInSPA, 3, false);
         } else {
             requestUrl = serviceUrl + urlType + "login?provider=" + providerName + "&appkey=" + appkey;
             var appVersion = voltmx.sdk.getFoundryAppVersion();
             if (!voltmx.sdk.isNullOrUndefined(appVersion)) {
                 requestUrl += "&app_version=" + appVersion;
             }
             requestUrl = appendCustomOAuthParamsToURL(requestUrl);
             //Checking whether server is compatable to redirect to user defined callback url
             //Changes to support OAuth on IE11, MFSDK-3657
             if (voltmx.sdk.util.checkForIE11() && voltmx.sdk.util.isJsonObject(options) && options.hasOwnProperty(voltmx.sdk.constants.IE11_CROSS_DOMAIN_OAUTH_BASE_URL)) {
                 requestUrl = constructURLIE11(stripTrailingCharacter(options[voltmx.sdk.constants.IE11_CROSS_DOMAIN_OAUTH_BASE_URL], "/"), requestUrl);
             }
             if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance)) {
                 requestUrl = voltmx.sdk.pkceUtilityInstance.appendAppChallengeOnURL(requestUrl);
             }
         }
         if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_THIN_CLIENT && options[voltmx.sdk.constants.NO_POP_UP] === true) {
             //we will not override success url value given by user
             if (requestUrl.indexOf(voltmx.sdk.constants.OAUTH_REDIRECT_SUCCESS_URL) === -1) {
                 requestUrl = requestUrl + "&" + voltmx.sdk.constants.OAUTH_REDIRECT_SUCCESS_URL + "=" + voltmx.application.getBrowserProtocol() + "//" + voltmx.application.getBaseURL();
             }
             var loginHelperFunction = callback;
             var isError = false;
             var codeVerifierBodyParamsJSON = {};
             var metaDataManagerForLoginInSameWindow = options[voltmx.sdk.constants.METADATA_MANAGER_FOR_LOGIN_IN_SAME_WINDOW_OBJECT];
             if (voltmx.sdk.util.isPlatformPlainJS()) {
                 if (!voltmx.sdk.isNullOrUndefined(appConfig)) {
                     metaDataManagerForLoginInSameWindow.setItem(voltmx.sdk.constants.KEY_APPCONFIG_FOR_SINGLE_WINDOW_LOGIN, JSON.stringify(appConfig));
                 } else {
                     voltmx.sdk.logsdk.error("Appconfig is null or undefined.");
                     var errorObject = voltmx.sdk.error.getSingleWindowLoginErrObj(voltmx.sdk.errorcodes.invalid_appconfig, voltmx.sdk.errormessages.invalid_appconfig);
                     isError = true;
                     metaDataManagerForLoginInSameWindow.destroy();
                     loginHelperFunction(null, null, null, isError, errorObject);
                     return;
                 }
             }
             metaDataManagerForLoginInSameWindow.setItem(voltmx.sdk.constants.ENABLE_IDENTITY_PKCE, options[voltmx.sdk.constants.IS_ENABLE_IDENTITY_PKCE]);
             if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance)) {
                 codeVerifierBodyParamsJSON = voltmx.sdk.pkceUtilityInstance.appendAppVerifierInBodyParams(codeVerifierBodyParamsJSON);
                 metaDataManagerForLoginInSameWindow.saveAppVerifier(codeVerifierBodyParamsJSON, saveAppVerifierSuccessCallback, function(errorObject) {
                     voltmx.sdk.logsdk.error("Failed to save app_verifier at middleware.");
                     isError = true;
                     metaDataManagerForLoginInSameWindow.destroy();
                     loginHelperFunction(null, null, null, isError, errorObject);
                 });
             } else {
                 saveAppVerifierSuccessCallback();
             }

             function saveAppVerifierSuccessCallback() {
                 if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance)) {
                     voltmx.sdk.logsdk.info("app_verifier was saved at middleware");
                 }
                 metaDataManagerForLoginInSameWindow.saveMetaData();
                 voltmx.sdk.logsdk.info("login metadata for no popup login was saved");
                 var userCustomDataSaveHandle = options[voltmx.sdk.constants.CUSTOM_DATA_SAVE_HANDLE];
                 if (voltmx.sdk.isNullOrUndefined(userCustomDataSaveHandle)) {
                     //user does not want to store data before app loose context
                     voltmx.sdk.logsdk.info("user has not provided" + voltmx.sdk.constants.CUSTOM_DATA_SAVE_HANDLE + ", we will proceed directly to auth");
                     _openWindowInSelfMode();
                 } else {
                     if (typeof(userCustomDataSaveHandle) !== 'function') {
                         voltmx.sdk.logsdk.error("user has provided" + voltmx.sdk.constants.CUSTOM_DATA_SAVE_HANDLE + " but argument type is not a function");
                         var errorObject = voltmx.sdk.error.getSingleWindowLoginErrObj(voltmx.sdk.errorcodes.invalid_custom_data_save_handle, voltmx.sdk.errormessages.invalid_custom_data_save_handle);
                         isError = true;
                         metaDataManagerForLoginInSameWindow.destroy();
                         loginHelperFunction(null, null, null, isError, errorObject);
                         return;
                     }
                     voltmx.sdk.logsdk.info("calling user's " + voltmx.sdk.constants.CUSTOM_DATA_SAVE_HANDLE);
                     userCustomDataSaveHandle(_openWindowInSelfMode, function(err) {
                         voltmx.sdk.logsdk.error("Error occurred while performing customDataSaveHandle.");
                         var errorObject = voltmx.sdk.error.getSingleWindowLoginErrObj(voltmx.sdk.errorcodes.custom_data_save_handle_failed, voltmx.sdk.errormessages.custom_data_save_handle_failed);
                         isError = true;
                         metaDataManagerForLoginInSameWindow.destroy();
                         loginHelperFunction(null, null, null, isError, errorObject);
                         return;
                     })
                 }

                 function _openWindowInSelfMode() {
                     var config = {};
                     config[voltmx.sdk.constants.KEY_URL] = requestUrl;
                     config[voltmx.sdk.constants.KEY_IS_SAME_WINDOW] = true;
                     voltmx.application.openURLAsync(config);
                 }
             }
         } else {
             if (voltmx.os.deviceInfo().name === voltmx.sdk.constants.PLATFORM_SPA && !voltmx.sdk.util.isMobileDevice() && voltmx.sdk.util.isPWAStandaloneOrFullscreen()) {
                 _popup = voltmx.sdk.util.openPopupWindow(requestUrl, "");
             } else {
                 _popup = _window.open(requestUrl);
             }
         }
     } else {
         var browserSF = null;
         var userDefined = false;
         var userDefinedBrowserOnSuccess = null;
         var userDefinedBrowserOnFailure = null;
         var userDefinedBrowserEvent = null;
         if (voltmx.sdk.util.hasBrowserWidget(options)) {
             browserSF = options[voltmx.sdk.constants.BROWSER_WIDGET];
             userDefined = true;
         } else if (options && options["UseDeviceBrowser"] && isMFVersionCompatible) {
             voltmx.sdk.util.OAuthCallback = callback;
             voltmx.sdk.util.OAuthType = type;
         } else {
             var formBasic = {
                 id: "popUp",
                 skin: null,
                 isModal: false,
                 transparencyBehindThePopup: 80,
                 "layoutType": voltmx.flex.FREE_FORM,
                 "needAppMenu": false
             };
             var formLayout = {
                 containerWeight: 100,
                 padding: [5, 5, 5, 5],
                 "paddingInPixel": true
             };
             var formPSP = {
                 "titleBar": true,
                 "titleBarConfig": {
                     "renderTitleText": true,
                     "prevFormTitle": false,
                     "titleBarLeftSideView": "button",
                     "labelLeftSideView": "Back",
                     "titleBarRightSideView": "none"
                 },
                 "titleBarSkin": "slTitleBar"
             };
             //to do.. this is a workaround for android browser issue.. need to refactor this code
             browserSF = new voltmx.ui.Browser({
                 "id": "browserSF",
                 "text": "Browser",
                 "isVisible": true,
                 "detectTelNumber": true,
                 "screenLevelWidget": true,
                 "left": "0%",
                 "top": "0%",
                 "width": "100%",
                 "height": "100%",
                 "enableZoom": false
             }, {}, {});
             var prevForm = voltmx.application.getCurrentForm();
             var oauthForm = new voltmx.ui.Form2(formBasic, formLayout, formPSP);
             oauthForm.add(browserSF);
             oauthForm.show();
         }
         var urlConf;
         var headersConf = {};
         if (!voltmx.sdk.isNullOrUndefined(voltmxRef.currentClaimToken)) {
             headersConf[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
         }
         voltmxRef.appendGlobalHeaders(headersConf);
         requestUrl = serviceUrl + urlType;
         if (isLogout) {
             requestUrl += "logout?provider=" + providerName + "&appkey=" + appkey + "&slo=" + slo;
             // Due to the non-stickiness of SAML sessions, SID (session id) has to be passed
             // to identity server for logout to fetch session specific context.
             if (type == voltmx.sdk.constants.AUTH_PROVIDER_TYPE_SAML) {
                 requestUrl += "&session_id=" + voltmxRef.idSid;
             }
         } else {
             requestUrl += "login?provider=" + providerName + "&appkey=" + appkey;
         }
         if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.getFoundryAppVersion())) {
             requestUrl += "&app_version=" + voltmx.sdk.getFoundryAppVersion();
         }
         if (isLogout) {
             userDefinedBrowserOnSuccess = browserSF.onSuccess;
             userDefinedBrowserOnFailure = browserSF.onFailure;
             browserSF.onSuccess = handleOAuthLogoutSuccessCallback;
             browserSF.onFailure = handleOAuthLogoutFailureCallback;
         } else {
             if (options && options["success_url"] && isMFVersionCompatible) requestUrl += "&success_url=" + options["success_url"];
             if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance)) {
                 requestUrl = voltmx.sdk.pkceUtilityInstance.appendAppChallengeOnURL(requestUrl);
             }
             if (options && options["UseDeviceBrowser"] && isMFVersionCompatible) {
                 voltmx.application.openURL(requestUrl);
                 return;
             } else {
                 isLoginCallbackInvoked = false;
                 verifyAndStoreDefinedBrowserEvent(browserSF.onPageStarted);
                 browserSF.onPageStarted = handleRequestCallback;
                 requestUrl = appendCustomOAuthParamsToURL(requestUrl);
             }
         }
         urlConf = {
             URL: requestUrl,
             requestMethod: constants.BROWSER_REQUEST_METHOD_GET
         };
         if (!isLogout && Object.keys(headersConf).length > 0) {
             urlConf["headers"] = headersConf;
         }
         browserSF.requestURLConfig = urlConf;

         function resetBrowserOnSuccessandFailureEvents(browser) {
             //Resetting the overridden onSuccess and onFailure callbacks to user defined callbacks
             browser.onSuccess = userDefinedBrowserOnSuccess;
             browser.onFailure = userDefinedBrowserOnFailure;
         }

         function handleOAuthLogoutSuccessCallback(browser) {
             if (!userDefined) {
                 var prevFormPostShow = prevForm.postShow;

                 function postShowOverride() {
                     oauthForm.destroy();
                     if (prevFormPostShow) {
                         prevFormPostShow();
                     }
                     prevForm.postShow = prevFormPostShow;
                 }
                 prevForm.postShow = postShowOverride;
                 prevForm.show();
             }
             voltmx.sdk.isOAuthLogoutInProgress = false;
             callback(isSuccess);
             //Invoking user defined onSuccess event of browser widget
             if (!voltmx.sdk.isNullOrUndefined(userDefinedBrowserOnSuccess)) voltmx.sdk.verifyAndCallClosure(userDefinedBrowserOnSuccess, browser);
             resetBrowserOnSuccessandFailureEvents(browser);
         }

         function handleOAuthLogoutFailureCallback(browser) {
             voltmx.sdk.isOAuthLogoutInProgress = false;
             isSuccess = false;
             //Invoking user defined onFailure event of browser widget
             if (!voltmx.sdk.isNullOrUndefined(userDefinedBrowserOnFailure)) voltmx.sdk.verifyAndCallClosure(userDefinedBrowserOnFailure, browser);
             resetBrowserOnSuccessandFailureEvents(browser);
         }

         function displayPrevForm() {
             var prevFormPostShow = prevForm.postShow;

             function postShowOverride() {
                 oauthForm.destroy();
                 if (prevFormPostShow) {
                     prevFormPostShow();
                 }
                 prevForm.postShow = prevFormPostShow;
             }
             prevForm.postShow = postShowOverride;
             prevForm.show();
         }

         function verifyAndStoreDefinedBrowserEvent(browserEvent) {
             if (browserEvent !== null) {
                 userDefinedBrowserEvent = browserEvent;
             }
         }

         function verifyAndCallUserDefinedBrowserEvent(browserWidget, params) {
             if (userDefinedBrowserEvent !== null) {
                 userDefinedBrowserEvent(browserWidget, params);
             }
         }

         function resetOAuthLoginUserDefinedBrowserEvent(browserWidget) {
             //Resetting the overridden onPageStarted/handleRequest callbacks to user defined callback after invoking /token call.
             //If not reset, when the user does login next time using same browser widget, overridden SDK's handleRequestCallback
             //is considered as user defined callback on these events. This ends up calling handleRequestCallback again.
             browserWidget.onPageStarted = userDefinedBrowserEvent;
         }

         function handleRequestCallback(browserWidget, params) {
             var originalUrl = params["originalURL"];
             if (originalUrl.toLowerCase().indexOf(serviceUrl.toLowerCase()) >= 0) {
                 if (!isLoginCallbackInvoked && !voltmx.sdk.isNullOrUndefined(params.queryParams) && !voltmx.sdk.isNullOrUndefined(params.queryParams.code)) {
                     if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance) && voltmx.sdk.isNullOrUndefined(params.queryParams.oauth_session_id)) {
                         verifyAndCallUserDefinedBrowserEvent(browserWidget, params);
                         return false;
                     }
                     if (!userDefined) {
                         displayPrevForm();
                     }
                     var headers = {};
                     if (type === "oauth2" || type === "saml") {
                         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
                     }
                     if (!isLoginCallbackInvoked) {
                         // make request for tokens
                         voltmx.timer.schedule(new Date().getTime().toString(), function(url, callback, code, headers) {
                             return function() {
                                 var bodyParams = {
                                     code: code
                                 };
                                 if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance)) {
                                     bodyParams = voltmx.sdk.pkceUtilityInstance.appendAppVerifierInBodyParams(bodyParams);
                                 }
                                 if (!(voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance) || voltmx.sdk.isNullOrUndefined(params.queryParams.oauth_session_id))) {
                                     bodyParams.oauth_session_id = params.queryParams.oauth_session_id;
                                 }
                                 callback(url, bodyParams, headers);
                             };
                         }(urlType + "token", callback, decodeURIComponent(params.queryParams.code), headers), 1, false);
                         isLoginCallbackInvoked = true;
                     }
                 } else if (!isLoginCallbackInvoked && typeof(params.queryParams) !== "undefined" && typeof(params.queryParams.error) !== "undefined") {
                     if (!userDefined) {
                         displayPrevForm();
                     }
                     isLoginCallbackInvoked = true;
                     callback(urlType, {
                         error: decodeURIComponent(params.queryParams.error)
                     }, headers, true);
                 }
             }
             verifyAndCallUserDefinedBrowserEvent(browserWidget, params);
             if (isLoginCallbackInvoked) {
                 resetOAuthLoginUserDefinedBrowserEvent(browserWidget);
             }
             return false;
         }
     }
 }
 /**
  * Handles the deeplink callback, this needs to be called once deep link redirection is done.
  * @param {json} params parameters from Identity service - "code": HashValue
  */
 function handleDeeplinkCallback(params) {
     if (params && voltmx.sdk.isValidDeeplinkCallback(params)) {
         var headers = {};
         var requestUrl;
         if (voltmx.sdk.util.OAuthType === "oauth2" || voltmx.sdk.util.OAuthType === "saml") {
             headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
         }
         if (voltmx.sdk.util.OAuthType === "oauth2") {
             requestUrl = "/oauth2/token";
         } else if (voltmx.sdk.util.OAuthType === "saml") {
             requestUrl = "/saml/token";
         } else {
             requestUrl = "/login";
         }
         // make request for tokens
         var bodyParams = {
             code: decodeURIComponent(params.launchparams.code)
         };
         if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.pkceUtilityInstance)) {
             bodyParams = voltmx.sdk.pkceUtilityInstance.appendAppVerifierInBodyParams(bodyParams);
         }
         if (!voltmx.sdk.isNullOrUndefined(params.launchparams.oauth_session_id)) {
             bodyParams.oauth_session_id = params.launchparams.oauth_session_id;
         }
         voltmx.sdk.util.OAuthCallback(requestUrl, bodyParams, headers);
     }
 }
 if (voltmx.sdk) {
     voltmx.sdk.offline = {};
 }
 //defined constants related to offline authentication.
 voltmx.sdk.offline.isOfflineEnabled = false;
 voltmx.sdk.offline.persistToken = false;
 voltmx.sdk.constants.iterations = 1024;
 voltmx.sdk.constants.keyLength = 256;
 /**
  *	This API is to be used to store the user login success response to the device and read it in the offline auth success scenario.
  */
 voltmx.sdk.offline.saveUserAuthInformation = function(dbKey, authResponse) {
     //validating arguments
     if (voltmx.sdk.isNullOrUndefined(dbKey) || typeof(dbKey) != "string" || dbKey.length === 0 || voltmx.sdk.isNullOrUndefined(authResponse) || typeof(authResponse) != "object" || Object.keys(authResponse).length === 0) {
         voltmx.sdk.logsdk.warn("### voltmx.sdk.offline.saveUserAuthInformation invalid arguments passed, returning");
         return;
     }
     var stringifiedResponse = JSON.stringify(authResponse);
     var encryptedAuthResponse = voltmx.sdk.util.encryptText(stringifiedResponse, [voltmx.sdk.util.getSharedClientId()], voltmx.sdk.constants.ENCRYPTION_ALGO_AES);
     voltmx.sdk.dataStore.setItem(dbKey, encryptedAuthResponse);
     voltmx.sdk.logsdk.info("saved auth info from the login success response");
 };
 /**
  *	This API is to be used to retrieve the user login success response to the device and read it in the offline auth success scenario.
  */
 voltmx.sdk.offline.getUserAuthInformation = function(dbKey) {
     var decryptedAuthResponse = null;
     var encryptedAuthResponse;
     if (!voltmx.sdk.isNullOrUndefined(dbKey) && typeof(dbKey) == "string") encryptedAuthResponse = voltmx.sdk.dataStore.getItem(dbKey);
     if (!voltmx.sdk.isNullOrUndefined(encryptedAuthResponse)) {
         decryptedAuthResponse = voltmx.sdk.util.decryptText(encryptedAuthResponse, [voltmx.sdk.util.getSharedClientId()], voltmx.sdk.constants.ENCRYPTION_ALGO_AES);
         if (voltmx.sdk.isNullOrUndefined(decryptedAuthResponse) || decryptedAuthResponse === '') {
             voltmx.sdk.offline.removePersistedUserAuthInformation();
         }
     }
     return decryptedAuthResponse;
 };
 /**
  *	This Utility API is to enable the developer read the claims token when the device is in offline mode.
  */
 voltmx.sdk.offline.getClaimsToken = function() {
     var userAuthInfoStr = voltmx.sdk.offline.getUserAuthInformation("authResponse");
     if (userAuthInfoStr != null && userAuthInfoStr != undefined) {
         var userAuthInfo = JSON.parse(userAuthInfoStr);
         return userAuthInfo.claims_token;
     }
     return null;
 };
 /**
  *	This Utility API is to update the the backend token.
  */
 voltmx.sdk.offline.updatePersistedToken = function(data) {
     var userAuthInfoStr = voltmx.sdk.offline.getUserAuthInformation(voltmx.sdk.constants.PERSISTED_AUTH_RESPONSE);
     if (userAuthInfoStr != null && userAuthInfoStr != undefined) {
         voltmx.sdk.offline.saveUserAuthInformation(voltmx.sdk.constants.PERSISTED_AUTH_RESPONSE, data);
     }
 };
 /**
  * Utility method to get persistToken flag from data store.
  */
 voltmx.sdk.offline.isPersistentLoginResponseEnabled = function() {
     var persistTokenFlag = voltmx.sdk.dataStore.getItem(voltmx.sdk.constants.PERSIST_LOGIN_RESPONSE_FLAG);
     if (!voltmx.sdk.isNullOrUndefined(persistTokenFlag) && persistTokenFlag === true) {
         return true;
     }
     return false;
 }
 voltmx.sdk.offline.removePersistedUserAuthInformation = function() {
     voltmx.store.removeItem(voltmx.sdk.constants.PERSISTED_AUTH_RESPONSE);
 };

 function getOfflineLoginDBKeyForProvider(providerName) {
     return "userCredentials" + providerName;
 }
 /**
  *  This Utility API to be used for the user to be able to login offline into the application.
  */
 voltmx.sdk.offline.loginOffline = function(providerName, successCallback, errorCallback) {
     //retrieving the temporarily stored encrypted username.
     var tempUserIdBase64 = voltmx.sdk.dataStore.getItem("tempUserCredentials");
     if (tempUserIdBase64 != null && tempUserIdBase64 != undefined) {
         var storedBase64 = voltmx.sdk.dataStore.getItem(getOfflineLoginDBKeyForProvider(providerName));
         if (tempUserIdBase64 == storedBase64) {
             var authResponseStr = voltmx.sdk.offline.getUserAuthInformation("authResponse");
             if (authResponseStr) successCallback(JSON.parse(authResponseStr));
             else {
                 errorCallback(voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.offline_auth_failed, voltmx.sdk.errormessages.offline_auth_failed));
             }
         } else {
             errorCallback(voltmx.sdk.error.getClientErrObj(voltmx.sdk.errorcodes.offline_auth_failed, voltmx.sdk.errormessages.offline_auth_failed))
         }
     }
 };
 /**
  *  This API generates the PBKDF2 key by reading the options passed as argument.
  */
 voltmx.sdk.offline.getKey = function(options) {
     var userid = options["userid"];
     var password = options["password"];
     var salt = userid + password;
     var iterations = options["iterations"];
     var klen = options["keyLength"];
     var key = voltmx.crypto.createPBKDF2Key(options["algo"], options["password"], salt, iterations, klen);
     return key;
 };
 /**
  *  This api saves the temporary user credentials to the device store.  This is to be called only if the app is offline auth enabled.
  */
 voltmx.sdk.offline.saveTempUserCredentials = function(options) {
     var op = {
         "algo": voltmx.sdk.constants.HASHING_ALGORITHM,
         "userid": options["userid"],
         "password": options["password"],
         "iterations": voltmx.sdk.constants.iterations,
         "keyLength": voltmx.sdk.constants.keyLength
     };
     var key = voltmx.sdk.offline.getKey(op);
     var encrypteduserid = voltmx.crypto.encrypt("aes", key, options["userid"], {});
     var base64userid = voltmx.convertToBase64(encrypteduserid);
     voltmx.sdk.dataStore.setItem("tempUserCredentials", base64userid);
 };
 /**
  *  This Utility API is to update the the claims token.
  */
 voltmx.sdk.offline.updateAuthToken = function(data) {
     var userAuthInfoStr = voltmx.sdk.offline.getUserAuthInformation("authResponse");
     if (userAuthInfoStr != null && userAuthInfoStr != undefined) {
         voltmx.sdk.offline.saveUserAuthInformation("authResponse", data);
     }
 };
 /**
  *  This Util method reads the temporarily stored user credentials and updates the actual store of user credentials. This should be called on successful onlnine login.
  */
 voltmx.sdk.offline.updateSuccessUserCredentials = function(providerName) {
     var tempUserObj = voltmx.sdk.dataStore.getItem("tempUserCredentials");
     if (tempUserObj != null && tempUserObj != undefined) voltmx.sdk.dataStore.setItem(getOfflineLoginDBKeyForProvider(providerName), tempUserObj);
     voltmx.sdk.dataStore.removeItem("tempUserCredentials");
 };
 /**
  *  Removes the user auth information from device store.
  */
 voltmx.sdk.offline.removeUserAuthInformation = function() {
     voltmx.sdk.dataStore.removeItem("authResponse");
 };
 /**
  *  This API removes the user credentials from the device store.
  */
 voltmx.sdk.offline.removeUserCredentials = function(providerName) {
     voltmx.sdk.dataStore.removeItem(getOfflineLoginDBKeyForProvider(providerName));
     voltmx.sdk.dataStore.removeItem("tempUserCredentials");
 };
 /**
  * Created by Tharalika Palakurthy
  */
 //SSO FFI functions
 voltmx.sdk.util.saveSSOToken = function(SSOToken) {
     if (typeof(SSOFFI) !== "undefined") {
         voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.saveSSOToken");
         var encryptedToken = voltmx.sdk.util.encryptSSOToken(SSOToken);
         return SSOFFI.saveToken(encryptedToken, voltmx.sdk.constants.SSO_TOKEN_KEY);
     } else {
         return null;
     }
 };
 voltmx.sdk.util.getSSOToken = function() {
     if (typeof(SSOFFI) !== "undefined") {
         voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.getSSOToken");
         var decryptedToken = SSOFFI.getToken(voltmx.sdk.constants.SSO_TOKEN_KEY);
         return voltmx.sdk.util.decryptSSOToken(decryptedToken);
     } else {
         return null;
     }
 };
 voltmx.sdk.util.deleteSSOToken = function() {
     if (typeof(SSOFFI) !== "undefined") {
         voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.deleteSSOToken");
         return SSOFFI.deleteToken(voltmx.sdk.constants.SSO_TOKEN_KEY);
     } else {
         return null;
     }
 };
 // initializeSSO function calls sendAppInstalledBroadcast from SSOFFI which
 // should be called in Pre-App init of the IDE app which sends a broadcast
 // for the new app installed.
 voltmx.sdk.util.initializeSSO = function() {
     if (typeof(SSOFFI) !== "undefined") {
         voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.initializeSSO");
         SSOFFI.sendAppInstalledBroadcast();
     } else {
         voltmx.sdk.logsdk.error("Error Occurred in voltmx.sdk.util.initializeSSO, SSOFFI cannot be null or undefined");
     }
 };
 /**
  * Returns a unique identifier for device to encrypt/decrypt sso token.
  * Android & iOS SDK is generating a UUID if not exist and share accross multiple applications.
  * This UUID is used as a secure key for encrypting/decrypting tokens.
  * @return {string}
  * @private
  */
 voltmx.sdk.util.getAndSaveUUIDforSSO = function() {
     var deviceUUID = SSOFFI.getToken(voltmx.sdk.constants.KEY_DEVICE_ID);
     if (voltmx.sdk.isNullOrUndefined(deviceUUID) || deviceUUID === "") {
         deviceUUID = voltmx.license.generateUUID().toString();
         SSOFFI.saveToken(deviceUUID, voltmx.sdk.constants.KEY_DEVICE_ID);
     }
     return deviceUUID;
 };
 var KNYMobileFabric = VMXFoundry = null;
 var KNYMetricsService = VMXMetricsService = null;
 var KNYMessagingService = VMXMessagingService = null;
 voltmx.setupsdks = function(initConfig, successCallBack, errorCallBack) {
     var acceptedSvcDoc = {};
     var acceptedMfAppMetaData = null;
     // Function to get appMetadata from cache if available else it should create metadata
     //  from appConfig in startup.js (metadata bundled by tools during build time)
     function getAppConfigFromCache() {
         var dsAppConfig;
         var dsAppData = null;
         var dsAppMetaData = null;
         var dsAppServiceDoc = null;
         // Clear app Meta data if developer has set voltmx.sdk.clearAppCredentials as true
         if (voltmx.sdk.clearAppCredentials === true) {
             voltmx.sdk.dataStore.removeItem(initConfig.appConfig.appId);
         } else {
             dsAppData = voltmx.sdk.dataStore.getItem(appConfig.appId);
             dsAppServiceDoc = voltmx.sdk.dataStore.getItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.MOBILE_FABRIC_SERVICE_DOC));
         }
         if (!voltmx.sdk.isNullOrUndefined(dsAppData)) {
             dsAppMetaData = JSON.parse(dsAppData);
         } else {
             voltmx.sdk.logsdk.debug("Failed to retrieve config data form Cache");
             return null;
         }
         //create meta data from retrieved cache
         if (!voltmx.sdk.isNullOrUndefined(dsAppMetaData)) {
             if (voltmx.sdk.util.isAppConfigEncrypted()) {
                 var appKey = voltmx.sdk.util.decryptAppConfig(dsAppMetaData.appKey);
                 var appSecret = voltmx.sdk.util.decryptAppConfig(dsAppMetaData.appSecret);
                 var serviceUrl = voltmx.sdk.util.decryptAppConfig(dsAppMetaData.serviceUrl);
                 if (!voltmx.sdk.isNullOrUndefined(appKey) || !voltmx.sdk.isNullOrUndefined(appSecret) || !voltmx.sdk.isNullOrUndefined(serviceUrl) || !voltmx.sdk.isNullOrUndefined(dsAppServiceDoc)) {
                     //update the decrypted values back in dsAppMetaData
                     dsAppMetaData.appKey = appKey;
                     dsAppMetaData.appSecret = appSecret;
                     dsAppMetaData.serviceUrl = serviceUrl;
                 } else {
                     voltmx.sdk.logsdk.debug("Failed to retrieve config data form Cache");
                     return null;
                 }
                 //decrypting the service doc here, to avoid data inconsistency
                 if (!voltmx.sdk.isNullOrUndefined(dsAppServiceDoc)) {
                     var decryptedSvcDoc = voltmx.sdk.util.decryptAppConfig(dsAppServiceDoc);
                     if (!voltmx.sdk.isNullOrUndefined(decryptedSvcDoc)) {
                         try {
                             dsAppServiceDoc = JSON.parse(decryptedSvcDoc);
                         } catch (err) {
                             voltmx.sdk.logsdk.debug("Failed to parse the service doc : ", err.toString());
                             return null;
                         }
                     } else {
                         voltmx.sdk.logsdk.debug("Failed to decrypt cached service doc");
                         return null;
                     }
                 } else {
                     voltmx.sdk.logsdk.debug("Failed to retrieve service doc form Cache");
                     return null;
                 }
             } else {
                 // App getting crashed while trying to parse encrypted AppServiceDoc data.
                 // To handle this scenario adding try catch and checking for salt key. If salt key is available
                 // setting flag to true and calling same getAppConfigFromCache() again to decrypt the data else returning null
                 try {
                     dsAppServiceDoc = JSON.parse(dsAppServiceDoc);
                 } catch (err) {
                     if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.dataStore.getItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.SHARED_CLIENT_IDENTIFIER)))) {
                         voltmx.sdk.logsdk.debug("Setting Encryption App Config flag to true");
                         voltmx.sdk.dataStore.setItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.ENCRYPTION_APPCONFIG_FLAG), true);
                         return getAppConfigFromCache();
                     } else {
                         voltmx.sdk.logsdk.debug("Failed to parse App Service Doc data form Cache" + err);
                         return null;
                     }
                 }
             }
         } else {
             voltmx.sdk.logsdk.debug("Failed to retrieve config data form Cache");
             return null;
         }
         dsAppConfig = {
             "dsAppMetaData": dsAppMetaData,
             "dsAppServiceDoc": dsAppServiceDoc
         };
         return dsAppConfig;
     }
     // Function to create an SDK object and set client params
     //  with client application's appId and appName
     function initializeVMXFoundryObject(appId, appName, appVersion) {
         var sdkObj = new voltmx.sdk();
         sdkObj.setClientParams({
             "aid": appId,
             "aname": appName,
             "aversion": appVersion
         });
         return sdkObj;
     }
     // Function to create session url (IST) for non-MF app
     function getLicenseUrl(appConfig) {
         var url = "";
         if (appConfig.isturlbase) {
             url = appConfig.isturlbase + "/IST";
         } else if (appConfig.secureurl) {
             url = getFromServerUrl(appConfig.secureurl, "IST");
         } else if (appConfig.url) {
             url = getFromServerUrl(appConfig.url, "IST");
         }
         return url;
     }
     // Function to create session url (IST) for non-MF app
     function getMetricsUrl(appConfig) {
         var url = "";
         if (appConfig.isturlbase) {
             url = appConfig.isturlbase + "/CMS";
         } else if (appConfig.secureurl) {
             url = getFromServerUrl(appConfig.secureurl, "CMS");
         } else if (appConfig.url) {
             url = getFromServerUrl(appConfig.url, "CMS");
         }
         return url;
     }
     // Function to make anonymous login if required.
     function callAnonymousLoginIfRequired(sdkObj) {
         if (voltmx.sdk.skipAnonymousCall) {
             // Enabling this flag to connect to any protected integration service.
             sdkObj.isAnonymousProvider = true;
         } else {
             var identityObject = sdkObj.getIdentityService("$anonymousProvider");
             identityObject.login(null, function(res) {
                 voltmx.sdk.logsdk.trace("Anonymous login finished successfully.");
             }, function(res) {
                 voltmx.sdk.logsdk.warn("Anonymous login finished with failure. \n" + JSON.stringify(res));
             });
         }
     };
     // Function to initialize Metrics Service for APM
     function initializeMetricsForAPM(sdkObj, eventTypes) {
         var metricsService = sdkObj.getMetricsService();
         if (!voltmx.sdk.isNullOrUndefined(metricsService)) {
             metricsService.setEventTracking(eventTypes);
         }
         return metricsService;
     }
     //Picking default values from startup.js
     acceptedSvcDoc = initConfig.appConfig.svcDoc;
     acceptedMfAppMetaData = {
         "appKey": initConfig.appKey,
         "appSecret": initConfig.appSecret,
         "serviceUrl": initConfig.serviceUrl
     };
     // Fetching data from cache
     var cachedAppConfig = getAppConfigFromCache();
     // Picking the latest appKey, appSecret and ServiceDoc for initialization
     // with respect to the latest published Foundry app, if cached.
     if (!voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(cachedAppConfig)) {
         var cachedSvcDoc = cachedAppConfig.dsAppServiceDoc;
         var cachedMfAppMetaData = cachedAppConfig.dsAppMetaData;
         // Checking for same Foundry app and version
         if ((cachedMfAppMetaData.appKey === initConfig.appKey) && (cachedMfAppMetaData.appSecret === initConfig.appSecret) && validateServiceUrls() && (Math.abs(parseFloat(appConfig.svcDoc.app_version) - parseFloat(cachedSvcDoc.app_version)) < 1e-9)) {
             var toolsBundledSvcDocEtagDateTime = new Date(parseInt(initConfig.appConfig.svcDoc.service_doc_etag, 16)).getTime();
             var cachedSvcDocEtagDateTime = new Date(parseInt(voltmx.sdk.dataStore.getItem(voltmx.sdk.constants.TOOLS_ETAG_ID), 16)).getTime();
             // Checking for latest published service doc
             if (cachedSvcDocEtagDateTime > toolsBundledSvcDocEtagDateTime) {
                 acceptedSvcDoc = cachedSvcDoc;
                 acceptedMfAppMetaData = cachedMfAppMetaData;
             } else {
                 voltmx.sdk.util.deleteMetadatafromDs();
             }
         } else {
             voltmx.sdk.util.deleteMetadatafromDs();
         }
     }
     //To validate both the service urls from cache and startup.js.
     function validateServiceUrls() {
         if (getBaseUrl(cachedMfAppMetaData.serviceUrl).toLowerCase() !== getBaseUrl(initConfig.serviceUrl).toLowerCase()) {
             return false;
         }
         if (getPathFromUrl(cachedMfAppMetaData.serviceUrl) !== getPathFromUrl(initConfig.serviceUrl)) {
             return false;
         }
         return true;
     }
     // To fetch base url from service url
     function getBaseUrl(serviceUrl) {
         var index = serviceUrl.indexOf("//");
         var baseUrl = "";
         // adding +2 to avoid double slash in the service url to get serviceUrl without hostname
         index = index + 2;
         var serviceUrlWithOutHostName = serviceUrl.substring(index);
         //fetching the baseurl substring from serviceUrl
         baseUrl = serviceUrl.substring(0, (serviceUrlWithOutHostName.indexOf("/")) + index);
         return baseUrl;
     }
     // To fetch remaining path from service url
     function getPathFromUrl(serviceUrl) {
         var remainingPath = serviceUrl.split(getBaseUrl(serviceUrl));
         return remainingPath[1];
     }
     // Initialize VMXFoundry Object
     if (VMXFoundry === null) {
         KNYMobileFabric = VMXFoundry = initializeVMXFoundryObject(initConfig.appConfig.appId, initConfig.appConfig.appName, initConfig.appConfig.appVersion);
     }
     if (initConfig && initConfig.appConfig && (getLicenseUrl(initConfig.appConfig) === "")) {
         if (voltmx.license && voltmx.license.setIsLicenseUrlAvailable) {
             voltmx.license.setIsLicenseUrlAvailable(false);
             voltmx.sdk.isLicenseUrlAvailable = false;
         }
     }
     try {
         // Pass the appkey, appSecret, SvcDoc to initWithServiceDoc
         VMXFoundry.initWithServiceDoc(acceptedMfAppMetaData.appKey, acceptedMfAppMetaData.appSecret, acceptedSvcDoc);
         // set eventtypes for APM
         KNYMetricsService = VMXMetricsService = initializeMetricsForAPM(KNYMobileFabric, initConfig.eventTypes);
         if (voltmx.sdk.getPlatformName() !== voltmx.sdk.constants.PLATFORM_THIN_CLIENT) {
             //Call anonymous login to avoid delay in first call invocation
             // or to avoid timing issues in case of parallel service calls at application startup.
             // This is an asynchronous call, and it is  good to have at this place. Can be removed if we see delays in App launch
             callAnonymousLoginIfRequired(VMXFoundry);
         }
         // call successcallback if exists
         voltmx.sdk.verifyAndCallClosure(successCallBack, VMXFoundry);
     } catch (error) {
         // call errorcallback
         var errorMsg = error ? error.toString() : "";
         voltmx.print("Error in setupsdks " + errorMsg);
         voltmx.sdk.verifyAndCallClosure(errorCallBack, error);
     }
 };
 /*
     // An example to show the usage of invokeEASMetaServiceWithLiteInit
 	var appCredentials = {
 					"appKey":"40c6c885d62f0981f115badb25b79e17",
 					"appSecret":"463e9450bbe238d58b75449370dc1b84",
 					"serviceUrl":"https://100000010.auth.sit2-hclvoltmx.net/appconfig"
 	};
 	// dataObject is optional in this case(GET Operation).
 	// Not necessary if you are passing other values in options like oDataUrl and objectName.
 	var mDataObject = new voltmx.sdk.dto.DataObject("Employee", {});
 	var versionCheckOptions = {
 					"serviceName":"EmployeeModelSchema",
 					"objectName":"Employee",
 					"headers": {},
 					"params":{  "dataObject":mDataObject,  //dataObject is optional
 								"queryParams": {},
 								"oDataUrl": ""
 						}
 	};
 	versionCheckSuccessCallback = function(serviceResponse) {
       alert(JSON.stringify(serviceResponse))
     }
     versionCheckErrorCallback = function(serviceResponse) {
       alert(JSON.stringify(serviceResponse))
     }

     function checkLatestAppversionFromEAS(){
       voltmx.invokeEASMetaServiceWithLiteInit(appCredentials, versionCheckOptions, versionCheckSuccessCallback, versionCheckErrorCallback);
     }
  checkLatestAppversionFromEAS();
 */
 voltmx.invokeEASMetaServiceWithLiteInit = function(appCredentials, versionCheckOptions, versionCheckSuccessCallback, versionCheckFailureCallback) {
     var claimsToken = null;
     var networkProvider = new voltmxNetworkProvider();
     // calling lite_init, which does not impact the child apps servicedoc. as it won't save any metadata
     lite_init(appCredentials, function(svcDoc) {
         var svcObj = null;
         if (svcDoc && typeof(svcDoc.services_meta) === 'object') {
             svcObj = svcDoc.services_meta[versionCheckOptions["serviceName"]];
         }
         // check if the service exists in the Mf app.
         if (!voltmx.sdk.isNullOrUndefined(svcObj)) {
             var identitySelfLoginUrl = svcDoc.selflink.replace("/appconfig", "/login");
             // get Claims Token to make a service call
             getClaimsToken(identitySelfLoginUrl, appCredentials, function(token) {
                 // Make Service call to check new version
                 claimsToken = token;
                 fetchCurrentVersion(svcObj, versionCheckOptions["objectName"], versionCheckOptions["headers"], versionCheckOptions["params"], function(versionResponse) {
                     versionCheckSuccessCallback(versionResponse);
                 }, function(integrationError) {
                     versionCheckFailureCallback(integrationError);
                 });
             }, function(identityError) {
                 versionCheckFailureCallback(identityError);
             });
         } else {
             // Service doesn't exist, we are creating a custom error object
             var error = {};
             error[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.invalid_user_app_services;
             error[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.invalid_user_app_services;
             error[voltmx.sdk.constants.MF_ERROR_MSG] = "Service name '" + versionCheckOptions["serviceName"] + "' doesn't exist.";
             versionCheckFailureCallback(error);
         }
     }, function(initError) {
         versionCheckFailureCallback(initError);
     });

     function lite_init(appCredentials, successCallback, errorCallback) {
         if (!(appCredentials && appCredentials.appKey && appCredentials.appSecret && appCredentials.serviceUrl)) {
             voltmx.sdk.verifyAndCallClosure(errorCallback, "Invalid initialization parameters passed. Please check appKey, appSecret and ServiceUrl parameters");
             return;
         }
         networkProvider = new voltmxNetworkProvider();
         var serviceUrl = appCredentials.serviceUrl.trim();
         // to handle http integrity in network calls
         var options = {};
         options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
         options[voltmx.sdk.constants.IS_APP_CONFIG_CALL] = true;
         var headers = {};
         headers[voltmx.sdk.constants.APP_KEY_HEADER] = appCredentials.appKey;
         headers[voltmx.sdk.constants.APP_SECRET_HEADER] = appCredentials.appSecret;
         headers[voltmx.sdk.constants.HTTP_OVERRIDE_HEADER] = "GET";
         //Resetting the value.
         voltmx.sdk.setFoundryAppVersion(null);
         networkProvider.post(serviceUrl, {}, headers, function(data) {
             data = voltmx.sdk.formatSuccessResponse(data);
             successCallback(data);
         }, function(data) {
             errorCallback(data);
         }, null, null);
     }

     function getClaimsToken(endPointUrl, appCredentials, claimsSuccessCallback, claimsFailureCallback) {
         var headers = {};
         headers[voltmx.sdk.constants.APP_KEY_HEADER] = appCredentials.appKey;
         headers[voltmx.sdk.constants.APP_SECRET_HEADER] = appCredentials.appSecret;
         headers[voltmx.sdk.constants.SDK_TYPE_HEADER] = voltmx.sdk.getSdkType();
         headers[voltmx.sdk.constants.SDK_VERSION_HEADER] = voltmx.sdk.version;
         headers[voltmx.sdk.constants.PLATFORM_TYPE_HEADER] = voltmx.sdk.getPlatformName();
         headers[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
         headers[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_FORM_URL_ENCODED;
         networkProvider.post(endPointUrl, {}, headers, function(data) {
             data = voltmx.sdk.formatSuccessResponse(data);
             claimsToken = data.claims_token.value;
             claimsSuccessCallback(data.claims_token.value)
         }, function(errorResponse) {
             claimsFailureCallback(errorResponse);
         }, null, null);
     }

     function mergeHeaders(defaultHeaders, headers) {
         // if the user has defined his own headers, use them
         if (!voltmx.sdk.isNullOrUndefined(headers)) {
             if ((Object.keys(headers)).length !== 0 && typeof(headers) === "object") {
                 var defaultKeys = Object.keys(defaultHeaders);
                 var lowerCaseHeaders = defaultKeys.map(function(x) {
                     return x.toLowerCase()
                 });
                 for (var header in headers) {
                     var headerConst = header;
                     if (lowerCaseHeaders.indexOf(headerConst.toLowerCase()) !== -1) {
                         for (var i = 0; i < defaultKeys.length; i++) {
                             var tempKey = defaultKeys[i];
                             if (tempKey.toLowerCase() === headerConst.toLowerCase()) {
                                 defaultHeaders[tempKey] = headers[header];
                             }
                         }
                     } else {
                         defaultHeaders[header] = headers[header];
                     }
                 }
             }
         }
         return defaultHeaders;
     }

     function fetchCurrentVersion(serviceObj, objectName, headers, versionCheckOptions, onSuccess, onFailure) {
         if (versionCheckOptions && !voltmx.sdk.isNullOrUndefined(headers) && voltmx.sdk.isNullOrUndefined(versionCheckOptions["headers"])) {
             versionCheckOptions["headers"] = headers;
         }
         var tmpDataUrl = encodeURI(stripTrailingCharacter(serviceObj["url"] + "/objects/", "/"));
         _fetch(serviceObj, objectName, versionCheckOptions, tmpDataUrl, onSuccess, onFailure);
     }

     function _fetch(serviceObj, objectName, options, tmpDataUrl, successCallback, serviceErrorCallback) {
         var dataObject = options["dataObject"];
         var odataqueryStr = voltmx.sdk.isNullOrUndefined(dataObject) ? null : dataObject.getOdataUrl();
         if (voltmx.sdk.isNullOrUndefined(odataqueryStr)) {
             odataqueryStr = options["oDataUrl"];
         }
         var headers = options["headers"];
         var queryParams = options["queryParams"];
         var url = tmpDataUrl + "/" + objectName;
         var version = null;
         if (serviceObj) {
             version = serviceObj["version"];
         }
         if (!voltmx.sdk.isNullOrUndefined(odataqueryStr)) {
             if (odataqueryStr.charAt(0) === '$') {
                 odataqueryStr = odataqueryStr.substring(1);
             }
             var odatastr = "";
             var odataList = odataqueryStr.split(/&\$(?=(?:(?:[^']*'){2})*[^']*$)/g);
             for (var list of odataList) {
                 var olist = list.split(/=(?=(?:(?:[^']*'){2})*[^']*$)/g)
                 odatastr = odatastr + "&$" + olist[0] + "=" + encodeURIComponent(olist[1]);
             }
             if (odatastr.charAt(0) === '&') {
                 odatastr = odatastr.substring(1);
             }
             url = url + "?" + odatastr;
             if (!voltmx.sdk.isNullOrUndefined(queryParams)) {
                 url = url + "&" + voltmx.sdk.util.objectToQueryParams(queryParams);
             }
         } else if (!voltmx.sdk.isNullOrUndefined(queryParams)) {
             url = url + "?" + voltmx.sdk.util.objectToQueryParams(queryParams);
         }
         if (!headers) {
             //if headers not sent by the deveolper
             headers = {};
         }
         var isVoltmxApiVersionAvailable = false;
         //check for x-voltmx-api-version case insensitive
         for (var header in headers) {
             if (header !== null && header !== 'undefined') {
                 if (header.toLowerCase() === voltmx.sdk.constants.API_VERSION_HEADER.toLowerCase()) isVoltmxApiVersionAvailable = true
             }
         }
         if (!isVoltmxApiVersionAvailable) {
             headers[voltmx.sdk.constants.API_VERSION_HEADER] = version;
         }
         invokeObjectOperation(url, objectName, headers, null, voltmx.sdk.constants.HTTP_METHOD_GET, function(response) {
             voltmx.sdk.verifyAndCallClosure(successCallback, response);
         }, function(error) {
             voltmx.sdk.verifyAndCallClosure(serviceErrorCallback, error);
         }, voltmx.sdk.util.checkAndFetchNetworkProviderOptions(options));
     }

     function invokeObjectOperation(url, svcid, headers, formData, httpMethod, successCallback, failureCallback, networkProviderOptions) {
         var networkProvider = new voltmxNetworkProvider();
         //var reportingData = voltmx.sdk.getEncodedReportingParamsForSvcid(svcid);
         var defaultHeaders = {};
         if (!httpMethod) {
             //default http method is post
             httpMethod = "POST";
         }
         defaultHeaders[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = claimsToken;
         defaultHeaders[voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
         defaultHeaders[voltmx.sdk.constants.HTTP_CONTENT_HEADER] = voltmx.sdk.constants.CONTENT_TYPE_JSON;
         var deviceId = voltmx.sdk.getDeviceId();
         if (!voltmx.sdk.isNullOrUndefined(deviceId)) {
             defaultHeaders[voltmx.sdk.constants.DEVICEID_HEADER] = deviceId;
         }
         // if the user has defined his own headers, use them
         if (headers) {
             var tempHeader = "";
             for (var header in headers) {
                 if (voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT.toLowerCase() === header.toLowerCase()) {
                     //Accept can be multiple
                     //Reason being client can be programmed to accept more than one type of content from server.
                     tempHeader = voltmx.sdk.constants.HTTP_REQUEST_HEADER_ACCEPT;
                     if (defaultHeaders[tempHeader].toLowerCase() !== headers[header].toLowerCase()) {
                         defaultHeaders[header] = defaultHeaders[tempHeader] + "," + headers[header];
                     }
                 } else if (voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER.toLowerCase() === header.toLowerCase()) {
                     tempHeader = voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER;
                     if (defaultHeaders[tempHeader] !== headers[header]) {
                         defaultHeaders[tempHeader] = headers[header];
                     }
                 } else if ("content-type" === header.toLowerCase()) {
                     tempHeader = voltmx.sdk.constants.HTTP_CONTENT_HEADER;
                     //Content-type can and should be a single value.
                     //Reason being client can only send a single kind of content at a single instance
                     if (defaultHeaders[tempHeader].toLowerCase() !== headers[header].toLowerCase()) {
                         defaultHeaders[tempHeader] = headers[header];
                     }
                 } else {
                     if (defaultHeaders[header] !== headers[header]) {
                         defaultHeaders[header] = headers[header];
                     }
                 }
             }
         }

         function networksuccess(res) {
             voltmx.sdk.verifyAndCallClosure(successCallback, res);
         }

         function networkerror(xhr, status, err) {
             if (xhr && !(status && err)) {
                 err = xhr;
             }
             voltmx.sdk.verifyAndCallClosure(failureCallback, voltmx.sdk.error.getObjectServiceErrObj(err));
         }
         if (httpMethod === "GET") {
             networkProvider.get(url, null, defaultHeaders, networksuccess, networkerror, "formdata", networkProviderOptions);
         } else {
             networkProvider.post(url, formData, defaultHeaders, networksuccess, networkerror, "formdata", networkProviderOptions);
         }
     }
 };
 voltmx.sdk.util = voltmx.sdk.util || {};

 function voltmxLogger() {
     this.log = function(text) {
         if (voltmx.sdk.isDebugEnabled) {
             voltmx.print(text);
         }
     }
 }
 /**
  * Flag used to override the network availability api for automation testing.
  * @type {boolean}
  */
 overrideNetworkFlag = false;
 /**
  *	Utility Method for the application to check the network availability.
  */
 voltmx.sdk.isNetworkAvailable = function() {
     //Check the network flag if set for testing. This would mandate the application to be offline if device has network connectivity.
     if (overrideNetworkFlag !== undefined && overrideNetworkFlag !== null && overrideNetworkFlag && overrideNetworkFlag === true) return false;
     return voltmx.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY);
 };
 /**
  *	Utility method to set the network flag for offline testing.
  */
 voltmx.sdk.overrideNetworkFlag = function() {
     overrideNetworkFlag = true;
 };
 /**
  *	Utility method to reset the network flag set for offline testing.
  */
 voltmx.sdk.resetNetworkFlag = function() {
     overrideNetworkFlag = false;
     overrideNetworkFlag = undefined;
 };
 voltmx.sdk.overrideAnonymousLoginFlag = function() {
     voltmx.sdk.skipAnonymousCall = true;
 };
 voltmx.sdk.resetAnonymousLoginFlag = function() {
     voltmx.sdk.skipAnonymousCall = false;
 };

 function voltmxNetworkProvider() {
     this.post = function(url, params, headers, successCallback, failureCallback, voltmxContentType, options) {
         if (voltmx.sdk.util.isNullOrEmptyString(url)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, "url cannot be null or empty");
             return;
         }
         //Appending global params
         if (voltmx.sdk.isNullOrUndefined(params)) {
             params = {};
         }
         if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.currentInstance)) {
             url = voltmx.sdk.currentInstance.appendGlobalParams(url, headers, params);
         }
         voltmxNetHttpRequest(url, params, headers, "POST", voltmxContentType, successCallback, failureCallback, options);
     };
     this.put = function(url, params, headers, successCallback, failureCallback, voltmxContentType, options) {
         if (voltmx.sdk.util.isNullOrEmptyString(url)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, "url cannot be null or empty");
             return;
         }
         //Appending global params
         if (voltmx.sdk.isNullOrUndefined(params)) {
             params = {};
         }
         if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.currentInstance)) {
             url = voltmx.sdk.currentInstance.appendGlobalParams(url, headers, params);
         }
         voltmxNetHttpRequest(url, params, headers, "PUT", voltmxContentType, successCallback, failureCallback, options);
     };
     this.invokeDeleteRequest = function(url, params, headers, successCallback, failureCallback, voltmxContentType, options) {
         if (voltmx.sdk.util.isNullOrEmptyString(url)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, "url cannot be null or empty");
             return;
         }
         //Appending global params
         if (voltmx.sdk.isNullOrUndefined(params)) {
             params = {};
         }
         if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.currentInstance)) {
             url = voltmx.sdk.currentInstance.appendGlobalParams(url, headers, params);
         }
         voltmxNetHttpRequest(url, params, headers, "DELETE", voltmxContentType, successCallback, failureCallback, options);
     };
     //postSync will only work for Richclients like Android,IOS
     this.postSync = function(url, params, headers) {
         if (voltmx.sdk.util.isNullOrEmptyString(url)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, "url cannot be null or empty");
             return;
         }
         //Appending global params
         if (voltmx.sdk.isNullOrUndefined(params)) {
             params = {};
         }
         if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.currentInstance)) {
             url = voltmx.sdk.currentInstance.appendGlobalParams(url, headers, params);
         }
         return voltmxNetHttpRequestSync(url, params, headers);
     };
     this.get = function(url, params, headers, successCallback, failureCallback, voltmxContentType, options) {
         if (voltmx.sdk.util.isNullOrEmptyString(url)) {
             voltmx.sdk.verifyAndCallClosure(failureCallback, "url cannot be null or empty");
             return;
         }
         //Appending global params
         if (voltmx.sdk.isNullOrUndefined(params)) {
             params = {};
         }
         if (!voltmx.sdk.isNullOrUndefined(voltmx.sdk.currentInstance)) {
             url = voltmx.sdk.currentInstance.appendGlobalParams(url, headers, params);
         }
         voltmxNetHttpRequest(url, null, headers, "GET", voltmxContentType, successCallback, failureCallback, options);
     }
 }

 function voltmxNetHttpRequest(url, params, headers, httpMethod, voltmxContentType, successCallback, failureCallback, options) {
     // give failure call back if network is not available
     if (!voltmx.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
         var errorObj = {};
         errorObj.httpresponse = {};
         errorObj[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.connectivity_error_code;
         errorObj[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.connectivity_error_code;
         errorObj[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.connectivity_error_message;
         errorObj.httpresponse.headers = {};
         errorObj.httpresponse.url = url;
         failureCallback(errorObj);
         return;
     }
     var paramsTable = null;
     var httpRequest;
     if (options && options["httpRequestOptions"] && options["httpRequestOptions"] instanceof Object) {
         httpRequest = new voltmx.net.HttpRequest(options["httpRequestOptions"]);
     } else {
         httpRequest = new voltmx.net.HttpRequest();
     }
     if (options && options["queryParams"] && options["queryParams"] instanceof Object) {
         url = addQueryParamsToURL(url, options["queryParams"]);
     }
     // check for the deprecated property if set in appmiddlewaresecureinvokerasync() API
     if (options && options["httpconfig_old"]) {
         if (options["httpconfig_old"]["timeout"]) {
             httpRequest.timeout = options["httpconfig_old"]["timeout"] * 1000;
         }
     }
     // As older versions of IE doesn't have xmlHttpRequest2, and it doesn't support "withCredentials" property
     // We put a check to handle a crash. Cookies will not be transferred in CORS request for IE due to this restriction
     if (typeof(XMLHttpRequest) !== "undefined" && "withCredentials" in (new XMLHttpRequest()) && options && options["xmlHttpRequestOptions"] && options["xmlHttpRequestOptions"]["enableWithCredentials"] === true) {
         httpRequest.enableWithCredentials = true;
     }
     var isInvalidResponse = false;
     //if httpmethod is not provided falling back to POST
     if (!httpMethod) {
         httpMethod = constants.HTTP_METHOD_POST;
     }
     httpRequest.open(httpMethod, url);

     function localRequestCallback(result) {
         var readyState = Number(httpRequest.readyState.toString());
         var status = Number(httpRequest.status.toString());
         var response = {};
         if (readyState === 4) {
             var responseHeaders = httpRequest.getAllResponseHeaders();
             //If response headers has X-Voltmx-Passthrough, ignoring parsing the response content. With this, passthrough flag
             //is optional for passthrough services and will be deprecated in future releases
             if (responseHeaders && (responseHeaders.hasOwnProperty(voltmx.sdk.constants.PASSTHROUGH_RESPONSE_HEADER.toLowerCase()) || responseHeaders.hasOwnProperty(voltmx.sdk.constants.PASSTHROUGH_RESPONSE_HEADER)) && (voltmx.sdk.convertPassthroughResponseToJson !== true)) {
                 response.rawResponse = result.response;
             } else if (options && options[voltmx.sdk.constants.PASSTHROUGH] && voltmx.sdk.convertPassthroughResponseToJson !== true) {
                 //If option "passthrough" is enabled then SDK will not parse the result from backend.
                 response.rawResponse = result.response;
             } else {
                 //parseHttpResponse parse response based on the content-type response header
                 var parsedResp = parseHttpResponse(httpRequest);
                 if (parsedResp.isRawResponse) {
                     response.rawResponse = parsedResp.response;
                 } else {
                     response = parsedResp.response;
                 }
                 isInvalidResponse = parsedResp.isInvalidResponse;
             }
             voltmx.sdk.setLogLevelFromServerResponse(responseHeaders);
             if (response && !isInvalidResponse) {
                 response.httpresponse = {};
                 response.httpresponse.headers = responseHeaders;
                 response.httpresponse.url = url;
                 response.httpresponse.responsecode = status;
             }
             if (isInvalidResponse || (!response && status >= 200 && status < 300)) {
                 var errorMessage = {};
                 errorMessage.httpresponse = {};
                 errorMessage[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.invalid_json_code;
                 errorMessage[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.invalid_json_message;
                 errorMessage[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.invalid_json_code;
                 errorMessage[voltmx.sdk.constants.HTTP_STATUS_CODE] = status;
                 errorMessage.httpresponse["response"] = parsedResp.response;
                 errorMessage.httpresponse.headers = responseHeaders;
                 errorMessage.httpresponse.url = url;
                 errorMessage.httpresponse.responsecode = status;
                 failureCallback(errorMessage);
             } else if (status >= 200 && status < 300) {
                 if (!response.opstatus) {
                     response.opstatus = 0;
                 }
                 if (response.opstatus == 0 || (response.opstatus >= 500100 && response.opstatus <= 500200)) {
                     if (responseHeaders && (responseHeaders.hasOwnProperty(voltmx.sdk.constants.PASSTHROUGH_RESPONSE_HEADER.toLowerCase()) || responseHeaders.hasOwnProperty(voltmx.sdk.constants.PASSTHROUGH_RESPONSE_HEADER))) {
                         validateIntegrityAndHandleCallbackInvocation(response);
                     } else if (options && (options[voltmx.sdk.constants.DISABLE_INTEGRITY] || options[voltmx.sdk.constants.PASSTHROUGH] || options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY])) {
                         successCallback(response);
                     } else {
                         validateIntegrityAndHandleCallbackInvocation(response);
                     }
                 } else {
                     failureCallback(response);
                 }
             } else {
                 invokeNetworkErrorCallback(url, httpRequest, response, status);
             }

             function invokeNetworkErrorCallback(url, httpRequest, response, status) {
                 var errorObj = {};
                 errorObj.httpresponse = {};
                 if (status == 408) {
                     errorObj[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.request_timed_out_code;
                     errorObj[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.request_timed_out_code;
                     errorObj[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.request_timed_out_message;
                 } else if (status == 503) {
                     errorObj[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.service_unavailable;
                     errorObj[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.service_unavailable;
                     errorObj[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.service_unavailable_message;
                 } else if (status == 504) {
                     errorObj[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.connection_timeout;
                     errorObj[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.connection_timeout;
                     errorObj[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.connection_timeout_message;
                 } else if ((status > 99) && (!voltmx.sdk.isNullOrUndefined(response))) {
                     errorObj = response;
                 } else {
                     errorObj[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.connectivity_error_code;
                     errorObj[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.connectivity_error_code;
                     errorObj[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.connectivity_error_message;
                 }
                 errorObj[voltmx.sdk.constants.HTTP_STATUS_CODE] = status;
                 errorObj.httpresponse.headers = httpRequest.getAllResponseHeaders();
                 errorObj.httpresponse.url = url;
                 failureCallback(errorObj);
             }

             function validateIntegrityAndHandleCallbackInvocation(response) {
                 if (typeof(voltmxRef) !== "undefined" && voltmxRef && voltmxRef.mainRef.integrityKey === true) {
                     if (response.httpresponse.headers.hasOwnProperty(voltmx.sdk.constants.INTEGRITY_HEADER) || response.httpresponse.headers.hasOwnProperty(voltmx.sdk.constants.INTEGRITY_HEADER.toLowerCase())) {
                         if (!(voltmx.sdk.isNullOrUndefined(httpRequest.integrityStatus))) {
                             var integrityStatus = parseInt(httpRequest["integrityStatus"].toString());
                             switch (integrityStatus) {
                                 case constants.HTTP_INTEGRITY_CHECK_NOT_DONE:
                                     failureCallback(voltmx.sdk.error.getIntegrityErrorMessage(httpRequest, url));
                                     break;
                                 case constants.HTTP_INTEGRITY_CHECK_SUCCESSFUL:
                                     successCallback(response);
                                     break;
                                 case constants.HTTP_INTEGRITY_CHECK_FAILED:
                                     //With V9-P2 release, for binary calls integrity check happens on random string.
                                     //With V8 client and V9 server, integrity check will fail for binary. So based on
                                     //ignoreintegrity flag calling successcallback as these calls happens to be binary.
                                     if (!voltmx.sdk.isNullOrUndefined(options) && options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY]) {
                                         successCallback(response);
                                     } else {
                                         failureCallback(voltmx.sdk.error.getIntegrityErrorMessage(httpRequest, url));
                                     }
                                     break;
                             }
                         } else {
                             failureCallback(voltmx.sdk.error.getIntegrityErrorMessage(httpRequest, url));
                         }
                     } else if (options && options != null && options[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY]) {
                         successCallback(response);
                     } else {
                         failureCallback(voltmx.sdk.error.getIntegrityErrorMessage(httpRequest, url));
                     }
                 } else {
                     successCallback(response);
                 }
             }
         }
     }
     if (voltmxContentType === "application/json") {
         if (params) {
             paramsTable = JSON.stringify(params);
         }
     } else if (voltmxContentType == "formdata" || voltmxContentType == "multipart") {
         //for specific requests like object services we will send formdata through form encoding mechanism.
         if (params) {
             //for object services we are getting voltmx.net.FormData so using the same.
             paramsTable = params;
         }
     } else {
         //preparing params for other than object services
         var firstKey = true;
         for (var key in params) {
             if (firstKey) {
                 paramsTable = new voltmx.net.FormData();
                 firstKey = false;
             }
             if (typeof(params[key]) != "undefined") {
                 if (typeof(params[key]) !== "string") {
                     params[key] = JSON.stringify(params[key]);
                 }
                 paramsTable.append((key), (params[key]));
             }
         }
     }
     if (headers) {
         for (var key in headers) {
             httpRequest.setRequestHeader(key, headers[key]);
         }
     } else {
         httpRequest.setRequestHeader(voltmx.sdk.constants.HTTP_CONTENT_HEADER, voltmx.sdk.constants.CONTENT_TYPE_JSON);
     }
     httpRequest.onReadyStateChange = localRequestCallback;
     if ((typeof(voltmxRef) !== "undefined" && voltmxRef && voltmxRef.mainRef.integrityKey === true) || (!voltmx.sdk.isNullOrUndefined(options) && options.isAppConfigCall === true)) {
         var properties = voltmxRef.mainRef.integrityParams;
         try {
             //check is for windows 8.x and Kiosk platforms,which doesn't support integrity
             if (voltmx.sdk.constants.SET_INTEGRITY_CHECK in voltmx.net) {
                 voltmx.net.setIntegrityCheck(properties);
             }
         } catch (e) {
             voltmx.sdk.logsdk.warn("Invalid Integrity properties received");
             throw "Invalid Integrity properties received";
         }
     } else {
         if ((options && (options[voltmx.sdk.constants.DISABLE_INTEGRITY] || options[voltmx.sdk.constants.PASSTHROUGH])) || ((typeof(voltmxRef) !== "undefined" && voltmxRef && voltmxRef.mainRef.integrityKey === false) || (!voltmx.sdk.isNullOrUndefined(options) && options.isAppConfigCall === false))) {
             //mesasging service and pass through enabled integration svc doesn't support http message body integrity
             //if integrity is enabled earlier,remove integrity
             //check is for windows 8.x and Kiosk platforms,which doesn't support integrity
             if (voltmx.sdk.constants.DISABLE_INTEGRITY_CHECK in httpRequest) {
                 httpRequest.disableIntegrityCheck = true;
             } else if (voltmx.sdk.constants.REMOVE_INTEGRITY_CHECK in voltmx.net) {
                 voltmx.net.removeIntegrityCheck();
             }
         } else {
             //check is for windows 8.x and Kiosk platforms,which doesn't support integrity
             if (voltmx.sdk.constants.DISABLE_INTEGRITY_CHECK in httpRequest) {
                 httpRequest.disableIntegrityCheck = true;
             } else if (voltmx.sdk.constants.REMOVE_INTEGRITY_CHECK in voltmx.net) {
                 voltmx.net.removeIntegrityCheck();
             }
         }
     }
     if (paramsTable) {
         httpRequest.send(paramsTable);
     } else {
         httpRequest.send();
     }
     /**
      * copied from spa_offlineobjects/KSUtils/KSNetworkUtils.js
      * Method to add the query parameters after URI encoding to the URL.
      * @param {string} url URL to which the query params are to be appended.
      * @param {Object} queryParams JSON object containing the query parameters.
      */
     function addQueryParamsToURL(url, queryParams) {
         if (queryParams && Object.keys(queryParams).length > 0) {
             var encodedQueryParams = "";
             var ampersandSubstring = "&";
             for (var key in queryParams) {
                 encodedQueryParams += key + "=" + encodeURIComponent(queryParams[key]) + ampersandSubstring;
             }
             //Remove the trailing ampersand for the last key-value pair..
             encodedQueryParams = encodedQueryParams.slice(0, -1);
             //Check if the URL has query params already..
             if (url.indexOf('?') > -1) {
                 url += "&" + encodedQueryParams;
             } else {
                 url += "?" + encodedQueryParams;
             }
         }
         return url;
     }
 }

 function voltmxNetHttpRequestSync(url, params, headers) {
     var paramsTable = null;
     var httpRequest = new voltmx.net.HttpRequest();
     var isInvalidJSON = false;
     httpRequest.open(constants.HTTP_METHOD_POST, url, false);
     var firstKey = true;
     for (var key in params) {
         if (firstKey) {
             paramsTable = new voltmx.net.FormData();
             firstKey = false;
         }
         if (typeof(params[key]) != "undefined") {
             if (typeof(params[key]) !== "string") {
                 params[key] = JSON.stringify(params[key]);
             }
             paramsTable.append((key), (params[key]));
         }
     }
     if (headers) {
         for (var key in headers) {
             httpRequest.setRequestHeader(key, headers[key]);
         }
     } else {
         httpRequest.setRequestHeader(voltmx.sdk.constants.HTTP_CONTENT_HEADER, voltmx.sdk.constants.CONTENT_TYPE_JSON);
     }
     //httpRequest.onReadyStateChange = localRequestCallback;
     httpRequest.send(paramsTable);
     var response = null;
     var status = Number(httpRequest.status.toString());
     voltmx.sdk.setLogLevelFromServerResponse(httpRequest.getAllResponseHeaders());
     if (httpRequest.response) {
         response = httpRequest.response;
     }
     if (response && typeof(response) === 'string') {
         if (voltmx.sdk.isJson(response)) {
             response = JSON.parse(response);
         } else {
             isInvalidJSON = true;
         }
     }
     if (response && !(isInvalidJSON)) {
         response.httpresponse = {};
         response.httpresponse.headers = httpRequest.getAllResponseHeaders();
         response.httpresponse.url = url;
         response.httpresponse.responsecode = status;
     }
     if (isInvalidJSON || (!response && status >= 200 && status < 300)) {
         var errorMessage = {};
         errorMessage.httpresponse = {};
         errorMessage[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.invalid_json_code;
         errorMessage[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.invalid_json_message;
         errorMessage[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.invalid_json_code;
         errorMessage[voltmx.sdk.constants.HTTP_STATUS_CODE] = status;
         errorMessage.httpresponse["response"] = response;
         errorMessage.httpresponse.headers = httpRequest.getAllResponseHeaders();
         errorMessage.httpresponse.url = url;
         errorMessage.httpresponse.responsecode = status;
         return errorMessage;
     } else if (status >= 200 && status < 300) {
         if (!response.opstatus) {
             response.opstatus = 0;
         }
         return response;
     } else {
         var resultTable = {};
         if (response) {
             resultTable = response;
             resultTable.httpStatusCode = httpRequest.status.toString();
         } else {
             resultTable[voltmx.sdk.constants.MF_OPSTATUS] = voltmx.sdk.errorcodes.connectivity_error_code;
             resultTable[voltmx.sdk.constants.MF_ERROR_CODE] = voltmx.sdk.errorcodes.connectivity_error_code;
             resultTable[voltmx.sdk.constants.MF_ERROR_MSG] = voltmx.sdk.errormessages.connectivity_error_message;
         }
         return resultTable;
     }
 }

 function voltmxDataStore() {
     //voltmx.sdk.logsdk.trace("Setting voltmxDataStore");
     this.setItem = function(key, value) {
         if (typeof(key) !== "string") {
             throw new Exception(voltmx.sdk.errorConstants.DATA_STORE_EXCEPTION, "Invalid Key");
         } else {
             try {
                 key = key.replace(/\//gi, "");
                 voltmx.store.setItem(key, value);
             } catch (e) {
                 voltmx.sdk.logsdk.error("Failed to set item in dtastore:" + e);
             }
         }
     };
     this.getItem = function(key) {
         voltmx.sdk.logsdk.debug("Getting item for key:" + key);
         if (typeof(key) !== "string") {
             throw new Exception(voltmx.sdk.errorConstants.DATA_STORE_EXCEPTION);
         } else {
             key = key.replace(/\//gi, "");
             var value = voltmx.store.getItem(key);
             if (value === null || value === undefined) {
                 voltmx.sdk.logsdk.debug("No value found with key:" + key);
                 return null;
             } else {
                 return value;
             }
         }
     };
     this.removeItem = function(key) {
         voltmx.sdk.logsdk.debug("Removing item for key:" + key);
         if (typeof(key) !== "string") {
             throw new Exception(Error.DATA_STORE_EXCEPTION);
         } else {
             key = key.replace(/\//gi, "");
             voltmx.store.removeItem(key); //If no item with that key exists, the method does not perform any action. Thus no need to check for key availablity.
         }
     };
     this.destroy = function() {
         voltmx.sdk.logsdk.info("Destroying data store for this app");
         voltmx.store.clear();
     };
     this.getAllItems = function() {
             voltmx.sdk.logsdk.info("Getting all item from data store");
             var items = {};
             var len = voltmx.store.length(); //get key length
             for (var i = 0; i < len; i++) {
                 var key = voltmx.store.key(i); //get ith key
                 var value = voltmx.store.getItem(key); //get value
                 items[key] = value; //prepare itemset
             }
             return items;
         }
         /**
          * This method first encrypt the value and save encrypted value against the given key
          * @param key
          * @param value -can accept JSON(converts to string) or plain string only
          */
     this.setSecureItem = function(key, value) {
             voltmx.sdk.logsdk.info("saving data after encryption of plain data");
             if (voltmx.sdk.util.isJsonObject(value)) {
                 value = JSON.stringify(value);
             }
             var encryptionKey = [voltmx.sdk.util.getSharedClientId()];
             var encryptionAlgorithm = voltmx.sdk.constants.ENCRYPTION_ALGO_AES;
             var securedValue = voltmx.sdk.util.encryptText(value, encryptionKey, encryptionAlgorithm);
             this.setItem(key, securedValue);
         }
         /**
          * This method retrieves saved encrypted value and decrypt it into original value
          * @param key
          * @returns {*} can return JSON if value is parsed or string otherwise
          */
     this.getSecureItem = function(key) {
         voltmx.sdk.logsdk.info("retrieving encrypted data as plain data");
         var value = this.getItem(key);
         var encryptionKey = [voltmx.sdk.util.getSharedClientId()];
         var decryptionAlgorithm = voltmx.sdk.constants.ENCRYPTION_ALGO_AES;
         var securedValue = voltmx.sdk.util.decryptText(value, encryptionKey, decryptionAlgorithm);
         if (voltmx.sdk.isJson(securedValue)) {
             securedValue = JSON.parse(securedValue);
         }
         return securedValue;
     }
 }

 function parseHttpResponse(httpRequest) {
     var isInvalidResponse = false;
     var isJsonResponse = false;
     var parsedResponse = {};
     parsedResponse.isRawResponse = false;
     var value = "";
     var response = null;
     if (voltmx.sdk.isNullOrUndefined(httpRequest) || voltmx.sdk.isNullOrUndefined(httpRequest.response)) {
         voltmx.sdk.logsdk.warn("parseHttpResponse :: Null or Invalid response received");
     } else if (httpRequest.responseType && httpRequest.responseType === "blob") {
         parsedResponse.response = httpRequest.response;
         parsedResponse.isRawResponse = true;
     } else {
         response = voltmx.sdk.cloneObject(httpRequest.response);
         voltmx.sdk.logsdk.debug("parseHttpResponse :: Network response :", response);
         //Defaulting to JSON format
         if (voltmx.sdk.util.isJsonObject(response)) {
             parsedResponse.response = response;
             isJsonResponse = true;
         } else if (voltmx.sdk.util.isValidString(response)) {
             if (voltmx.sdk.isJson(response)) {
                 parsedResponse.response = JSON.parse(response);
                 isJsonResponse = true;
             }
         }
         //Handling when response is not json
         if (!isJsonResponse) {
             if (voltmx.sdk.util.isValidString(httpRequest.response)) {
                 parsedResponse.response = response;
             } else {
                 parsedResponse.response = httpRequest.response;
             }
             var lowerCaseHeaders = voltmx.sdk.util.convertJsonKeysToLowerCase(httpRequest.getAllResponseHeaders());
             //value variable contains response header in lower case
             if (!voltmx.sdk.isNullOrUndefined(lowerCaseHeaders)) {
                 value = lowerCaseHeaders[voltmx.sdk.constants.HTTP_CONTENT_HEADER.trim().toLowerCase()];
             } else {
                 voltmx.sdk.logsdk.warn("parseHttpResponse :: received null response headers  " + lowerCaseHeaders);
             }
             voltmx.sdk.logsdk.warn("parseHttpResponse :: content-type of response " + value);
             //MFSDK-3525 Adding an additional check to see if content type is present.
             if (voltmx.sdk.util.isValidString(value) && value.startsWith(voltmx.sdk.constants.CONTENT_TYPE_JSON)) {
                 voltmx.sdk.logsdk.warn("parseHttpResponse :: Unhandled content received for content-type application/json");
                 isInvalidResponse = true;
             } else {
                 parsedResponse.isRawResponse = true;
             }
         }
     }
     parsedResponse.isInvalidResponse = isInvalidResponse;
     return parsedResponse;
 }
 voltmx.sdk.getSdkType = function() {
     return voltmx.sdk.constants.SDK_TYPE_IDE;
 };
 voltmx.sdk.getPayload = function(voltmxRef) {
     var payload = {};
     payload.os = voltmx.os.deviceInfo().version + "";
     payload.dm = voltmx.os.deviceInfo().model;
     payload.did = voltmx.sdk.getDeviceId();
     payload.ua = voltmx.os.userAgent();
     if (appConfig) {
         payload.aid = appConfig.appId;
         payload.aname = appConfig.appName;
     } else {
         var clientParams = voltmxRef.getClientParams();
         payload.aid = clientParams.aid ? clientParams.aid : voltmxRef.mainRef.baseId;
         payload.aname = clientParams.aname ? clientParams.aname : voltmxRef.mainRef.name;
     }
     payload.chnl = voltmx.sdk.getChannelType();
     payload.plat = voltmx.sdk.getPlatformName();
     if (payload.plat === voltmx.sdk.constants.PLATFORM_IOS && payload.dm.toLowerCase().indexOf("ipod") !== -1) {
         payload.chnl = "ipod";
     }
     payload.aver = appConfig.appVersion;
     payload.atype = voltmx.sdk.getAType();
     payload.stype = "b2c";
     payload.kuid = voltmxRef.getUserId();
     payload.mfaid = voltmxRef.mainRef.appId;
     payload.mfbaseid = voltmxRef.mainRef.baseId;
     payload.mfaname = voltmxRef.mainRef.name;
     payload.sdkversion = voltmx.sdk.version;
     payload.sdktype = voltmx.sdk.getSdkType();
     if (voltmx.application.getCurrentForm()) {
         var fid = voltmx.application.getCurrentForm().id;
         if (fid) {
             payload.fid = fid;
         }
     }
     payload.sessiontype = voltmx.sdk.util.getSessionType();
     payload.clientUUID = voltmxRef.clientUUID;
     return payload;
 };
 /**
  * Returns unique identifier for a device.
  * In case of Android & Windows the API voltmx.os.deviceInfo().deviceid is guaranteed to provide unique identifier for a device.
  * In case of iOS the API voltmx.os.deviceInfo().identifierForVendor is guaranteed to provide unique key per vendor.
  * A different value is returned for apps on the same device that come from different vendors, and for apps on different devices regardless of vendor
  * @return {string}
  */
 voltmx.sdk.getDeviceId = function() {
     // For Android, SPA & Windows platforms.
     return voltmx.os.deviceInfo().deviceid;
 };
 voltmx.sdk.getChannelType = function() {
     var returnVal = "";
     returnVal = "mobile";
     return returnVal;
 };
 voltmx.sdk.getPlatformName = function() {
     var returnVal = "";
     returnVal = voltmx.sdk.constants.PLATFORM_ANDROID;
     return returnVal;
 };
 voltmx.sdk.util.isPlatformPlainJS = function() {
     var isPlatformPlainJS = false;
     return isPlatformPlainJS;
 }
 voltmx.sdk.util.createSessionAndSendIST = function() {
     voltmx.license.createSession();
     voltmx.license.captureVoltmxLicenseUsage(true);
 }
 voltmx.mbaas.invokeMbaasServiceFromVoltmx = function(url, inputParam, serviceID, operationID, callBack, infoObject) {
     var currentInstance = voltmx.sdk.getCurrentInstance();
     if (!currentInstance) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + "this service.");
     }
     var integrationService = currentInstance.getIntegrationService(serviceID);
     var options = {};
     if (inputParam && inputParam["httpconfig"]) {
         options["httpconfig_old"] = inputParam["httpconfig"];
         delete inputParam["httpconfig"];
     }
     if (inputParam && inputParam["httpRequestOptions"] && inputParam["httpRequestOptions"] instanceof Object) {
         options["httpRequestOptions"] = inputParam["httpRequestOptions"];
         delete inputParam["httpRequestOptions"];
     }
     if (inputParam && inputParam["xmlHttpRequestOptions"] && inputParam["xmlHttpRequestOptions"] instanceof Object) {
         options["xmlHttpRequestOptions"] = inputParam["xmlHttpRequestOptions"];
         delete inputParam["xmlHttpRequestOptions"];
     }
     var headers = null;
     if (inputParam && inputParam["httpheaders"]) {
         headers = inputParam["httpheaders"];
         delete inputParam["httpheaders"];
     }
     integrationService.invokeOperation(operationID, headers, inputParam, function(res) {
         if (typeof(callBack) === 'function') {
             callBack(400, res, infoObject);
         }
     }, function(res) {
         if (typeof(callBack) === 'function') {
             callBack(400, res, infoObject);
         }
     }, options);
 };
 voltmx.mbaas.invokeMbaasServiceFromVoltmxSync = function(url, inputParam, serviceID, operationID) {
     var currentInstance = voltmx.sdk.getCurrentInstance();
     if (!currentInstance) {
         throw new Exception(voltmx.sdk.errorConstants.INIT_FAILURE, voltmx.sdk.constants.INIT_FAILURE_MESSAGE + "this service.");
     }
     var integrationService = currentInstance.getIntegrationService(serviceID);
     var headers = null;
     if (inputParam && inputParam["httpheaders"]) {
         headers = inputParam["httpheaders"];
         delete inputParam["httpheaders"];
     }
     return integrationService.invokeOperationSync(operationID, headers, inputParam);
 };
 voltmx.mbaas.invokeMbaasServiceFromVoltmxAsync = function(url, inputParam, serviceID, operationID, callBack, info) {
     voltmx.mbaas.invokeMbaasServiceFromVoltmx(url, inputParam, serviceID, operationID, callBack, info);
 };
 //Helps to prepare the input wrapped into voltmx.net.FormData
 voltmx.sdk.getFormData = function(payload) {
     var formData = new voltmx.net.FormData();
     formData.append(voltmx.sdk.constants.JSON_DATA, JSON.stringify(payload));
     return formData;
 };
 //Helps to update prepare the input wrapped into voltmx.net.FormData
 voltmx.sdk.updateFormData = function(formData, key, value) {
     formData.append(key, JSON.stringify(value));
     return formData;
 };
 //Helps to get the atype for Spa and DesktopWeb applications it would be voltmx.sdk.constants.SDK_ATYPE_SPA ,for android wear applications it would be "watch" and remaining it would be "native"
 voltmx.sdk.getAType = function() {
     var returnVal = voltmx.sdk.constants.SDK_ATYPE_NATIVE;
     return returnVal;
 };
 voltmx.sdk.setLicenseCall = function(appKey, appSecret, data) {
     //checking if new MF app is connected
     var reportingServiceUrl = data.reportingsvc.session;
     if (typeof(appConfig) != "undefined") {
         if ((appKey === appConfig.appKey) && (appSecret === appConfig.appSecret) && (typeof(appConfig.svcDoc) !== "undefined" && reportingServiceUrl === appConfig.svcDoc.reportingsvc.session)) {
             return; //user is doing init on same environment and same MF-app
         } else {
             appConfig.isturlbase = reportingServiceUrl.replace("/IST", "");
             appConfig.appKey = appKey;
             appConfig.appSecret = appSecret;
             appConfig.serviceUrl = data.selflink;
             appConfig.svcDoc = data;
             // IST is triggered with new sid and new MF app on the same or different IST server based on how isturlbase is populated
             voltmx.sdk.util.createSessionAndSendIST();
         }
     }
 };
 /**
  * Saving App metadata in storage for Persistence
  */
 voltmx.sdk.util.saveMetadatainDs = function(appKey, appSecret, servConfig) {
     var appId = {
         "appKey": voltmx.sdk.util.encryptAppConfig(appKey),
         "appSecret": voltmx.sdk.util.encryptAppConfig(appSecret),
         "serviceUrl": voltmx.sdk.util.encryptAppConfig(servConfig.selflink)
     };
     voltmx.sdk.dataStore.setItem(voltmx.sdk.constants.TOOLS_ETAG_ID, servConfig.service_doc_etag);
     voltmx.sdk.logsdk.debug("Update done. Current version = " + voltmx.sdk.getCurrentInstance().mainRef.config.service_doc_etag + " Updated to " + servConfig.service_doc_etag);
     voltmx.sdk.dataStore.setItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.MOBILE_FABRIC_SERVICE_DOC), voltmx.sdk.util.encryptAppConfig(JSON.stringify(servConfig)));
     voltmx.sdk.dataStore.setItem(appConfig.appId, JSON.stringify(appId));
     voltmx.sdk.dataStore.setItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.ENCRYPTION_APPCONFIG_FLAG), true);
     voltmx.sdk.logsdk.info("### saveMetadatainDs:: metadata saved successfuly in dataStore");
 };
 /**
  * Deleting App metadata from datastore(cache)
  */
 voltmx.sdk.util.deleteMetadatafromDs = function() {
     voltmx.sdk.dataStore.removeItem(appConfig.appId);
     voltmx.sdk.dataStore.removeItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.MOBILE_FABRIC_SERVICE_DOC));
     voltmx.sdk.dataStore.removeItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.ENCRYPTION_APPCONFIG_FLAG));
     /** Checking whether Persisted login or Offline login or refresh login tokens are present in secure storage
      {returns} boolean
      */
     function shouldSharedClientIdentifierNeedsToBeRemoved() {
         return voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(voltmx.sdk.dataStore.getItem(voltmx.sdk.constants.PERSISTED_AUTH_RESPONSE)) && voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(voltmx.sdk.dataStore.getItem(voltmx.sdk.constants.OFFLINE_LOGIN_AUTH_RESPONSE)) && voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(voltmx.sdk.dataStore.getItem(voltmx.sdk.constants.PERSISTED_REFRESH_LOGIN_PROVIDER_TOKENS));
     }
     if (shouldSharedClientIdentifierNeedsToBeRemoved()) {
         voltmx.sdk.logsdk.debug("### deleteMetadatafromDs:: Login meta not available, deleting identifier.");
         voltmx.sdk.dataStore.removeItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.SHARED_CLIENT_IDENTIFIER));
     }
     voltmx.sdk.logsdk.info("### deleteMetadatafromDs:: metadata deleted successfuly from dataStore");
 };
 /**
  * Validates the deeplink params. A valid deeplink redirection will contain params "code" & "launchmode" is 3.
  * @param {map} params  - query parameters from the deeplink redirection
  */
 voltmx.sdk.isValidDeeplinkCallback = function(params) {
     if (params && params.launchmode == voltmx.sdk.constants.LAUNCHMODE_DEEPLINK && params.launchparams.code) return true;
     else return false;
 };
 voltmx.sdk.getReportingParamsForOfflineObjects = function() {
     var reportingData = voltmx.sdk.getPayload(voltmxRef);
     reportingData.xmode = "offline";
     reportingData.rsid = voltmx.sdk.currentInstance.getSessionId();
     return JSON.stringify(reportingData);
 };
 var MFAppVersion;
 voltmx.sdk.setFoundryAppVersion = function(version) {
     MFAppVersion = version;
 };
 /**
  * Returns the default Foundry application version. For auto init app version will be available in appConfig,
  * for manual init developer has to send Foundry version explicitly.
  *
  * Foundry version in manual init has more priority over one specified in Iris.
  * @return {*}
  */
 voltmx.sdk.getFoundryAppVersion = function() {
     if (!voltmx.sdk.isNullOrUndefined(MFAppVersion)) {
         return MFAppVersion;
     } else if (!voltmx.sdk.isNullOrUndefined(appConfig) && !voltmx.sdk.isNullOrUndefined(appConfig.runtimeAppVersion)) {
         if (appConfig.runtimeAppVersion == "Default" && !voltmx.sdk.isNullOrUndefined(appConfig.svcDoc)) {
             return appConfig.svcDoc.app_default_version;
         }
         return appConfig.runtimeAppVersion;
     }
 };
 /**
  * Encrypt given SSO token
  *
  * @param ssotoken token to be encrypted.
  * @return encrypted SSO token
  */
 voltmx.sdk.util.encryptSSOToken = function(ssotoken) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.encryptSSOToken");
     return voltmx.sdk.util.encryptText(ssotoken, [voltmx.sdk.util.getAndSaveUUIDforSSO()], voltmx.sdk.constants.ENCRYPTION_ALGO_AES);
 };
 /**
  * Decrypt given encrypted_token
  *
  * @param token to be decrypted
  * @return decrypted token
  */
 voltmx.sdk.util.decryptSSOToken = function(encryptedtoken) {
     voltmx.sdk.logsdk.trace("Entering into voltmx.sdk.util.decryptSSOToken");
     if (voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(encryptedtoken)) {
         return encryptedtoken;
     }
     var decryptedToken = voltmx.sdk.util.decryptText(encryptedtoken, [voltmx.sdk.util.getAndSaveUUIDforSSO()], voltmx.sdk.constants.ENCRYPTION_ALGO_AES);
     if (voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(decryptedToken)) {
         // Backward compatibility. Since we didnt encrypt with deviceID decryption will fail. Decrypt with old key "ssoencryption". Encrypting with deviceID & persisting response.
         decryptedToken = voltmx.sdk.util.decryptText(encryptedtoken, [voltmx.sdk.constants.SSO_ENCRYPTION_KEY], voltmx.sdk.constants.ENCRYPTION_ALGO_AES);
         if (!voltmx.sdk.isNullOrUndefined(decryptedToken) && decryptedToken !== '') {
             voltmx.sdk.util.saveSSOToken(decryptedToken);
         }
     }
     return decryptedToken;
 };
 /**
  * Generates key to encrypt/decrypt any text.
  * @param salt {Array}
  * @param keyStrength {Integer}
  * @returns string
  */
 voltmx.sdk.util.generateSecureKeyFromText = function(salt, keyStrength) {
     var secureKey = "";
     if (!voltmx.sdk.isNullOrUndefined(salt) && voltmx.sdk.isArray(salt)) {
         var params = {};
         params["passphrasetext"] = salt;
         params["subalgo"] = voltmx.sdk.constants.ENCRYPTION_ALGO_AES;
         if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_IOS && keyStrength === voltmx.sdk.constants.AES_ALGO_KEY_STRENGTH_256) {
             params[voltmx.sdk.constants.ENC_PASSPHRASE_HASH_ALGO] = voltmx.sdk.constants.HASH_FUNCTION_SHA2;
         } else {
             params[voltmx.sdk.constants.ENC_PASSPHRASE_HASH_ALGO] = voltmx.sdk.constants.HASH_FUNCTION_MD5;
         }
         secureKey = voltmx.crypto.newKey(voltmx.sdk.constants.ENC_TYPE_PASSPHRASE, keyStrength, params);
     } else {
         throw new Exception(voltmx.sdk.errorConstants.CONFIGURATION_FAILURE, "Invalid param. salt cannot be null, should be of type Array");
     }
     return secureKey;
 };
 /**
  * Encrypts text with the given salt and encryptionAlgo.
  * @param text to be encrypted
  * @param salt additional input to a one-way function that "hashes" data
  * @param encryptionAlgo algo to be used to decrypt
  * @returns decrypted string
  */
 voltmx.sdk.util.encryptText = function(text, salt, encryptionAlgo) {
     try {
         var encryptionKey = voltmx.sdk.util.generateSecureKeyFromText(salt, voltmx.sdk.constants.AES_ALGO_KEY_STRENGTH_256);
         if (voltmx.sdk.isNullOrUndefined(encryptionKey)) {
             encryptionKey = voltmx.sdk.util.generateSecureKeyFromText(salt, voltmx.sdk.constants.AES_ALGO_KEY_STRENGTH_128);
         }
         var encryptedText = voltmx.crypto.encrypt(encryptionAlgo, encryptionKey, text, {});
         if (voltmx.sdk.isNullOrUndefined(encryptedText) || encryptedText == "") {
             voltmx.sdk.util.recordCustomEvent("INVALID CRYPTO RESPONSE", "encryptedText: " + encryptedText, "encryptedText: null or EMPTY", "cipher", null);
         }
         var base64Data = voltmx.convertToBase64(encryptedText);
         if (voltmx.sdk.isNullOrUndefined(base64Data) || base64Data == "") {
             voltmx.sdk.util.recordCustomEvent("INVALID BASE64 DATA", "base64Data: " + base64Data, "base64Data: null or EMPTY", "cipher", null);
         }
         return base64Data;
     } catch (exception) {
         voltmx.sdk.logsdk.error("Exception occurred while encrypting text, exception :", exception);
         voltmx.sdk.util.recordCustomEvent("INVALID CRYPTO RESPONSE", "get encryptText: " + text, "encryptText: exception", "cipher", null);
     }
 };
 /**
  * Decrypts text with given decryptionAlgo and decryptionKey
  * @param text to be decrypted
  * @param salt additional input to a one-way function that "hashes" data in case of fallback
  * @param decryptionAlgo algo to be used to decrypt
  * @param decryptionKey key to be used to decrypt
  * @returns decrypted string
  */
 voltmx.sdk.util.performDecryption = function(text, salt, decryptionAlgo, decryptionKey) {
     try {
         // convert base64 to rawbytes
         var raw_text = voltmx.sdk.util.convertBase64ToRawBytes(text);
         var decryptText = voltmx.crypto.decrypt(decryptionAlgo, decryptionKey, raw_text, {});
         if (voltmx.sdk.isNullOrUndefined(decryptText) || decryptText == "") {
             voltmx.sdk.util.recordCustomEvent("INVALID CRYPTO RESPONSE", "get decryptText: " + text, "decryptText: null", "decipher", null);
             if (isKeyStrength256ForDecryption) {
                 isKeyStrength256ForDecryption = false;
                 decryptText = voltmx.sdk.util.fallBackToAES128ForDecryption(text, salt, decryptionAlgo);
             }
         }
         return decryptText;
     } catch (exception) {
         voltmx.sdk.logsdk.error("Exception occurred while converting to raw text, exception :", exception);
         voltmx.sdk.util.recordCustomEvent("INVALID CRYPTO RESPONSE", "get decryptText: " + text, "decryptText: exception", "decipher", null);
     }
 };
 /**
  * Initiates text decryption with the given salt and encryptionAlgo 128 bit
  * Immediate encryption with 256 bit is initiated for cases where 256 bit is supported and are using 128 bit until now
  * @param text to be decrypted
  * @param salt additional input to a one-way function that "hashes" data
  * @param decryptionAlgo algo to be used to decrypt
  * @returns decrypted string
  */
 voltmx.sdk.util.fallBackToAES128ForDecryption = function(text, salt, decryptionAlgo) {
     try {
         var decryptionKey = voltmx.sdk.util.generateSecureKeyFromText(salt, voltmx.sdk.constants.AES_ALGO_KEY_STRENGTH_128);
         var decryptText = voltmx.sdk.util.performDecryption(text, salt, decryptionAlgo, decryptionKey);
         voltmx.sdk.util.encryptText(decryptText, salt, voltmx.sdk.constants.ENCRYPTION_ALGO_AES);
         return decryptText;
     } catch (exception) {
         voltmx.sdk.logsdk.error("Exception occurred while decrypting text using AES 128, exception :", exception);
     }
 };
 /**
  * Flag to maintain info on decryption key size
  * @type {boolean}
  */
 isKeyStrength256ForDecryption = true;
 /**
  * Initiates text decryption with the given salt and encryptionAlgo 256 bit and falls back to 128 bit in cases of 256 bit not being supported
  * @param text to be decrypted
  * @param salt additional input to a one-way function that "hashes" data
  * @param decryptionAlgo algo to be used to decrypt
  * @returns decrypted string
  */
 voltmx.sdk.util.decryptText = function(text, salt, decryptionAlgo) {
     try {
         var decryptedText = null;
         var decryptionKey = voltmx.sdk.util.generateSecureKeyFromText(salt, voltmx.sdk.constants.AES_ALGO_KEY_STRENGTH_256);
         if (!voltmx.sdk.isNullOrUndefined(decryptionKey)) {
             isKeyStrength256ForDecryption = true;
             decryptedText = voltmx.sdk.util.performDecryption(text, salt, decryptionAlgo, decryptionKey);
         } else {
             isKeyStrength256ForDecryption = false;
             decryptedText = voltmx.sdk.util.fallBackToAES128ForDecryption(text, salt, decryptionAlgo);
         }
         return decryptedText;
     } catch (exception) {
         voltmx.sdk.logsdk.error("Exception occurred while decrypting text using AES 256, exception :", exception);
     }
 };
 /**
  * Converts base64String to raw bytes using frameworks API voltmx.convertToRawBytes
  */
 voltmx.sdk.util.convertBase64ToRawBytes = function(base64String) {
     var retVal = voltmx.convertToRawBytes(base64String);
     if (voltmx.sdk.isNullOrUndefined(retVal) || retVal == "") {
         voltmx.sdk.util.recordCustomEvent("INVALID RAW BYTES", "get convertBase64ToRawBytes: ", "rawbytes: null", "decipher", null);
     }
     return retVal;
 };
 /**
  * Returns type of object
  * framework api voltmx.type is not supported by Phonegap and plain-js platforms
  * @return {*}
  */
 voltmx.sdk.util.type = function(objectVar) {
     if (voltmx.sdk.getAType() === voltmx.sdk.constants.SDK_ATYPE_NATIVE) {
         var type = voltmx.type(objectVar);
         if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_WINDOWS) {
             type = type.replace("kony", "voltmx");
         }
         return type;
     } else {
         return typeof(objectVar)
     }
 };
 voltmx.sdk.util.encryptAppConfig = function(data) {
     var encryptionSalt = [voltmx.sdk.util.getSharedClientId()];
     var encryptionAlgo = voltmx.sdk.constants.ENCRYPTION_ALGO_AES;
     if (voltmx.sdk.isNullOrUndefined(data) || data == "") {
         voltmx.sdk.util.recordCustomEvent("INVALID APP CONFIG", "set appConfig: " + data, "appConfig: null or EMPTY", "cipher", null);
     }
     return voltmx.sdk.util.encryptText(data, encryptionSalt, encryptionAlgo);
 }
 voltmx.sdk.util.decryptAppConfig = function(data) {
         var encryptionSalt = [voltmx.sdk.util.getSharedClientId()];
         var encryptionAlgo = voltmx.sdk.constants.ENCRYPTION_ALGO_AES;
         var appConfig = voltmx.sdk.util.decryptText(data, encryptionSalt, encryptionAlgo);
         if (voltmx.sdk.isNullOrUndefined(appConfig) || appConfig == "") {
             voltmx.sdk.util.recordCustomEvent("INVALID APP CONFIG", "get appConfig: " + data, "appConfig: null", "decipher", null);
         }
         return appConfig;
     }
     /**
      * Loads the saved App metadata from datastore
      * @param dsAppMetaData to be updated
      * @param dsAppServiceDoc to be updated
      * @returns dsAppConfig {Object} - Contains both updated params
      */
 voltmx.sdk.util.loadMetadataFromDs = function(dsAppMetaData, dsAppServiceDoc) {
     var dsAppConfig = {};
     var dsAppData = voltmx.sdk.dataStore.getItem(appConfig.appId);
     dsAppServiceDoc = voltmx.sdk.dataStore.getItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.MOBILE_FABRIC_SERVICE_DOC));
     if (!voltmx.sdk.isNullOrUndefined(dsAppData)) {
         dsAppMetaData = JSON.parse(dsAppData);
     }
     if (voltmx.sdk.util.isAppConfigEncrypted()) {
         if (!voltmx.sdk.isNullOrUndefined(dsAppMetaData)) {
             var appKey = voltmx.sdk.util.decryptAppConfig(dsAppMetaData.appKey);
             var appSecret = voltmx.sdk.util.decryptAppConfig(dsAppMetaData.appSecret);
             var serviceUrl = voltmx.sdk.util.decryptAppConfig(dsAppMetaData.serviceUrl);
             if (voltmx.sdk.util.isNullOrEmptyString(appKey) || voltmx.sdk.util.isNullOrEmptyString(appSecret) || voltmx.sdk.util.isNullOrEmptyString(serviceUrl)) {
                 voltmx.sdk.logsdk.warn("Null values for appKey, appSecret or serviceUrl found");
                 dsAppMetaData.appKey = appConfig.appKey;
                 dsAppMetaData.appSecret = appConfig.appSecret;
                 dsAppMetaData.serviceUrl = appConfig.serviceUrl;
                 voltmx.sdk.logsdk.info("Using appKey, appSecret and serviceUrl from Startup.js appConfig");
                 voltmx.sdk.util.recordCustomEvent("Decrypted appKey,appSecret and serviceUrl equals NULL", "fallback startup.js appConfig", "loadMetadataFromDS", "update metadata run time", null);
             } else {
                 dsAppMetaData.appKey = appKey;
                 dsAppMetaData.appSecret = appSecret;
                 dsAppMetaData.serviceUrl = serviceUrl;
             }
         } else {
             voltmx.sdk.util.recordCustomEvent("RETRIEVE DS APP METADATA", "DS_AppMetaData not found.", "", "decipher", null);
         }
         if (!voltmx.sdk.isNullOrUndefined(dsAppServiceDoc)) {
             dsAppServiceDoc = voltmx.sdk.util.decryptAppConfig(dsAppServiceDoc);
         }
     }
     dsAppConfig = {
         dsAppMetaData: dsAppMetaData,
         dsAppServiceDoc: dsAppServiceDoc
     };
     return dsAppConfig;
 };
 /**
  * Generates a guid if it is not already present in the datastore and sets encrytion flag
  * @returns a guid from the ds
  */
 voltmx.sdk.util.getSharedClientId = function() {
     if (voltmx.sdk.isNullOrUndefined(voltmx.sdk.dataStore.getItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.SHARED_CLIENT_IDENTIFIER)))) {
         voltmx.sdk.dataStore.setItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.SHARED_CLIENT_IDENTIFIER), voltmx.license.generateUUID());
         voltmx.sdk.util.recordCustomEvent("INVALID SHARED CLIENT_ID", "Generated new SharedClient ID", "SCID: NEW_VALUE", "decipher", null);
     }
     var sharedClientID = voltmx.sdk.dataStore.getItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.SHARED_CLIENT_IDENTIFIER));
     if (voltmx.sdk.isNullOrUndefined(sharedClientID)) {
         voltmx.sdk.util.recordCustomEvent("INVALID SHARED CLIENT_ID", "get SharedClient ID", "SCID: null", "decipher", null);
     }
     return sharedClientID;
 };
 /**
  * Checks the encrytion flag in ds to validate whether appConfig is encrypted or not
  * @returns {Boolean}
  */
 voltmx.sdk.util.isAppConfigEncrypted = function() {
     if (!voltmx.sdk.isNullOrUndefined(voltmx.store.getItem(voltmx.sdk.util.prefixAppid(voltmx.sdk.constants.ENCRYPTION_APPCONFIG_FLAG)))) {
         return true;
     } else {
         voltmx.sdk.util.recordCustomEvent("NO SHARED CLIENT_ID", "", "APP Config is not encrypted", "decipher", null);
         return false;
     }
 };
 /**
  * This function checks and updates integrityKey from serviceDoc
  * @param {Object} serviceDoc - serviceDoc to be read for integrity_check_required key
  */
 voltmx.sdk.util.checkAndUpdateIntegrityKey = function(serviceDoc) {
     if (serviceDoc.hasOwnProperty("integrity_check_required") && serviceDoc.integrity_check_required === true) {
         //MF server >=8.2
         voltmxRef.mainRef.integrityKey = true;
     } else {
         //MF server < 8.2 and integrity is disabled
         voltmxRef.mainRef.integrityKey = false;
     }
 };
 voltmx.sdk.util.recordCustomEvent = function(eventSubType, formID, widgetID, flowTag, metadata) {
     try {
         if (voltmx.sdk.isNullOrUndefined(VMXMetricsService) && voltmx.sdk.currentInstance && voltmx.sdk.currentInstance.getMetricsService) {
             KNYMetricsService = VMXMetricsService = voltmx.sdk.currentInstance.getMetricsService();
         }
         // Null check to make sure that the VMXMetricsService object is available before making send event calls.
         if (!voltmx.sdk.isNullOrUndefined(VMXMetricsService)) {
             /* Commenting this function invocation due to bug : MFSDK-5496.
                Can be uncommented if required */
             //  VMXMetricsService.sendEvent("Custom", eventSubType, formID, widgetID, flowTag, metadata);
         } else {
             voltmx.sdk.logsdk.warn("recordCustomEvent failed as Metrics Service is not available");
         }
     } catch (error) {
         voltmx.sdk.logsdk.warn("recordCustomEvent failed due to " + error);
     }
 };
 voltmx.sdk.util.recordAndFlushCustomEvent = function(eventSubType, formID, widgetID, flowTag, metadata) {
     try {
         if (voltmx.sdk.isNullOrUndefined(VMXMetricsService) && voltmx.sdk.currentInstance && voltmx.sdk.currentInstance.getMetricsService) {
             KNYMetricsService = VMXMetricsService = voltmx.sdk.currentInstance.getMetricsService();
         }
         // Null check to make sure that the VMXMetricsService object is available before making send event calls.
         if (!voltmx.sdk.isNullOrUndefined(VMXMetricsService)) {
             /* Commenting these function invocations due to bug : MFSDK-5496.
                Can be uncommented if required */
             //   VMXMetricsService.sendEvent("Custom", eventSubType, formID, widgetID, flowTag, metadata);
             //  VMXMetricsService.flushEvents();
         } else {
             voltmx.sdk.logsdk.warn("recordAndFlushCustomEvent failed as Metrics Service is not available");
         }
     } catch (error) {
         voltmx.sdk.logsdk.warn("recordAndFlushCustomEvent failed due to " + error);
     }
 };
 /**
  * Utility function to store, get and remove refresh tokens from datastore
  */
 voltmx.sdk.util.getRefreshLoginTokenStoreUtility = (function() {
     var refreshLoginTokenStoreUtilitySingletonObject = null;

     function refreshLoginTokenStoreUtility() {
         var currentObject = this;
         /**
          * This is an utility method to retrieve the persisted refresh login provider tokens
          * @returns {Object} - JSON Object containing all persisted login provider tokens
          */
         var getPersistedRefreshLoginProviderTokensObject = function() {
                 voltmx.sdk.logsdk.perf("Entering getPersistedRefreshLoginProviderTokensObject");
                 var encryptedPersistedRefreshLoginProviderTokens = voltmx.sdk.dataStore.getItem(voltmx.sdk.constants.PERSISTED_REFRESH_LOGIN_PROVIDER_TOKENS);
                 var persistedRefreshLoginProviderTokensObject = null;
                 if (!voltmx.sdk.isNullOrUndefined(encryptedPersistedRefreshLoginProviderTokens)) {
                     voltmx.sdk.logsdk.info("decrypting persisted refresh login tokens");
                     var decryptedPersistedRefreshLoginProviderTokens = voltmx.sdk.util.decryptText(encryptedPersistedRefreshLoginProviderTokens, [voltmx.sdk.util.getSharedClientId()], voltmx.sdk.constants.ENCRYPTION_ALGO_AES);
                     if (!voltmx.sdk.isNullOrUndefined(decryptedPersistedRefreshLoginProviderTokens) && voltmx.sdk.isJson(decryptedPersistedRefreshLoginProviderTokens)) {
                         voltmx.sdk.logsdk.info("parsing decrypted persisted refresh login tokens");
                         persistedRefreshLoginProviderTokensObject = JSON.parse(decryptedPersistedRefreshLoginProviderTokens);
                     } else {
                         voltmx.sdk.logsdk.warn("failed to decrypt " + voltmx.sdk.constants.PERSISTED_REFRESH_LOGIN_PROVIDER_TOKENS + " for refresh login");
                     }
                     voltmx.sdk.logsdk.info("returning persisted refresh login tokens");
                 } else {
                     voltmx.sdk.logsdk.info("there are no available persisted refresh login tokens");
                 }
                 return persistedRefreshLoginProviderTokensObject;
             }
             /**
              * This is an utility method to store refresh login tokens in datastore
              * @param {JSON} refreshLoginProviderTokensObject - JSON Object containing provider specific refresh tokens as key, value pairs
              */
         var storePersistedRefreshLoginProviderTokensObject = function(refreshLoginProviderTokensObject) {
                 voltmx.sdk.logsdk.perf("Entering storePersistedRefreshLoginProviderTokensObject");
                 if (voltmx.sdk.isNullOrUndefined(refreshLoginProviderTokensObject)) {
                     return;
                 }
                 var stringifiedRefreshLoginProviderTokens = JSON.stringify(refreshLoginProviderTokensObject);
                 voltmx.sdk.logsdk.info("encrypting refresh login tokens object and persisting");
                 var encryptedRefreshLoginProviderTokens = voltmx.sdk.util.encryptText(stringifiedRefreshLoginProviderTokens, [voltmx.sdk.util.getSharedClientId()], voltmx.sdk.constants.ENCRYPTION_ALGO_AES);
                 voltmx.sdk.dataStore.setItem(voltmx.sdk.constants.PERSISTED_REFRESH_LOGIN_PROVIDER_TOKENS, encryptedRefreshLoginProviderTokens);
             }
             /**
              * This is an utility method used to remove all persisted refresh login provider tokens from datastore
              */
         this.removeAllPersistedRefreshLoginProviderTokens = function() {
                 voltmx.sdk.logsdk.perf("Entering removeAllPersistedRefreshLoginProviderTokens");
                 voltmx.sdk.dataStore.removeItem(voltmx.sdk.constants.PERSISTED_REFRESH_LOGIN_PROVIDER_TOKENS);
             }
             /**
              * This function is used to store the refresh tokens based on provider
              * @param {string} provider - name of the provider for which the refresh tokens needs to be stored
              * @param {Object} tokensData - JSON Object containing both backend and internal refresh tokens for the provided provider
              */
         this.storeTokens = function(provider, tokensData) {
                 voltmx.sdk.logsdk.perf("Entering storeTokens");
                 if (voltmx.sdk.util.isNullOrEmptyString(provider) || voltmx.sdk.util.isNullOrUndefinedOrEmptyObject(tokensData)) {
                     return;
                 }
                 var persistedRefreshLoginProviderTokensObject = getPersistedRefreshLoginProviderTokensObject();
                 if (voltmx.sdk.isNullOrUndefined(persistedRefreshLoginProviderTokensObject)) {
                     persistedRefreshLoginProviderTokensObject = {};
                 }
                 persistedRefreshLoginProviderTokensObject[provider] = tokensData;
                 voltmx.sdk.logsdk.info("persisting refresh login tokens in datastore");
                 storePersistedRefreshLoginProviderTokensObject(persistedRefreshLoginProviderTokensObject);
                 voltmx.sdk.logsdk.info("successfully stored refresh login tokens");
             }
             /**
              * This function gets the persisted refresh tokens
              * @param {string} provider - name of the provider for which the refresh tokens data needs to be retrieved
              * @returns {Object} - JSON Object containing provider specific internal and backend refresh token
              */
         this.getTokens = function(provider) {
                 voltmx.sdk.logsdk.perf("Entering getTokens");
                 if (voltmx.sdk.util.isNullOrEmptyString(provider)) {
                     return null;
                 }
                 voltmx.sdk.logsdk.info("Fetching refresh login provider tokens from datastore");
                 var persistedRefreshLoginProviderTokensObject = getPersistedRefreshLoginProviderTokensObject();
                 var providerTokens = null;
                 if (!voltmx.sdk.isNullOrUndefined(persistedRefreshLoginProviderTokensObject)) {
                     providerTokens = persistedRefreshLoginProviderTokensObject[provider];
                 }
                 voltmx.sdk.logsdk.info("returning provider specific tokens");
                 return providerTokens;
             }
             /**
              * This function removes the persisted refresh tokens for the provider
              * @param {string} provider - name of the provider for which the refresh tokens have to be removed
              */
         this.removeTokens = function(provider) {
                 voltmx.sdk.logsdk.perf("Entering removeTokens");
                 if (voltmx.sdk.util.isNullOrEmptyString(provider)) {
                     return null;
                 }
                 voltmx.sdk.logsdk.info("Fetching refresh login provider tokens from datastore");
                 var persistedRefreshLoginProviderTokensObject = getPersistedRefreshLoginProviderTokensObject();
                 if (voltmx.sdk.isNullOrUndefined(persistedRefreshLoginProviderTokensObject)) {
                     return;
                 }
                 voltmx.sdk.logsdk.info("removing provider specific tokens from datastore");
                 delete persistedRefreshLoginProviderTokensObject[provider];
                 if (Object.keys(persistedRefreshLoginProviderTokensObject).length === 0) {
                     //removing persistedRefreshLoginProviderTokens from datastore
                     currentObject.removeAllPersistedRefreshLoginProviderTokens();
                 } else {
                     storePersistedRefreshLoginProviderTokensObject(persistedRefreshLoginProviderTokensObject);
                 }
             }
             /**
              * This function returns the provider specific token (token can be internal or backend refresh token based on tokenType)
              * @param provider - name of the provider for which the token has to be retrieved
              * @param tokenType - internal / backend refresh token constant
              * @returns token - corresponding internal or backend refresh token
              */
         var getToken = function(provider, tokenType) {
                 voltmx.sdk.logsdk.perf("Entering getToken");
                 var tokensData = currentObject.getTokens(provider);
                 var token = null;
                 if (!voltmx.sdk.isNullOrUndefined(tokensData)) {
                     token = tokensData[tokenType];
                 }
                 return token;
             }
             /**
              * This function updates the token (can be internal/refresh) based on the tokenType
              * @param provider - name of the provider for which the token has to be updated
              * @param tokenType - type of the token to be updated (internal/refresh token)
              */
         var setToken = function(provider, tokenType, token) {
                 voltmx.sdk.logsdk.perf("Entering setToken");
                 var tokensData = currentObject.getTokens(provider);
                 if (!voltmx.sdk.isNullOrUndefined(tokensData)) {
                     tokensData[tokenType] = token;
                     currentObject.storeTokens(provider, tokensData);
                 }
             }
             /**
              * This function gets the internal refresh token for the given provider
              * @param {string} provider - name of the provider for which the internal refresh token has to be retrieved
              * @returns {string} internal refresh token for the given provider, returns null if provider is invalid
              */
         this.getInternalRefreshToken = function(provider) {
                 voltmx.sdk.logsdk.perf("Entering getInternalRefreshToken");
                 return getToken(provider, voltmx.sdk.constants.INTERNAL_REFRESH_TOKEN);
             }
             /**
              * This function set the internal refresh token for the give providers
              * @param {string/Array} providers - name of the provider/providers for which the given internal refresh token has to be updated
              * @param {string} internalRefreshToken - internal refresh token for the given provider
              */
         this.setInternalRefreshToken = function(providers, internalRefreshToken) {
                 voltmx.sdk.logsdk.perf("Entering setInternalRefreshToken");
                 //if given list of providers
                 if (!voltmx.sdk.isNullOrUndefined(providers) && (providers.constructor === Array)) {
                     var persistedRefreshLoginProviderTokens = getPersistedRefreshLoginProviderTokensObject();
                     if (voltmx.sdk.isNullOrUndefined(persistedRefreshLoginProviderTokens)) {
                         voltmx.sdk.logsdk.warn("there are no refresh login providers in data store, so provided backend refresh tokens can't be updated");
                         return;
                     }
                     var persistedProvidersList = Object.keys(persistedRefreshLoginProviderTokens);
                     if (!voltmx.sdk.isNullOrUndefined(persistedProvidersList)) {
                         for (var index = 0; index < providers.length; index++) {
                             if (persistedProvidersList.indexOf(providers[index]) != -1) {
                                 persistedRefreshLoginProviderTokens[providers[index]][voltmx.sdk.constants.INTERNAL_REFRESH_TOKEN] = internalRefreshToken;
                             }
                         }
                         //store the updated tokens in data store
                         storePersistedRefreshLoginProviderTokensObject(persistedRefreshLoginProviderTokens);
                     }
                 } else { // if given a provider
                     setToken(providers, voltmx.sdk.constants.INTERNAL_REFRESH_TOKEN, internalRefreshToken);
                 }
             }
             /**
              * This function gets the backend refresh token for the given provider
              * @param {string} provider - name of the provider for which the backend refresh token has to be retrieved
              * @returns {string} backendRefreshToken - backend refresh token for the given provider
              */
         this.getBackendRefreshToken = function(provider) {
                 voltmx.sdk.logsdk.perf("Entering getBackendRefreshToken");
                 return getToken(provider, voltmx.sdk.constants.BACKEND_REFRESH_TOKEN);
             }
             /**
              * This function updates the backend refresh token for the given provider
              * @param {string} provider - name of the provider for which the given backendRefreshToken has to be updated
              * @param {string} backendRefreshToken - backend refresh token for the given provider
              */
         this.setBackendRefreshToken = function(provider, backendRefreshToken) {
                 voltmx.sdk.logsdk.perf("Entering setBackendRefreshToken");
                 setToken(provider, voltmx.sdk.constants.BACKEND_REFRESH_TOKEN, backendRefreshToken);
             }
             /**
              * This function returns JSON object of all the persisted internal and refresh tokens with provider
              * @returns {Object} - JSON object containing aggregate of internal and backend refresh tokens
              */
         this.getAllPersistedRefreshLoginProviderTokens = function() {
                 voltmx.sdk.logsdk.perf("Entering getAllPersistedRefreshLoginProviderTokens");
                 return getPersistedRefreshLoginProviderTokensObject();
             }
             /**
              * This function updates backend refresh tokens for the given providers
              * @param {Object} backendRefreshTokens - JSON object containing provider name as key and value as backend refresh token
              */
         this.setBulkBackendRefreshTokens = function(backendRefreshTokens) {
             voltmx.sdk.logsdk.perf("Entering setBulkBackendRefreshTokens");
             if (voltmx.sdk.isNullOrUndefined(backendRefreshTokens) || !(backendRefreshTokens instanceof Object)) {
                 voltmx.sdk.logsdk.warn("provided backend refresh tokens are null/undefined or not an Object type");
                 return;
             }
             var persistedRefreshLoginProviderTokens = getPersistedRefreshLoginProviderTokensObject();
             if (voltmx.sdk.isNullOrUndefined(persistedRefreshLoginProviderTokens)) {
                 voltmx.sdk.logsdk.warn("there are no refresh login providers in data store, so provided backend refresh tokens can't be updated");
                 return;
             }
             var persistedProvidersList = Object.keys(persistedRefreshLoginProviderTokens);
             if (!voltmx.sdk.isNullOrUndefined(persistedProvidersList)) {
                 var providers = Object.keys(backendRefreshTokens);
                 var provider = null;
                 for (var index = 0; index < providers.length; index++) {
                     provider = providers[index];
                     if (persistedProvidersList.indexOf(provider) != -1) {
                         if (!voltmx.sdk.isNullOrUndefined(backendRefreshTokens[provider]) && voltmxRef.refreshLoginProvidersSet.has(provider)) {
                             persistedRefreshLoginProviderTokens[provider][voltmx.sdk.constants.BACKEND_REFRESH_TOKEN] = backendRefreshTokens[provider];
                         } else {
                             voltmx.sdk.logsdk.warn("backend refresh token for " + provider + " is null or undefined");
                         }
                     }
                 }
                 //store the updated tokens in data store
                 storePersistedRefreshLoginProviderTokensObject(persistedRefreshLoginProviderTokens);
             }
         }
     }
     return function() {
         if (voltmx.sdk.isNullOrUndefined(refreshLoginTokenStoreUtilitySingletonObject)) {
             refreshLoginTokenStoreUtilitySingletonObject = new refreshLoginTokenStoreUtility();
         }
         return refreshLoginTokenStoreUtilitySingletonObject;
     };
 })();
 /**
  * Utility function for PKCE enablement in Oauth flows
  * @return singleton utility object
  */
 voltmx.sdk.util.getUtilityForPKCE = (function() {
     var utilityObject = null;
     /**
      * Helper class containing methods for generating app verifier, app challenge,
      * updating url & body params
      */
     function helperClassPKCE() {
         var secureParams = null;
         /**
          * This method resets app verifier & app challenge to null
          * @return void
          */
         this.resetPKCEObject = function() {
             voltmx.sdk.logsdk.debug("secure params reset");
             secureParams = null;
         };
         /**
          * This method resets runtime utility object's PKCE values
          * and tries to generates app verifier & app challenge
          * @return void
          */
         this.initializePKCEObject = function(options) {
             utilityObject.resetPKCEObject();
             try {
                 var app_verifier = voltmx.crypto.generateSecureRandom({
                     "size": 43,
                     "type": "base64"
                 });
                 app_verifier = replaceUnwantedCharacters(app_verifier);
                 app_verifier = app_verifier.substring(0, 128);
                 var base64table = {
                     "returnBase64String": "true"
                 };
                 var app_challenge = voltmx.crypto.createHash(voltmx.sdk.constants.HASHING_ALGORITHM, app_verifier, base64table);
                 app_challenge = replaceUnwantedCharacters(app_challenge);
                 if (!voltmx.sdk.isNullOrUndefined(app_verifier) && !voltmx.sdk.isNullOrUndefined(app_challenge)) {
                     voltmx.sdk.logsdk.debug("secure params generated");
                     secureParams = {};
                     secureParams[voltmx.sdk.constants.APP_VERIFIER] = app_verifier;
                     secureParams[voltmx.sdk.constants.APP_CHALLENGE] = app_challenge;
                 } else {
                     voltmx.sdk.logsdk.error("secure params generated are null");
                 }
             } catch (e) {
                 voltmx.sdk.logsdk.error("could not generated secure params due to " + JSON.stringify(e));
                 return false;
             }
             return true;
         };
         /**
          * This method replaces unwanted chars present in base64 table to RFC standardized char values
          * @param base64String - {string}
          * @return {string} base64 string with unwanted characters replaced
          */
         function replaceUnwantedCharacters(base64String) {
             return base64String.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
         }
         /**
          * This method adds app_challenge & app_challenge_method as queryParams on url
          * @param {String} url to call for login
          * @return {String} url with added query params
          */
         this.appendAppChallengeOnURL = function(url) {
             if (!voltmx.sdk.isNullOrUndefined(secureParams) && !voltmx.sdk.isNullOrUndefined(url)) {
                 url += "&" + voltmx.sdk.constants.APP_CHALLENGE + voltmx.sdk.constants.EQUAL_TO + secureParams[voltmx.sdk.constants.APP_CHALLENGE] + "&" + voltmx.sdk.constants.KEY_APP_CHALLENGE_METHOD + voltmx.sdk.constants.EQUAL_TO + voltmx.sdk.constants.APP_CHALLENGE_METHOD_VALUE;
                 if (voltmx.sdk.getPlatformName() === voltmx.sdk.constants.PLATFORM_THIN_CLIENT) {
                     url += "&" + voltmx.sdk.constants.OAUTH_SESSION_RESPONSE_TYPE + voltmx.sdk.constants.EQUAL_TO + voltmx.sdk.constants.HEADER;
                 } else {
                     url += "&" + voltmx.sdk.constants.OAUTH_SESSION_RESPONSE_TYPE + voltmx.sdk.constants.EQUAL_TO + voltmx.sdk.constants.QUERY;
                 }
                 //after we passed app_challenge, we should no longer keep values with us.
                 delete secureParams[voltmx.sdk.constants.APP_CHALLENGE];
             }
             return url;
         };
         /**
          * This method adds app_verifier in bodyParams
          * and destroys runtime utility object's PKCE values for cleanup and avoiding misuse
          * @param {JSON} bodyParams
          * @return {JSON} bodyParams with added app_verifier
          */
         this.appendAppVerifierInBodyParams = function(bodyParams) {
             if (!voltmx.sdk.isNullOrUndefined(secureParams) && voltmx.sdk.util.isJsonObject(bodyParams)) {
                 bodyParams[voltmx.sdk.constants.APP_VERIFIER] = secureParams[voltmx.sdk.constants.APP_VERIFIER];
                 //after we passed app_verifier, last step of login activity will end & we should no longer keep values with us.
                 utilityObject.resetPKCEObject();
             }
             return bodyParams;
         };
     }
     return function() {
         if (voltmx.sdk.isNullOrUndefined(utilityObject)) {
             utilityObject = new helperClassPKCE();
             Object.freeze(utilityObject);
         }
         return utilityObject;
     }
 })();
 /** Utility to genarete clientUUID for service calls **/
 voltmx.sdk.util.checkAndGenerateClientUUID = function() {
     var persistedClientUUID = voltmx.sdk.util.decryptAndRetrieveClientUUID();
     if (voltmx.sdk.util.isNullOrEmptyString(persistedClientUUID)) {
         var clientUUID = voltmx.license.generateUUID().toString();
         voltmxRef.clientUUID = clientUUID;
         voltmx.sdk.util.encryptAndSaveClientUUID(clientUUID);
     } else {
         voltmxRef.clientUUID = persistedClientUUID;
     }
 };
 voltmx.sdk.util.encryptAndSaveClientUUID = function(clientUUID) {
     var encryptionSalt = [voltmx.sdk.util.getSDKUniversalSalt()];
     var encryptionAlgo = voltmx.sdk.constants.ENCRYPTION_ALGO_AES;
     var encrpytedText = voltmx.sdk.util.encryptText(clientUUID, encryptionSalt, encryptionAlgo);
     voltmx.sdk.dataStore.setItem(voltmx.sdk.constants.CLIENT_SDK_UUID, encrpytedText);
 };
 voltmx.sdk.util.decryptAndRetrieveClientUUID = function() {
     var encryptedText = voltmx.sdk.dataStore.getItem(voltmx.sdk.constants.CLIENT_SDK_UUID);
     if (voltmx.sdk.util.isNullOrEmptyString(encryptedText)) {
         return null;
     }
     var encryptionSalt = [voltmx.sdk.util.getSDKUniversalSalt()];
     var encryptionAlgo = voltmx.sdk.constants.ENCRYPTION_ALGO_AES;
     var decrpytedText = voltmx.sdk.util.decryptText(encryptedText, encryptionSalt, encryptionAlgo);
     return decrpytedText;
 };
 /** Utility to get sdk universal salt **/
 voltmx.sdk.util.getSDKUniversalSalt = function() {
     var salt = voltmx.sdk.dataStore.getItem(voltmx.sdk.constants.CLIENT_SDK_UNIVERSAL_SALT);
     if (!voltmx.sdk.util.isNullOrEmptyString(salt)) {
         return salt;
     }
     salt = voltmx.license.generateUUID().toString();
     voltmx.sdk.dataStore.setItem(voltmx.sdk.constants.CLIENT_SDK_UNIVERSAL_SALT, salt);
     return salt;
 };
 /**
  * Utility function to manage sdk meta data for login in same window
  */
 voltmx.sdk.util.getMetaDataManagerForLoginInSameWindow = (function() {
     var utilityObject = null;

     function MetaDataManager() {
         var metaData = null;
         var networkProvider = null;
         /**
          * This function returns Middleware endpoint for saving and retrieve values in cookie
          * @return {*}
          */
         function getClientStateEndpoint() {
             var mainRef = voltmxRef.mainRef;
             var middlewareServerUrl = mainRef.config.reportingsvc.session.split("/IST")[0];
             return middlewareServerUrl + voltmx.sdk.constants.APP_VERIFIER_MW_STORE_ENDPOINT;
         }
         /**
          * This method sets given value to current object of utility against given key
          * @param key
          * @param value
          */
         this.setItem = function(key, value) {
                 voltmx.sdk.logsdk.info("setting value for MetaDataManagerForLoginInSameWindow for key-" + key);
                 metaData.set(key, value);
             }
             /**
              * This method returns corresponding value for given key
              * @param key
              * @returns {any}
              */
         this.getItem = function(key) {
                 voltmx.sdk.logsdk.info("getting value for MetaDataManagerForLoginInSameWindow for key-" + key);
                 return metaData.get(key);
             }
             /**
              * This method retrieves app verifier at Middleware as sdk/browser being a public client should not store locally
              * successCallback will be called with app verifier body json if call gets passed ,otherwise failureCallback with error.
              * @param successCallback
              * @param failureCallback
              */
         this.retrieveAppVerifier = function(successCallback, failureCallback) {
                 voltmx.sdk.logsdk.info("Entering retrieveAppVerifier");
                 voltmx.sdk.claimsRefresh(_getCodeVerifier, failureCallback);

                 function _getCodeVerifier() {
                     voltmx.sdk.logsdk.info("getCodeVerifier's claims passed");
                     var middlewareStateUrl = getClientStateEndpoint();
                     var headers = {};
                     headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
                     headers[voltmx.sdk.constants.APP_KEY_HEADER] = voltmxRef.mainRef.appKey;
                     headers[voltmx.sdk.constants.APP_SECRET_HEADER] = voltmxRef.mainRef.appSecret;
                     var networkOptions = {};
                     networkOptions.xmlHttpRequestOptions = {};
                     networkOptions.xmlHttpRequestOptions.enableWithCredentials = true;
                     networkOptions[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
                     networkProvider.get(middlewareStateUrl, null, headers, function(response) {
                         voltmx.sdk.logsdk.info("Exiting retrieveAppVerifier with success");
                         voltmx.sdk.verifyAndCallClosure(successCallback, response);
                     }, function(err) {
                         voltmx.sdk.logsdk.error("unable to save the app verifier at middleware " + middlewareStateUrl + " , due to " + err.message);
                         var errorObject = voltmx.sdk.error.getSingleWindowLoginErrObj(voltmx.sdk.errorcodes.app_verifier_retrieve_failed, voltmx.sdk.errormessages.app_verifier_retrieve_failed);
                         voltmx.sdk.verifyAndCallClosure(failureCallback, errorObject);
                     }, null, networkOptions);
                 }
             }
             /**
              * This method saves app verifier at Middleware as sdk/browser being a public client should not store locally
              * successCallback will be called if call gets passed ,otherwise failureCallback with error.
              * @param appVerifierJSON
              * @param successCallback
              * @param failureCallback
              */
         this.saveAppVerifier = function(appVerifierJSON, successCallback, failureCallback) {
                 voltmx.sdk.logsdk.info("Entering saveAppVerifier");
                 voltmx.sdk.claimsRefresh(_saveAppVerifier, failureCallback);

                 function _saveAppVerifier() {
                     voltmx.sdk.logsdk.info("saveAppVerifier's claims passed");
                     var middlewareStateUrl = getClientStateEndpoint();
                     var headers = {};
                     headers[voltmx.sdk.constants.KONY_AUTHORIZATION_HEADER] = voltmxRef.currentClaimToken;
                     headers[voltmx.sdk.constants.APP_KEY_HEADER] = voltmxRef.mainRef.appKey;
                     headers[voltmx.sdk.constants.APP_SECRET_HEADER] = voltmxRef.mainRef.appSecret;
                     var networkOptions = {};
                     networkOptions.xmlHttpRequestOptions = {};
                     networkOptions.xmlHttpRequestOptions.enableWithCredentials = true;
                     networkOptions[voltmx.sdk.constants.IGNORE_MESSAGE_INTEGRITY] = true;
                     networkProvider.post(middlewareStateUrl, appVerifierJSON, headers, function(response) {
                         voltmx.sdk.logsdk.info("Exiting saveAppVerifier with success");
                         voltmx.sdk.verifyAndCallClosure(successCallback, response);
                     }, function(err) {
                         voltmx.sdk.logsdk.error("unable to save the app verifier at middleware " + middlewareStateUrl + " , due to " + err.message);
                         var errorObject = voltmx.sdk.error.getSingleWindowLoginErrObj(voltmx.sdk.errorcodes.app_verifier_save_failed, voltmx.sdk.errormessages.app_verifier_save_failed);
                         voltmx.sdk.verifyAndCallClosure(failureCallback, errorObject);
                     }, voltmx.sdk.constants.CONTENT_TYPE_JSON, networkOptions);
                 }
             }
             /**
              * This method stores all value in secured way
              */
         this.saveMetaData = function() {
                 voltmx.sdk.logsdk.info("saving data inside MetaDataManagerForLoginInSameWindow");
                 voltmx.sdk.dataStore.setSecureItem(voltmx.sdk.constants.KEY_METADATA_SDK_LOGIN_FOR_SAME_WINDOW, this.getMetadataJSON());
             }
             /**
              * This method returns all values of Map as JSON
              * @returns {JSON}
              */
         this.getMetadataJSON = function() {
                 voltmx.sdk.logsdk.info("getting value of MetaDataManagerForLoginInSameWindow in json format");
                 var metaJSON = {};
                 metaData.forEach(function(value, key) {
                     metaJSON[key] = value;
                 });
                 return metaJSON;
             }
             /**
              * This method retrieves and returns secured values stored and rehydrate the current util object
              * @returns {JSON}
              */
         this.loadSavedMetaData = function() {
                 if (voltmx.sdk.isNullOrUndefined(metaData) || metaData.size === 0) {
                     voltmx.sdk.logsdk.info("retrieving saved value of MetaDataManagerForLoginInSameWindow");
                     var metaJSON = voltmx.sdk.dataStore.getSecureItem(voltmx.sdk.constants.KEY_METADATA_SDK_LOGIN_FOR_SAME_WINDOW);
                     for (key in metaJSON) {
                         this.setItem(key, metaJSON[key]);
                     }
                 }
             }
             /**
              * This method removes stored values
              */
         this.removeSavedMetaData = function() {
                 voltmx.sdk.logsdk.info("removing saved value of MetaDataManagerForLoginInSameWindow");
                 voltmx.sdk.dataStore.removeItem(voltmx.sdk.constants.KEY_METADATA_SDK_LOGIN_FOR_SAME_WINDOW);
             }
             /**
              * This method initialize metaData object
              */
         this.initialize = function() {
                 if (voltmx.sdk.isNullOrUndefined(metaData) && voltmx.sdk.isNullOrUndefined(networkProvider)) {
                     voltmx.sdk.logsdk.info("initializing private variable of MetaDataManagerForLoginInSameWindow");
                     metaData = new Map();
                     networkProvider = new voltmxNetworkProvider();
                 }
             }
             /**
              * This method removes any stored secured values and make run time values null
              */
         this.destroy = function() {
             voltmx.sdk.logsdk.info("making internal variable null & removing saved state of MetaDataManagerForLoginInSameWindow");
             this.removeSavedMetaData();
             metaData = null;
             networkProvider = null;
         }
     }
     return function() {
         voltmx.sdk.logsdk.info("returning singleton instance of MetaDataManagerForLoginInSameWindow");
         if (voltmx.sdk.isNullOrUndefined(utilityObject)) {
             utilityObject = new MetaDataManager();
             Object.freeze(utilityObject);
         }
         return utilityObject;
     }
 })();
 var FileStorageClasses = null;
 // Initialization
 voltmx.sdk.FileStorageClasses.init = function() {
     if (FileStorageClasses == null) {
         FileStorageClasses = voltmx.sdk.FileStorageClasses.import();
     }
 };
 // Add token to headers
 voltmx.sdk.FileStorageClasses.addTokenToHeaders = function(headers, token) {
     if (headers === null || headers === undefined) {
         headers = {};
     }
     headers["X-Voltmx-Authorization"] = token;
     return headers;
 };
 // Converts HashMap to json
 voltmx.sdk.FileStorageClasses.createJSONObjectFromHashMap = function(hashMap, logPrefix) {
     if (!hashMap) {
         return null;
     }
     JavaClasses = voltmx.sdk.JavaClasses.import();
     gson = new JavaClasses.GsonBuilder().serializeNulls().create();
     records = gson.toJson(hashMap);
     voltmx.sdk.logsdk.debug(logPrefix + " : " + records);
     records = JSON.parse(records);
     return records;
 };
 // Converts json to HashMap
 voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject = function(json, logPrefix) {
         if (!json) {
             return null;
         }
         jsonString = JSON.stringify(json);
         voltmx.sdk.logsdk.debug(logPrefix + " : " + jsonString);
         JavaClasses = voltmx.sdk.JavaClasses.import();
         return new JavaClasses.Gson().fromJson(jsonString, JavaClasses.HashMap.class);
     }
     // Creates an instance of ISuccessCallback
 voltmx.sdk.FileStorageClasses.createISuccessCallback = function(successCallback, logMessage) {
     voltmx.sdk.FileStorageClasses.init();
     onSuccessMethod = function(res) {
         voltmx.sdk.logsdk.debug(logMessage);
         jsonObject = voltmx.sdk.FileStorageClasses.createJSONObjectFromHashMap(res, "Records");
         successCallback(jsonObject);
     };
     scb = new FileStorageClasses.SuccessCallback();
     scb.successCallback = onSuccessMethod;
     scb.successLog = "onSuccess";
     return scb;
 };
 // Creates an instance of IFailureCallback
 voltmx.sdk.FileStorageClasses.createIFailureCallback = function(failureCallback, logMessage) {
         voltmx.sdk.FileStorageClasses.init();
         onFailureMethod = function(err) {
             voltmx.sdk.logsdk.debug(logMessage);
             jsonObject = voltmx.sdk.FileStorageClasses.createJSONObjectFromHashMap(err, "Errors");
             failureCallback(jsonObject);
         }
         fcb = new FileStorageClasses.FailureCallback();
         fcb.failureCallback = onFailureMethod;
         fcb.failureLog = "onFailure";
         return fcb;
     }
     // List files
 voltmx.sdk.FileStorageClasses.listFiles = function(url, filter, headers, successCallback, failureCallback, options) {
     voltmx.sdk.FileStorageClasses.init();
     voltmx.sdk.logsdk.trace("Invoking list files");
     success = voltmx.sdk.FileStorageClasses.createISuccessCallback(successCallback, "listFiles: Execute Select Query records success");
     failure = voltmx.sdk.FileStorageClasses.createIFailureCallback(failureCallback, "listFiles: Execute Select Query records failed");
     voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
         voltmx.sdk.logsdk.info("listFiles : Refresh claims token SUCCESS");
         token = voltmx.sdk.getCurrentInstance().currentClaimToken;
         headers = voltmx.sdk.FileStorageClasses.addTokenToHeaders(headers, token);
         headersMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(headers, "headers");
         optionsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(options, "options");
         FileStorageClasses.BinaryFileStorageInterface.listFiles(url, filter, headersMap, success, failure, optionsMap);
     }.bind(this), function(error) { //claims refresh failure callback
         voltmx.sdk.logsdk.error("listFiles : Refresh claims token FAILED");
         failureCallback(error);
     });
 };
 // Uploads file
 voltmx.sdk.FileStorageClasses.upload = function(url, uploadInputType, uploadParams, successCallback, failureCallback, options) {
     voltmx.sdk.FileStorageClasses.init();
     voltmx.sdk.logsdk.trace("Invoking upload");
     success = voltmx.sdk.FileStorageClasses.createISuccessCallback(successCallback, "upload: Execute success");
     failure = voltmx.sdk.FileStorageClasses.createIFailureCallback(failureCallback, "upload: Execute failed");
     voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
         voltmx.sdk.logsdk.info("upload : Refresh claims token SUCCESS");
         token = voltmx.sdk.getCurrentInstance().currentClaimToken;
         headers = uploadParams["headers"];
         headers = voltmx.sdk.FileStorageClasses.addTokenToHeaders(headers, token);
         uploadParams["headers"] = headers;
         uploadMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(uploadParams, "UploadParams");
         optionsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(options, "options");
         FileStorageClasses.BinaryFileStorageInterface.uploadWithUrl(url, uploadInputType, uploadMap, success, failure, optionsMap);
     }.bind(this), function(error) { //claims refresh failure callback
         voltmx.sdk.logsdk.error("upload : Refresh claims token FAILED");
         failureCallback(error);
     });
 };
 // Downloads file
 voltmx.sdk.FileStorageClasses.download = function(url, downloadParams, successCallback, failureCallback, options) {
     voltmx.sdk.FileStorageClasses.init();
     voltmx.sdk.logsdk.trace("Invoking downloadFile");
     success = voltmx.sdk.FileStorageClasses.createISuccessCallback(successCallback, "downloadFile: Execute success");
     failure = voltmx.sdk.FileStorageClasses.createIFailureCallback(failureCallback, "downloadFile: Execute failed");
     voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
         voltmx.sdk.logsdk.info("downloadFile : Refresh claims token SUCCESS");
         token = voltmx.sdk.getCurrentInstance().currentClaimToken;
         headers = downloadParams["headers"];
         headers = voltmx.sdk.FileStorageClasses.addTokenToHeaders(headers, token);
         downloadParams["headers"] = headers;
         downloadMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(downloadParams, "DownloadParams");
         optionsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(options, "options");
         FileStorageClasses.BinaryFileStorageInterface.download(url, downloadMap, success, failure, optionsMap);
     }.bind(this), function(error) { //claims refresh failure callback
         voltmx.sdk.logsdk.error("upload : Refresh claims token FAILED");
         failureCallback(error);
     });
 };
 voltmx.sdk.FileStorageClasses.deleteById = function(url, fileId, deleteParams, headers, successCallback, failureCallback, options) {
     voltmx.sdk.FileStorageClasses.init();
     voltmx.sdk.logsdk.trace("Invoking deleteById");
     success = voltmx.sdk.FileStorageClasses.createISuccessCallback(successCallback, "deleteById: Execute success");
     failure = voltmx.sdk.FileStorageClasses.createIFailureCallback(failureCallback, "deleteById: Execute failed");
     voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
         voltmx.sdk.logsdk.info("deleteById : Refresh claims token SUCCESS");
         token = voltmx.sdk.getCurrentInstance().currentClaimToken;
         deleteParamsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(deleteParams, "deleteParams");
         headers = voltmx.sdk.FileStorageClasses.addTokenToHeaders(headers, token);
         headersMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(headers, "Headers");
         optionsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(options, "options");
         FileStorageClasses.BinaryFileStorageInterface.deleteById(url, fileId, deleteParamsMap, headersMap, success, failure, optionsMap);
     }.bind(this), function(error) { //claims refresh failure callback
         voltmx.sdk.logsdk.error("deleteById : Refresh claims token FAILED");
         failureCallback(error);
     });
 };
 voltmx.sdk.FileStorageClasses.deleteByCriteria = function(url, deleteParams, headers, successCallback, failureCallback, options) {
     voltmx.sdk.FileStorageClasses.init();
     voltmx.sdk.logsdk.trace("Invoking deleteByCriteria");
     success = voltmx.sdk.FileStorageClasses.createISuccessCallback(successCallback, "deleteByCriteria: Execute success");
     failure = voltmx.sdk.FileStorageClasses.createIFailureCallback(failureCallback, "deleteByCriteria: Execute failed");
     voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
         voltmx.sdk.logsdk.info("deleteByCriteria : Refresh claims token SUCCESS");
         token = voltmx.sdk.getCurrentInstance().currentClaimToken;
         deleteParamsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(deleteParams, "deleteParams");
         headers = voltmx.sdk.FileStorageClasses.addTokenToHeaders(headers, token);
         headersMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(headers, "Headers");
         optionsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(options, "options");
         FileStorageClasses.BinaryFileStorageInterface.deleteByCriteria(url, deleteParamsMap, headersMap, success, failure, optionsMap);
     }.bind(this), function(error) { //claims refresh failure callback
         voltmx.sdk.logsdk.error("deleteByCriteria : Refresh claims token FAILED");
         failureCallback(error);
     });
 };
 voltmx.sdk.FileStorageClasses.update = function(url, updateParams, successCallback, failureCallback, options) {
     voltmx.sdk.FileStorageClasses.init();
     voltmx.sdk.logsdk.trace("Invoking update");
     success = voltmx.sdk.FileStorageClasses.createISuccessCallback(successCallback, "update: Execute success");
     failure = voltmx.sdk.FileStorageClasses.createIFailureCallback(failureCallback, "update: Execute failed");
     voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
         voltmx.sdk.logsdk.info("update : Refresh claims token SUCCESS");
         token = voltmx.sdk.getCurrentInstance().currentClaimToken;
         headers = updateParams["headers"];
         headers = voltmx.sdk.FileStorageClasses.addTokenToHeaders(headers, token);
         updateParams["headers"] = headers;
         updateParamsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(updateParams, "updateParams");
         optionsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(options, "options");
         FileStorageClasses.BinaryFileStorageInterface.update(url, updateParamsMap, success, failure, optionsMap);
     }.bind(this), function(error) { //claims refresh failure callback
         voltmx.sdk.logsdk.error("deleteByCriteria : Refresh claims token FAILED");
         failureCallback(error);
     });
 };
 voltmx.sdk.FileStorageClasses.abort = function(url, fileId, abortParams, headers, successCallback, failureCallback, options) {
     voltmx.sdk.FileStorageClasses.init();
     voltmx.sdk.logsdk.trace("Invoking abort");
     success = voltmx.sdk.FileStorageClasses.createISuccessCallback(successCallback, "abort: Execute success");
     failure = voltmx.sdk.FileStorageClasses.createIFailureCallback(failureCallback, "abort: Execute failed");
     voltmx.sdk.claimsRefresh(function() { //claims refresh success callback
         voltmx.sdk.logsdk.info("abort : Refresh claims token SUCCESS");
         token = voltmx.sdk.getCurrentInstance().currentClaimToken;
         abortParamsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(abortParams, "abortParams");
         headers = voltmx.sdk.FileStorageClasses.addTokenToHeaders(headers, token);
         headersMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(headers, "Headers");
         optionsMap = voltmx.sdk.FileStorageClasses.createHashMapFromJSONObject(options, "options");
         FileStorageClasses.BinaryFileStorageInterface.abort(url, fileId, abortParamsMap, headersMap, success, failure, optionsMap);
     }.bind(this), function(error) { //claims refresh failure callback
         voltmx.sdk.logsdk.error("abort : Refresh claims token FAILED");
         failureCallback(error);
     });
 };