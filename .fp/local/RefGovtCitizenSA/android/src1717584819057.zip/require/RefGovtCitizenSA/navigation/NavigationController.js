define("RefGovtCitizenSA/navigation/NavigationController", {
    //Add your navigation controller code here.
});
