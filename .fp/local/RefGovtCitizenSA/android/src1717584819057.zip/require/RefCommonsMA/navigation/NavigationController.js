define("RefCommonsMA/navigation/NavigationController", {
    //Add your navigation controller code here.
});
